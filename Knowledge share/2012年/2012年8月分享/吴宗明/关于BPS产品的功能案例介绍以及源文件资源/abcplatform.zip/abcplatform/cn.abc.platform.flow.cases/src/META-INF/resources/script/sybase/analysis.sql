
if exists (select 1
            from  sysobjects
           where  id = object_id('WFKPIDEF')
            and   type = 'U')
   drop table WFKPIDEF
go

if exists (select 1
            from  sysobjects
           where  id = object_id('WFKPIDATA')
            and   type = 'U')
   drop table WFKPIDATA
go

if exists (select 1
            from  sysobjects
           where  id = object_id('WFKPIBOARDDEF')
            and   type = 'U')
   drop table WFKPIBOARDDEF
go

/*==============================================================*/
/* Table: WFKPIDEF                                              */
/*==============================================================*/
create table WFKPIDEF  (
   KPI_ID               numeric                        not null,
   KPI_CODE             VARCHAR(128)                   not null,
   KPI_NAME             VARCHAR(128)                   not null,
   KPI_DESC             VARCHAR(512),
   KPI_OWNER            VARCHAR(128)				   null,
   ORDER_ID             numeric,
   REMARK               VARCHAR(512)                   null,
   constraint PK_WFKPIDEF primary key (KPI_ID)
)
go

/*==============================================================*/
/* Table: WFKPIDATA                                             */
/*==============================================================*/
create table WFKPIDATA  (
   KPI_CODE             VARCHAR(128)                          not null,
   KPI_VALUE            numeric,
   REMARK               VARCHAR(512)						  null,
   constraint PK_WFKPIDATA primary key (KPI_CODE)
)
go

/*==============================================================*/
/* Table: WFKPIBOARDDEF                                         */
/*==============================================================*/
create table WFKPIBOARDDEF  (
   BOARD_ID             numeric                        not null,
   BOARD_NAME           VARCHAR(128)                   not null,
   CAL_UNIT             VARCHAR(16),
   KPI_ID               numeric,
   UP_VALUE             numeric,
   M1UP_VALUE           numeric,
   M1_COLOR             VARCHAR(16)					   null,
   M2UP_VALUE           numeric,
   M2_COLOR             VARCHAR(16)					   null,
   M3_COLOR             VARCHAR(16)					   null,
   BOTTOM_VALUE         numeric,
   ORDER_ID             numeric,
   REMARK               VARCHAR(512)				   null,
   constraint PK_WFKPIBOARDDEF primary key (BOARD_ID)
)
go

insert into WFKPIDEF(KPI_ID, KPI_CODE, KPI_NAME, KPI_DESC, KPI_OWNER, ORDER_ID, REMARK) values(0, 'cust_complaint', '�վ��ͻ�Ͷ�ߴ���', '�վ��ͻ�Ͷ�ߴ���', 'admin', 0, '�վ��ͻ�Ͷ�ߴ���' );

insert into WFKPIBOARDDEF(BOARD_ID, BOARD_NAME, CAL_UNIT, KPI_ID, BOTTOM_VALUE, M1UP_VALUE, M2UP_VALUE, UP_VALUE, ORDER_ID, REMARK) values(0, '�վ��ͻ�Ͷ�ߴ���', '����', 0, 0, 20, 50, 100, 0, '�վ��ͻ�Ͷ�ߴ���' );

insert into WFKPIDATA(KPI_CODE, KPI_VALUE, REMARK) values('cust_complaint', 28, '28��');

commit;