/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2011-1-2
 *******************************************************************************/


package cn.abc.platform.flow.cases;

import com.eos.workflow.api.BPSServiceClientFactory;
import com.eos.workflow.api.IBPSServiceClient;
import com.eos.workflow.api.impl.UddiAddress;
import com.eos.workflow.data.WFActivityInst;
import com.eos.workflow.data.WFProcessInst;
import com.primeton.workflow.api.WFServiceException;

public class Event {
	
	public void activityTimeOut(WFProcessInst processInst) {
		System.out.println("**************************************");
		System.out.println("ʵ�����Ϊ "+ processInst.getProcessInstID() +" �������ѳ�ʱ���뾡�������");
		System.out.println("**************************************");
	}
	
	public void activityBackEvent(WFProcessInst processInst, WFActivityInst activityInst) {
		System.out.println("**************************************");
		System.out.println("ʵ�����Ϊ "+ processInst.getProcessInstID() + " ��������ʵ�����Ϊ "+ activityInst.getActivityInstID() + " �Ļ���ˣ��Զ�����ҵ�񲹳��¼���");
		System.out.println("**************************************");
	}
	
	public void activityExecute(WFProcessInst processInst, WFActivityInst activityInst) throws Exception {
		if (true) {
			throw new Exception("��ɻʱ�����쳣��");
		}
	}
	
	public void activityCallBack(WFActivityInst activityInst) {
		IBPSServiceClient client = null;
		try {
			client = BPSServiceClientFactory.getDefaultClient();
			if (activityInst != null) {
				client.getBackActivityManager().backActivity(activityInst.getActivityInstID(), "manualActivity", "path");
			}			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void startProcess(WFProcessInst processInst) {
		final String LOGIC_NAME = "abcplatform";
		IBPSServiceClient client = null;
		try {
			UddiAddress config = new UddiAddress();
			config.setUddiHost("127.0.0.1");
			config.setUddiPort("9080");
			config.setUddiWebContext("abcplatform");
			client = BPSServiceClientFactory.getClient(config);
			BPSServiceClientFactory.getLoginManager().setCurrentUser("tiger", "000000");
			
			long processInstId = -1;
			processInstId = client.getProcessInstManager(LOGIC_NAME).createAndStartProcessInstance("cn.abc.platform.flow.demo.assessment", "Assessment", "�����ⲿ��������ʾ��");
			if (processInstId != -1) {
				client.getRelativeDataManager(LOGIC_NAME).setRelativeData(processInstId, "actor", processInst.getCreator());
				
				//����ⲿ���������ɹ������ⲿ����ʵ�����д�뵽�������̵����������
				IBPSServiceClient local = BPSServiceClientFactory.getDefaultClient();
				local.getRelativeDataManager().setRelativeData(processInst.getProcessInstID(), "sub1", String.valueOf(processInstId));
			}
		} catch (WFServiceException ex) {
			ex.printStackTrace();
		}
	}
}