/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2011-1-3
 *******************************************************************************/


package cn.abc.platform.flow.cases;

import com.eos.workflow.data.WFProcessInst;

public class Actor {

	public String setActivityActorByBiz(WFProcessInst processInst) {
		if (processInst != null) {
			return "fish";
		}
		
		return "tiger";
	}
}
