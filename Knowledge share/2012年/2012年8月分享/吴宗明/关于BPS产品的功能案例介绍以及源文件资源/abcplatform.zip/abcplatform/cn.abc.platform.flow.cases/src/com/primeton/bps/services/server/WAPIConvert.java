/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2010-12-29
 *******************************************************************************/


package com.primeton.bps.services.server;

import com.eos.workflow.data.WFActivityInst;
import com.eos.workflow.data.WFWorkItem;
import com.primeton.workflow.api.PageCond;

public class WAPIConvert {

	public static WAPIActivityInst[] ToolsWFActivityInstToArray(java.util.List<WFActivityInst> nacts) throws Exception {
		WAPIActivityInst acts[] = new WAPIActivityInst[nacts.size()];
		for (int i = 0; i<nacts.size();i++){
			WFActivityInst ai = (WFActivityInst)nacts.get(i);
			acts[i] = new WAPIActivityInst();
			acts[i].setActivityDefID(ai.getActivityDefID());
			acts[i].setActivityInstDesc(ai.getActivityInstDesc());
			acts[i].setActivityInstID(ai.getActivityInstID());
			acts[i].setActivityInstName(ai.getActivityInstName());
			acts[i].setActivityType(ai.getActivityType());
			acts[i].setCatalogName(ai.getCatalogName());
			acts[i].setCatalogUUID(ai.getCatalogUUID());
			acts[i].setCreateTime(ai.getCreateTime());
			acts[i].setCurrentState(ai.getCurrentState());
			acts[i].setEndTime(ai.getEndTime());
			acts[i].setPriority(ai.getPriority());
			acts[i].setProcessInstID(ai.getProcessInstID());
			acts[i].setRollbackFlag(ai.getRollbackFlag());
			acts[i].setStartTime(ai.getStartTime());
			acts[i].setSubProcessID(ai.getSubProcessID());
		}
		return acts;
	}
	
	public static WAPIWorkItem[] ToolsWFWorkItemToWAPIWorkItem(com.eos.workflow.helper.ResultList bpsl) throws Exception {
		WAPIWorkItem wis[] = new WAPIWorkItem[bpsl.size()];
		PageCond pg = bpsl.getPageCond();
		for (int i = 0; i<bpsl.size();i++){
			WFWorkItem wi = (WFWorkItem)bpsl.get(i);
			
			wis[i] = new WAPIWorkItem();
			
			wis[i].setActionMask(wi.getActionMask());
			wis[i].setActionURL(wi.getActionURL());
			wis[i].setActivityDefID(wi.getActivityDefID());
			wis[i].setActivityInstID(wi.getActivityInstID());
			wis[i].setActivityInstName(wi.getActivityInstName());
			wis[i].setAllowAgent(wi.getAllowAgent());
			wis[i].setAssistant(wi.getAssistant());
			wis[i].setAssistantName(wi.getAssistantName());
			wis[i].setBizState(wi.getBizState());
			wis[i].setCatalogName(wi.getCatalogName());
			wis[i].setCatalogUUID(wi.getCatalogUUID());
			wis[i].setCreateTime(wi.getCreateTime());
			wis[i].setCurrentState(wi.getCurrentState());
			wis[i].setEndTime(wi.getEndTime());
			wis[i].setFinalTime(wi.getFinalTime());
			wis[i].setIsTimeOut(wi.getIsTimeOut());
			wis[i].setLimitNum(wi.getLimitNum());
			wis[i].setLimitNumDesc(wi.getLimitNumDesc());
			wis[i].setParticipant(wi.getParticipant());
			wis[i].setPartiName(wi.getPartiName());
			wis[i].setPriority(wi.getPriority());
			wis[i].setProcessChName(wi.getProcessChName());
			wis[i].setProcessDefID(wi.getProcessDefID());
			wis[i].setProcessDefName(wi.getProcessDefName());
			wis[i].setProcessInstID(wi.getProcessInstID());
			wis[i].setProcessInstName(wi.getProcessInstName());
			wis[i].setRemindTime(wi.getRemindTime());
			wis[i].setRootProcInstID(wi.getRootProcInstID());
			wis[i].setStartTime(wi.getStartTime());
			wis[i].setStatesList(wi.getStatesList());
			wis[i].setTimeOutNum(wi.getTimeOutNum());
			wis[i].setTimeOutNumDesc(wi.getTimeOutNumDesc());
			wis[i].setUrlType(wi.getUrlType());
			wis[i].setWorkItemDesc(wi.getWorkItemDesc());
			wis[i].setWorkItemID(wi.getWorkItemID());
			wis[i].setWorkItemName(wi.getWorkItemName());
			wis[i].setWorkItemType(wi.getWorkItemType());

		}
		
		if (bpsl.size()>1) {
			wis[0].setBeginIndex(pg.getBeginIndex());
			wis[0].setBegin(pg.getBegin());
			wis[0].setLength(pg.getLength());
			wis[0].setIsCount(pg.getIsCount());
			wis[0].setCount(pg.getCount());
			wis[0].setTotalPage(pg.getTotalPage());
			wis[0].setCurrentPage(pg.getCurrentPage());
		}
		return wis;
	}
}
