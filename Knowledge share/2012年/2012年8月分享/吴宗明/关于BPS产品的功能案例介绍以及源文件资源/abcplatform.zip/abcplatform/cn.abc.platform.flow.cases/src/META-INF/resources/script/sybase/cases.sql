/*CREATE TABLES*/

if exists (select 1
            from  sysobjects
           where  id = object_id('OM_ORGANIZATION')
            and   type = 'U')
   drop table OM_ORGANIZATION
go

if exists (select 1
            from  sysobjects
           where  id = object_id('OM_POSITION')
            and   type = 'U')
   drop table OM_POSITION
go

if exists (select 1
            from  sysobjects
           where  id = object_id('OM_EMPLOYEE')
            and   type = 'U')
   drop table OM_EMPLOYEE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('OM_EMPORG')
            and   type = 'U')
   drop table OM_EMPORG
go

if exists (select 1
            from  sysobjects
           where  id = object_id('OM_EMPPOSITION')
            and   type = 'U')
   drop table OM_EMPPOSITION
go

if exists (select 1
            from  sysobjects
           where  id = object_id('AC_ROLE')
            and   type = 'U')
   drop table AC_ROLE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('AC_OPERATOR')
            and   type = 'U')
   drop table AC_OPERATOR
go

if exists (select 1
            from  sysobjects
           where  id = object_id('AC_OPERATORROLE')
            and   type = 'U')
   drop table AC_OPERATORROLE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('BIZ_TASKLIST')
            and   type = 'U')
   drop table BIZ_TASKLIST
go

/*==============================================================*/
/* Table: OM_ORGANIZATION                                       */
/*==============================================================*/
create table OM_ORGANIZATION (
   ORGID                numeric(10)          not null,
   ORGCODE              varchar(32)          not null,
   ORGNAME              varchar(64)          null,
   ORGLEVEL             numeric(2)           null,
   ORGDEGREE            varchar(255)         null,
   PARENTORGID          numeric(10)          null,
   ORGSEQ               varchar(512)         null,
   ORGTYPE              varchar(12)          null,
   ORGADDR              varchar(256)         null,
   ZIPCODE              varchar(10)          null,
   MANAPOSITION         numeric(10)          null,
   MANAGERID            numeric(10)          null,
   ORGMANAGER           varchar(128)         null,
   LINKMAN              varchar(30)          null,
   LINKTEL              varchar(20)          null,
   EMAIL                varchar(128)         null,
   WEBURL               varchar(512)         null,
   STARTDATE            datetime             null,
   ENDDATE              datetime             null,
   STATUS               varchar(255)         null,
   AREA                 varchar(30)          null,
   CREATETIME           datetime            null,
   LASTUPDATE           datetime             null,
   UPDATOR              numeric(10)          null,
   SORTNO               int                  null,
   ISLEAF               char(1)              null,
   SUBCOUNT             numeric(10)          null,
   REMARK               varchar(512)         null
)
go

alter table OM_ORGANIZATION
   add constraint P_ORGNIZATION primary key nonclustered (ORGID)
go

/*==============================================================*/
/* Table: OM_POSITION                                           */
/*==============================================================*/
create table OM_POSITION (
   POSITIONID           numeric(10)          not null,
   POSICODE             varchar(20)          null,
   POSINAME             varchar(128)         not null,
   POSILEVEL            numeric(2)           null,
   MANAPOSI             numeric(10)          null,
   DUTYID               numeric(10)          null,
   ORGID                numeric(10)          null,
   POSITIONSEQ          varchar(512)         not null,
   POSITYPE             varchar(255)         null,
   CREATETIME           datetime            null,
   LASTUPDATE           datetime             null,
   UPDATOR              numeric(10)          null,
   STARTDATE            datetime             null,
   ENDDATE              datetime             null,
   STATUS               varchar(255)         null,
   ISLEAF               char(1)              null,
   SUBCOUNT             numeric(10)          null
)
go

alter table OM_POSITION
   add constraint P_POSITION primary key nonclustered (POSITIONID)
go

/*==============================================================*/
/* Table: OM_EMPLOYEE                                           */
/*==============================================================*/
create table OM_EMPLOYEE (
   EMPID                numeric(10)          not null,
   EMPCODE              varchar(30)          null,
   OPERATORID           numeric(18)          null,
   USERID               varchar(30)          null,
   EMPNAME              varchar(50)          null,
   REALNAME             varchar(50)          null,
   GENDER               varchar(255)         null,
   BIRTHDATE            datetime             null,
   POSITION             numeric(10)          null,
   EMPSTATUS            varchar(255)         null,
   CARDTYPE             varchar(255)         null,
   CARDNO               varchar(20)          null,
   INDATE               datetime             null,
   OUTDATE              datetime             null,
   OTEL                 varchar(12)          null,
   OADDRESS             varchar(255)         null,
   OZIPCODE             varchar(10)          null,
   OEMAIL               varchar(128)         null,
   FAXNO                varchar(14)          null,
   MOBILENO             varchar(14)          null,
   MSN                  varchar(16)          null,
   HTEL                 varchar(12)          null,
   HADDRESS             varchar(128)         null,
   HZIPCODE             varchar(10)          null,
   PEMAIL               varchar(128)         null,
   PARTY                varchar(255)         null,
   DEGREE               varchar(255)         null,
   MAJOR                numeric(10)          null,
   SPECIALTY            varchar(1024)        null,
   WORKEXP              varchar(512)         null,
   REGDATE              datetime             null,
   CREATETIME           datetime            null,
   LASTMODYTIME         datetime             null,
   ORGIDLIST            varchar(128)         null,
   ORGID                numeric(10)          null,
   REMARK               varchar(512)         null
)
go

alter table OM_EMPLOYEE
   add constraint P_EMPLOYEE primary key nonclustered (EMPID)
go

/*==============================================================*/
/* Table: OM_EMPORG                                             */
/*==============================================================*/
create table OM_EMPORG (
   ORGID                numeric(10)          not null,
   EMPID                numeric(10)          not null,
   ISMAIN               char(1)              null
)
go

alter table OM_EMPORG
   add constraint PK_OM_EMPORG primary key nonclustered (ORGID, EMPID)
go

/*==============================================================*/
/* Table: OM_EMPPOSITION                                        */
/*==============================================================*/
create table OM_EMPPOSITION (
   POSITIONID           numeric(10)          not null,
   EMPID                numeric(10)          not null,
   ISMAIN               char(1)              null
)
go

alter table OM_EMPPOSITION
   add constraint PK_OM_EMPPOSITION primary key nonclustered (POSITIONID, EMPID)
go

/*==============================================================*/
/* Table: AC_ROLE                                               */
/*==============================================================*/
create table AC_ROLE (
   ROLEID               varchar(64)          not null,
   ROLENAME             varchar(64)          null,
   ROLETYPE             varchar(255)         null,
   ROLEDESC             varchar(256)         null,
   APPID                numeric(10)          null
)
go

alter table AC_ROLE
   add constraint P_ROLE primary key nonclustered (ROLEID)
go

/*==============================================================*/
/* Table: AC_OPERATOR                                           */
/*==============================================================*/
create table AC_OPERATOR (
   OPERATORID           numeric(18)          not null,
   USERID               varchar(64)          not null,
   PASSWORD             varchar(100)         null,
   INVALDATE            datetime             null,
   OPERATORNAME         varchar(64)          null,
   AUTHMODE             varchar(255)         null,
   STATUS               varchar(255)         null,
   UNLOCKTIME           datetime             null,
   MENUTYPE             varchar(255)         null,
   LASTLOGIN            datetime            null,
   ERRCOUNT             numeric(10)          null,
   STARTDATE            datetime             null,
   ENDDATE              datetime             null,
   VALIDTIME            varchar(255)         null,
   MACCODE              varchar(128)         null,
   IPADDRESS            varchar(128)         null,
   EMAIL                varchar(255)         null
)
go

alter table AC_OPERATOR
   add constraint P_OPERATOR primary key nonclustered (OPERATORID)
go

/*==============================================================*/
/* Table: AC_OPERATORROLE                                       */
/*==============================================================*/
create table AC_OPERATORROLE (
   OPERATORID           numeric(18)          not null,
   ROLEID               varchar(64)          not null,
   AUTH                 varchar(255)         null
)
go

alter table AC_OPERATORROLE
   add constraint PK_AC_OPERATORROLE primary key nonclustered (OPERATORID, ROLEID)
go

/*==============================================================*/
/* Table: BIZ_TASKLIST                                          */
/*==============================================================*/
create table BIZ_TASKLIST (
   BIZID           		numeric(18)          not null,
   TASKID				numeric(18)			 not null,
   TASKNAME             varchar(255)		 null,
   TASKTYPE				char(2)              not null,
   PROCESSINSTID        numeric(18)          not null,
   REMARK               varchar(255)         null
)
go

alter table BIZ_TASKLIST
   add constraint PK_BIZ_TASKLIST primary key nonclustered (BIZID)
go

/*INIT*/

-- ϵͳ����Ա --
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(1,'sysadmin','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'sysadmin','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sysadmin@localhost');
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(2,'tiger','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'Tiger','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'tiger@localhost');
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(3,'fish','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'Fish','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fish@localhost');
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(4,'kitty','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'Kitty','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'kitty@localhost');
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(5,'cheng','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'Cheng','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cheng@localhost');
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(6,'goose','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'Goose','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cheng@localhost');
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(7,'snoppy','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'Snoppy','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cheng@localhost');
INSERT INTO AC_OPERATOR (OPERATORID,USERID,PASSWORD,INVALDATE,OPERATORNAME,AUTHMODE,STATUS,UNLOCKTIME,MENUTYPE,LASTLOGIN,ERRCOUNT,STARTDATE,ENDDATE,VALIDTIME,MACCODE,IPADDRESS,EMAIL)
VALUES(8,'micky','ZwsUcorZkCrsujLiL6T2vQ==',NULL,'Micky','local','running',NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cheng@localhost');

-- Ĭ�Ͻ�ɫ  --
INSERT INTO AC_ROLE (ROLEID,ROLENAME,ROLETYPE,ROLEDESC,APPID ) VALUES ('eosadmin','ϵͳ����Ա','1',NULL,NULL);
INSERT INTO AC_ROLE (ROLEID,ROLENAME,ROLETYPE,ROLEDESC,APPID ) VALUES ('bpsadmin','���̹���Ա','1',NULL,1);
INSERT INTO AC_ROLE (ROLEID,ROLENAME,ROLETYPE,ROLEDESC,APPID ) VALUES ('role1','����','1',NULL,1);
INSERT INTO AC_ROLE (ROLEID,ROLENAME,ROLETYPE,ROLEDESC,APPID ) VALUES ('role2','����','1',NULL,1);
INSERT INTO AC_ROLE (ROLEID,ROLENAME,ROLETYPE,ROLEDESC,APPID ) VALUES ('role3','����','1',NULL,1);
INSERT INTO AC_ROLE (ROLEID,ROLENAME,ROLETYPE,ROLEDESC,APPID ) VALUES ('role4','�ܼ�','1',NULL,1);
INSERT INTO AC_ROLE (ROLEID,ROLENAME,ROLETYPE,ROLEDESC,APPID ) VALUES ('role5','����','1',NULL,1);

-- ����Ա��ɫ --
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (1,'eosadmin',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (1,'bpsadmin',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (2,'role1',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (2,'role2',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (3,'role1',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (4,'role3',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (5,'role4',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (6,'role1',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (7,'role2',NULL);
INSERT INTO AC_OPERATORROLE (OPERATORID,ROLEID,AUTH ) VALUES (8,'role2',NULL);
