/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2010-12-29
 *******************************************************************************/


package com.primeton.bps.services.server;

public class WAPIWorkItem {

	private long workItemID;
	
	private String workItemName;
	
	private String workItemType;
	
	private String workItemDesc;
	
	private int currentState;
	
	private String partiName;
	
	private  int priority;
	
	private String isTimeOut;
	
	private long limitNum;
	
	private String limitNumDesc;
	
	private String createTime;
	
	private String startTime;
	
	private String endTime;
	
	private String finalTime;
	
	private String remindTime;
	
	private  String actionURL;
	
	private  long processInstID;
	
	private  long activityInstID;
	
	private  String statesList;
	
	private  int timeOutNum;
	
	private String timeOutNumDesc;
	
	private String actionMask;
	
	private String processInstName;
	
	private  String activityInstName;
	
	private  long processDefID;
	
	private String processDefName;
	
	private String processChName;
	
	private String activityDefID;
	
	private String allowAgent;
	
	private int bizState;
	
	private String assistantName;
	
	private String urlType;
	
	private long rootProcInstID;
	
	private String participant;
	
	private String assistant;
	
	private String catalogUUID;
	
	private String catalogName;
	
	public String getActionMask() {
		return actionMask;
	}
	
	public void setActionMask(String actionMask) {
		this.actionMask = actionMask;
	}
	
	public String getActionURL() {
		return actionURL;
	}
	
	public void setActionURL(String actionURL) {
		this.actionURL = actionURL;
	}
	
	public String getActivityDefID() {
		return activityDefID;
	}
	
	public void setActivityDefID(String activityDefID) {
		this.activityDefID = activityDefID;
	}
	
	public long getActivityInstID() {
		return activityInstID;
	}
	
	public void setActivityInstID(long activityInstID) {
		this.activityInstID = activityInstID;
	}
	
	public String getActivityInstName() {
		return activityInstName;
	}
	
	public void setActivityInstName(String activityInstName) {
		this.activityInstName = activityInstName;
	}
	
	public String getAllowAgent() {
		return allowAgent;
	}
	
	public void setAllowAgent(String allowAgent) {
		this.allowAgent = allowAgent;
	}
	
	public String getAssistant() {
		return assistant;
	}
	
	public void setAssistant(String assistant) {
		this.assistant = assistant;
	}
	
	public String getAssistantName() {
		return assistantName;
	}
	
	public void setAssistantName(String assistantName) {
		this.assistantName = assistantName;
	}
	
	public int getBizState() {
		return bizState;
	}
	
	public void setBizState(int bizState) {
		this.bizState = bizState;
	}
	
	public String getCatalogName() {
		return catalogName;
	}
	
	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}
	
	public String getCatalogUUID() {
		return catalogUUID;
	}
	
	public void setCatalogUUID(String catalogUUID) {
		this.catalogUUID = catalogUUID;
	}
	
	public String getCreateTime() {
		return createTime;
	}
	
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
	public int getCurrentState() {
		return currentState;
	}
	
	public void setCurrentState(int currentState) {
		this.currentState = currentState;
	}
	
	public String getEndTime() {
		return endTime;
	}
	
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public String getFinalTime() {
		return finalTime;
	}
	
	public void setFinalTime(String finalTime) {
		this.finalTime = finalTime;
	}
	
	public String getIsTimeOut() {
		return isTimeOut;
	}
	
	public void setIsTimeOut(String isTimeOut) {
		this.isTimeOut = isTimeOut;
	}
	
	public long getLimitNum() {
		return limitNum;
	}
	
	public void setLimitNum(long limitNum) {
		this.limitNum = limitNum;
	}
	
	public String getLimitNumDesc() {
		return limitNumDesc;
	}
	
	public void setLimitNumDesc(String limitNumDesc) {
		this.limitNumDesc = limitNumDesc;
	}
	
	public String getParticipant() {
		return participant;
	}
	
	public void setParticipant(String participant) {
		this.participant = participant;
	}
	
	public String getPartiName() {
		return partiName;
	}
	
	public void setPartiName(String partiName) {
		this.partiName = partiName;
	}
	
	public int getPriority() {
		return priority;
	}
	
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	public String getProcessChName() {
		return processChName;
	}
	
	public void setProcessChName(String processChName) {
		this.processChName = processChName;
	}
	
	public long getProcessDefID() {
		return processDefID;
	}
	
	public void setProcessDefID(long processDefID) {
		this.processDefID = processDefID;
	}
	
	public String getProcessDefName() {
		return processDefName;
	}
	
	public void setProcessDefName(String processDefName) {
		this.processDefName = processDefName;
	}
	
	public long getProcessInstID() {
		return processInstID;
	}
	
	public void setProcessInstID(long processInstID) {
		this.processInstID = processInstID;
	}
	
	public String getProcessInstName() {
		return processInstName;
	}
	
	public void setProcessInstName(String processInstName) {
		this.processInstName = processInstName;
	}
	
	public String getRemindTime() {
		return remindTime;
	}
	
	public void setRemindTime(String remindTime) {
		this.remindTime = remindTime;
	}
	
	public long getRootProcInstID() {
		return rootProcInstID;
	}
	
	public void setRootProcInstID(long rootProcInstID) {
		this.rootProcInstID = rootProcInstID;
	}
	
	public String getStartTime() {
		return startTime;
	}
	
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	
	public String getStatesList() {
		return statesList;
	}
	
	public void setStatesList(String statesList) {
		this.statesList = statesList;
	}
	
	public int getTimeOutNum() {
		return timeOutNum;
	}
	
	public void setTimeOutNum(int timeOutNum) {
		this.timeOutNum = timeOutNum;
	}
	
	public String getTimeOutNumDesc() {
		return timeOutNumDesc;
	}
	
	public void setTimeOutNumDesc(String timeOutNumDesc) {
		this.timeOutNumDesc = timeOutNumDesc;
	}
	
	public String getUrlType() {
		return urlType;
	}
	
	public void setUrlType(String urlType) {
		this.urlType = urlType;
	}
	
	public String getWorkItemDesc() {
		return workItemDesc;
	}
	
	public void setWorkItemDesc(String workItemDesc) {
		this.workItemDesc = workItemDesc;
	}
	
	public long getWorkItemID() {
		return workItemID;
	}
	
	public void setWorkItemID(long workItemID) {
		this.workItemID = workItemID;
	}
	
	public String getWorkItemName() {
		return workItemName;
	}
	
	public void setWorkItemName(String workItemName) {
		this.workItemName = workItemName;
	}
	
	public String getWorkItemType() {
		return workItemType;
	}
	
	public void setWorkItemType(String workItemType) {
		this.workItemType = workItemType;
	}
	
    private int beginIndex;
    
    private int begin;
    
    private int length;
    
    private boolean isCount;
    
    private int count;
    
    private int totalPage;
    
    private int currentPage;
    
	public boolean getIsCount() {
		return isCount;
	}
	
	public void setIsCount(boolean isCount) {
		this.isCount = isCount;
	}
	
	public int getBegin() {
		return begin;
	}
	
	public void setBegin(int begin) {
		this.begin = begin;
	}
	
	public int getBeginIndex() {
		return beginIndex;
	}
	
	public void setBeginIndex(int beginIndex) {
		this.beginIndex = beginIndex;
	}
	
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}
	
	public int getCurrentPage() {
		return currentPage;
	}
	
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	
	public int getLength() {
		return length;
	}
	
	public void setLength(int length) {
		this.length = length;
	}
	
	public int getTotalPage() {
		return totalPage;
	}
	
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
}
