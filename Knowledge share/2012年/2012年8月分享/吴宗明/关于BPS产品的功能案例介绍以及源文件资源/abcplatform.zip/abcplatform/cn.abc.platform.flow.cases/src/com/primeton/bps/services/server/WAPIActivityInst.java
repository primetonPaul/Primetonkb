/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2010-12-29
 *******************************************************************************/


package com.primeton.bps.services.server;

public class WAPIActivityInst {

	private  long activityInstID;
	
	private  String activityInstName;
	
	private  String activityInstDesc;
	
	private  String activityType;
	
	private  int currentState;
	
	private  int priority;
	
	private  String createTime;
	
	private  String startTime;
	
	private  String endTime;
	
	private  long subProcessID;
	
	private  String activityDefID;
	
	private  long processInstID;
	
	private  String rollbackFlag;
	
	private  String catalogUUID;
	
	private  String catalogName;
	
	public String getActivityDefID() {
		return activityDefID;
	}
	
	public void setActivityDefID(String activityDefID) {
		this.activityDefID = activityDefID;
	}
	
	public String getActivityInstDesc() {
		return activityInstDesc;
	}
	
	public void setActivityInstDesc(String activityInstDesc) {
		this.activityInstDesc = activityInstDesc;
	}
	
	public long getActivityInstID() {
		return activityInstID;
	}
	
	public void setActivityInstID(long activityInstID) {
		this.activityInstID = activityInstID;
	}
	
	public String getActivityInstName() {
		return activityInstName;
	}
	
	public void setActivityInstName(String activityInstName) {
		this.activityInstName = activityInstName;
	}
	
	public String getActivityType() {
		return activityType;
	}
	
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	
	public String getCatalogName() {
		return catalogName;
	}
	
	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}
	
	public String getCatalogUUID() {
		return catalogUUID;
	}
	
	public void setCatalogUUID(String catalogUUID) {
		this.catalogUUID = catalogUUID;
	}
	
	public String getCreateTime() {
		return createTime;
	}
	
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
	public int getCurrentState() {
		return currentState;
	}
	
	public void setCurrentState(int currentState) {
		this.currentState = currentState;
	}
	
	public String getEndTime() {
		return endTime;
	}
	
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public int getPriority() {
		return priority;
	}
	
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	public long getProcessInstID() {
		return processInstID;
	}
	
	public void setProcessInstID(long processInstID) {
		this.processInstID = processInstID;
	}
	
	public String getRollbackFlag() {
		return rollbackFlag;
	}
	
	public void setRollbackFlag(String rollbackFlag) {
		this.rollbackFlag = rollbackFlag;
	}
	
	public String getStartTime() {
		return startTime;
	}
	
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	
	public long getSubProcessID() {
		return subProcessID;
	}
	
	public void setSubProcessID(long subProcessID) {
		this.subProcessID = subProcessID;
	}
}
