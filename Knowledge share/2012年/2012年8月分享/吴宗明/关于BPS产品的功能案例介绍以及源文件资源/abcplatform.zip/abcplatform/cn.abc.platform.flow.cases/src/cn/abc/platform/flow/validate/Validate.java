/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2010 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2011-1-7
 *******************************************************************************/


package cn.abc.platform.flow.validate;

public class Validate {
	
	public boolean authentication(String userId, String password) {
		System.out.println("************************************************************\r\n");
		System.out.print("��ʼ����Զ�̷������������֤��");
		if (userId != null && password != null) {
			System.out.println("��ͨ������У�飬��Ȩ���з��ʡ�\r\n");
			System.out.println("************************************************************");
			return true;
		}
		System.out.println("δͨ������У�飬�ܾ����ʡ�\r\n");
		System.out.println("************************************************************");
		return false;
	}
}
