/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2011-1-5
 *******************************************************************************/


package cn.abc.platform.flow.om;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.eos.common.connection.ConnectionHelper;
import com.eos.das.sql.INamedSqlSession;
import com.eos.das.sql.NamedSqlSessionFactory;
import com.eos.system.exception.EOSRuntimeException;
import com.eos.workflow.omservice.IWFOMService;
import com.eos.workflow.omservice.WFParticipant;
import com.primeton.workflow.api.PageCond;
import com.primeton.workflow.api.ParticipantType;

public class WFOMServiceImpl implements IWFOMService {

	private static WFOMServiceImpl instance = null;
	
	public static final String PARTICIPANT_TYPE_PERSON = "person"; //��Ա
	public static final String PARTICIPANT_TYPE_ROLE = "part"; //��ɫ
	public static final String PARTICIPANT_TYPE_ORGANIZATION = "organ";//����
	public static final String PARTICIPANT_TYPE_POSITION = "post";//��λ
	
    //�ӿ�ʵ�ֵ�����sql����
	private static String NAMESQL_PACKAGE = "cn.abc.platform.flow.cases.process.";
	//��ȡ����Դ�Ĺ�����
	private static String CONTRIBUTION_NAME = "cn.abc.platform.flow.cases";
	//ȱʡ����Դ����
	private static String DATASOURCE = "default";
	
	//�����������б�
	public static Map<String, ParticipantType> participantTypes = new HashMap<String, ParticipantType>();
	
	public WFOMServiceImpl() {
		init();
	}
	
	public static synchronized WFOMServiceImpl getInstance() {
		if (instance == null) {
			instance = new WFOMServiceImpl();
		}
		return instance;
	}
	
	/*
	 * ����ID�����ͻ�ȡ��Ӧ������
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#findParticipantByID(java.lang.String, java.lang.String)
	 */
	public WFParticipant findParticipantByID(String typeCode, String participantID) {
		ParticipantType partType = participantTypes.get(typeCode);
		if (partType == null) {
			return null;
		}
		
		WFParticipant participant = null;
		Connection conn = getConnection();
		INamedSqlSession session = NamedSqlSessionFactory.createSQLMapSession(conn);
		try {
			
			List<WFParticipant> list = new ArrayList<WFParticipant>();
			if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				list = queryNamedSql(session, "query_organization", parameterMap);
			} else if (PARTICIPANT_TYPE_ROLE.equalsIgnoreCase(typeCode)) {
				Map<String, String> parameterMap = new HashMap<String, String>();
				parameterMap.put("id", participantID);
				list = queryNamedSql(session, "query_role", parameterMap);
			} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(typeCode)) {//��λ
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				list = queryNamedSql(session, "query_position", parameterMap);
			} else if (PARTICIPANT_TYPE_PERSON.equalsIgnoreCase(typeCode)) {//����
				Map<String, String> parameterMap = new HashMap<String, String>();
				parameterMap.put("id", participantID);
				list = queryNamedSql(session, "query_person", parameterMap);
			}
			if (list != null && list.size() > 0) {
				participant = list.get(0);
				participant.setTypeCode(typeCode);
				participant.setId(participantID);
			}
		} finally {
			closeSession(session, conn);
		}		
		return participant;
	}

	/*
	 * ��ȡĳ�����͵ĸ�������
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#findRootParticipants(java.lang.String)
	 */
	public List<WFParticipant> findRootParticipants(String typeCode) {
		ParticipantType partType = participantTypes.get(typeCode);
		if (partType == null || !partType.isShowAtRootArea()) {
			return new ArrayList<WFParticipant>();
		}
		
		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		
		Connection conn = getConnection();
		INamedSqlSession session = NamedSqlSessionFactory.createSQLMapSession(conn);
		try {
			if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(typeCode)) {
				wfParticipants = queryNamedSql(session, "query_rootorganizations", null);
			} else if (PARTICIPANT_TYPE_ROLE.equalsIgnoreCase(typeCode)) {
				wfParticipants = queryNamedSql(session, "query_rootroles", null);
			} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(typeCode)) {
				wfParticipants = queryNamedSql(session, "query_rootpositions", null);
			} else {
				wfParticipants = new ArrayList<WFParticipant>();
			}
		} finally {
			closeSession(session, conn);
		}		
		
		return wfParticipants;
	}

	/*
	 * ��ѯ�����¼������ߡ�����ָ���Ĳ����ߣ��÷�����Ҫ���ظò����ߵĸ��ֲ�ͬ���͵��Ӳ�����
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getAllChildParticipants(java.lang.String, java.lang.String)
	 */
	public List<WFParticipant> getAllChildParticipants(String typeCode, String participantID) {
		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		
		Connection conn = getConnection();
		INamedSqlSession session = NamedSqlSessionFactory.createSQLMapSession(conn);
		try {
			if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				wfParticipants = queryNamedSql(session, "query_allorgsub", parameterMap);
			} else if (PARTICIPANT_TYPE_ROLE.equalsIgnoreCase(typeCode)) {
				Map<String, String> parameterMap = new HashMap<String, String>();
				parameterMap.put("id", participantID);
				wfParticipants = queryNamedSql(session, "query_allrolesub", parameterMap);
			} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				wfParticipants = queryNamedSql(session, "query_allpositionsub", parameterMap);
			}
		} finally {
			closeSession(session, conn);
		}	
		return wfParticipants;
	}

	/*
	 * ��ѯ���е��ϼ������ߡ���ʵ�ֵ�ʱ��Ӧ�ý�ָ�������ߵ����и������߲�ѯ������������
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getAllParentParticipants(java.lang.String, java.lang.String)
	 */
	public List<WFParticipant> getAllParentParticipants(String typeCode, String participantID) {
		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		
		Connection conn = getConnection();
		INamedSqlSession session = NamedSqlSessionFactory.createSQLMapSession(conn);
		try {
			if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				wfParticipants = queryNamedSql(session, "query_allorgparents", parameterMap);
			} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				wfParticipants = queryNamedSql(session, "query_allpositionparents", parameterMap);
			} else if (PARTICIPANT_TYPE_PERSON.equalsIgnoreCase(typeCode)) {
				Map<String, String> parameterMap = new HashMap<String, String>();
				parameterMap.put("id", participantID);
				wfParticipants = queryNamedSql(session, "query_allpersonparents", parameterMap);
				wfParticipants.addAll(queryNamedSql(session, "query_allpersonparents1", parameterMap));
			} else {
				wfParticipants = null;
			}
		} finally {
			closeSession(session, conn);
		}		
		return wfParticipants;
	}

	/*
	 * ��ѯ�����ߵ�ĳ��ָ�����͵��Ӳ�����
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getChildParticipants(java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<WFParticipant> getChildParticipants(String typeCode, String participantID, String childCode) {
		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		
		Connection conn = getConnection();
		INamedSqlSession session = NamedSqlSessionFactory.createSQLMapSession(conn);
		try {
			if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(childCode)) {
					wfParticipants = queryNamedSql(session, "query_orgsuborg", parameterMap);
				} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(childCode)) {
					wfParticipants = queryNamedSql(session, "query_orgsubpost", parameterMap);
				} else if (PARTICIPANT_TYPE_PERSON.equalsIgnoreCase(childCode)) {
					wfParticipants = queryNamedSql(session, "query_orgsubperson", parameterMap);
				}
			} else if (PARTICIPANT_TYPE_ROLE.equalsIgnoreCase(typeCode)) {
				Map<String, String> parameterMap = new HashMap<String, String>();
				parameterMap.put("id", participantID);
				if (PARTICIPANT_TYPE_PERSON.equalsIgnoreCase(childCode)) {
					wfParticipants = queryNamedSql(session, "query_allrolesub", parameterMap);
				}
			} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(childCode)) {
					wfParticipants = queryNamedSql(session, "query_positionsubpost", parameterMap);
				} else if (PARTICIPANT_TYPE_PERSON.equalsIgnoreCase(childCode)) {
					wfParticipants = queryNamedSql(session, "query_positionsubperson", parameterMap);
				}
			} else {
				wfParticipants = null;
			}
		} finally {
			closeSession(session, conn);
		}		
		return wfParticipants;
	}

	/*
	 * ��������
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getJointChildParticipant(java.lang.String, java.util.List)
	 */
	public List<WFParticipant> getJointChildParticipant(String typeCode, List<String> jointType) {
		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		return wfParticipants;
	}

	/*
	 * ��ѯĳ�������ߵ�ָ�����͵ĸ�������
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getParentParticipants(java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<WFParticipant> getParentParticipants(String typeCode, String participantID, String parentCode) {
		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		
		Connection conn = getConnection();
		INamedSqlSession session = NamedSqlSessionFactory.createSQLMapSession(conn);
		try {
			if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(typeCode)) {
				Map<String, Integer> parameterMap = new HashMap<String, Integer>();
				parameterMap.put("id", new Integer(participantID));
				if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(parentCode)) {
					wfParticipants = queryNamedSql(session, "query_orgparentsorg", parameterMap);
				}
			} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(typeCode)) {
				Map<String, String> parameterMap = new HashMap<String, String>();
				parameterMap.put("id", participantID);
				if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(parentCode)) {
				     wfParticipants = queryNamedSql(session, "query_positionparentsorg", parameterMap);
				} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(parentCode)){
					wfParticipants = queryNamedSql(session, "query_positionparentspost", parameterMap);
				}
			} else if (PARTICIPANT_TYPE_PERSON.equalsIgnoreCase(typeCode)) {
				Map<String, String> parameterMap = new HashMap<String, String>();
				parameterMap.put("id", participantID);
				if (PARTICIPANT_TYPE_ORGANIZATION.equalsIgnoreCase(parentCode)) {
					wfParticipants = queryNamedSql(session, "query_personparentsorg", parameterMap);
				} else if (PARTICIPANT_TYPE_POSITION.equalsIgnoreCase(parentCode)) {
					wfParticipants = queryNamedSql(session, "query_personparentspost", parameterMap);
				} else if (PARTICIPANT_TYPE_ROLE.equalsIgnoreCase(parentCode)) {
					wfParticipants = queryNamedSql(session, "query_personparentsrole", parameterMap);
				}
			} else {
				wfParticipants = null;
			}
		} finally {
			closeSession(session, conn);
		}		
		return wfParticipants;
	}

	/*
	 * ��ȡĳ�������ߵĲ��뷶Χ
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getParticipantScope(java.lang.String, java.lang.String)
	 */
	public List<WFParticipant> getParticipantScope(String typeCode, String participantID) {
		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		
		Connection conn = getConnection();
		INamedSqlSession session = NamedSqlSessionFactory.createSQLMapSession(conn);
		try {
			if (PARTICIPANT_TYPE_PERSON.equalsIgnoreCase(typeCode)) {
				WFParticipant self = findParticipantByID("person", participantID);
				if (self != null) {
					wfParticipants.add(self);//���ȼ����Լ�
					Map<String, String> parameterMap = new HashMap<String, String>();
					parameterMap.put("id", participantID);
                    //���μ�����Ա������������λ����ɫ�б�
					wfParticipants.addAll(queryNamedSql(session, "query_personscopeorg", parameterMap));
					wfParticipants.addAll(queryNamedSql(session, "query_personscopepost", parameterMap));
					wfParticipants.addAll(queryNamedSql(session, "query_personscoperole", parameterMap));

					getIterativeParent(wfParticipants, participantID, PARTICIPANT_TYPE_PERSON, PARTICIPANT_TYPE_ORGANIZATION);
				}
			}
		} finally {
			closeSession(session, conn);
		}		
		return wfParticipants;
	}

	/*
	 * ��ȡָ������������
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getParticipantType(java.lang.String)
	 */
	public ParticipantType getParticipantType(String typeCode) {
		return participantTypes.get(typeCode);
	}

	/*
	 * ��ȡ���еĲ��������ͣ��÷���ͨ���ڹ��캯���е��ã����Գ�ʼ�������������б�
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getParticipantTypes()
	 */
	public List<ParticipantType> getParticipantTypes() {
		List<ParticipantType> participantTypeList = null;

		if (participantTypes.size() > 0) {
			participantTypeList = new ArrayList<ParticipantType>();

			ParticipantType participantType = null;

			Set<String> participantTypeSets = participantTypes.keySet();
			Iterator<String> i = participantTypeSets.iterator();
			while (i.hasNext()) {
				participantType = participantTypes.get(i.next());
				participantTypeList.add(participantType);
			}
		}

		return participantTypeList;
	}

	/*
	 * ��ȡĳ�����͵����в�����
	 * 
	 * (non-Javadoc)
	 * @see com.eos.workflow.omservice.IWFOMService#getParticipants(java.lang.String, com.primeton.workflow.api.PageCond)
	 */
	public List<WFParticipant> getParticipants(String typeCode, PageCond page) {
		ParticipantType partType = participantTypes.get(typeCode);
		if (partType == null) {
			return null;
		}

		List<WFParticipant> wfParticipants = new ArrayList<WFParticipant>();
		return wfParticipants;
	}
	
	/**
	 * 
	 * ��ʼ������
	 *
	 */
	private void init() {
		//person  Ϊֱ�Ӳ����� 
		//��������
		//������ part,organ,post
		ParticipantType person = null;
		//prefix,code,displayname,description,showatroot,priority,isleaf,subparti,joinpart,joinparttype
		person = new ParticipantType('P', PARTICIPANT_TYPE_PERSON, "����", "����", false, 1, true, null, false, null);

		//part ��ɫ 
		//������Ϊ person
		//�޸�����
		ParticipantType role = null;
		List<String> roleChildParticipantTypeCodes = new ArrayList<String>();
		roleChildParticipantTypeCodes.add(PARTICIPANT_TYPE_PERSON);
		role = new ParticipantType('A', PARTICIPANT_TYPE_ROLE, "��ɫ", "��ɫ", true, 3, false, roleChildParticipantTypeCodes, false, null);

		//organ ���� 
		//������Ϊ person,organ,post
		//������Ϊ organ
		ParticipantType organization = null;
		List<String> organizationChildParticipantTypeCodes = new ArrayList<String>();
		organizationChildParticipantTypeCodes.add(PARTICIPANT_TYPE_PERSON);
		organizationChildParticipantTypeCodes.add(PARTICIPANT_TYPE_POSITION);
		organizationChildParticipantTypeCodes.add(PARTICIPANT_TYPE_ORGANIZATION);
		organization = new ParticipantType('B', PARTICIPANT_TYPE_ORGANIZATION, "����", "����", true, 4, false, organizationChildParticipantTypeCodes, false, null);

		//post ��λ 
		//������Ϊ person,post 
		//������Ϊ post,organ
		ParticipantType position = null;
		List<String> positionChildParticipantTypeCodes = new ArrayList<String>();
		positionChildParticipantTypeCodes.add(PARTICIPANT_TYPE_PERSON);
		positionChildParticipantTypeCodes.add(PARTICIPANT_TYPE_POSITION);
		position = new ParticipantType('C', PARTICIPANT_TYPE_POSITION, "��λ", "��λ", false, 2, false, positionChildParticipantTypeCodes, false, null);
		
		//������𼯺ϻ���
		participantTypes.put(PARTICIPANT_TYPE_PERSON, person);
		participantTypes.put(PARTICIPANT_TYPE_ROLE, role);
		participantTypes.put(PARTICIPANT_TYPE_ORGANIZATION, organization);
		participantTypes.put(PARTICIPANT_TYPE_POSITION, position);
	}
	
	private static Connection getConnection() {
		return getConnection(null);
	}
	
	/**
	 * �ӵ�ǰ��contribution�и�������Դ�ı���������ݿ����ӡ�
	 * 
	 * @param dsName ����Դ����
	 * @return ������ݿ�����
	 */
	private static Connection getConnection(String name) {
		if (name == null || name.trim().equals(""))
			name = DATASOURCE;

		return ConnectionHelper.getContributionConnection(CONTRIBUTION_NAME, name);
	}
	
	/**
	 * �ر�����sql��DAS session�����ݿ����ӡ�
	 * 
	 * @param session ���ݷ��ʻỰ����
	 * @param conn ���ݿ�����
	 */
	private static void closeSession(INamedSqlSession session, Connection conn) {
		if (session != null) {
			try {
				session.close();
			} catch (Exception ex) {
				throw new EOSRuntimeException("Close session failed!", ex);
			}
		}
		if (conn != null) {
			try {
				if (!conn.isClosed())
					conn.close();
			} catch (Exception ex) {
				throw new EOSRuntimeException("Close connection failed!", ex);
			}
		}
	}	
	
	@SuppressWarnings("unchecked")
	private static List<WFParticipant> queryNamedSql(INamedSqlSession session, String namedSqlId, Object param) {
		return session.queryForList(NAMESQL_PACKAGE + namedSqlId, param);
	}
	
	/**
	 * �ݹ��ѯ���ڵ�
	 */
	private void getIterativeParent(List<WFParticipant> wfParticipantParents, String participantID, String typeCode, String parentCode) {
		List<WFParticipant> wfParticipantParentTemps = null;

		wfParticipantParentTemps = getParentParticipants(typeCode, participantID, parentCode);
		int parentCount = wfParticipantParentTemps == null ? 0 : wfParticipantParentTemps.size();

		if (parentCount > 0) {
			for (int i = 0; i < parentCount; i++) {
				if (!wfParticipantParents.contains(wfParticipantParentTemps.get(i))) {
					wfParticipantParents.add(wfParticipantParentTemps.get(i));
				}
				getIterativeParent(wfParticipantParents, wfParticipantParentTemps.get(i).getId(), wfParticipantParentTemps.get(i).getTypeCode(), parentCode);
			}
		}
	}
}
