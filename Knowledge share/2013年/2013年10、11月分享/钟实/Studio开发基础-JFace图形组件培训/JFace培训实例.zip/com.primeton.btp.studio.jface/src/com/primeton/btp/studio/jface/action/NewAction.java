/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��19��
 *******************************************************************************/


package com.primeton.btp.studio.jface.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.ImageData;

import com.primeton.btp.studio.jface.window.ApplicationWindowExample;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class NewAction extends Action {
	/**
	 * 
	 */
	public NewAction() {
		super();
		setText("�½�(&N)");
		this.setAccelerator(SWT.ALT+SWT.SHIFT+'N');
		this.setToolTipText("�½�");
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.action.Action#run()
	 */
	@Override
	public void run() {
		ApplicationWindowExample.status.setMessage("��ʼ�½��ļ�");
	}
}

/*
 * �޸���ʷ
 * $Log$ 
 */