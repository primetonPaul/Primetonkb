/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��20��
 *******************************************************************************/


package com.primeton.btp.studio.jface.table;

import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.Item;

import com.primeton.btp.studio.jface.tree.PersonEO;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class TableCellModifier implements ICellModifier{
	
	private TableViewer table;
	
	/**
	 * 
	 */
	public TableCellModifier(TableViewer table) {
		this.table = table;
	}
	
	//�������Ϊ��һ�У����ò����޸�
	public boolean canModify(Object element, String property) {
		if ( property.equals(TableWindow.COLUMN_NAME[0]))
			return false;
		return true;
	}
	//�����ڱ༭״̬ʱ����ʾ��ֵ
	public Object getValue(Object element, String property) {
		PersonEO p = (PersonEO) element;
		if ( property.equals(TableWindow.COLUMN_NAME[1]))
			return p.getName();
		else if ( property.equals(TableWindow.COLUMN_NAME[2]))
			return p.getGender();
		else if ( property.equals(TableWindow.COLUMN_NAME[3]))
			return p.getColor();
		return null;
	}
	//���޸ĺ����ø�������
	public void modify(Object element, String property, Object value) {
		if (element instanceof Item) 
			element = ((Item) element).getData();
		PersonEO p = (PersonEO) element;
		if ( property.equals(TableWindow.COLUMN_NAME[1]))
			p.setName( (String)value );
		else if ( property.equals(TableWindow.COLUMN_NAME[2]))
			p.setGender( (String)value );
		else if ( property.equals(TableWindow.COLUMN_NAME[3]))
			p.setColor( (String)value );
		//ˢ�±���
		table.refresh();
	}
	
}

/*
 * �޸���ʷ
 * $Log$ 
 */