/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��19��
 *******************************************************************************/


package com.primeton.btp.studio.jface.wizard;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class JFaceImageRegistry {
	
	private static JFaceImageRegistry  INSTANCE;
	
	private static ImageRegistry imageRegistry;
	
	public static JFaceImageRegistry getINSTANCE(){
		if(INSTANCE == null){
			INSTANCE = new JFaceImageRegistry();
			initImageRegistry();
		}
		return INSTANCE;
	}

	/**
	 * 
	 */
	private static void initImageRegistry() {
		imageRegistry = new ImageRegistry();
		imageRegistry.put("file", ImageDescriptor.createFromFile(JFaceImageRegistry.class, "/icons/file.gif"));
		imageRegistry.put("folder", ImageDescriptor.createFromFile(JFaceImageRegistry.class, "/icons/folder.gif"));
		imageRegistry.put("topic",  ImageDescriptor.createFromFile(JFaceImageRegistry.class, "/icons/topic.gif"));
		imageRegistry.put("toc_closed",  ImageDescriptor.createFromFile(JFaceImageRegistry.class, "/icons/toc_closed.gif"));
		imageRegistry.put("toc_open",  ImageDescriptor.createFromFile(JFaceImageRegistry.class, "/icons/toc_open.gif"));
	}
	
	public ImageDescriptor getImageDescriptor(String imageKey){
		return imageRegistry.getDescriptor(imageKey);
	}
	
}

/*
 * �޸���ʷ
 * $Log$ 
 */