package com.primeton.btp.studio.jface.tree;

import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.graphics.Image;

import com.primeton.btp.studio.jface.wizard.JFaceImageRegistry;

public class TreeLabelProvider implements ILabelProvider{

	public Image getImage(Object element) {
		if ( element instanceof ProductEO)
			return JFaceImageRegistry.getINSTANCE().getImageDescriptor("topic").createImage();
		else if  ( element instanceof CategoryEO)
			return JFaceImageRegistry.getINSTANCE().getImageDescriptor("toc_closed").createImage();
		return null;
	}
	//��ʾ���ڵ������
	public String getText(Object element) {
		return ((TreeElement)element).getName();
	}
	public void addListener(ILabelProviderListener listener) {
		
	}
	public void dispose() {
		
	}
	public boolean isLabelProperty(Object element, String property) {
		return false;
	}

	public void removeListener(ILabelProviderListener listener) {
		
	}


}
