package com.primeton.btp.studio.jface.window;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

import com.primeton.btp.studio.jface.action.ExitAction;
import com.primeton.btp.studio.jface.action.NewAction;
import com.primeton.btp.studio.jface.action.OpenAction;
import com.primeton.btp.studio.jface.action.SaveAction;

/**
 * ApplicationWindowʾ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class ApplicationWindowExample extends ApplicationWindow {

	public static StatusLineManager status;
	
	private NewAction newA = new NewAction();
	private OpenAction openA = new OpenAction();
	private SaveAction saveA = new SaveAction();
	private ExitAction exitA =new ExitAction();
	
	public ApplicationWindowExample() {
		super(null);
		this.addMenuBar();
		this.addToolBar(SWT.FLAT);
		this.addStatusLine();
	}
	
	@Override
	protected MenuManager createMenuManager() {
		//�������˵�����
		MenuManager menuBar = new MenuManager();
		//���Ӳ˵���
		MenuManager fileMenu = new MenuManager("�ļ�(&F)");
		//���Ӳ˵���
		menuBar.add(fileMenu);
		fileMenu.add(newA);
		fileMenu.add(openA);
		fileMenu.add(saveA);
		fileMenu.add(new Separator());
		fileMenu.add(exitA);
		
		return menuBar;
	}
	
	@Override
	protected ToolBarManager createToolBarManager(int style) {
		ToolBarManager toolbar = new ToolBarManager(style);
		toolbar.add(newA);
		toolbar.add(new Separator());
		toolbar.add(openA);
		toolbar.add(new Separator());
		toolbar.add(saveA);
		toolbar.add(new Separator());
		toolbar.add(exitA);
		return toolbar;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.window.ApplicationWindow#createStatusLineManager()
	 */
	@Override
	protected StatusLineManager createStatusLineManager() {
		status = new StatusLineManager();
		return status;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.window.Window#createContents(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	protected Control createContents(Composite parent) {
		getShell().setText("ApplicationWindowExample");
		getShell().setSize(500, 400);
		return parent;
	}
	
	public static void main(String[] args) {
		ApplicationWindowExample example = new ApplicationWindowExample();
		example.setBlockOnOpen(true);
		example.open();
		Display.getDefault().dispose();
	}

}
