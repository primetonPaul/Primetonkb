package com.primeton.btp.studio.jface.window;

import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

/**
 * JFace����ʾ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class HelloJFace extends ApplicationWindow {

	public HelloJFace() {
		super(null);
	}
	
	@Override
	protected Control createContents(Composite parent) {
		getShell().setText("Hello JFace");
		getShell().setSize(200, 100);
		Label label = new Label(parent,SWT.CENTER);
		label.setText("���~JFace");
		return parent;
	}
	
	public static void main(String[] args) {
		HelloJFace hf = new HelloJFace();
		hf.setBlockOnOpen(true);
		hf.open();
		Display.getDefault().dispose();
	}

}
