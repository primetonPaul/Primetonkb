/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��16��
 *******************************************************************************/


package com.primeton.bps.studio.train.utils;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * SWT������
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class SWTUtil {
	private static Display display = new Display();
	/**
	 * @return
	 */
	public static Shell getShell() {
        Shell shell = new Shell(display);		
        return shell;
	}

	/**
	 * @param shell
	 */
	public static void openShell(Shell shell) {
		//��Shell����
		shell.open();
		//�������ڲ���,����Shell����
		while(!shell.isDisposed()){
			if(!display.readAndDispatch()){
				display.sleep();
			}
		}
		display.dispose();
	}

}

/*
 * �޸���ʷ
 * $Log$ 
 */