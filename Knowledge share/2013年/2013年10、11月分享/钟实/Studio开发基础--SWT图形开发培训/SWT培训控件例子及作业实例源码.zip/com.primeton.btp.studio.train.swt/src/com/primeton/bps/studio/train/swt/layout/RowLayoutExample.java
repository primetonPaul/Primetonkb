/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��16��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * FillLayout����ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class RowLayoutExample {
		public static void main(String[] args) {
			   Shell shell = SWTUtil.getShell();
			   shell.setText("RowLayout Example");
			   shell.setLayout(new RowLayout()); 
			   
				Label label1 = new Label(shell, SWT.NONE);
				label1.setText("����Label�ؼ�");
				label1.setLayoutData(new RowData(100, 100));
				Label label2 = new Label(shell, SWT.SEPARATOR);
				label2.setLayoutData(new RowData(20, 20));
				Label label3 = new Label(shell, SWT.SEPARATOR|SWT.HORIZONTAL);
				label3.setLayoutData(new RowData(150, 150));
				shell.pack();
				SWTUtil.openShell(shell);
		}
}

/*
 * �޸���ʷ
 * $Log$ 
 */