/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.widget;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * Label�ؼ�ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class LabelExample {
	
	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Label�ؼ�ʵ��");
		shell.setSize(300, 300);
		shell.setLayout(new GridLayout());
		
		new Label(shell, SWT.NONE).setText("����Label�ؼ�");
		new Label(shell, SWT.SEPARATOR);		
		new Label(shell, SWT.SEPARATOR|SWT.HORIZONTAL);
		
		shell.open();
		while(!shell.isDisposed()){
			if(!display.readAndDispatch()){
				display.sleep();
			}
		}
		display.dispose();
	}
	
}

/*
 * �޸���ʷ
 * $Log$ 
 */