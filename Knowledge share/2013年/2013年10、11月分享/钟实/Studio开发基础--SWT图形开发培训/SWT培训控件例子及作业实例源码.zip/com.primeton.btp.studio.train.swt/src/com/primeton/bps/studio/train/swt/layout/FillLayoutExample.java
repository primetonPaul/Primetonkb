/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��16��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * FillLayout����ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class FillLayoutExample {
		public static void main(String[] args) {
			   Shell shell = SWTUtil.getShell();
			   shell.setText("FillLayout Example");
			   shell.setLayout(new FillLayout(SWT.HORIZONTAL)); 
			   
				new Label(shell, SWT.NONE).setText("����Label�ؼ�");
				new Label(shell, SWT.SEPARATOR);
				new Label(shell, SWT.SEPARATOR|SWT.HORIZONTAL);
			   
				shell.pack();
				SWTUtil.openShell(shell);
		}
}

/*
 * �޸���ʷ
 * $Log$ 
 */