/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/

package com.primeton.bps.studio.train.swt.widget;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Shell;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * Combo�ؼ�ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class ComboExample {
	public static void main(String[] args) {
		Shell shell = SWTUtil.getShell();
		shell.setText("Combo World");
		shell.setLayout(new GridLayout(3, true)); // layouts are explained later
		
		String[] items = "One Two Three Four Five Six".split(" ");
		Combo one = new Combo(shell, SWT.DROP_DOWN);
		one.setItems(items);
		Combo two = new Combo(shell, SWT.DROP_DOWN | SWT.READ_ONLY);
		two.setItems(items);
		Combo three = new Combo(shell, SWT.SIMPLE);
		three.setItems(items);

		// pack and show
//		shell.pack();
		SWTUtil.openShell(shell);
	}
}

/*
 * �޸���ʷ $Log$
 */