/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��16��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * StackLayout����ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class StackLayoutExample {

	 public static void main (String [] args) {
	  Shell shell = SWTUtil.getShell();
	  shell.setBounds (10, 10, 300, 200);
	  
	  // create the composite that the pages will share
	  final Composite contentPanel = new Composite (shell, SWT.BORDER);
	  contentPanel.setBounds (100, 10, 190, 90);
	  final StackLayout layout = new StackLayout ();
	  contentPanel.setLayout (layout);

	  // create the first page's content
	 final Composite page1 = new Composite (contentPanel, SWT.NONE);
	  page1.setLayout (new RowLayout ());
	  Label label = new Label (page1, SWT.NONE);
	  label.setText ("Label on page 1");
	  label.pack ();

	  // create the second page's content 
	  final Composite page2 = new Composite (contentPanel, SWT.NONE);
	  page2.setLayout (new RowLayout ());
	  Button button = new Button (page2, SWT.NONE);
	  button.setText ("Label on page 2");
	  button.pack ();

	  // create the button that will switch between the pages
	  Button pageButton = new Button (shell, SWT.PUSH);
	  pageButton.setText ("Push");
	  pageButton.setBounds (10, 10, 80, 25);
	  pageButton.addListener (SWT.Selection, new Listener () {
	   public void handleEvent (Event event) {
		   if( layout.topControl == page1){
			   layout.topControl =page2;
		   }else{
			   layout.topControl = page1;
		   }
		   contentPanel.layout();
	   }
	  });
	  layout.topControl = page1;

	  SWTUtil.openShell(shell); 
	 }
}

/*
 * �޸���ʷ
 * $Log$ 
 */