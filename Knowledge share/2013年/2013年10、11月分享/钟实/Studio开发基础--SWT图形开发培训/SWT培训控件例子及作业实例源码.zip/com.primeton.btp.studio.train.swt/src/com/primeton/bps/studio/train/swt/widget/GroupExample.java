/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.widget;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class GroupExample {
	public static void main(String[] args) {
	    Shell shell = SWTUtil.getShell();
	    shell.setText("Group World");
	    shell.setLayout(new GridLayout()); // layouts are explained later 
		
	    Group buttonGroup = new Group(shell, SWT.SHADOW_OUT);
	    buttonGroup.setText("Six buttons");
	    buttonGroup.setLayout(new GridLayout(3, true));
	    for(int i = 0; i < 6; i++) {
	       new Button(buttonGroup, SWT.RADIO).setText("Bottle " + (i + 1));
	    }
		
	    Composite composite = new Composite(shell, SWT.SHADOW_OUT);
	    composite.setLayout(new GridLayout(3, true));
	    for(int i = 0; i < 6; i++) {
	       new Button(composite, SWT.RADIO).setText("Bottle " + (i + 1));
	    }
	    
	    // pack and show
	    shell.pack();
	    SWTUtil.openShell(shell);
	}
}

/*
 * �޸���ʷ
 * $Log$ 
 */