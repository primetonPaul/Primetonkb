/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��16��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * GirdLayout����ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class GirdLayoutExample {
	public static void main(String[] args) {
		   Shell shell = SWTUtil.getShell();
		   shell.setText("GridLayoutExample");
		   shell.setLayout(new GridLayout(4, false)); // 2 columns, same width
			
		   // Username
		   new Label(shell, SWT.RIGHT).setText("Username:");
		   Combo cmbUsername = new Combo(shell, SWT.DROP_DOWN);
		   GridData nameComboData = new GridData(GridData.FILL_HORIZONTAL);
		   nameComboData.horizontalSpan = 3;
		   cmbUsername.setLayoutData(nameComboData);
		   cmbUsername.setItems(new String[]{"Howard", "Admin", "Kalman"});
		   cmbUsername.setText("Admin");
			
		   // Password
		   new Label(shell, SWT.RIGHT).setText("Password:");
		   Text txtPassword = new Text(shell, SWT.BORDER | SWT.PASSWORD);
	           txtPassword.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));                
	                txtPassword.addModifyListener(new ModifyListener() {
						
						@Override
						public void modifyText(ModifyEvent e) {
							
						}
					});
		   // Login Button
		   Button loginButton = new Button(shell, SWT.PUSH | SWT.FLAT);
		   loginButton.setText("Proceed to your account");
		   GridData data = new GridData(GridData.FILL_HORIZONTAL);
		   data.horizontalSpan = 3; // span 2 columns
		   loginButton.setLayoutData(data);

		   SWTUtil.openShell(shell);	
		}

}

/*
 * �޸���ʷ
 * $Log$ 
 */