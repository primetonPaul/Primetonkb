/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.widget;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * List�ؼ�ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class ListExample {
	public static void main(String[] args) {

	    Shell shell = SWTUtil.getShell();
	    shell.setText("List World");
	    shell.setLayout(new GridLayout(2, true)); // layouts are explained later 
		
	    String[] items = "One Two Three Four Five Six".split(" ");
	    List one = new List(shell, SWT.SINGLE | SWT.BORDER);
	    one.setItems(items);
	    one.select(2);
	    List two = new List(shell, SWT.MULTI | SWT.BORDER);
	    two.setItems(items);
	    two.setSelection(items);
		
	    // pack and show
	    shell.pack();
	    SWTUtil.openShell(shell);	
	}
}

/*
 * �޸���ʷ
 * $Log$ 
 */