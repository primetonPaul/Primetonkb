/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.shell;

import org.eclipse.swt.widgets.Shell;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * Shellʹ��ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class ShellExample {
	
	public static void main(String[] args) {
		//��������ʼ��Shell����.
		Shell shell = SWTUtil.getShell();
		shell.setText("Shell Example");
		shell.setSize(300, 300);
		
		//��Shell����
		SWTUtil.openShell(shell);
	}
	
}

/*
 * �޸���ʷ
 * $Log$ 
 */