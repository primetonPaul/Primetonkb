package com.primeton.bps.studio.train.swt.event;

/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * Eventʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class EventExample {

	private static boolean numbersOnly;

	public static void main(String[] args) {
		Shell shell = SWTUtil.getShell();
		shell.setText("EventExample");
		shell.setLayout(new GridLayout(2, false));


		Button btnAllow = new Button(shell, SWT.CHECK);
		btnAllow.setText("��֧����������");
		GridData data = new GridData(GridData.HORIZONTAL_ALIGN_CENTER);
		data.horizontalSpan = 2;
		btnAllow.setLayoutData(data);
		btnAllow.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent selectionEvent) {
				numbersOnly = ((Button) (selectionEvent.widget)).getSelection();
			}
		});
		
		// input
		Label lblInput = new Label(shell, SWT.RIGHT);
		lblInput.setText("Type in here:");
		data = new GridData(GridData.HORIZONTAL_ALIGN_END);
		lblInput.setLayoutData(data);
		Text input = new Text(shell, SWT.BORDER);
		// ���Ӽ���
		input.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent vEvent) {
				vEvent.doit = false; // don't allow anything but numbers
				if (!numbersOnly || vEvent.character == '\b') {
					vEvent.doit = true;
				} else if (Character.isDigit(vEvent.character) && numbersOnly) {
					vEvent.doit = true;
				}
			}
		});
		
		shell.pack();
		SWTUtil.openShell(shell);
	}
}

/*
 * �޸���ʷ $Log$
 */