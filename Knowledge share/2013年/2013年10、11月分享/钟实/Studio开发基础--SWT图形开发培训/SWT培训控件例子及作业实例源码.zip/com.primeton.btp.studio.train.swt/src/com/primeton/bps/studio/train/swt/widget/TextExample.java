/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.bps.studio.train.swt.widget;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.bps.studio.train.utils.SWTUtil;

/**
 * Text�ؼ�ʵ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class TextExample {
	public static void main(String[] args) {

	    Shell shell = SWTUtil.getShell();
	    shell.setText("Text World");
	    shell.setLayout(new GridLayout()); // layouts are explained later 
		
	    new Text(shell, SWT.NONE).setText("Missing something ...");
	    new Text(shell, SWT.BORDER); // regular textfield
	    new Text(shell, SWT.PASSWORD | SWT.BORDER).setText("pass");
	    new Text(shell, SWT.READ_ONLY | SWT.BORDER).setText("Can't type inside");
	    new Text(shell, SWT.MULTI | SWT.V_SCROLL | SWT.WRAP | SWT.BORDER).setText("\n\n\n");
		
	    // pack and show
	    shell.pack();
	    SWTUtil.openShell(shell);	

	}
}

/*
 * �޸���ʷ
 * $Log$ 
 */