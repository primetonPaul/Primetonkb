/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.manager;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import com.primeton.btp.studio.train.userinfo.zhongshi.model.Person;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 * Person��Ϣ�ļ�����
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class PersonFileManager {
	
	public static Person load(String filePath){
		Person person = null;
		String xmls;
		try {
			xmls = FileUtils.readFileToString(new File(filePath));
			XStream xStream=new XStream(new DomDriver());
			xStream.alias("person",Person.class);
			person = (Person) xStream.fromXML(xmls);
		} catch (IOException e) {
		}
		return person;
	} 
	
	public static void save(Person person,String filePath) throws IOException{
		XStream xStream=new XStream(new DomDriver());
		xStream.alias("person", Person.class);
		String strxml=xStream.toXML(person);
		FileUtils.writeStringToFile(new File(filePath), strxml);
	}

}

/*
 * �޸���ʷ
 * $Log$ 
 */