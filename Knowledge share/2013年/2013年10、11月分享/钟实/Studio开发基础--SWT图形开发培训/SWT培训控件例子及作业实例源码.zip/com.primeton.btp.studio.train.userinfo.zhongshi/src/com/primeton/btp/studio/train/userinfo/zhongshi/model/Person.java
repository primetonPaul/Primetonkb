/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.model;

import java.io.Serializable;

/**
 * Personģ��
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class Person implements Serializable {
	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = -3848848855616807817L;
	private String name;
	private int age;
	private Sex sex;
	private Hobby[] hobbys;
	private String info;
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return Returns the age.
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age The age to set.
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @return Returns the sex.
	 */
	public Sex getSex() {
		return sex;
	}
	/**
	 * @param sex The sex to set.
	 */
	public void setSex(Sex sex) {
		this.sex = sex;
	}
	/**
	 * @return Returns the hobbys.
	 */
	public Hobby[] getHobbys() {
		return hobbys;
	}
	/**
	 * @param hobbys The hobbys to set.
	 */
	public void setHobbys(Hobby[] hobbys) {
		this.hobbys = hobbys;
	}
	/**
	 * @return Returns the info.
	 */
	public String getInfo() {
		return info;
	}
	/**
	 * @param info The info to set.
	 */
	public void setInfo(String info) {
		this.info = info;
	}
		
}

/*
 * �޸���ʷ
 * $Log$ 
 */