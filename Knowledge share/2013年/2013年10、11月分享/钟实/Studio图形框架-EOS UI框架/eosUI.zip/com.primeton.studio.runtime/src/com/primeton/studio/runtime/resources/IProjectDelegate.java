/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/IProjectDelegate.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:53 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-25
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources;

import org.eclipse.core.runtime.IProgressMonitor;

import com.primeton.studio.runtime.library.ILibrary;

/**
 * ��Ŀ��Դ�Ĵ����ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IProjectDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/08/23 03:11:07  wanglei
 * Review:��IEOSProject�е�getLibraries�ƶ���IProjectDelegate�С�
 *
 * Revision 1.3  2007/08/08 01:48:04  wanglei
 * Remove:ȥ��addSourceFolder������
 *
 * Revision 1.2  2007/06/21 13:58:06  wanglei
 * Review:IProjectDelegateӦ��֧��isOpen�����ж�����Ч�ԡ�
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public interface IProjectDelegate extends IFolderDelegate {
	/**
	 * @return �õ���ǰ��Ŀ������Դ����Ŀ¼��<BR>
	 *
	 */
	public ISourceFolderDelegate[] getSourceFolders();

	/**
	 * Returns whether this project is open.
	 * <p>
	 * A project must be opened before it can be manipulated.
	 * A closed project is passive and has a minimal memory
	 * footprint; a closed project has no members.
	 * </p>
	 *
	 * @return <code>true</code> if this project is open, <code>false</code> if
	 *		this project is closed or does not exist
	 * @see #open(IProgressMonitor)
	 * @see #close(IProgressMonitor)
	 */
	public boolean isOpen();

	/**
	 * @return ���ص�ǰ��Ŀʹ�õĿ⡣<BR>
	 *
	 *
	 */
	public ILibrary[] getLibraries();
}
