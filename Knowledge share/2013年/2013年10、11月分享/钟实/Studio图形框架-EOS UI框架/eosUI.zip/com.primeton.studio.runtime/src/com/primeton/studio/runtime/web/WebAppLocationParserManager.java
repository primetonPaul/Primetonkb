/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/web/WebAppLocationParserManager.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-8-22
 *******************************************************************************/


package com.primeton.studio.runtime.web;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Platform;

/**
 * �ṩ��Թ��̵�web app��λ
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: WebAppLocationParserManager.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/08/22 09:52:25  zhuxing
 * Update:���ɾ��linkĿ¼������
 * 
 */
public class WebAppLocationParserManager {
	/**
	 * extension point id
	 */
	private static final String EXTENSION_POINT = "com.primeton.studio.runtime.webAppLocationParser";
	
	private static List<IWebAppLocationParser> parsers = null;
	
	private WebAppLocationParserManager() {}
	
	/**
	 * �������̶�Ӧ��web app ·��
	 * 
	 * @param project
	 * @return
	 */
	public static IPath getWebAppLocation(IProject project) {
		if (parsers == null)
			loadExtensions();
		
		for (Iterator iter = parsers.iterator(); iter.hasNext();) {
			IWebAppLocationParser parser = (IWebAppLocationParser) iter.next();
			IPath location = parser.getLocation(project);
			if (location != null)
				return location;
		}
		return null;
	}
	
	private static void loadExtensions() {
		try {
			IExtensionRegistry registry = Platform.getExtensionRegistry();
			IExtensionPoint point = registry.getExtensionPoint(EXTENSION_POINT);
			IExtension[] extensions = point.getExtensions();
			
			for (int i = 0; i < extensions.length; i++) {
				IConfigurationElement[] elements = extensions[i].getConfigurationElements();
				for (int j = 0; j < elements.length; j++) {
					Object parser = elements[j].createExecutableExtension("class");
					if (parser instanceof IWebAppLocationParser) {
						parsers = new ArrayList<IWebAppLocationParser>();
						parsers.add((IWebAppLocationParser)parser);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
