/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.archive;

import java.io.File;
import java.util.Properties;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.adapter.ArchiveContributionAdapterFactory;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * Jar�����ļ���Ŀ¼�Ļ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ArchiveResourceDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/02/26 01:51:09  liu-jun
 * jira 3755
 * �޸��ߣ�lvyuan
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2008/04/22 10:40:30  hongsq
 * Update:��ʱFix���ÿ��в�������Java������Eos����������
 *
 * Revision 1.4  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.3  2007/09/25 06:08:51  wanglei
 * Review:ʵ����equals��hashCode������
 *
 * Revision 1.2  2007/06/28 09:31:51  wanglei
 * Remove:����������name��
 *
 * Revision 1.1  2007/06/26 07:53:56  wanglei
 * �ύ��CVS��
 *
 */

public abstract class ArchiveResourceDelegate extends AbstractArchiveResourceDelegate {

	private ArchiveRootFileDelegate archiveFile;

	private String path;

	private String name;

	private Properties persistentProperty = new Properties();

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param rootFile
	 * @param path
	 * @param name
	 */
	public ArchiveResourceDelegate(ArchiveRootFileDelegate rootFile, String path) {
		super();
		this.archiveFile = rootFile;
		this.path = path;
	}

	/**
	 * @param name the name to set
	 */
	protected void setName(String name) {
		this.name = name;
	}

	/**
	 * {@inheritDoc}
	 */
	public File getFile() {
		return this.archiveFile.getFile();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getFullPath() throws ResourceException {
		String fullPath = this.archiveFile.getFullPath() + "/" + this.path;
		return FilenameUtil.normalizeInUnixStyle(fullPath);
	}

	/**
	 * {@inheritDoc}
	 */
	public long getLastModified() {
		return this.archiveFile.getLastModified();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getName() throws ResourceException {
		return this.name;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getParent() throws ResourceException {
		return this.archiveFile.getParent(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate getProject() throws ResourceException {
		return this.archiveFile.getProject();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProjectRelativePath() throws ResourceException {
		String relativePath = this.archiveFile.getProjectRelativePath() + "/" + this.path;
		return FilenameUtil.normalizeInUnixStyle(relativePath);
	}

	/**
	 * {@inheritDoc}
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return this.archiveFile.getSourceFolder();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getSourceRelativePath() throws ResourceException {
		return this.path;
	}

	/**
	 * @return the archiveFile
	 */
	public ArchiveRootFileDelegate getArchiveFile() {
		return this.archiveFile;
	}

	/**
	 * @return the path
	 */
	public String getPath() {
		return this.path;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.archiveFile == null) ? 0 : this.archiveFile.hashCode());
		result = PRIME * result + ((this.name == null) ? 0 : this.name.hashCode());
		result = PRIME * result + ((this.path == null) ? 0 : this.path.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ArchiveResourceDelegate other = (ArchiveResourceDelegate) obj;
		if (this.archiveFile == null) {
			if (other.archiveFile != null) {
				return false;
			}
		}
		else if (!this.archiveFile.equals(other.archiveFile)) {
			return false;
		}

		if (this.name == null) {
			if (other.name != null) {
				return false;
			}
		}
		else if (!this.name.equals(other.name)) {
			return false;
		}

		if (this.path == null) {
			if (other.path != null) {
				return false;
			}
		}
		else if (!this.path.equals(other.path)) {
			return false;
		}

		return true;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.AbstractArchiveResourceDelegate#getPersistentProperty(java.lang.String)
	 */
	@Override
	public String getPersistentProperty(String key) {
		return this.persistentProperty.getProperty(key);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.AbstractArchiveResourceDelegate#setPersistentProperty(java.lang.String, java.lang.String)
	 */
	@Override
	public void setPersistentProperty(String key, String value) {
		this.persistentProperty.setProperty(key, value);
	}

	@Override
	public Object getAdapter(Class adapter) {
		Object object =  super.getAdapter(adapter);
		if(object == null ){
			if(adapter == IContribution.class){
				return new ArchiveContributionAdapterFactory().getAdapter(this, adapter);
			}
		}
		return object;
	}
}
