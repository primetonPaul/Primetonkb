/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/DOCNameSpaceUtil.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-5-13
 *******************************************************************************/


package com.primeton.studio.runtime.model.internal;

import org.apache.commons.lang.StringUtils;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.ModelHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.IType;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yourname (mailto:yourname@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DOCNameSpaceUtil.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/05/13 07:30:13  lvyuan
 * Update:�ع�EDOC�����ɷ�ʽ
 * 
 */
public class DOCNameSpaceUtil {
	
//	 TODO FixMe �˿�Ĵ����NameSpaceUtil���������NameSpaceUtil������JDT�Ķ���
	// ����������е�ECD�ڼ��ɱ����ʱ����Ҫ�޸Ľű������������������
	private static final String POINT = ".";
	
	/**
	 * ��ȡeosElement�����ƿռ�
	 * @param eosElement
	 * @return
	 */
	public static String getNameSpace4EOSElement(IEosElement eosElement) {
		if(eosElement instanceof IContribution){
			return eosElement.getName();
		}
		if (eosElement instanceof IEosModel) {
			return ModelHelper.getNamespace((IEosModel) eosElement);
		}

		if (eosElement instanceof IType) {
			IType type = (IType) eosElement;

			if(RuntimeConstant.NODE_COMPONENT_SERVICE.equals(type.getImplementationType())){
				String parentName = getNameSpace4EOSElement(type.getParent());
				String serviceName = type.getName();
				return parentName+"/"+serviceName;
			}

			IEosElement parentElement = type.getParent();
			String extension = StringUtils.substringAfterLast(parentElement.getName(), ".");
			if(StringUtils.equals(extension, RuntimeConstant.JAVA)){
				return ModelHelper.getNamespace(parentElement);
			}
			return ModelHelper.getNamespace(parentElement) + POINT + type.getName();
		}

		if (eosElement instanceof IField) {//�е�����
			IField field = (IField) eosElement;
			return getNameSpace4EOSElement(field.getParent()) + POINT + field.getName();
		}
		if(eosElement instanceof IMethod){
			return getNameSpace4IMethod((IMethod)eosElement);
		}
		return ModelHelper.getNamespace(eosElement);
	}
	
	/**
	 * ��ȡIMethod�����ƿռ�
	 * @param method
	 * @return
	 */
	public static String getNameSpace4IMethod(IMethod method) {
		if(RuntimeConstant.NODE_COMPONENT_OPERATION.equals(method.getImplementationType())){
			return getNameSpace4OperatorNode(method);
		}
		if(RuntimeConstant.BIZLET.equals(method.getImplementationType())){
			return ModelHelper.getNamespace(method.getParent()) + POINT + method.getName();
		}
		return getNameSpace4EOSElement(method.getParent()) + POINT + method.getName();
	}
	
	/**
	 * ��ȡOperatorNode�����ƿռ�
	 * @param operatorNode
	 * @return
	 */
	public static String getNameSpace4OperatorNode(IMethod operatorNode) {
		IType serviceNode = (IType) operatorNode.getParent();
		String methodName = operatorNode.getName();
		String parentName = serviceNode.getParent().getName();
		String compositeName = serviceNode.getParent().getParent().getResource().getSourceRelativePath();
		compositeName = FilenameUtil.toPackageWithoutExtension(compositeName);
		return compositeName+POINT+parentName+"/"+serviceNode.getName() + POINT + methodName;
	}
}
