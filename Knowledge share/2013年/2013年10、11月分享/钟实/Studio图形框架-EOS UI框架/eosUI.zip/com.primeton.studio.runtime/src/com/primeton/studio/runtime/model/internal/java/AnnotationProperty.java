/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.internal.java;

import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.core.base.AbstractNamingElement;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.model.java.IAnnotationProperty;

/**
 * IAnnotationProperty��Ĭ��ʵ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AnnotationProperty.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/10/31 08:31:09  wanglei
 * Add:�ύ��CVS��
 *
 */

public class AnnotationProperty extends AbstractNamingElement implements IAnnotationProperty {

	private IEosElement element;

	private Object value;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AnnotationProperty() {
		super();
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param displayName
	 * @param name
	 */
	public AnnotationProperty(String displayName, String name) {
		super(displayName, name);
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getValue() {
		return this.value;
	}

	/**
	 * @param element the element to set
	 */
	public final void setElement(IEosElement element) {
		this.element = element;
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosElement getElement() {
		return this.element;
	}

	/**
	 * @param value the value to set
	 */
	public final void setValue(Object value) {
		this.value = value;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + ((this.element == null) ? 0 : this.element.hashCode());
		result = PRIME * result + ((this.value == null) ? 0 : this.value.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		final AnnotationProperty other = (AnnotationProperty) obj;
		if (!ObjectUtils.equals(this.element, other.element)) {
			return false;
		}

		return ObjectUtils.equals(this.value, other.value);
	}
}
