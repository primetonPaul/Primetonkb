/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/AbstractMultiResourceLocator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-8-19
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;


/**
 * IEosMultiResourceLocator�ĳ���ʵ��
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: AbstractMultiResourceLocator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/08/20 07:47:03  hongsq
 * Update:�ṩһ��ӿ�֧�ֲ���һ���ļ������޸�xsd,wsdl��ع����������ƿռ��ظ�
 * 
 */
public abstract class AbstractMultiResourceLocator implements IEosMultiResourceLocator {

}
