/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/query/QueryResult.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-6-5
 *******************************************************************************/

package com.primeton.studio.runtime.index.query;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Searcher;

import com.primeton.studio.runtime.exception.IndexException;
import com.primeton.studio.runtime.index.IndexManager;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * ֧�������صĲ�ѯ�����<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: QueryResult.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/05/08 09:05:47  wanglei
 * Jira:����EOSP-231��
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
public abstract class QueryResult<E> {

	private Query query;

	private Hits hits;

	private IProjectDelegate project;

	private QueryStatement statement;

	private Map<Integer, E> results = new HashMap<Integer, E>();

	private Searcher currentearcher;

	private int size = -1;

	/**
	 *
	 */
	QueryResult(IProjectDelegate projectDelegate, Query query, QueryStatement statement) {
		this.project = projectDelegate;
		this.query = query;
		this.statement = (QueryStatement) statement.clone();

		if (!statement.isLazyLoading()) {
			Searcher searcher = IndexManager.getInstance().getSearcher(this.project);
			try {
				this.hits = searcher.search(query);
				if(null!=hits){
					this.load(this.hits, 0, this.hits.length());
				}
			} catch (IOException e) {
				throw new IndexException(e);
			}
		}
	}

	/**
	 * ���ؽ����<BR>
	 * @return
	 */
	public int size() {
		if ((!checkSearchResult()) || (-1 == size)) {

			if(null==hits){
				size=0;
				return size;
			}

			try {
				size = this.computeSize(hits);
			} catch (Exception e) {
				throw new IndexException(e);
			}
		}

		return size;
	}

	/**
	 * ������ʵ�־���ļ�����<BR>
	 *
	 * @param hits
	 * @return
	 * @throws IOException
	 * @throws CorruptIndexException
	 */
	protected abstract int computeSize(Hits hits) throws CorruptIndexException, IOException;

	/**
	 *
	 *
	 */
	private synchronized boolean checkSearchResult() {

		if (!statement.isLazyLoading()) {
			return true;
		}

		Searcher searcher = IndexManager.getInstance().getSearcher(this.project);
		if (searcher != this.currentearcher) {
			this.results.clear();
			this.currentearcher = searcher;

			try {
				this.hits = searcher.search(query);
				return false;
			} catch (IOException e) {
				throw new IndexException(e);
			}
		}
		return true;
	}

	/**
	 * @return Returns the statement.
	 */
	protected QueryStatement getStatement() {
		return statement;
	}

	/**
	 * @return Returns the project.
	 */
	protected IProjectDelegate getProject() {
		return project;
	}

	/**
	 *
	 * @param index
	 * @return
	 */
	public E get(int index) {

		this.checkSearchResult();
		if (index >= this.size()) {
			throw new RuntimeException("the index is out of range");
		}

		if(null==this.hits){
			throw new RuntimeException("the index is out of range");
		}

		Integer integer = Integer.valueOf(index);
		E result = this.results.get(integer);
		if (null != result) {
			return result;
		}

		List<E> list;
		try {
			list = this.load(this.hits, index, index + statement.getPageSize());

			for (int i = 0; i < list.size(); i++) {
				E item = list.get(i);
				Integer newIndex = Integer.valueOf(index + i);
				this.results.put(newIndex, item);
			}


			return this.results.get(integer);
		} catch (Exception e) {
			throw new IndexException(e);
		}
	}

	/**
	 *
	 * @param hits
	 * @param startIndex
	 * @param endIndex
	 * @return
	 * @throws IOException
	 * @throws CorruptIndexException
	 */
	protected abstract List<E> load(Hits hits, int startIndex, int endIndex) throws CorruptIndexException, IOException;

}
