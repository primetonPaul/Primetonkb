/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.index.base;

import java.io.IOException;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;

import com.primeton.studio.core.util.AdapterUtil;
import com.primeton.studio.runtime.core.IReference;
import com.primeton.studio.runtime.exception.IndexException;
import com.primeton.studio.runtime.index.IFileIndexer;
import com.primeton.studio.runtime.index.internal.IndexBuilderImpl;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * IFileIndexer�ĳ���ʵ�֣�����IReference����������<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractFileIndexer.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/12/19 06:41:53  wanglei
 * Update:ʵ����������
 *
 * Revision 1.2  2007/12/19 03:45:17  wanglei
 * Review:Ϊ���������ķ���������һ��buildKind������
 *
 * Revision 1.1  2007/12/12 10:06:37  wanglei
 * Add:�ύ��CVS��
 *
 */

public abstract class AbstractFileIndexer implements IFileIndexer {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractFileIndexer() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean buildIndex(IFileDelegate fileDelegate, IAdaptable adaptable, int buildKind, IProgressMonitor monitor) {
		IndexBuilderImpl indexBuilder = (IndexBuilderImpl) AdapterUtil.getAdapter(adaptable,IndexBuilderImpl.class);

		if (null == indexBuilder) {
			return false;
		}

		IReference[] references = this.getReference(fileDelegate, adaptable, buildKind);
		if (ArrayUtils.isEmpty(references)) {
			return false;
		}
		else {
			try {
				indexBuilder.doBuild(fileDelegate, references, monitor);
				return true;
			} catch (IOException e) {
				throw new IndexException(e);
			}
		}
	}

	/**
	 * �����õ�ָ���ļ������ù�ϵ���Ӷ�����Ԫ���ݽ���������<BR>
	 *
	 * @param fileDelegate
	 * @param adaptable
	 * @param buildKind
	 * @return
	 */
	public abstract IReference[] getReference(IFileDelegate fileDelegate, IAdaptable adaptable, int buildKind);

	/**
	 * {@inheritDoc}
	 */
	public IFileIndexer cloneSelf() {
		return this;
		//Ĭ�����̰߳�ȫ��
	}

	/**
	 * {@inheritDoc}
	 */
	public int getPriority() {
		return 0;
	}

}
