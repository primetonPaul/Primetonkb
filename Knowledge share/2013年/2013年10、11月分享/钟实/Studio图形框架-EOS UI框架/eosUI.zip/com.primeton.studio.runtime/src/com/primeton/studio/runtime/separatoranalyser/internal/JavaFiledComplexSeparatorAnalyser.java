/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/internal/JavaFiledComplexSeparatorAnalyser.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.internal;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.model.IJavaAnalyser;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.separatoranalyser.AbstractSeparatorAnalyser;
import com.primeton.studio.runtime.separatoranalyser.ComplexSeparatorContext;
import com.primeton.studio.runtime.separatoranalyser.ISeparatorPolicy;
import com.primeton.studio.runtime.separatoranalyser.SeparatorModel;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: JavaFiledComplexSeparatorAnalyser.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/10/29 10:27:37  liu-jun
 * Bug:13984 ��javabean�е�List������ʾ����ȷ commit by yangmd
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:46  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class JavaFiledComplexSeparatorAnalyser extends AbstractSeparatorAnalyser{
	private IProjectDelegate projectDelegate;
	/**
	 * 
	 * @param projectDelegate
	 */
	public JavaFiledComplexSeparatorAnalyser(IProjectDelegate projectDelegate) {
		super();
		this.projectDelegate = projectDelegate;
	}

	/**
	 * @param element
	 * @param separatorPolicy
	 * @param separatormodel
	 * @param childName
	 * @return
	 */
	protected Object doGetOneChild(ComplexSeparatorContext context,Object element, ISeparatorPolicy separatorPolicy, SeparatorModel separatormodel, String childName) {
		Object obj = element;
		IJavaAnalyser javaAnalyser = null;
		String parentContent = context.getParentContent();
		if(obj instanceof IJavaAnalyser){
			javaAnalyser = (IJavaAnalyser)obj;
		} else if(obj instanceof IField){
			IType type = ((IField)obj).getDeclaringType();
			javaAnalyser = getJavaAnalyser(parentContent, type);
		} else if(obj instanceof IType){
			IType type = (IType)obj;
			javaAnalyser = getJavaAnalyser(parentContent, type);
		} 
		if(javaAnalyser == null)return null;
		childName = StringUtils.substringBefore(childName, "[");
		IField field = javaAnalyser.getField(null,childName);
		if(field == null)return null;
		SeparatorModel sepaModel = new SeparatorModel(separatormodel,field);
		if(separatorPolicy.accept(sepaModel)){
			return field;
		}		
		return null;
	}

	/**
	 * @param childName
	 * @param type
	 * @return
	 */
	private IJavaAnalyser getJavaAnalyser(String childName, IType type) {
		IJavaAnalyser javaAnalyser;
		String fieldType = type.getName();
		int typeArrayCount = arrayCount(type);
		int strArrayCount = arrayCount(childName);
		if(typeArrayCount < 1 || typeArrayCount == strArrayCount){
			fieldType = StringUtils.substringBefore(fieldType, "<");
			fieldType = StringUtils.substringBefore(fieldType, "[]");
			javaAnalyser = RuntimeHelper.getJavaAnalyser(this.projectDelegate, fieldType);
		} else {
//			javaAnalyser = RuntimeHelper.getJavaAnalyser(this.projectDelegate, Object.class.getName());
			javaAnalyser = null;//��������������û���±�����ֱ�ӷ���
		}
		return javaAnalyser;
	}
	
}
