/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/project/ProjectValidationResult.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Oct 21, 2010
 *******************************************************************************/


package com.primeton.studio.runtime.project;

import org.eclipse.core.resources.IProject;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author guwei (mailto:guwei@primeton.com)
 */
public class ProjectValidationResult {
	//IProject project, String message, int severity, int priority, String type
	private IProject project;

	private String message;

	private int serverity;

	private int priority;

	private String type;

	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return this.message;
	}

	/**
	 * @param message The message to set.
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return Returns the priority.
	 */
	public int getPriority() {
		return this.priority;
	}

	/**
	 * @param priority The priority to set.
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * @return Returns the project.
	 */
	public IProject getProject() {
		return this.project;
	}

	/**
	 * @param project The project to set.
	 */
	public void setProject(IProject project) {
		this.project = project;
	}

	/**
	 * @return Returns the serverity.
	 */
	public int getServerity() {
		return this.serverity;
	}

	/**
	 * @param serverity The serverity to set.
	 */
	public void setServerity(int serverity) {
		this.serverity = serverity;
	}

	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}

}

/*
 * �޸���ʷ
 * $Log: ProjectValidationResult.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/10/21 08:47:07  guwei
 * JIRA: EOSP-324 ����Ŀ����֤��Ҫ�ṩ��չ��
 *
 */