/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.library.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.core.base.AbstractNamingElement;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.internal.Contribution;
import com.primeton.studio.runtime.core.internal.filter.BinaryCompositeArchiverResourceFilter;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.archive.ArchiveRootFileDelegate;
import com.primeton.studio.runtime.validator.internal.ContributionValidator;

/**
 * ILibrary��Ĭ��ʵ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: LibraryImpl.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/04/07 07:03:12  wanglei
 * Review:����û����ȷ����ʱ�����Bug��
 *
 * Revision 1.2  2009/01/06 05:59:13  lvyuan
 * Update:�޸����ÿ��жϵ�����
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.12  2008/05/16 06:43:40  wanglei
 * Review:�����ӿڽṹ������Ӧ��Java�����.metadataĿ¼�С�
 *
 * Revision 1.11  2008/04/16 02:37:38  wanglei
 * UnitTest:timestamps������Ӧ�ó־û���
 *
 * Revision 1.10  2008/04/15 03:31:16  wanglei
 * Update:ʵ��isResourceChanged������
 *
 * Revision 1.9  2007/12/11 05:38:01  wanglei
 * Add:����Ĭ�Ϲ��캯����
 *
 * Revision 1.8  2007/12/11 02:24:32  wanglei
 * Add:����isDefault���������ж��Ƿ���Ĭ�����ÿ⡣
 *
 * Revision 1.7  2007/12/10 07:07:44  chenxp
 * UnitTest:���Ӷ���Ŀ��Ч�Ե���֤
 *
 * Revision 1.6  2007/11/29 06:05:18  wanglei
 * Update:ʵ��getProject������
 *
 * Revision 1.5  2007/11/29 02:39:00  wanglei
 * Review:��RuntimeManager���������ÿ���Contribution�����Ƶ�LibraryImpl�С�
 *
 * Revision 1.4  2007/08/09 06:58:17  wanglei
 * Update:����Դ����ת��ILibraryManager�ӿ��С�
 *
 * Revision 1.3  2007/06/30 13:11:17  wanglei
 * Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.2  2007/06/28 09:23:12  wanglei
 * Review:��ΪComposite��Ҫ���棬��������getComposites������
 *
 * Revision 1.1  2007/04/23 09:01:12  wanglei
 * Update:�ϲ�Library��LibraryRepository
 *
 */
public class LibraryImpl extends AbstractNamingElement implements ILibrary {

	private String path;

	private String kind;

	private int type;

	private boolean isDefault;

	private boolean loaded = false;

	private transient Map timestamps = new HashMap();

	private transient IContribution[] contributions;

	private transient IProjectDelegate projectDelegate;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * Ϊ�����ṩ�ġ�<BR>
	 *
	 * The default constructor.<BR>
	 * Used to reflection.<BR>
	 *
	 */
	protected LibraryImpl() {
		super();
	}

	/**
	 * ������<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param type
	 */
	public LibraryImpl(int type) {
		super();
		this.type = type;
	}

	/**
	 * @return the kind
	 */
	public String getKind() {
		return this.kind;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}

	/**
	 * @return the name
	 */
	public String getPath() {
		return this.path;
	}

	/**
	 * @param name the name to set
	 */
	public void setPath(String name) {
		this.path = name;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getType() {
		return this.type;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public final boolean isDefault() {
		return this.isDefault;
	}

	/**
	 * @param isDefault the isDefault to set
	 */
	public final void setDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public final IProjectDelegate getProject() {
		return this.projectDelegate;
	}

	/**
	 * @param project the project to set
	 */
	public final void setProject(IProjectDelegate project) {
		this.projectDelegate = project;
	}

	/**
	 * {@inheritDoc}
	 */
	public IContribution[] getContributions() {
		if (null == this.contributions) {
			this.contributions = this.createContributions();
		}

		return this.contributions;
	}

	/**
	 * �����ÿⴴ�����Contribution��<BR>
	 *
	 * @param projectName
	 * @return
	 */
	public final IContribution[] createContributions() {

		IResourceDelegate[] resourceDelegates = RuntimeManager.getLibraryManager().getResources(this);
		List list = new ArrayList();
		this.timestamps.clear();

		for (int i = 0; i < resourceDelegates.length; i++) {
			IResourceDelegate delegate = resourceDelegates[i];
			internalCreateContributions(this.projectDelegate, delegate, list);
			this.timestamps.put(delegate, new Long(delegate.getLastModified()));
		}

		//FIXME Ŀ¼����Ŀ����δ֧�֡�

		IContribution[] results = new IContribution[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * �������ÿ��Contribution��<BR>
	 *
	 * @param project
	 * @param resourceDelegate
	 * @param list
	 */
	private void internalCreateContributions(IProjectDelegate project, IResourceDelegate resourceDelegate, List list) {
		this.loaded = true;

		if (resourceDelegate.getType() == IResourceDelegate.FILE) {
			IFileDelegate fileDelegate = (IFileDelegate) resourceDelegate;

			if (!ResourceHelper.isValidResource(fileDelegate)) {
				return;
			}

			if (!ResourceHelper.isValidProject(project)) {
				return;
			}

			ArchiveRootFileDelegate rootFile = new ArchiveRootFileDelegate(project.getName(), fileDelegate);
			rootFile.setResourceFilter(BinaryCompositeArchiverResourceFilter.getInstance());
			rootFile.setLevel(ArchiveRootFileDelegate.ONE_LEVEL);

			try {
				rootFile.load();

				IResourceDelegate[] resources = rootFile.getChildren();

				for (int i = 0; i < resources.length; i++) {
					IResourceDelegate delegate = resources[i];

					try {
						if (delegate instanceof ArchiveRootFileDelegate) {
							IFolderDelegate folder = (IFolderDelegate) delegate;

							if (ContributionValidator.INSTANCE.validate(folder, null, null)) {
								IContribution contribution = new Contribution(folder);
								list.add(contribution);
							}
						}
					} catch (Exception e) {
						RuntimeManager.getLogger().error(e);
					}

				}
			} catch (IOException e) {
				RuntimeManager.getLogger().error(e);
			}
		}
		//��ѹ���ļ�������
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + (this.isDefault ? 1231 : 1237);
		result = PRIME * result + ((this.kind == null) ? 0 : this.kind.hashCode());
		result = PRIME * result + ((this.path == null) ? 0 : this.path.hashCode());
		result = PRIME * result + this.type;
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!super.equals(obj)) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		final LibraryImpl other = (LibraryImpl) obj;

		if (!ObjectUtils.equals(this.kind, other.kind)) {
			return false;
		}

		if (!ObjectUtils.equals(this.path, other.path)) {
			return false;
		}
		if (this.type != other.type) {
			return false;
		}

		return this.isDefault == other.isDefault;

	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isResourceChanged() {

		if (!this.loaded) {
			return false;
		}
		IResourceDelegate[] resourceDelegates = RuntimeManager.getLibraryManager().getResources(this);

		if (ArrayUtils.isEmpty(resourceDelegates)) {
			return this.timestamps.isEmpty();
		}

		if (resourceDelegates.length != this.timestamps.size()) {
			return true;
		}

		for (int i = 0; i < resourceDelegates.length; i++) {
			IResourceDelegate delegate = resourceDelegates[i];
			Long stamp = (Long) this.timestamps.get(delegate);

			if (null == stamp) {
				return true;
			}

			if (stamp.longValue() != delegate.getLastModified()) {
				return true;
			}
		}

		return false;
	}
}
