/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/query/QueryStatement.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-6-5
 *******************************************************************************/

package com.primeton.studio.runtime.index.query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;

import com.eos.system.utility.ClassUtil;
import com.primeton.studio.core.ICloneable;
import com.primeton.studio.core.util.entry.StringMapEntry;

/**
 * ע�⣬�����ѯ�����࣬һ�����ڲ�ѯ�Ժ��κζ������޸ģ������ᷴӳ����ѯ����С�<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: QueryStatement.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.4  2009/10/21 08:45:44  chenxp
 * Update: �Ż�studio����
 *
 * Revision 1.3  2009/07/22 05:09:17  lvyuan
 * Update:�ع�����namespace��Ϊһ��StringEntry
 *
 * Revision 1.2  2009/07/21 09:51:19  lvyuan
 * Update:�ع��������ҽӿڣ��������ö���ؼ���
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
public final class QueryStatement implements ICloneable {

	private boolean caseSensitive;

	private String[] binaryTypes;

	private String[] extensions;

	private boolean includeLibrary = true;

	private boolean includeSource = true;

	private boolean lazyLoading = true;

	private int pageSize = 20;
	
	// ���ƿռ�����ֶαȽ���Ҫ�����Ե��������
	private StringMapEntry nameSpace;
	
	private List<StringMapEntry> keyWords = new ArrayList<StringMapEntry>();;
	
	//private String keyWord;

	private String queryField;

	private boolean includeContributions = true;

	/**
	 *
	 */
	public QueryStatement() {
		super();
	}

	/**
	 * @return Returns the queryField.
	 */
	String getQueryField() {
		return queryField;
	}

	/**
	 * @param queryField The queryField to set.
	 */
	void setQueryField(String queryField) {

		if (null != this.queryField) {
			throw new RuntimeException("the query field can't be updated.");
		}

		this.queryField = queryField;
	}

	/**
	 * @return Returns the binaryTypes.
	 */
	public String[] getBinaryTypes() {
		return binaryTypes;
	}

	/**
	 * @param binaryTypes The binaryTypes to set.
	 */
	public void setBinaryTypes(String[] binaryTypes) {
		this.binaryTypes = binaryTypes;
	}

	/**
	 * @return Returns the caseSensitive.
	 */
	public boolean isCaseSensitive() {
		return caseSensitive;
	}

	/**
	 * @param caseSensitive The caseSensitive to set.
	 */
	public void setCaseSensitive(boolean caseSensitive) {
		this.caseSensitive = caseSensitive;
	}

	/**
	 * @return Returns the extensions.
	 */
	public String[] getExtensions() {
		return extensions;
	}

	/**
	 * @param extension The extensions to set.
	 */
	public void setExtensions(String[] extensions) {
		this.extensions = extensions;
	}

	/**
	 * @return Returns the includeLibrary.
	 */
	public boolean isIncludeLibrary() {
		return includeLibrary;
	}

	/**
	 * @param includeLibrary The includeLibrary to set.
	 */
	public void setIncludeLibrary(boolean includeLibrary) {
		this.includeLibrary = includeLibrary;
	}

	/**
	 * @return Returns the includeSource.
	 */
	public boolean isIncludeSource() {
		return includeSource;
	}

	/**
	 * @param includeSource The includeSource to set.
	 */
	public void setIncludeSource(boolean includeSource) {
		this.includeSource = includeSource;
	}
	
	/**
	 * @param entry
	 */
	public void addKeyWords(StringMapEntry entry){
		keyWords.add(entry);
	}
	
	/**
	 * @return Returns the lazyLoading.
	 */
	public boolean isLazyLoading() {
		return lazyLoading;
	}

	/**
	 * @param lazyLoading The lazyLoading to set.
	 */
	public void setLazyLoading(boolean lazyLoading) {
		this.lazyLoading = lazyLoading;
	}

	/**
	 * @return Returns the pageSize.
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * @param pageSize The pageSize to set.
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * @return Returns the includeContributions.
	 */
	public boolean isIncludeContributions() {
		return includeContributions;
	}

	/**
	 * @param includeContributions The includeContributions to set.
	 */
	public void setIncludeContributions(boolean includeContributions) {
		this.includeContributions = includeContributions;
	}

	/**
	 * {@inheritDoc}
	 */
	public Object clone() {

		QueryStatement queryStatement = new QueryStatement();

		ClassUtil.copyFields(this, queryStatement);
		queryStatement.binaryTypes=(String[]) ArrayUtils.clone(binaryTypes);
		queryStatement.extensions=(String[]) ArrayUtils.clone(extensions);

		return queryStatement;

	}

	/**
	 * @return Returns the nameSpace.
	 */
	public StringMapEntry getNameSpace() {
		return nameSpace;
	}

	/**
	 * @param nameSpace The nameSpace to set.
	 */
	public void setNameSpace(StringMapEntry nameSpace) {
		this.nameSpace = nameSpace;
	}

	/**
	 * 
	 * 
	 * @return Returns the keyWords.
	 */
	public List<StringMapEntry> getKeyWords() {
		return keyWords;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + Arrays.hashCode(binaryTypes);
		result = PRIME * result + (caseSensitive ? 1231 : 1237);
		result = PRIME * result + Arrays.hashCode(extensions);
		result = PRIME * result + (includeContributions ? 1231 : 1237);
		result = PRIME * result + (includeLibrary ? 1231 : 1237);
		result = PRIME * result + (includeSource ? 1231 : 1237);
		result = PRIME * result + ((keyWords == null) ? 0 : keyWords.hashCode());
		result = PRIME * result + ((nameSpace == null) ? 0 : nameSpace.hashCode());
		result = PRIME * result + ((queryField == null) ? 0 : queryField.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final QueryStatement other = (QueryStatement) obj;
		if (!Arrays.equals(binaryTypes, other.binaryTypes)) {
			return false;
		}
		if (caseSensitive != other.caseSensitive) {
			return false;
		}
		if (!Arrays.equals(extensions, other.extensions)) {
			return false;
		}
		if (includeContributions != other.includeContributions) {
			return false;
		}
		if (includeLibrary != other.includeLibrary) {
			return false;
		}
		if (includeSource != other.includeSource) {
			return false;
		}
		if (!ObjectUtils.equals(keyWords, other.keyWords)) {
			return false;
		}
		if (!ObjectUtils.equals(nameSpace, other.nameSpace)) {
			return false;
		}
		return ObjectUtils.equals(queryField, other.queryField);
	}

}
