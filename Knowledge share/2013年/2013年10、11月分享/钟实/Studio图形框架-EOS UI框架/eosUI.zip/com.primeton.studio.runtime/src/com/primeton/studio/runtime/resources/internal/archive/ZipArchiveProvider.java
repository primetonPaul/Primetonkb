/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/ZipArchiveProvider.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-10
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ZipArchiveProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 * 
 */
public class ZipArchiveProvider implements IArchiveProvider{
	private ZipFile zipFile;
	private int stripLevel;
	private ZipEntry root = new ZipEntry("/");
	private Map directoryEntryCache = new HashMap();
	private Map<String,Object> parent;
	
	private Map<Object,List> children; 
	/**
	 * 
	 * @param file
	 */
	public ZipArchiveProvider(ZipFile file){
		this.zipFile = file;
		this.stripLevel = 0;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#getChildren(java.lang.Object)
	 */
	public List getChildren(Object element){
		if(this.children == null){
			initialize();
		}
		return this.children.get(element);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#getContents(java.lang.Object)
	 */
	public InputStream getContents(Object element) {
		try {
			return zipFile.getInputStream((ZipEntry) element);
		} catch (IOException e) {
			return null;
		}
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#getLabel(java.lang.Object)
	 */
	public String getLabel(Object element) {
		if (element.equals(root)) {
			return ((ZipEntry) element).getName();
		}
		return stripPath(new Path(((ZipEntry) element).getName()).lastSegment());
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#getFullPath(java.lang.Object)
	 */
	public String getFullPath(Object element) {
		return stripPath(((ZipEntry) element).getName());
	}
	/*
	 * Strip the leading directories from the path
	 */
	private String stripPath(String path) {
		String pathOrig = new String(path);
		for (int i = 0; i < stripLevel; i++) {
			int firstSep = path.indexOf('/');
			// If the first character was a seperator we must strip to the next
			// seperator as well
			if (firstSep == 0) {
				path = path.substring(1);
				firstSep = path.indexOf('/');
			}
			// No seperator wasw present so we're in a higher directory right
			// now
			if (firstSep == -1) {
				return pathOrig;
			}
			path = path.substring(firstSep);
		}
		return path;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#isFolder(java.lang.Object)
	 */
	public boolean isFolder(Object element) {
		return ((ZipEntry) element).isDirectory();
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#getParent(java.lang.Object)
	 */
	public Object getParent(Object element){
		if(this.parent == null){
			if(this.children == null)initialize();
			Collection<List> values = this.children.values();
			for (Iterator iter = values.iterator(); iter.hasNext();) {
				List list = (List) iter.next();
				for (Iterator iterator = list.iterator(); iterator.hasNext();) {
					Object entry = iterator.next();
					String path = this.getFullPath(entry);
					this.parent.put(path, entry);
				}
			}
		}
		return this.parent.get(this.getFullPath(element));
	}
	/**
	 * 
	 *
	 */
	private void initialize() {
		children = new HashMap<Object, List>(1000);
		children.put(root, new ArrayList());
		Enumeration entries = zipFile.entries();
		while (entries.hasMoreElements()) {
			ZipEntry entry = (ZipEntry) entries.nextElement();
			IPath path = new Path(entry.getName()).addTrailingSeparator();

			if (entry.isDirectory()) {
				createContainer(path);
			} else
			{
				// Ensure the container structure for all levels above this is initialized
				// Once we hit a higher-level container that's already added we need go no further
				int pathSegmentCount = path.segmentCount();
				if (pathSegmentCount > 1) {
					createContainer(path.uptoSegment(pathSegmentCount - 1));
				}
				createFile(entry);
			}
		}
	}
	/**
	 * 
	 * @param pathname
	 * @return
	 */
	protected ZipEntry createContainer(IPath pathname) {
		ZipEntry existingEntry = (ZipEntry) directoryEntryCache.get(pathname);
		if (existingEntry != null) {
			return existingEntry;
		}

		ZipEntry parent;
		if (pathname.segmentCount() == 1) {
			parent = root;
		} else {
			parent = createContainer(pathname.removeLastSegments(1));
		}
		ZipEntry newEntry = new ZipEntry(pathname.toString());
		directoryEntryCache.put(pathname, newEntry);
		List childList = new ArrayList();
		children.put(newEntry, childList);

		List parentChildList = (List) children.get(parent);
		parentChildList.add(newEntry);
		return newEntry;
	}
	/**
	 * 
	 * @param entry
	 */
	protected void createFile(ZipEntry entry) {
		IPath pathname = new Path(entry.getName());
		ZipEntry parent;
		if (pathname.segmentCount() == 1) {
			parent = root;
		} else {
			parent = (ZipEntry) directoryEntryCache.get(pathname
					.removeLastSegments(1));
		}

		List childList = (List) children.get(parent);
		childList.add(entry);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#getRoot()
	 */
	public Object getRoot() {
		return root;
	}
	
	/**
	 * 
	 * @return
	 */
	public ZipFile getZipFile() {
		return zipFile;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#closeArchive()
	 */
	public boolean closeArchive(){
		try {
			getZipFile().close();
		} catch (IOException e) {
			return false;
		}
		return true;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#setStrip(int)
	 */
	public void setStrip(int level) {
		stripLevel = level;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.IArchiveProvider#getStrip()
	 */
	public int getStrip() {
		return stripLevel;
	}
}