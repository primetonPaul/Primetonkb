/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.runtime/src/com/primeton/studio/workbench/core/exception/ModelParseException.java,v
 * 1.1 2006/12/31 09:50:01 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2006-12-29
 **********************************************************************************************************************/

package com.primeton.studio.runtime.exception;

import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ��¼����ģ��ʱ���ֵ��쳣��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ModelParseException.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/01/22 02:35:03  wanglei
 * Update:���Ĺ��캯����
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 *
 */
public final class ModelParseException extends RuntimeException {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	private IResourceDelegate resourceDelegate;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param message
	 * @param cause
	 */
	public ModelParseException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param message
	 */
	public ModelParseException(String message) {
		super(message);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param cause
	 */
	public ModelParseException(Throwable cause) {
		super(cause);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param cause
	 * @param resourceDelegate
	 */
	public ModelParseException(Throwable cause, IResourceDelegate resourceDelegate) {
		super(cause);
		this.resourceDelegate = resourceDelegate;
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param message
	 * @param cause
	 * @param resourceDelegate
	 */
	public ModelParseException(String message, Throwable cause, IResourceDelegate resourceDelegate) {
		super(message, cause);
		this.resourceDelegate = resourceDelegate;
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param message
	 * @param resourceDelegate
	 */
	public ModelParseException(String message, IResourceDelegate resourceDelegate) {
		super(message);
		this.resourceDelegate = resourceDelegate;
	}

	/**
	 * @return the resourceDelegate
	 */
	public IResourceDelegate getResourceDelegate() {
		return this.resourceDelegate;
	}

}
