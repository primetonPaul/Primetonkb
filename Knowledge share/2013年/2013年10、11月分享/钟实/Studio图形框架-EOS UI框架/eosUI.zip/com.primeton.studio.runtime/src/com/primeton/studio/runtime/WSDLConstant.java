/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/WSDLConstant.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-5-30
 *******************************************************************************/


package com.primeton.studio.runtime;

import javax.xml.namespace.QName;
/**
 *
 * ���ƿռ䳣��.
 *
 * @author yangjun (mailto:yangjun@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: WSDLConstant.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/07/08 01:41:46  chenxp
 * Update:���ӳ���DESCRIPTION
 *
 * Revision 1.1  2008/07/04 11:43:11  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/03/25 00:56:19  chenxp
 * Update:����Server�˵������ع�WSDL�ļ����ɸ�ʽ
 *
 * Revision 1.1  2008/03/19 07:29:04  chenxp
 * Update:�ع�WSDL�ĸ�ʽ
 *
 * Revision 1.2  2007/10/23 07:06:11  chenxp
 * CodeReview:���ݱ���淶����ע�͡�
 *
 * Revision 1.1  2007/07/11 06:57:41  yangjun
 * Review:�����޸�
 *
 */
public class WSDLConstant{

	//Namespace URIs.
	public static final String NS_URI_EOS = "http://www.primeton.com/eos6";
	public static final String PREFIX_EOS = "eos";

	public static final String NS_URI_WSDL =  "http://schemas.xmlsoap.org/wsdl/";
	public static final String PREFIX_WSDL = "wsdl";

	public static final String NS_URI_XSD =  "http://www.w3.org/2001/XMLSchema";
	public static final String PREFIX_XSD = "xsd";

	public static final String NS_URI_EOS_JAVA = "http://www.primeton.com/eos6/java";
	public static final String PREFIX_EOS_JAVA = "eosjava";

	public static final QName Q_ELEM_EOS_DESCRIPTION = new QName(NS_URI_EOS, "Description");

	public static final QName Q_EOS6 = new QName(NS_URI_EOS, PREFIX_EOS);

	public static final String NS_PREFIX_WSDL_SOAP  = "wsdlsoap";
	public static final String URI_WSDL11_SOAP = "http://schemas.xmlsoap.org/wsdl/soap/";

	public static final String NS_PREFIX_SOAP_ENC   = "soapenc";

	public static final String URI_APACHE_SOAP = "http://xml.apache.org/xml-soap";
	public static final String NS_PREFIX_APACHE_SOAP = "apachesoap";

	public static final String URI_SDO_JAVA = "commonj.sdo/java";
	public static final String NS_PREFIX_SDO_JAVA = "sdoJava";

	//
    // SOAP-ENC Namespaces
    //
    public static final String URI_SOAP11_ENC =
                                "http://schemas.xmlsoap.org/soap/encoding/" ;
    public static final String URI_SOAP12_ENC =
                                   "http://www.w3.org/2003/05/soap-encoding";
    public static final String URI_SOAP12_NOENC =
                     "http://www.w3.org/2003/05/soap-envelope/encoding/none";

    public static final String TYPE_XSD = "xsdType";
    public static final String TYPE_JAVA = "javaType";
    public static final String TYPE_DATAENTITY = "dataEntity";

    public static final String IS_ARRAY = "isArray";

    public static final String DESCRIPTION = "description";

    /**
	 * ����ڵ�
	 */
	public static final String TYPE_SERVICE = "wsdl_service";

	/**
	 * wsdl:types�ж����type��Ӧ�Ľڵ����ͳ���
	 */
	public static final String TYPE_WSDLTYPE = RuntimeConstant.WSDL_TYPE;

	/**
	 * wsdl:porttype��ӦIType�����ͳ���
	 */
	public static final String TYPE_PORTTYPE = "wsdl_portType";

	/**
	 * ��Դ���ϵ����ͽڵ�(����Type�ĸ��ڵ�)
	 */
	public static final String NODE_TYPE_TYPES = "Types";

	/**
	 * ��Դ���ϵĶ˿����ͽڵ�(����portType�ĸ��ڵ�)
	 */
	public static final String NODE_TYPE_PORTTYPES = "PortTypes";

	/**
	 * ��Դ���ϵķ���ڵ�(����service�ĸ��ڵ�)
	 */
	public static final String NODE_TYPE_SERVICES = "Services";

	public static final String NODE_TYPE = "NodeType";

	/**
	 * service port��Ӧ�ڵ����ͳ���
	 */
	public static final String TYPE_PORT = "wsdl_port";

	public static final String SOAP_ADDRESS_LOCATION = "soap_address_location";
//
//	public static final String SOAP12_ADDRESS = "soap12:address";

	public static final String SOAP_ADDRESS = "address";

	public static final String SOAP_BINDING = "binding";

	public static final String SOAP_TARGET_NAMESPACE = "http://schemas.xmlsoap.org/wsdl/soap/";

	public static final String SOAP12_TARGET_NAMESPACE = "http://schemas.xmlsoap.org/wsdl/soap12/";

	public static final String MIME_NAMESPACE = "http://schemas.xmlsoap.org/wsdl/mime/";

	public static final String MIME_MULTIPARTRELATED = "multipartRelated";
}
