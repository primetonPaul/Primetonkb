/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/java/JavaResourceDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-30
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.java;

import java.io.File;

import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.resources.internal.base.AbstractResourceDelegate;

/**
 * Javaƽ̨�ļ��ӿڵĻ��ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaResourceDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 * Revision 1.2  2009/02/18 10:35:01  wanglei
 * Update:�������ɱ������Ҳ���ģ�͵�Bug��
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.9  2007/09/10 01:12:43  wanglei
 * Review:����equals��hashCode������
 *
 * Revision 1.8  2007/06/28 09:33:49  wanglei
 * Review:�������࣬��֧��getData��setData������
 *
 * Revision 1.7  2007/05/30 08:58:46  wanglei
 * Refactor:��ΪIResourceDelegate��getSource�ع���getSourceFolder��
 *
 * Revision 1.6  2007/05/08 09:03:03  wanglei
 * Refactor:��getSrcFolder��getSrcFolders���ĳ�getSourceFoder��getSourceFoders������
 *
 * Revision 1.5  2007/04/23 09:05:20  wanglei
 * Update:��ΪJavaResourceManager�ع��˼����������ƣ�����Ҫ���и��¡�
 *
 * Revision 1.4  2007/04/18 08:38:45  wanglei
 * Update:�����еķ������ö�ת����JavaResourceManager��������
 *
 * Revision 1.3  2007/04/05 01:07:00  wanglei
 * Add:������toString������
 *
 * Revision 1.2  2007/03/30 02:19:24  wanglei
 * Remove:ȥ����Ԫ���ݷ�����
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */
public abstract class JavaResourceDelegate extends AbstractResourceDelegate implements IResourceDelegate {
	private File file;

	/**
	 * ֱ�Ӵ����ļ���<BR>
	 *
	 * @param file
	 */
	public JavaResourceDelegate(File file) {
		super();
		this.file = file;
	}

	/**
	 * ֱ�Ӵ����ļ���<BR>
	 *
	 * @param fileName
	 */
	public JavaResourceDelegate(String fileName) {
		super();
		this.file = new File(fileName);
	}

	/**
	 * @return Returns the file.
	 */
	public File getFile() {
		return this.file;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean exists() throws ResourceException {
		return this.file.exists();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getFullPath() throws ResourceException {
		return this.file.getAbsolutePath();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getName() throws ResourceException {
		return this.file.getName();
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getParent() throws ResourceException {
		return JavaResourceManager.getInstance().getParent(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate getProject() throws ResourceException {
		return JavaResourceManager.getInstance().getProject(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProjectRelativePath() throws ResourceException {
		return JavaResourceManager.getInstance().getProjectRelativePath(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public IRootDelegate getRoot() throws ResourceException {
		return JavaResourceManager.getInstance().getRoot();
	}

	/**
	 * {@inheritDoc}
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return JavaResourceManager.getInstance().getSourceFolder(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getSourceRelativePath() throws ResourceException {
		return JavaResourceManager.getInstance().getSourceRelativePath(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public long getLastModified() {
		return this.file.lastModified();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProtocol() {
		return RuntimeConstant.JAVA;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isBinary() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (this.file == null) {
			return false;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		final JavaResourceDelegate other = (JavaResourceDelegate) obj;

		if (!ObjectUtils.equals(this.file, other.file)) {
			return false;
		}

		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.file == null) ? 0 : this.file.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		return this.file.getAbsolutePath();
	}
}
