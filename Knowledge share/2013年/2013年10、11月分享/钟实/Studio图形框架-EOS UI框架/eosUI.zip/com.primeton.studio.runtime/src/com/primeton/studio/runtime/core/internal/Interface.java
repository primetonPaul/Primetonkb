/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IInterface;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * �ӿ�ʵ����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: Interface.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/06/21 14:07:58  wanglei
 * Review:ȥ������Ҫ��import��
 *
 * Revision 1.2  2007/06/15 09:56:40  wanglei
 * Update:�����˹��캯����
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public class Interface extends Type implements IInterface {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public Interface() {
		super();
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param resource
	 * @param parent
	 */
	public Interface(IResourceDelegate resource, IEosElement parent) {
		super(resource, parent);
	}

}
