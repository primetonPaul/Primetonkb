/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/internal/NullAnalyser.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-6-4
 *******************************************************************************/

package com.primeton.studio.runtime.index.internal;

import java.io.IOException;
import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharTokenizer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;

/**
 * ����������������ΪEOS��ģ���ǲ���Ҫ���зִʡ�<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: NullAnalyser.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
public final class NullAnalyser extends Analyzer {

	private static final NullAnalyser instance = new NullAnalyser();

	/**
	 * @return Returns the instance.
	 */
	public static NullAnalyser getInstance() {
		return instance;
	}

	/**
	 *
	 */
	private NullAnalyser() {
		super();
	}

	public TokenStream tokenStream(String fieldName, Reader reader) {
		return new NullLowerLetterTokenizer(reader);
	}

	public TokenStream reusableTokenStream(String fieldName, Reader reader) throws IOException {
		Tokenizer tokenizer = (Tokenizer) getPreviousTokenStream();
		if (tokenizer == null) {
			tokenizer = new NullLowerLetterTokenizer(reader);
			setPreviousTokenStream(tokenizer);
		} else
			tokenizer.reset(reader);
		return tokenizer;
	}
}

class NullLowerLetterTokenizer extends CharTokenizer {

	/** Construct a new LetterTokenizer. */
	public NullLowerLetterTokenizer(Reader in) {
		super(in);
	}

	/** Collects only characters which satisfy
	 * {@link Character#isLetter(char)}.*/
	protected boolean isTokenChar(char c) {
		return true;
	}

	/** Collects only characters which satisfy
	 * {@link Character#isLetter(char)}.*/
	protected char normalize(char c) {
		return Character.toLowerCase(c);
	}
}
