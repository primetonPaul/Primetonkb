/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/util/PathUtil.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-5-30
 *******************************************************************************/

package com.primeton.studio.runtime.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;
import org.osgi.framework.Bundle;

/**
 * ��ȡ��ǰ�����װ·��������
 *
 * @author wengzr (mailto:wengzr@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: PathUtil.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.4  2009/05/15 04:36:32  lvyuan
 * BugFix:Bug18677 ���ʻ� �޸�by lvyuan
 *
 * Revision 1.3  2009/05/07 03:47:27  lvyuan
 * Update:����һ�����ʻ����߷���
 *
 * Revision 1.2  2009/04/22 06:40:15  wanglei
 * Update:������getPluginOSPath������
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/03/28 08:37:48  hongsq
 * Update:����һ������URL�ķ���
 *
 * Revision 1.5  2007/12/18 07:39:36  wanglei
 * Review:ʹ��FilenameUtils������PathUtil��
 *
 * Revision 1.4  2007/10/09 02:20:14  caiwei
 * review:�ϲ�PathUtil
 *
 * Revision 1.3  2007/07/04 04:01:03  yanfei
 * Update:removeFileExtension��������log.
 *
 * Revision 1.2  2007/06/22 11:18:40  yanfei
 * Update:�޸Ļ�ȡcomposite basename�ķ�����
 *
 * Revision 1.1  2007/05/31 05:45:19  wengzr
 * �ύCVS
 *
 * Revision 1.1  2007/05/30 08:56:08  wengzr
 * �ع�Template��ʵ��,�Ƴ�JETMETTER,�����Զ������class��ʽ
 * ����ģ����ģ����չ��,��������ʱClassLoader����
 *
 */
public class PathUtil {

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private PathUtil() {
	//Nothing to do
	}

	/**
	 * ���ص�ǰeclipse�İ�װĿ¼
	 * @return eclipse��װĿ¼
	 * @throws IOException
	 */
	public static String getEclipseHome() throws IOException {
		return FileLocator.toFileURL(Platform.getInstallLocation().getURL()).getFile();
	}

	/**
	 * �õ�ָ�������Ŀ¼��<BR>
	 *
	 * @param plugin
	 * @return
	 */
	public static String getPluginOSPathString(Plugin plugin) {
		return getPluginOSPathString(plugin, null);
	}

	/**
	 * �õ�ָ�������ָ��Ŀ¼��·����
	 *
	 * @param plugin
	 * @param subDirPath
	 * @return
	 */
	public static String getPluginOSPathString(Plugin plugin, String subDirPath) {
		IPath path = subDirPath == null ? getPluginOSPath(plugin, null) : getPluginOSPath(plugin, new Path(subDirPath));
		return path == null ? null : path.toString();
	}

	/**
	 * �õ�ָ�������ָ��Ŀ¼��·����
	 *
	 * @param pluginId �����ID��
	 * @param subDirPath
	 * @return
	 */
	public static String getPluginOSPath(String pluginId, String subDirPath) {
		URL platformContextURL = getPluginOSURL(pluginId, subDirPath);
		String fullPath = (new File(platformContextURL.getPath())).getAbsolutePath();
		IPath osPath = new Path(fullPath);

		return osPath.toString();
	}

	/**
	 * �õ�ָ�����·����
	 *
	 * @param pluginId �����ID��
	 * @param subDirPath
	 * @return
	 */
	public static String getPluginOSPath(String pluginId) {
		Bundle bundle = Platform.getBundle(pluginId);
		if (bundle == null) {
			return null;
		}

		URL installLocation = bundle.getEntry("/");
		URL local = null;

		try {
			local = FileLocator.toFileURL(installLocation);
			return local.getFile();
		} catch (Exception _ex) {
			return null;
		}
	}


	/**
	 * �õ�ָ�������ָ��Ŀ¼��·����
	 *
	 * @param pluginId �����ID��
	 * @param subDirPath
	 * @return
	 */
	public static URL getPluginOSURL(String pluginId, String subDirPath) {
		Bundle bundle = Platform.getBundle(pluginId);
		if (bundle == null) {
			return null;
		}

		URL installLocation = bundle.getEntry("/");
		URL local = null;
		URL platformContextURL = null;
		try {
			local = FileLocator.toFileURL(installLocation);

			platformContextURL = subDirPath == null ? local : new URL(local, subDirPath.toString());
		} catch (Exception _ex) {
			return null;
		}
		return platformContextURL;
	}

	/**
	 * ��ȡPlugin����·��
	 * @param thePlugin
	 * @param subDirPath
	 * @return
	 */
	public static IPath getPluginOSPath(Plugin thePlugin, IPath subDirPath) {
		IPath osPath = null;
		Bundle bundle = thePlugin.getBundle();
		if (bundle == null) {
			return null;
		}

		URL installLocation = bundle.getEntry("/");
		URL local = null;
		try {
			local = FileLocator.toFileURL(installLocation);

			URL platformContextURL = subDirPath == null ? local : new URL(local, subDirPath.toString());
			String fullPath = (new File(platformContextURL.getPath())).getAbsolutePath();
			osPath = new Path(fullPath);
		} catch (Exception e) {
			return null;
		}
		return osPath;
	}
	
	/**
	 * �Ȼ�ȡPlugin NL�µ�ָ��Ŀ¼�������Ŀ¼�����ڣ��򷵻�Ĭ�ϵ�Ŀ¼��<BR>
	 * @param thePlugin
	 * @param subDirPath
	 * @return
	 */
	public static String getPluginNLOSPath(String pluginId, Locale locale,String subDirPath) {
		if(locale ==null)
		{
			return getPluginOSPath(pluginId,subDirPath); 
		}
		else
		{  
			String nlPath = "nl/"+locale.getLanguage()+"/"+locale.getCountry();
			if(subDirPath == null){ 
				subDirPath = "";
			}
			String nlFilePath = getPluginOSPath(pluginId, nlPath + "/"+ subDirPath);
			if(nlFilePath == null  || !new File(nlFilePath).exists()){
				return getPluginOSPath(pluginId,subDirPath); 
			}
			else{
				return nlFilePath;
			}
		}
	}

	/**
	 * ��ȡ plugin .metadata Ŀ¼��ָ������Ŀ¼���ļ��ľ���·��
	 * ������ .metadata Ŀ¼, subPath = "/"
	 * @param plugin
	 * @param subPath
	 * @return
	 */
	public static String pluginMetadataPath(Plugin plugin, String subPath) {
		try {
			if (plugin == null) {
				return null;
			}
			String path = plugin.getStateLocation().toString();

			if (subPath == null || ".".equals(subPath) || "/".equals(subPath)) { //$NON-NLS-1$ //$NON-NLS-2$
				return path;
			}
			subPath = subPath.replace('/', File.separatorChar);
			return path + File.separator + subPath;
		} catch (Exception e) {
			return ""; //$NON-NLS-1$
		}
	}
}
