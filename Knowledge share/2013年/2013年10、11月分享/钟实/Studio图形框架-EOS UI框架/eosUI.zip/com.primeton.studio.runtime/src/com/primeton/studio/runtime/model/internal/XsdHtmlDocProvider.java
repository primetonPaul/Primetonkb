/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/XsdHtmlDocProvider.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-9-21
 *******************************************************************************/


package com.primeton.studio.runtime.model.internal;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * XSD�ļ���HtmlDocProvider
 *
 * @author Chenty (mailto:chenty@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: XsdHtmlDocProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/10/12 07:22:47  hongsq
 * BUG:19932
 * �����������⡿����ʵ����ʾ���ƹ��ʻ�����
 *
 * Revision 1.1  2009/09/21 11:45:21  chenty
 * BUG��20447
 * �������е�XSDʹ����ʾ������ʾ����ȷ.
 * 
 */
public class XsdHtmlDocProvider extends DefaultHtmlDocProvider {

	private static final XsdHtmlDocProvider INSTANCE = new XsdHtmlDocProvider();
	
	/**
	 * ˽�еĹ��캯��.
	 */
	private XsdHtmlDocProvider() {
		super();
	}
	
	@Override
	public int getChildType() {
		return IEosElement.FIELD;
	}

	@Override
	public String getKey(IEosElement element) {
		return element.getNamespace();
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.base.AbstractModelDocumentProvider#getDefaultContent(com.primeton.studio.runtime.core.IEosElement)
	 */
	@Override
	protected String getDefaultContent(IEosElement element) {
		return element.getDisplayName();
	}

	@Override
	public IFileDelegate getDocumentFile(IEosModel model) {
		
		return super.getDocumentFile(model);
	}
	
	/**
	 * ��ȡ����. 
	 * @return
	 */
	public static XsdHtmlDocProvider getInstance(){
		return INSTANCE;
	}
}
