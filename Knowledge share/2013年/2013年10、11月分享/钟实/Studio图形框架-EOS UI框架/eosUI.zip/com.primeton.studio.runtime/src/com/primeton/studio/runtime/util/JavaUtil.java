/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.util;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.runtime.core.internal.Type;

/**
 * �ṩJava��EOSԪģ�ͽ�����һЩ���ܺ�����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaUtil.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/10/24 08:55:51  wanglei
 * Add:�ύ��CVS��
 *
 */

public class JavaUtil {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	private JavaUtil() {
		super();
	}

	/**
	 * ��Ϊ��JDT��������֧��������жϡ�<BR>
	 *
	 * @param refactorType
	 */
	public static void refactor(Type refactorType) {

		String typeName = refactorType.getName();

		if (typeName.endsWith(IConstant.CLASS_ARRAY)) {
			String newTypeName = StringUtils.substringBeforeLast(typeName, IConstant.CLASS_ARRAY);

			Type componentType = new Type(refactorType.getResource(), refactorType);
			componentType.setName(newTypeName);
			refactorType.setComponentType(componentType);

			refactor(componentType);
		}
	}
}
