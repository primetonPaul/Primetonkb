/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.base;

import java.util.Collection;

import org.eclipse.core.runtime.Assert;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.IReference;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.model.IModelFactory;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * IReference�Ļ��ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractReference.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/04/14 10:17:42  wanglei
 * Jira:����EOSP-197��
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2007/12/17 05:33:38  wanglei
 * Add:����getReferenceFile��getReferenceModel����������
 *
 * Revision 1.7  2007/08/15 07:23:53  wanglei
 * Review:���ټ����Դ��parent��
 *
 * Revision 1.6  2007/06/28 09:21:35  wanglei
 * Review:�������getModel��setModel�ᵽ�����С�
 *
 * Revision 1.5  2007/06/22 08:40:35  wanglei
 * Review:ȥ��referenceName���Ժ�����getUsedTypes������
 *
 * Revision 1.4  2007/06/15 10:01:29  wanglei
 * Update:������Ĭ�Ϲ��캯����
 *
 * Revision 1.3  2007/06/15 09:43:40  wanglei
 * Update:�����˹��캯����
 *
 * Revision 1.2  2007/06/12 05:10:50  wanglei
 * Add:����getReferenceName��
 *
 * Revision 1.1  2007/06/04 06:39:02  wanglei
 * �ύ��CVS��
 *
 */

public abstract class AbstractReference extends AbstractEosElement implements IReference {

	private IFileDelegate referenceFile;

	private IEosModel model;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param resource
	 * @param parent
	 * @param type
	 */
	public AbstractReference(IResourceDelegate resource, IEosElement parent) {
		super(resource, parent);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param type
	 */
	public AbstractReference() {
		super(null, null);
	}

	/**
	 * {@inheritDoc}
	 */
	public IField[] getUsedFields() {
		Collection col = this.getChildrenOfType(FIELD);
		IField[] results = new IField[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IMethod[] getUsedMethods() {
		Collection col = this.getChildrenOfType(METHOD);
		IMethod[] results = new IMethod[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IType[] getUsedTypes() {
		Collection col = this.getChildrenOfType(TYPE);
		IType[] results = new IType[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkParent() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkResource() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosModel getReferenceModel() {

		//TODO ��δ���
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate getReferenceFile() {

		if (null == this.referenceFile) {
			this.referenceFile = this.findReferenceFile();
		}

		return this.referenceFile;
	}

	/**
	 * @return
	 */
	protected IFileDelegate findReferenceFile() {

		if (RuntimeConstant.JAVA.equals(this.getImplementationType())) {
			return null;
		}
		String name = this.getName();
		IModelFactory factory = RuntimeHelper.getModelFactory((IFileDelegate)this.getResource());
		Assert.isNotNull(factory, "the resource is not supported,please check there is a model for '" + name + "'");

		IResourceDelegate resourceDelegate = this.getResource();
		Assert.isNotNull(resourceDelegate, "the resource of the reference can't be null,please check your constructor.");

		IProjectDelegate project = resourceDelegate.getProject();
		String[] namespaces = factory.getPossibleNames(name);
		IFileDelegate file = RuntimeHelper.findFile(project, namespaces);
		return file;
	}

}
