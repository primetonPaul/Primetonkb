/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal;



import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IParameter;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: Parameter.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2008/12/29 10:25:51  chenxp
 * Update:ֻ���м򵥵�equalsSelf�Ƚϡ�
 *
 * Revision 1.2  2008/12/29 05:39:12  chenxp
 * Update:����equalsSelf����������������͵��жϡ�
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/06/15 10:01:29  wanglei
 * Update:������Ĭ�Ϲ��캯����
 *
 * Revision 1.3  2007/06/15 09:43:40  wanglei
 * Update:�����˹��캯����
 *
 * Revision 1.2  2007/04/27 10:12:50  wanglei
 * UnitTest:����������IEosElement��
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public class Parameter extends Field implements IParameter {

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param resource
	 * @param parent
	 * @param type
	 */
	public Parameter(IResourceDelegate resource, IEosElement parent, IType type) {
		super(resource, parent, type);
	}

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param type
	 */
	public Parameter(IType type) {
		super(type);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param type
	 */
	public Parameter() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public int getElementType() {
		return PARAMETER;
	}

	@Override
	public boolean equalsSelf(Object obj) {
		/** �����������Ƿ�ƥ�� **/
		if(!(obj instanceof Parameter))
			return false;
		
		Parameter other = (Parameter)obj;
		Type thisType = (Type)this.getDeclaringType();
		Type otherType = (Type)other.getDeclaringType();
		
		if(!otherType.equalsSelf(thisType))
			return false;
		
		return super.equalsSelf(obj);
	}

}
