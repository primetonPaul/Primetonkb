/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.internal;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.jdt.core.JavaModelException;

import xjavadoc.SourceSet;
import xjavadoc.XClass;
import xjavadoc.XExecutableMember;
import xjavadoc.XField;
import xjavadoc.XJavaDoc;
import xjavadoc.XParameter;
import xjavadoc.filesystem.FileSourceSet;

import com.eos.system.utility.ClassUtil;
import com.eos.system.utility.ObjectUtil;
import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.core.util.GenericUtil;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimePlugin;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.IParameter;
import com.primeton.studio.runtime.core.ISuperTypeReference;
import com.primeton.studio.runtime.core.base.AbstractEosElement;
import com.primeton.studio.runtime.core.internal.Field;
import com.primeton.studio.runtime.core.internal.Method;
import com.primeton.studio.runtime.core.internal.Parameter;
import com.primeton.studio.runtime.core.internal.Result;
import com.primeton.studio.runtime.core.internal.SuperTypeReference;
import com.primeton.studio.runtime.core.internal.Type;
import com.primeton.studio.runtime.exception.JavaException;
import com.primeton.studio.runtime.model.IJavaAnalyser;
import com.primeton.studio.runtime.model.internal.java.AnnotationProperty;
import com.primeton.studio.runtime.model.internal.java.AnnotationType;
import com.primeton.studio.runtime.model.java.IAnnotationType;
import com.primeton.studio.runtime.util.MethodParamHelper;

/**
 * ����Java����Ƶķ�������<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: DefaultJavaAnalyser.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.6  2010/04/28 06:09:58  wanglei
 * Jira:����EOSP-212��
 *
 * Revision 1.5  2010/04/16 07:51:28  chenxp
 * BUG: 25754
 *
 * Revision 1.4  2008/10/29 10:04:41  liu-jun
 * Bug:14100 [3028�汾��֤]�����������е������߼�û����ʾ���� commit by yangmd
 *
 * Revision 1.3  2008/10/21 09:14:32  liu-jun
 * Bug:13936 ���ҳ���������߼���������һ�������߼���studio����ʱ��������������߼��Ƿ�
 * ���ڡ��������ʹ����Class.forName����������߼���ʵ�����溬�о�̬��ʼ������
 * ��ִ�о�̬��ʼ�������������̬��ʼ�������׳����쳣���������ʧ�ܣ����ڱ���
 * ���ҳ���������߼����� commit by yangmd
 *
 * Revision 1.2  2008/08/11 10:21:41  yanfei
 * FixBug:11118 ��������ͼ�й������Ĺ�������ʾ����ʾ���ơ�����
 * 11223 ��������ͼ���еĻ�������������������߼�����Ϊ�䳤����ʱ��ʾ������
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.27  2008/06/12 04:48:18  yangmd
 * Update:�޸�һ������Խ���쳣��
 *
 * Revision 1.26  2008/06/12 03:00:18  yangmd
 * Update:����field��implementationTypeΪJava
 *
 * Revision 1.25  2008/06/12 02:29:26  yangmd
 * Update:����method��ImplementTypeΪJava
 *
 * Revision 1.24  2008/06/12 02:24:02  yangmd
 * Update:����Method����ʾ����
 *
 * Revision 1.23  2008/05/10 08:18:09  yangmd
 * Update:����int��������
 *
 * Revision 1.22  2008/05/06 03:36:53  yangmd
 * Update:���������䳤�����
 *
 * Revision 1.21  2008/05/05 09:27:21  yangmd
 * Update:�޸�������ȷ����javadoc��bug
 *
 * Revision 1.20  2008/04/22 11:27:06  yangmd
 * Update:1.�޸�������ȷ��ȡjavadoc��bug;2.��ʽ��javadoc
 *
 * Revision 1.19  2008/03/07 07:42:48  yangmd
 * Update:�޸�classȡ���ƵĴ���Ӧ����getCanonicalName()������getName()
 *
 * Revision 1.18  2008/02/22 09:54:22  yangmd
 * Update:�ع�
 *
 * Revision 1.17  2008/02/22 09:51:49  yangmd
 * Update:��ȡ�����е�����
 *
 * Revision 1.16  2008/02/22 05:14:26  yangmd
 * Update:�޸��������ʱ������ƥ��Method��bug
 *
 * Revision 1.15  2008/02/21 10:41:52  yangmd
 * Update:ʵ�������߼��鿴JavaDoc��Ϣ����
 *
 * Revision 1.14  2008/02/21 07:27:36  yangmd
 * Update:֧�ֻ�ȡ�ĵ���Ϣ����
 *
 * Revision 1.13  2007/12/20 08:47:26  chenxp
 * Update:ΪResult��Parameter����implementationTypeֵ
 *
 * Revision 1.12  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.11  2007/12/18 06:43:54  wanglei
 * Review:����EOC�ĵ��������޸ġ�
 *
 * Revision 1.10  2007/11/28 09:18:24  chenxp
 * Update:����isInterface�����ж��Ƿ��ǽӿڡ�
 *
 * Revision 1.9  2007/10/31 08:31:44  wanglei
 * Add:�����˶�Annotation��֧�֡�
 *
 * Revision 1.8  2007/09/28 07:38:20  wanglei
 * Review:����IJavaAnalyser��ʵ�֣�֧�ִ��븸�ס�
 *
 * Revision 1.7  2007/09/17 02:09:02  wanglei
 * Review:Server�����ع������µ����������ݡ�
 *
 * Revision 1.6  2007/09/13 01:49:04  wanglei
 * Review:ȥ����org.eclipse.jdt.core�е�JavaModelException��������
 *
 * Revision 1.5  2007/09/10 05:46:17  wanglei
 * Review:û����ȷ������Ӧ�Ľӿ����ݡ�
 *
 * Revision 1.4  2007/08/23 06:41:02  wanglei
 * UnitTest:�������ʹ����Ĵ���
 *
 * Revision 1.3  2007/08/15 07:17:11  wanglei
 * Update:������ɹ��ܡ�
 *
 * Revision 1.2  2007/07/23 09:32:03  wanglei
 * Review:������Ҫ�Ƴ����õ�getImportReferences��
 *
 * Revision 1.1  2007/07/02 03:41:49  wanglei
 * �ύ��CVS��
 *
 */
public class DefaultJavaAnalyser implements IJavaAnalyser {

	private Class clazz;

	private String[] srcDirList;
	/**
	 *
	 */
	private static final Map<String,Class> primitiveType = new HashMap<String, Class>();
	static{
		primitiveType.put("byte", byte.class);
		primitiveType.put("int", int.class);
		primitiveType.put("short", short.class);
		primitiveType.put("char", char.class);
		primitiveType.put("long", long.class);
		primitiveType.put("float", float.class);
		primitiveType.put("double", double.class);
		primitiveType.put("boolean", boolean.class);
		primitiveType.put("void", void.class);
	}
	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param aClazz
	 */
	public DefaultJavaAnalyser(Class aClazz, String[] srcDirList) {
		super();
		this.clazz = aClazz;
		this.srcDirList = srcDirList;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getClassName() {
		return this.clazz.getName();
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.IJavaAnalyser#isInterface()
	 */
	public boolean isInterface() {
		return this.clazz.isInterface();
	}

	/**
	 * {@inheritDoc}
	 */
	public IField[] getDeclaredFields(IEosElement parent) {
		java.lang.reflect.Field[] javaFields = this.clazz.getDeclaredFields();
		return copy(parent, javaFields);
	}

	/**
	 * @param parent
	 * @param javaFields
	 * @return
	 */
	private IField[] copy(IEosElement parent, java.lang.reflect.Field[] javaFields) {
		if (ArrayUtils.isEmpty(javaFields)) {
			return new IField[0];
		}

		IField[] fields = new IField[javaFields.length];
		for (int i = 0; i < javaFields.length; i++) {
			java.lang.reflect.Field javaField = javaFields[i];
			fields[i] = this.copy(parent, javaField);
		}

		return fields;
	}

	/**
	 * ��Java���ֶ�Ԫ������Ϣ���Ƶ�EOS�ֶ���Ϣ�С�<BR>
	 *
	 * @param parent
	 * @param javaField
	 * @return
	 */
	private IField copy(IEosElement parent, java.lang.reflect.Field javaField) {
		Field field = null;

		if (null == parent) {
			field = new Field();
		}
		else {
			field = new Field(parent.getResource(), parent, null);
		}

		field.setName(javaField.getName());
		field.setModel(field);

		this.updateModifier(field.getModifier(), field);

		Type fieldType = new Type();
		this.refactor(javaField.getType(), javaField.getGenericType(), fieldType);
		field.setDeclaringType(fieldType);
		field.setImplementationType(RuntimeConstant.JAVA);
		return field;
	}

	/**
	 * ������һ��������Ӧ���������ݡ�<BR>
	 *
	 * @param genericType
	 * @param componentType
	 */
	private void refactor(Class refactorClass, java.lang.reflect.Type genericType, Type refactorType) {

		if (null == refactorClass) {
			refactorType.setName("void");
			return;
		}

		String name;
		//System.err.println("genericType  "+genericType.getClass());

		if (!(genericType instanceof Class)) {
			name = GenericUtil.getName(refactorClass, genericType);
			//����з���
			//���ù�����ȡ��ȫ����<BR>
		}
		else {
			Class componentClass = refactorClass;
			name = ClassUtil.getQualifiedName(componentClass);

			//System.err.println("componentClass:  "+ componentClass + "  name: " + name);
		}

		refactorType.setName(name);

		Type parentType = refactorType;

		while (name.endsWith(IConstant.CLASS_ARRAY)) {
			Type componentType = new Type(parentType.getResource(), parentType);
			name = StringUtils.substringBeforeLast(name, IConstant.CLASS_ARRAY);
			componentType.setName(name);

			parentType = componentType;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IMethod[] getDeclaredMethods(IEosElement parent) {
		java.lang.reflect.Method[] javaMethods = this.clazz.getDeclaredMethods();
		return copy(parent, javaMethods);
	}

	/**
	 * @param parent
	 * @param javaMethods
	 * @return
	 */
	private IMethod[] copy(IEosElement parent, java.lang.reflect.Method[] javaMethods) {
		if (ArrayUtils.isEmpty(javaMethods)) {
			return new IMethod[0];
		}
		XClass xclass = this.getXClass();
		IMethod[] methods = new IMethod[javaMethods.length];
		for (int i = 0; i < javaMethods.length; i++) {
			java.lang.reflect.Method method = javaMethods[i];
			methods[i] = this.copy(parent, method, xclass);
		}

		return methods;
	}

	/**
	 *
	 * @param parent
	 * @param javaMethod
	 * @param xclass
	 * @return
	 */
	private IMethod copy(IEosElement parent, java.lang.reflect.Method javaMethod, XClass xclass) {

		Method method = null;

		if (null == parent) {
			method = new Method();
		}
		else {
			method = new Method(parent.getResource(), parent);
		}
		method.setName(javaMethod.getName());
		String simpleName = getSimpleName(javaMethod);
		method.setDisplayName(simpleName);
		method.setImplementationType(RuntimeConstant.JAVA);
		method.setModel(javaMethod);

		if (javaMethod.isVarArgs()) {
			method.setVariable(true);
		}

		this.updateModifier(javaMethod.getModifiers(), method);

		Class returnClass = javaMethod.getReturnType();

		Type eosReturnType = new Type();
		this.refactor(returnClass, javaMethod.getGenericReturnType(), eosReturnType);

		Result result = new Result(null, method, eosReturnType);
		method.addChild(result);
		result.setImplementationType("Java");

		Class[] parameterTypes = javaMethod.getParameterTypes();
		java.lang.reflect.Type[] javaTypes = javaMethod.getGenericParameterTypes();

		if (!ArrayUtils.isEmpty(parameterTypes)) {
			MethodParamHelper.Param[] params = null;

			if(xclass == null){
				params = MethodParamHelper.getParams(javaMethod);
			} else {
				params = MethodParamHelper.getParams(javaMethod,xclass);
			}

			for (int i = 0; i < params.length; i++) {

				Class parameterClass = params[i].getParamType();

				Type eosParameterType = new Type();
				eosParameterType.setName(params[i].getName());

				Parameter parameter = new Parameter(null, method, eosParameterType);
				parameter.setName(params[i].getName());

				this.refactor(parameterClass, javaTypes[i], eosParameterType);

				parameter.setDeclaringType(eosParameterType);
				parameter.setImplementationType("Java");

				method.addChild(parameter);
			}
		}

		return method;
	}

	/**
	 * @param javaMethod
	 * @return
	 */
	private String getSimpleName(java.lang.reflect.Method javaMethod) {
		StringBuffer strBuffer = new StringBuffer(javaMethod.getName());
		strBuffer.append('(');
		Class[] clazzs = javaMethod.getParameterTypes();
		for (int i = 0; i < clazzs.length; i++) {
			Class class1 = clazzs[i];
			strBuffer.append(class1.getSimpleName());
			strBuffer.append(',');
		}
		if(clazzs.length > 0){
			strBuffer.deleteCharAt(strBuffer.length()-1);
		}
		strBuffer.append(')');
		String simpleName = strBuffer.toString();
		return simpleName;
	}

	/**
	 * ������Ӧ�ķ��ʼ���<BR>
	 *
	 * @param member
	 * @param element
	 * @throws JavaModelException
	 */
	private void updateModifier(int flags, AbstractEosElement element) {

		if ((flags & java.lang.reflect.Modifier.PUBLIC) != 0) {
			element.setModifier(IEosElement.PUBLIC_MODIFIER);
			return;
		}

		if ((flags & java.lang.reflect.Modifier.PRIVATE) != 0) {
			element.setModifier(IEosElement.PRIVATE_MODIFIER);
			return;
		}

		if ((flags & java.lang.reflect.Modifier.PROTECTED) != 0) {
			element.setModifier(IEosElement.PROTECTED_MODIFIER);
			return;
		}

		element.setModifier(IEosElement.PACKAGE_MODIFIER);
	}

	/**
	 * {@inheritDoc}
	 */
	public IField getField(IEosElement parent, String fieldName) {

		java.lang.reflect.Field javaField = ClassUtil.getField(this.clazz, fieldName);

		if (null == javaField) {
			return null;
		}
		else {
			return this.copy(parent, javaField);
		}

	}

	/**
	 * {@inheritDoc}
	 */
	public IField[] getFields(IEosElement parent) {
		java.lang.reflect.Field[] javaFields = this.clazz.getFields();
		return copy(parent, javaFields);
	}

	/**
	 * {@inheritDoc}
	 */
	public IMethod getMethod(IEosElement parent, String method, String[] parameters) {

		Class[] classes = null;
		if (!ArrayUtils.isEmpty(parameters)) {
			classes = new Class[parameters.length];
			for (int i = 0; i < classes.length; i++) {
				try {
					String className = formatName(parameters[i]);
					Class primitiveClass = primitiveType.get(className);
					if(primitiveClass != null){
						classes[i] = primitiveClass;
					} else {
						classes[i] = Class.forName(className, false, this.getClass().getClassLoader());
					}
				} catch (ClassNotFoundException e) {
					return null;
				} catch (NoClassDefFoundError e) {
					return null;
				} catch(ExceptionInInitializerError e){
					return null;
				} catch (LinkageError e){
					return null;
				}
			}
		}
		XClass xclass = this.getXClass();
		java.lang.reflect.Method javaMethod = ClassUtil.getMethod(this.clazz, method, classes);
		return this.copy(parent, javaMethod,xclass);

	}

	/**
	 * {@inheritDoc}
	 */
	public IMethod[] getMethods(IEosElement parent) {
		java.lang.reflect.Method[] javaMethods = this.clazz.getMethods();
		return copy(parent, javaMethods);
	}

	/**
	 * {@inheritDoc}
	 */
	public ISuperTypeReference[] getSuperTypeReferences(IEosElement parent) {

		List list = new ArrayList();

		List classList = ClassUtils.getAllSuperclasses(this.clazz);
		for (int i = 0; i < classList.size(); i++) {
			Class superClass = (Class) classList.get(i);
			SuperTypeReference superTypeReference = new SuperTypeReference();
			superTypeReference.setName(superClass.getCanonicalName());
			superTypeReference.setSuperType(ISuperTypeReference.IMPLEMENTATION_SUPER_TYPE);

			list.add(superTypeReference);
		}

		List interfaceList = ClassUtils.getAllInterfaces(this.clazz);
		for (int i = 0; i < interfaceList.size(); i++) {
			Class superClass = (Class) interfaceList.get(i);
			SuperTypeReference superTypeReference = new SuperTypeReference();
			superTypeReference.setName(superClass.getCanonicalName());
			superTypeReference.setSuperType(ISuperTypeReference.INTERFACE_SUPER_TYPE);

			list.add(superTypeReference);
		}

		ISuperTypeReference[] results = new ISuperTypeReference[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IAnnotationType[] getClassAnnotationTypes() {

		Annotation[] annotations = this.clazz.getDeclaredAnnotations();

		if (ArrayUtils.isEmpty(annotations)) {
			return IAnnotationType.NUL_TYPES;
		}

		IEosElement parent = this.createParent();
		List list = new ArrayList(5);

		this.computeAnnotations(annotations, parent, list);

		return convertResults(list);
	}

	/**
	 * @param list
	 * @return
	 */
	private IAnnotationType[] convertResults(List list) {
		AnnotationType[] types = new AnnotationType[list.size()];
		list.toArray(types);
		return types;
	}

	/**
	 * �������Annotation��<BR>
	 *
	 * @param annotations
	 * @param parent
	 * @param list
	 */
	private void computeAnnotations(Annotation[] annotations, IEosElement parent, List list) {
		XClass xclass = this.getXClass();
		for (int i = 0; i < annotations.length; i++) {
			Annotation annotation = annotations[i];
			Class annotationClass = annotation.annotationType();
			String name = annotationClass.getName();

			AnnotationType type = new AnnotationType(name, name);

			java.lang.reflect.Method[] methods = annotationClass.getDeclaredMethods();
			for (int j = 0; j < methods.length; j++) {
				java.lang.reflect.Method method = methods[j];
				String methodName = method.getName();
				AnnotationProperty property = new AnnotationProperty(methodName, methodName);

				property.setElement(this.copy(parent, method,xclass));

				try {
					Object value = method.invoke(annotation, ObjectUtil.NULL_OBJECTS);
					property.setValue(value);
				} catch (IllegalArgumentException e) {
					throw new JavaException(e);
				} catch (IllegalAccessException e) {
					throw new JavaException(e);
				} catch (InvocationTargetException e) {
					throw new JavaException(e);
				}

				type.addProperty(property);
			}

			list.add(type);
		}
	}

	private IEosElement createParent() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IAnnotationType[] getAllAnnotationTypes() throws JavaException {
		Annotation[] annotations = this.clazz.getDeclaredAnnotations();

		IEosElement parent = this.createParent();
		List list = new ArrayList(5);

		if (!ArrayUtils.isEmpty(annotations)) {
			this.computeAnnotations(annotations, parent, list);
		}

		this.doGetAllFieldAnnotationTypes(parent, list);
		this.doGetAllMethodAnnotationTypes(parent, list);

		return convertResults(list);
	}

	/**
	 * {@inheritDoc}
	 */
	public IAnnotationType[] getAllFieldAnnotationTypes() throws JavaException {
		IEosElement parent = this.createParent();
		List list = new ArrayList(5);

		doGetAllFieldAnnotationTypes(parent, list);

		return convertResults(list);
	}

	/**
	 * @param parent
	 * @param list
	 */
	private void doGetAllFieldAnnotationTypes(IEosElement parent, List list) {
		java.lang.reflect.Field[] fields = this.clazz.getFields();

		for (int i = 0; i < fields.length; i++) {
			java.lang.reflect.Field field = fields[i];
			Annotation[] annotations = field.getDeclaredAnnotations();

			if (ArrayUtils.isEmpty(annotations)) {
				continue;
			}

			this.computeAnnotations(annotations, parent, list);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IAnnotationType[] getAllMethodAnnotationTypes() throws JavaException {
		IEosElement parent = this.createParent();
		List list = new ArrayList(5);

		doGetAllMethodAnnotationTypes(parent, list);

		return convertResults(list);
	}

	/**
	 * @param parent
	 * @param list
	 */
	private void doGetAllMethodAnnotationTypes(IEosElement parent, List list) {
		java.lang.reflect.Method[] methods = this.clazz.getMethods();

		for (int i = 0; i < methods.length; i++) {
			java.lang.reflect.Method method = methods[i];
			Annotation[] annotations = method.getDeclaredAnnotations();

			if (ArrayUtils.isEmpty(annotations)) {
				continue;
			}

			this.computeAnnotations(annotations, parent, list);
		}
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.IJavaAnalyser#getJavaDocForClass()
	 */
	public String getJavaDocForClass() throws JavaException {
		XClass xClazz = getXClass();
		if(xClazz == null)return null;
		return DefaultJavaDocHelper.getJavadoc(xClazz);
	}
	/**
	 *
	 *
	 * @return
	 */
	private XClass getXClass() {
		File file = this.getJavaSrc();
		if(file == null){
			return null;
		}
		SourceSet sourceSet = new FileSourceSet(file);
		XJavaDoc javaDoc = new XJavaDoc();
		javaDoc.addSourceSet(sourceSet);
		XClass xClazz = javaDoc.getXClass(this.clazz.getSimpleName());
		return xClazz;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.IJavaAnalyser#getJavaDocForField(com.primeton.studio.runtime.core.IField)
	 */
	public String getJavaDocForField(IField field) throws JavaException {
		XClass xClazz = this.getXClass();
		if(xClazz == null){
			return null;
		}
		XField xField = xClazz.getField(field.getName());
		if(xField == null){
			return null;
		}
		return DefaultJavaDocHelper.getJavadoc(xField);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.IJavaAnalyser#getJavaDocForMethod(com.primeton.studio.runtime.core.IMethod)
	 */
	public String getJavaDocForMethod(IMethod method) throws JavaException {
		IParameter[] parameters = method.getParameters();
		XClass xClazz = this.getXClass();
		if(xClazz == null){
			return null;
		}
		List<XExecutableMember> methods = new ArrayList<XExecutableMember>();
		methods.addAll(xClazz.getMethods());
		methods.addAll(xClazz.getConstructors());
		XExecutableMember xmethod = null;
		boolean equals = true;
		out: for (Iterator iter = methods.iterator(); iter.hasNext();) {
			equals = true;
			XExecutableMember xmethodtemp = (XExecutableMember) iter.next();
			String xMethodName = xmethodtemp.getName();
			String methodName = method.getName();
			List list = xmethodtemp.getParameters();
			int size = list.size();
			if(xMethodName.equals(methodName) && parameters.length == size){
				if(size == 0){
					xmethod = xmethodtemp;
					break out;
				}
				boolean isVar = method.isVariable();
				for (int i = 0; i < size; i++) {
					XParameter element = (XParameter)list.get(i);
					String dimension = element.getDimensionAsString();
					String tempStr = element.getType().getTransformedQualifiedName();
					tempStr = tempStr + dimension;
					String typeName = parameters[i].getDeclaringType().getName();
					typeName = StringUtils.substringBefore(typeName, "<");
					if(i == size - 1 && isVar && (typeName.endsWith("...") || !typeName.endsWith("[]"))){
						typeName = StringUtils.substringBeforeLast(typeName, "...");
						typeName = typeName + "[]";
					}
					if(!tempStr.equals(typeName)){
						equals = false;
						continue out;
					}
				}
				if(equals){
					xmethod = xmethodtemp;
					break out;
				}
			}
		}
		if(xmethod != null){
			return DefaultJavaDocHelper.getJavadoc(xmethod);
		}
		return null;
	}

	/**
	 *
	 * @return
	 */
	private File getJavaSrc(){
		//����������� TODO
//		if(this.clazz.isArray()){
//			java.lang.Object
//		}
		String className = this.clazz.getCanonicalName();
		String fileSeparator = System.getProperty("file.separator");
		if(fileSeparator == null || "".equals(fileSeparator)){
			fileSeparator = File.separator;
		}
		className = StringUtils.replace(className, ".", fileSeparator);
		int index = className.indexOf('$');
		if(index > 0){
			className = className.substring(index);
		}
		className = className + ".java";
		for (int i = 0; i < srcDirList.length; i++) {
			String temp = srcDirList[i].trim();
			StringBuilder strbuilder = new StringBuilder(temp);
			if(temp.endsWith("/")){
				strbuilder.append(className);
			} else {
				strbuilder.append(File.separatorChar).append(className);
			}
			File file = new File(strbuilder.toString());
			if(file.exists()){
				return file;
			}
		}
		return null;
	}
	/**
	 * ��classNameת��Ϊ�ײ����ƣ�<br>
	 * ȡ�õ����ƾ���μ�<code>java.lang.Class#getName(String)</code>;
	 * @param className �����ǵײ����ƻ��߾��Ǳ�׼���ƣ�����Ǳ�׼���Ʋ���������Ļ���<br>
	 * 					className Ӧ���� java.lang.String[]��������ʽ����[���͡�]��Ӧ���ǳɶԳ��֡�
	 * @return ����java�ײ��ʾ�����ơ�
	 */
	private static final String formatName(String className){
		if(className == null)return null;
		if(className.indexOf('<') > 0){//�����ݴ������������ǲ���������<�ģ����͵Ĵ�����
			className = StringUtils.substringBefore(className, "<") +
			StringUtils.substringAfterLast(className, ">");
		}
		if(className.indexOf(']') > 0){
			StringBuffer strBuffer = new StringBuffer();
			String notArrayName = StringUtils.substringBefore(className, "[");
			Class primitiveClazz = primitiveType.get(notArrayName);
			strBuffer.append(notArrayName);
			final String objArrayEx = primitiveClazz != null?"":"L";
			strBuffer.insert(0,objArrayEx);
			String arrayId = "["+StringUtils.substringAfter(className, "[");
			int araycout = StringUtils.countMatches(arrayId, "[]");
			for (int i = 0; i < araycout; i++) {
				strBuffer.insert(0, '[');
			}
			className = strBuffer.toString();
		}
		return className;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public Object getFieldValue(IField field) {
		try {
			java.lang.reflect.Field javaField = this.clazz.getField(field.getName());
			if(Modifier.isStatic(javaField.getModifiers())){
				return javaField.get(null);
			}

		} catch (Exception e) {
			ExceptionUtil.getInstance().logException(e);
		}
		return null;
	}
}
