/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/internal/JavaFieldSeparatorPolicy.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.internal;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.model.IJavaAnalyser;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.separatoranalyser.DefaultSeparatorPolicy;
import com.primeton.studio.runtime.separatoranalyser.SeparatorModel;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: JavaFieldSeparatorPolicy.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2008/07/09 10:50:45  yangmd
 * Update:�ع���
 *
 * Revision 1.2  2008/07/08 13:22:25  yangmd
 * Update:������������
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:46  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.2  2008/05/23 01:36:39  yangmd
 * Update:������ʵ��������⴦��
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class JavaFieldSeparatorPolicy extends DefaultSeparatorPolicy{
	private IProjectDelegate project;
	
	private short pojoMehod = NONE;
	
	public static final short GET = 1;
	
	public static final short SET = 2;
	
	public static final short ALL = 3;
	
	public static final short NONE = 4;
	
	public static final short ONLY_ONE = 5;
	/**
	 * 
	 * @param project
	 * @param separator
	 */
	public JavaFieldSeparatorPolicy(IProjectDelegate project, String separator) {
		super(separator);
		this.project = project;
	}
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.DefaultSeparatorPolicy#accept(com.primeton.studio.runtime.helper.SeparatorModel)
	 */
	@Override
	public boolean accept(SeparatorModel separatorModel) {
		Object model = separatorModel.getThisModel();
		if(model instanceof IField){
			IField field = (IField)model;
			return filteField(separatorModel, field);
		}
		return super.accept(separatorModel);
	}
	/**
	 * @param separatorModel
	 * @param field
	 */
	protected boolean filteField(SeparatorModel separatorModel, IField field) {
		if(IField.PUBLIC_MODIFIER == field.getModifier()){
			return true;
		} else {
			if(this.pojoMehod == NONE){
				return true;
			}
			SeparatorModel backSepModel = separatorModel.getBackSeparatorModel();
			if(backSepModel != null){
				return filteField(field, backSepModel);
			}
		}
		return true;
	}
	/**
	 * @param field
	 * @param backSepModel
	 * @return
	 */
	private boolean filteField(IField field, SeparatorModel backSepModel) {
		Object model;
		model = backSepModel.getThisModel();
		IJavaAnalyser javaAnalyser = null;
		if(model instanceof IEosElement){
			IType type = null;
			if(model instanceof IType){
				type = (IType) model;
			} else if(model instanceof IField){
				field = (IField)model;
				type = field.getDeclaringType();
			}
			if(type != null){
				String name = type.getName();
				name = StringUtils.substringBefore(name, "<");
				name = StringUtils.substringBefore(name, "[");
				javaAnalyser = RuntimeHelper.createJavaAnalyser(project, name);
			}
		} else if(model instanceof IJavaAnalyser){
			javaAnalyser = (IJavaAnalyser) model;
		}
		if(javaAnalyser == null){
			return false;
		} else {
			return filteField(field, javaAnalyser);
		}
	}
	/**
	 * 
	 * @param field
	 * @param javaAnalyser
	 * @return
	 */
	private boolean filteField(IField field, IJavaAnalyser javaAnalyser) {
		if(field.getModifier() == IEosElement.PUBLIC_MODIFIER){
			return true;
		}
		IMethod[] methods = javaAnalyser.getMethods(null);
		String fieldName = field.getName();
		String lastName = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1, fieldName.length());
		lastName = lastName.trim();
		String getMethodName = "get" + lastName;
		String name = field.getDeclaringType().getName();
		if(Boolean.class.getName().equals(name) 
				|| boolean.class.getName().equals(name)){
			getMethodName = "is"+lastName;
		}
		String setMethodName = "set" + lastName;
		
		switch (pojoMehod) {
		case GET:
			return hasMethod(methods, getMethodName);
		case SET:
			return hasMethod(methods, setMethodName);
		case ALL:
			return hasMethod(methods, getMethodName) && hasMethod(methods, setMethodName);
		case ONLY_ONE:
			return hasMethod(methods, getMethodName) || hasMethod(methods, setMethodName);
		default:
			return true;
		}
	}
	/**
	 * 
	 * @param methods
	 * @param methodName
	 * @return
	 */
	private boolean hasMethod(IMethod[] methods, String methodName){
		for (int i = 0; i < methods.length; i++) {
			IMethod method = methods[i];
			if(method.getName().equals(methodName)){
				return true;
			}
		}
		return false;
	}
	/**
	 * @return Returns the pojoMehod.
	 */
	public short getPojoMehod() {
		return pojoMehod;
	}
	/**
	 * @param pojoMehod The pojoMehod to set.
	 */
	public void setPojoMehod(short pojoMehod) {
		this.pojoMehod = pojoMehod;
	}
	
}
