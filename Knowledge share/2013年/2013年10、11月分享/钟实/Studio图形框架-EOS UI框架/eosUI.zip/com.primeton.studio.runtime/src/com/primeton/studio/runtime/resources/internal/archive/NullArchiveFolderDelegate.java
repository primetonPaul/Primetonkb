/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.archive;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * Ϊ�˷�ֹ����Ҫ��NPE������д������࣬�����������ⷵ��ֵΪnull�����⡣<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: NullArchiveFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.2  2007/11/06 07:17:13  chenxp
 * CodeReview:����exists����
 *
 * Revision 1.1  2007/07/05 06:57:43  wanglei
 * �ύ��CVS��
 *
 */

public class NullArchiveFolderDelegate extends ArchiveResourceDelegate implements IFolderDelegate {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param rootFile
	 * @param path
	 */
	public NullArchiveFolderDelegate(ArchiveRootFileDelegate rootFile, String path) {
		super(rootFile, path);
	}

	/**
	 * {@inheritDoc}
	 */
	public IResourceDelegate[] getChildren() {
		return IResourceDelegate.NO_RESOURCES;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate getFile(String path) {
		String fullPath = this.getPath() + path;
		fullPath = FilenameUtil.normalizeInUnixStyle(fullPath);
		return new NullArchiveFileDelegate(this.getArchiveFile(), fullPath);
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getFolder(String path) {
		String fullPath = this.getPath() + path;
		fullPath = FilenameUtil.normalizeInUnixStyle(fullPath);
		return new NullArchiveFolderDelegate(this.getArchiveFile(), fullPath);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isPrefixOf(IResourceDelegate resourceDelegate) {
		if ((resourceDelegate instanceof NullArchiveFolderDelegate) || (resourceDelegate instanceof NullArchiveFileDelegate)) {
			ArchiveResourceDelegate archiveResource = (ArchiveResourceDelegate) resourceDelegate;
			if (!(archiveResource.getArchiveFile() == this.getArchiveFile())) {
				return false;
			}

			String folderPath = this.getFullPath();
			String resourcePath = archiveResource.getFullPath();

			return (folderPath.length() != resourcePath.length()) && resourcePath.startsWith(folderPath);
		}
		else {
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int getType() throws ResourceException {
		return FOLDER;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean exists() throws ResourceException {
		return false;
	}

}
