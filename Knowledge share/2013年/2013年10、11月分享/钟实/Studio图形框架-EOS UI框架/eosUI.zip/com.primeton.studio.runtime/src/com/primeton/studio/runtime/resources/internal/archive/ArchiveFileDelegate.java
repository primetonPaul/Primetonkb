/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.archive;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ������ʾѹ������һ���ļ���㵽�ļ���Դ��ӳ�䡣<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ArchiveFileDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/06/28 09:29:20  wanglei
 * UnitTest:getContents���ص�InputStream��Ҫreset��
 *
 * Revision 1.1  2007/06/26 07:53:56  wanglei
 * �ύ��CVS��
 *
 */

public class ArchiveFileDelegate extends ArchiveResourceDelegate implements IFileDelegate {

	private InputStream contents;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param rootFile
	 * @param path
	 */
	public ArchiveFileDelegate(ArchiveRootFileDelegate rootFile, String path) {
		super(rootFile, path);

		String fullPath = FilenameUtils.getFullPath(path);
		String name = StringUtils.removeStart(path, fullPath);
		this.setName(name);
	}

	/**
	 * {@inheritDoc}
	 */
	public int getType() throws ResourceException {
		return IResourceDelegate.FILE;
	}

	/**
	 * {@inheritDoc}
	 */
	public void create(InputStream inputStream) {
		throw new UnsupportedOperationException("The operation of 'create' is not supported yet.");
	}

	/**
	 * {@inheritDoc}
	 */
	public InputStream getContents() throws ResourceException {
		try {
			this.contents.reset();
		} catch (IOException e) {
			//Nothing to do
		}

		return this.contents;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getExtension() {
		return FilenameUtils.getExtension(this.getName());
	}

	/**
	 * {@inheritDoc}
	 */
	public void setContents(InputStream inputStream) {
		this.contents = inputStream;
	}

	/**
	 * {@inheritDoc}
	 */
	public String toString() {

		if (null != this.getPath()) {
			return this.getPath();
		}
		else {
			return super.toString();
		}
	}

}
