/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/ManufestHolder.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-12-4
 *******************************************************************************/

package com.primeton.studio.runtime;

import java.io.InputStream;
import java.util.jar.Manifest;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.internal.Contribution;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * TODO�˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ManufestHolder.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2008/09/11 06:04:58  yanfei
 * Bug:fix��ָ��
 *
 * Revision 1.1  2008/07/04 11:57:24  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/04/17 12:43:52  wanglei
 * Review:�ر�û�йص�����
 *
 * Revision 1.5  2008/04/11 11:09:13  lvyuan
 * Update����ʱ����������ɾ��һ����������������
 *
 * Revision 1.4  2008/01/07 09:36:19  lvyuan
 * Update:���øı��Ӧ�ñ��뱾����������������ģ��
 *
 * Revision 1.3  2007/12/29 03:30:06  lvyuan
 * Update:������ϵ�ı�ʱ��ҲҪ�������õ����Ĺ�������Ϊ���ܴ���ѭ����������
 *
 * Revision 1.2  2007/12/22 01:51:59  wanglei
 * Review:��CompositeUtil������ΪContributionUtil����SCA�����һ�¡�
 *
 * Revision 1.1  2007/12/06 05:19:13  lvyuan
 * Update:���ӹ�����һ���ı���
 *
 */
public class ManufestHolder {

	// û�иı�
	private static final int NONE = 0;

	// ���Ƹı�
	private static final int NAME = 1;

	// ������ı�
	private static final int REQUIRE_BUNDLE = 2;

	private static final int WEB_CONTEXT = 3;

	// ���Ƹı��Լ�������ı�
	private static final int ALL = 4;

	private ManufestHolder older;

	private Manifest manifest;

	private IFileDelegate manifestFile;

	public ManufestHolder(IFileDelegate fileDelegate) {
		this.manifestFile = fileDelegate;
		load(fileDelegate);
	}

	public ManufestHolder(IFileDelegate fileDelegate, ManufestHolder older) {
		this.older = older;
		this.manifestFile = fileDelegate;
		load(fileDelegate);
	}

	/**
	 * �¶�����оɵĶ��󣬷���Ƚϡ�<BR>
	 * @param fileDelegate
	 * @return
	 */
	ManufestHolder getManufestObject(IFileDelegate fileDelegate) {
		return new ManufestHolder(fileDelegate, this);
	}

	// ����
	private void load(IFileDelegate fileDelegate) {
		this.manifest = new Manifest();

		if (fileDelegate.exists()) {
			InputStream inStream = null;

			try {
				inStream = fileDelegate.getContents();
				this.manifest.read(inStream);
			} catch (Exception e) {
				ExceptionUtil.getInstance().handleException(e);
			} finally {
				IOUtils.closeQuietly(inStream);
			}
		}
	}

	/**
	 * @return bundle_name��
	 */
	public String getName() {
		return this.manifest.getMainAttributes().getValue(RuntimeConstant.BUNDLE_NAME);
	}

	public String getRequireBundle() {
		return this.manifest.getMainAttributes().getValue(RuntimeConstant.REQUIRE_BUNDLE);
	}

	public String getWebContextPath() {
		return this.manifest.getMainAttributes().getValue(RuntimeConstant.BUNDLE_WEB_CONTEXT);
	}

	public int getChangeType() {
		if (hasChange()) {
			if (this.older == null) {
				return ALL;
			}

			if (nameChanged() && requireBundleChanged() && webContextChanged()) {
				return ALL;
			}

			if (nameChanged()) {
				return NAME;
			}

			if (requireBundleChanged()) {
				return REQUIRE_BUNDLE;
			}

			if (webContextChanged()) {
				return WEB_CONTEXT;
			}

		}
		return NONE;
	}

	/**
	 * @return �����Ƿ��Ѿ��ı䡣
	 */
	private boolean nameChanged() {
		return (null == this.older) || !StringUtils.equals(this.getName(), this.older.getName());
	}

	/**
	 * @return �������Ƿ��Ѿ��ı䡣
	 */
	private boolean requireBundleChanged() {
		return null == this.older || !StringUtils.equals(this.getRequireBundle(), this.older.getRequireBundle());
	}

	public boolean webContextChanged() {
		return null == this.older || !StringUtils.equals(this.getWebContextPath(), this.older.getWebContextPath());
	}

	public boolean hasChange() {
		return this.older == null || (null != this.manifest && !this.manifest.equals(this.older.getManifest()));
	}

	/**
	 * @return Returns the manifest.
	 */
	public Manifest getManifest() {
		return manifest;
	}

	/**
	 * @param manifest The manifest to set.
	 */
	public void setManifest(Manifest manifest) {
		this.manifest = manifest;
	}

	/**
	 * @return Affect Contributions
	 */
	public IContribution[] getAffectContributions() {
		if (hasChange()) {
			int changeType = getChangeType();
			if (!this.manifestFile.exists()) {
				return RuntimeManager.getAllContributions(this.manifestFile.getSourceFolder().getProject());
			}

			IContribution self = RuntimeManager.createContribution(this.manifestFile);
			switch (changeType) {
				case WEB_CONTEXT:
					return new IContribution[] {
						self
					};
				case REQUIRE_BUNDLE:
				case NAME:
				case ALL:
					IContribution[] contributions = ContributionUtil.getAllReferencedContributions(self, true);
					if (!ArrayUtils.contains(contributions, self)) {
						ArrayUtils.add(contributions, self);
					}
					return contributions;
				default:
					break;
			}
		}
		return new Contribution[0];
	}
}
