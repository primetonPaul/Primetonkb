/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/TypeNameSpaceLocator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-7-22
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import org.apache.commons.io.FilenameUtils;

import com.primeton.studio.core.util.entry.StringMapEntry;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.index.IndexConstant;
import com.primeton.studio.runtime.index.model.DocumentItem;
import com.primeton.studio.runtime.index.query.IndexFinder;
import com.primeton.studio.runtime.index.query.QueryResult;
import com.primeton.studio.runtime.index.query.QueryStatement;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * ���Ӹ���TypeNameSpace�����ļ���ʵ�֡�<BR>
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: TypeNameSpaceLocator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/07/22 05:08:38  lvyuan
 * Update:����TypeNameSpace���ҷ�ʽ
 * 
 */
public class TypeNameSpaceLocator implements IEOSResourceLocator {

	/**
	 * ���캯����<BR>
	 */
	public TypeNameSpaceLocator() {
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFile(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate findFile(IProjectDelegate project, String[] namespaces) {
		for (int i = 0; i < namespaces.length; i++) {
			QueryStatement statement = new QueryStatement();
			String extension = FilenameUtils.getExtension(namespaces[i]);
			statement.setExtensions(new String[]{extension});
			statement.setNameSpace(new StringMapEntry(IndexConstant.TYPE_NAMESPACE,FilenameUtils.removeExtension(namespaces[i])));
			QueryResult<DocumentItem> result = IndexFinder.getInstance().searchFiles(project, statement);
			for (int j = 0; j < result.size(); j++) {
				DocumentItem item = result.get(j);
				if(item.getFile() != null){
					return item.getFile();
				}
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFile(com.primeton.studio.runtime.core.IContribution, java.lang.String[], boolean)
	 */
	public IFileDelegate findFile(IContribution contribution,
			String[] namespaces, boolean includeReference) {
		IContribution[] contributions = includeReference ? ContributionUtil.getAllRelatedContributions(new IContribution[] { contribution }) : new IContribution[] { contribution };
		for (int i = 0; i < namespaces.length; i++) {
			QueryStatement statement = new QueryStatement();
			String extension = FilenameUtils.getExtension(namespaces[i]);
			statement.setExtensions(new String[]{extension});
			statement.setNameSpace(new StringMapEntry(IndexConstant.TYPE_NAMESPACE,FilenameUtils.removeExtension(namespaces[i])));
			QueryResult<DocumentItem> result = IndexFinder.getInstance().searchFiles(contributions, statement);
			for (int j = 0; j < result.size(); j++) {
				DocumentItem item = result.get(j);
				if(item.getFile() != null){
					return item.getFile();
				}
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInFolders(java.lang.String[], com.primeton.studio.runtime.resources.IFolderDelegate[])
	 */
	public IFileDelegate findFileInFolders(String[] namespaces,
			IFolderDelegate[] folders) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInLibraries(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate findFileInLibraries(IProjectDelegate project,
			String[] namespaces) {
		// TODO
		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInSourceFolders(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate findFileInSourceFolders(IProjectDelegate project,
			String[] namespaces) {
		// TODO Auto-generated method stub
		return null;
	}

}
