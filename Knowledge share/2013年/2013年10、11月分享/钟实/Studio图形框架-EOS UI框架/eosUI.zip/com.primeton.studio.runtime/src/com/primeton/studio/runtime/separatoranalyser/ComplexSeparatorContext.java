/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/ComplexSeparatorContext.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-21
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ComplexSeparatorContext.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/10/29 10:27:37  liu-jun
 * Bug:13984 ��javabean�е�List������ʾ����ȷ commit by yangmd
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:45  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class ComplexSeparatorContext {
	private ISeparatorPolicy separatorPolicy;
	private Object element;
	private String childrenContents;
	private String parentContent;
	/**
	 * 
	 * @param separatorPolicy
	 * @param elementProxy
	 * @param childrenContents
	 */
	public ComplexSeparatorContext(ISeparatorPolicy separatorPolicy,
			Object element,String parentContent, String childrenContents) {
		this.separatorPolicy = separatorPolicy;
		this.element = element;
		this.parentContent = parentContent;
		this.childrenContents = childrenContents;
	}
	/**
	 * @return Returns the childrenContents.
	 */
	public String getChildrenContents() {
		return childrenContents;
	}
	/**
	 * @return Returns the separatorPolicy.
	 */
	public ISeparatorPolicy getSeparatorPolicy() {
		return separatorPolicy;
	}

	/**
	 * @param childrenContents The childrenContents to set.
	 */
	public void setChildrenContents(String childrenContents) {
		this.childrenContents = childrenContents;
	}

	/**
	 * @return Returns the element.
	 */
	public Object getElement() {
		return element;
	}
	/**
	 * @param element The element to set.
	 */
	public void setElement(Object element) {
		this.element = element;
	}
	/**
	 * @param separatorPolicy The separatorPolicy to set.
	 */
	public void setSeparatorPolicy(ISeparatorPolicy separatorPolicy) {
		this.separatorPolicy = separatorPolicy;
	}
	/**
	 * @return Returns the parentContent.
	 */
	public String getParentContent() {
		return parentContent;
	}
	/**
	 * @param parentContent The parentContent to set.
	 */
	public void setParentContent(String parentContent) {
		this.parentContent = parentContent;
	}
	
}
