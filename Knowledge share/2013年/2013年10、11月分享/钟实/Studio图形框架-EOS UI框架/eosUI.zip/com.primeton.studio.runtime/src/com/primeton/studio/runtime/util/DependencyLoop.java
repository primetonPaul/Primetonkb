/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/util/DependencyLoop.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-8-2
 *******************************************************************************/


package com.primeton.studio.runtime.util;

import com.primeton.studio.runtime.core.IContribution;

/**
 * ��������
 *
 * @author Chenxp (mailto:chenxp@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DependencyLoop.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/08/14 06:01:48  chenxp
 * Add:�ύ��ʼ���뵽cvs.
 *
 */
public class DependencyLoop {

	private IContribution [] members;
	private String name;

	public IContribution [] getMembers() {
		return members;
	}

	void setMembers(IContribution[] members) {
		this.members = members;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		return name;
	}

}
