/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/EOSSourceLocatorDirector.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-7-20
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * TODO�˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EOSSourceLocatorDirector.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.6  2009/07/23 05:07:50  lvyuan
 * Update:������ʽ��Ϊ����ʽ
 *
 * Revision 1.5  2009/07/22 05:08:38  lvyuan
 * Update:����TypeNameSpace���ҷ�ʽ
 *
 * Revision 1.4  2009/07/22 02:17:14  lvyuan
 * Update:����Ĭ����Դ������
 *
 * Revision 1.3  2009/07/21 09:51:38  lvyuan
 * Update:�����������ҵ�ʵ��
 *
 * Revision 1.2  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 * Revision 1.1  2009/07/20 10:38:50  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 * 
 */
public class EOSSourceLocatorDirector {
	
	private static EOSSourceLocatorDirector INSTANCE = new EOSSourceLocatorDirector();
	
	/**��������*/
	private IEOSResourceLocator defaultResourceLocator = new IEOSResourceLocator(){

		/* (non-Javadoc)
		 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFile(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
		 */
		public IFileDelegate findFile(IProjectDelegate project, String[] namespaces) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEOSResourceLocator element = (IEOSResourceLocator) iter.next();
				IFileDelegate fileDelegate = element.findFile(project, namespaces);
				if(fileDelegate != null){
					return fileDelegate;
				}
			}
			return null;
		}

		/* (non-Javadoc)
		 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFile(com.primeton.studio.runtime.core.IContribution, java.lang.String[], boolean)
		 */
		public IFileDelegate findFile(IContribution contribution, String[] namespaces, boolean includeReference) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEOSResourceLocator element = (IEOSResourceLocator) iter.next();
				IFileDelegate fileDelegate = element.findFile(contribution, namespaces, includeReference);
				if(fileDelegate != null){
					return fileDelegate;
				}
			}
			return null;
		}

		/* (non-Javadoc)
		 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInFolders(java.lang.String[], com.primeton.studio.runtime.resources.IFolderDelegate[])
		 */
		public IFileDelegate findFileInFolders(String[] namespaces, IFolderDelegate[] folders) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEOSResourceLocator element = (IEOSResourceLocator) iter.next();
				IFileDelegate fileDelegate = element.findFileInFolders(namespaces, folders);
				if(fileDelegate != null){
					return fileDelegate;
				}
			}
			return null;
		}

		/* (non-Javadoc)
		 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInLibraries(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
		 */
		public IFileDelegate findFileInLibraries(IProjectDelegate project, String[] namespaces) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEOSResourceLocator element = (IEOSResourceLocator) iter.next();
				IFileDelegate fileDelegate = element.findFileInLibraries(project, namespaces);
				if(fileDelegate != null){
					return fileDelegate;
				}
			}
			return null;
		}

		/* (non-Javadoc)
		 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInSourceFolders(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
		 */
		public IFileDelegate findFileInSourceFolders(IProjectDelegate project, String[] namespaces) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEOSResourceLocator element = (IEOSResourceLocator) iter.next();
				IFileDelegate fileDelegate = element.findFileInSourceFolders(project, namespaces);
				if(fileDelegate != null){
					return fileDelegate;
				}
			}
			return null;
		}
		
	};
	
	/**�������е�locator,����ͨ����չ�����ķ�ʽ*/
	private Map<Class,IEOSResourceLocator> locator = new LinkedHashMap<Class,IEOSResourceLocator>();
	
	private EOSSourceLocatorDirector(){
		locator.put(IndexSourceLocator.class,new IndexSourceLocator());
		locator.put(DefaultResourceLocator.class,new DefaultResourceLocator());
		locator.put(TypeNameSpaceLocator.class,new TypeNameSpaceLocator());
	}
	
	/**
	 * @return Ψһ��ʵ����<BR>
	 */
	public static EOSSourceLocatorDirector getInstance(){
		return INSTANCE;
	}
	
	/**
	 * @return Returns the defaultResourceLocator.
	 */
	public IEOSResourceLocator getResourceLocator() {
		return defaultResourceLocator;
	}
	
	/**
	 * @return Returns the defaultResourceLocator.
	 */
	public IEOSResourceLocator getResourceLocator(Class className) {
		if(locator.get(className) != null){
			return locator.get(className);
		}
		return defaultResourceLocator;
	}

	/**
	 * @param defaultResourceLocator The defaultResourceLocator to set.
	 */
	public void setDefaultResourceLocator(IEOSResourceLocator defaultResourceLocator) {
		this.defaultResourceLocator = defaultResourceLocator;
	}
}
