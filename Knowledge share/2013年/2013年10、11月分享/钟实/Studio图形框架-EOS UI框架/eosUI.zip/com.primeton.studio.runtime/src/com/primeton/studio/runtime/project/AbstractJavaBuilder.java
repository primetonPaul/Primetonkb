/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/project/AbstractJavaBuilder.java,v 1.1 2012/01/12 02:06:42 guwei Exp $
 * $Revision: 1.1 $
 * $Date: 2012/01/12 02:06:42 $
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2011-9-19
 *******************************************************************************/


package com.primeton.studio.runtime.project;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubProgressMonitor;

import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.runtime.RuntimeMessages;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceManager;

public abstract class AbstractJavaBuilder implements IJavaBuilder {
	private boolean isDeleteMarkers = true;//builderǰ�Ƿ�Ҫ���markers,Ĭ��Ϊtrue
	
	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * ��������������javabuilderר�ù��캯��
	 *
	 * The default constructor.<BR>
	 * @param isDeleteMarkers		 builderǰ�Ƿ�Ҫ���markers,�������ֵΪfalse,
	 * bulid���������buildǰ��markers������������ܻ���build����ʾ�Ѿ�invalided��markers
	 */
	public AbstractJavaBuilder() {
	}
	
	public void setDeleteMarkers(boolean deleteMarkers){
		this.isDeleteMarkers = deleteMarkers;
	}
	
	public void build(IFolder folder, boolean supportNoneJavaResources, IProgressMonitor monitor) {
		Assert.isNotNull(folder, "folder must not be null"); //$NON-NLS-1$
		Assert.isTrue(folder.exists(), "folder must exist"); //$NON-NLS-1$

		IFolder sourceFolder = EclipseResourceManager.getSourceFolder(folder);
		if (null == sourceFolder) {
			return;
		} else {
			try {
				this.doBuildFolder(sourceFolder, supportNoneJavaResources, monitor);
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace(System.out);
			}
		}
	}
	
	private void doBuildFolder(IFolder folder, boolean supportNoneJavaResources, final IProgressMonitor monitor) throws CoreException {

		IResource[] resources = folder.members();
		if (ArrayUtils.isEmpty(resources)) {
			return;
		}

		try {
			monitor.beginTask(null, EOSProjectBuilder.SCALE + 1);

			if(isDeleteMarkers){
				// ����֮ǰɾ��marker��Ϣ
				try {

					monitor.subTask("Remove Mark"); //$NON-NLS-1$

					folder.deleteMarkers(IMarker.PROBLEM, false, IResource.DEPTH_INFINITE);
					folder.deleteMarkers(IMarker.TEXT, false, IResource.DEPTH_INFINITE);
				} catch (Exception e) {
					ExceptionUtil.getInstance().handleException(e);
				}
			}

			monitor.worked(1);

			IProgressMonitor subMonitor = new SubProgressMonitor(monitor, EOSProjectBuilder.SCALE);
			monitor.subTask(RuntimeMessages.COMPILE);
			this.recursiveBuildFolder(folder, supportNoneJavaResources, subMonitor);
		} finally {
			monitor.done();
		}
	}
	
	private void recursiveBuildFolder(IFolder folder, boolean supportNoneJavaResources, final IProgressMonitor monitor) throws CoreException {

		IResource[] resources = folder.members();
		if (ArrayUtils.isEmpty(resources)) {
			return;
		}

		try {
			monitor.beginTask("Build Folder : ", resources.length * EOSProjectBuilder.SCALE); //$NON-NLS-1$

			for (int i = 0; i < resources.length; i++) {

				if (monitor.isCanceled()) {
					return;
				}
				//�����Cancel
				//����ֹ����

				IResource resource = resources[i];
				monitor.setTaskName("Build " + resource.getFullPath().toString()); //$NON-NLS-1$

				if (resource.getType() == IResource.FILE) {
					IFile file = (IFile) resource;
					buildFile(file, false, supportNoneJavaResources, monitor);
					monitor.worked(EOSProjectBuilder.SCALE);
				}

				if (resource instanceof IFolder) {
					IProgressMonitor subMonitor = new SubProgressMonitor(monitor, EOSProjectBuilder.SCALE);
					IFolder subFolder = (IFolder) resource;
					this.recursiveBuildFolder(subFolder, supportNoneJavaResources, subMonitor);
				}

			}
		} finally {
			monitor.done();
		}
	}
	
	protected abstract void buildFile(IFile file, boolean validate, boolean supportNoneJavaResources, IProgressMonitor monitor);

}

/*
 * �޸���ʷ
 * $Log: AbstractJavaBuilder.java,v $
 * Revision 1.1  2012/01/12 02:06:42  guwei
 * Update: �汾�������޸ģ�֧��eclipse3.6
 * 
 */