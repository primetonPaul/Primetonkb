/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal;

import java.util.Collection;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IMember;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.IParameter;
import com.primeton.studio.runtime.core.IResult;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.core.base.AbstractEosElement;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * �������<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: Method.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/07/22 02:01:56  chenxp
 * Update:����addChild������
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.14  2008/06/13 08:03:57  yujl
 * update:ɾ�����õ�����
 *
 * Revision 1.13  2008/06/13 07:53:57  yujl
 * update:ɾ�����õ���
 *
 * Revision 1.12  2008/05/30 06:17:55  chenxp
 * Update:����equalsChildren������
 *
 * Revision 1.11  2008/04/08 03:23:58  chenxp
 * UnitTest: ��ȷ��ʾ�����Ĳ�������
 *
 * Revision 1.10  2008/03/07 09:56:53  wanglei
 * Review:��������Ҫ�ȽϺ��ӽ��ġ�
 *
 * Revision 1.9  2007/08/14 08:41:52  wanglei
 * Add:���ӶԱ䳤������֧�֡�
 *
 * Revision 1.8  2007/06/28 09:20:22  wanglei
 * Review:��getModel��setModel�ᵽ�����С�
 *
 * Revision 1.7  2007/06/15 09:43:40  wanglei
 * Update:�����˹��캯����
 *
 * Revision 1.6  2007/06/13 06:35:15  wanglei
 * Remove:��ȥgetIdentifier.
 *
 * Revision 1.5  2007/06/04 11:55:56  wanglei
 * UnitTest:������getMarkCode��Bug��
 *
 * Revision 1.4  2007/06/04 07:15:42  wanglei
 * Update:֧�ֱ�ʶ�š�
 *
 * Revision 1.3  2007/05/28 05:47:28  wanglei
 * Add:Ϊ����IEosElement����getModel������
 *
 * Revision 1.2  2007/04/27 10:07:40  wanglei
 * UnitTest:����Ӧ����IMemberl�����ࡣ
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public class Method extends AbstractEosElement implements IMethod {

	private boolean variable;

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param parent
	 * @param parent
	 */
	public Method(IResourceDelegate resource, IEosElement parent) {
		super(resource, parent);
	}

	/**
	 *
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public Method() {
		super(null, null);
	}

	/**
	 * {@inheritDoc}
	 */
	public int getElementType() {
		return METHOD;
	}

	/**
	 * {@inheritDoc}
	 */
	public IParameter[] getParameters() {
		Collection col = this.getChildrenOfType(PARAMETER);
		IParameter[] results = new IParameter[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IResult[] getResults() {
		Collection col = this.getChildrenOfType(RESULT);
		IResult[] results = new IResult[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getDisplayName() {

		String displayName = this.internalGetDisplayName();
		String name = this.internalGetName();
		if (null != displayName) {
			return displayName;
		}

		name = name + "(";
		IParameter[] parameters = this.getParameters();
		for (int i = 0; i < parameters.length; i++) {
			IParameter parameter = parameters[i];
			IType type = parameter.getDeclaringType();
			if (null != type) {
				String typeName = type.getDisplayName();
				int index = typeName.lastIndexOf('.');
				typeName = index>0? typeName.substring(index+1) : typeName;
				if(i < (parameters.length-1))
					name += typeName + ",";
				else
					name += typeName;
			}

			/*name = name + parameter.getName();
			if (i != (parameters.length - 1)) {
				name = name + ",";
			}*/
		}

		name = name + ")";

		return name;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getMarkCode() {
		final int PRIME = 2;
		int result = 1;
		result = PRIME * result + ((this.getName() == null) ? 0 : this.getName().hashCode());

		IEosElement[] children = this.getChildren();
		if (null != children) {
			for (int i = 0; i < children.length; i++) {
				IEosElement element = children[i];

				if (element.getElementType() == PARAMETER || element.getElementType() == RESULT) {
					IMember member = (IMember) element;
					String name = member.getName();
					result = PRIME * result + (name == null ? 0 : name.hashCode());

					if (null != member.getDeclaringType()) {
						String typeName = member.getDeclaringType().getName();
						result = PRIME * result + (typeName == null ? 0 : typeName.hashCode());
					}
				}
			}
		}

		//TODO Ӧ��û����ô��

		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkParent() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkChildrenEquals() {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkResource() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isVariable() {
		return this.variable;
	}

	/**
	 * @param aVariable the variable to set
	 */
	public final void setVariable(boolean aVariable) {
		this.variable = aVariable;
	}
	
	/**
	 * ֻ�ȽϺ��ӵ���Ϣ��<BR>
	 *
	 * Note: �����Ƚ�ʱҪ���ǲ�����˳�����⣺���Method��Ҫ�������������ʵ��
	 * 
	 * @param other
	 */
	public boolean equalsChildren(final AbstractEosElement other) {
		Object[] currentChildren = this.getChildren();
		Object[] otherChildren = other.getChildren();

		if (currentChildren != null && null != otherChildren) {
			if (currentChildren.length != otherChildren.length) {
				return false;
			}

			for (int i = 0; i < currentChildren.length; i++) {

				Object currentChild = currentChildren[i];
				Object otherChild = otherChildren[i];

				if (!(currentChild instanceof AbstractEosElement)
						|| !(otherChild instanceof AbstractEosElement)) {
					return false;
				}

				AbstractEosElement currentChildElement = (AbstractEosElement) currentChild;
				AbstractEosElement otherChildElement = (AbstractEosElement) otherChild;

				if (currentChildElement.equalsSelf(otherChildElement) && currentChildElement.equalsChildren(otherChildElement)) {
					continue;
				} else {
					return false;
				}
			}
		}
		else {
			return (currentChildren == null && null == otherChildren);
		}

		return true;
	}

	@Override
	public void addChild(IEosElement child) {
		int length = 0;
		if (null != this.children) {
			length = this.children.length;
		}

		if (length == 0) {
			this.children = new IEosElement[] {
				child
			};
		}
		else {
			System.arraycopy(this.children, 0, this.children = new IEosElement[length + 1], 0, length);
			this.children[length] = child;
		}
	}

}
