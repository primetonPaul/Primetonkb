/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.index.base;

import com.primeton.studio.runtime.index.IFileIndexAnalyser;

/**
 * IFileIndexAnalyser�ĳ�����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractFileIndexAnalyser.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/02 03:20:09  wanglei
 * Add:���Ӷ��ļ�����������֧�֡�
 *
 */

public abstract class AbstractFileIndexAnalyser implements IFileIndexAnalyser {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractFileIndexAnalyser() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public int getPriority() {
		return 0;
	}

}
