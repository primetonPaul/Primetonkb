package com.primeton.studio.runtime.project;

import com.primeton.platform.Kernel;
import com.primeton.platform.service.impl.BundleVersionFilter;

/**
 * ��ȡInternalʵ�֣���ͬeclipse�汾��Ҫ��ͬ��ʵ��
 *
 * @author guwei (mailto:guwei@primeton.com)
 */
public class JavabuilderManager {
	public static JavabuilderManager instance = null;
	
	private JavabuilderManager(){}
	
	public static JavabuilderManager getInstance(){
		if(instance == null){
			instance = new JavabuilderManager();
		}
		return instance;
	}
	
	public IJavaBuilder getJavaBuilder(boolean isDeleteMarkers){
		Object obj = Kernel.getServiceManager().findService(IJavaBuilder.class, null, null, new BundleVersionFilter(false));
		if(obj instanceof AbstractJavaBuilder){
			((AbstractJavaBuilder)obj).setDeleteMarkers(isDeleteMarkers);
		}
		return (IJavaBuilder) obj;
	}
}

/*
 * �޸���ʷ
 * $Log: JavabuilderManager.java,v $
 * Revision 1.1  2012/01/12 02:06:42  guwei
 * Update: �汾�������޸ģ�֧��eclipse3.6
 * 
 */