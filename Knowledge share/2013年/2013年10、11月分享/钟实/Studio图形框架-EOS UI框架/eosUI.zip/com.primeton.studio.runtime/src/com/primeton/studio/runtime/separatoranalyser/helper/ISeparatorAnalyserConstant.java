/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/helper/ISeparatorAnalyserConstant.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-23
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.helper;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ISeparatorAnalyserConstant.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 06:02:11  yangmd
 * Update:�ع�separatorAnalyser����дע��
 * 
 */
public interface ISeparatorAnalyserConstant {
	/**
	 * Java����
	 */
	public static final String JAVA = "java";
	/**
	 * ʵ������
	 */
	public static final String ENTITY = "entity";
	
}
