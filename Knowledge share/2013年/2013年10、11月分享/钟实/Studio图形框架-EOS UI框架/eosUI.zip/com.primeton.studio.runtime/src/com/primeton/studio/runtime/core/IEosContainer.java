/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core;

import com.primeton.studio.runtime.resources.IFolderDelegate;


/**
 * Container�ӿ�<BR>
 * û���κ����ݣ�ֻ��һ����־�Խӿ�
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IEosContainer.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/01/07 01:59:15  wanglei
 * Review:���getFolder������
 *
 * Revision 1.1  2007/11/01 06:43:45  wanglei
 * Add:�ύ��CVS��
 *
 */
public interface IEosContainer extends IEosElement {

	/**
	 * �õ�Ŀ¼��Դ��<BR>
	 *
	 * @return
	 */
	public IFolderDelegate getFolder();

}
