/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/cache/SimpleCacheFactory.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2010-6-21
 *******************************************************************************/


package com.primeton.studio.runtime.cache;

import com.primeton.studio.runtime.cache.impl.LRUMemCache;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: SimpleCacheFactory.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/06/24 09:17:56  hongsq
 * Update:jira EOSP-286
 * 
 */
class SimpleCacheFactory implements ICacheFactory {
	

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.cache.ICacheFactory#createCache(java.lang.Object)
	 */
	public ICache createCache(Object cacheId) {
		//1500������������ܻ�������
		return new LRUMemCache(cacheId,1500);
	}

}
