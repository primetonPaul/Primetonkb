/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/FolderLookupParticipant.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-7-20
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;

import com.eos.system.utility.Assert;
import com.primeton.studio.core.util.entry.StringMapEntry;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.index.IndexConstant;
import com.primeton.studio.runtime.index.model.DocumentItem;
import com.primeton.studio.runtime.index.query.IndexFinder;
import com.primeton.studio.runtime.index.query.QueryResult;
import com.primeton.studio.runtime.index.query.QueryStatement;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;

/**
 * TODO�˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: FolderLookupParticipant.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.6  2009/10/13 06:29:58  chenxp
 * Update:�����ع�
 *
 * Revision 1.5  2009/08/20 07:47:03  hongsq
 * Update:�ṩһ��ӿ�֧�ֲ���һ���ļ������޸�xsd,wsdl��ع����������ƿռ��ظ�
 *
 * Revision 1.4  2009/08/06 02:41:23  lvyuan
 * Bugfix:20432 �����ļ����ǿյ���֤
 *
 * Revision 1.3  2009/07/22 05:08:38  lvyuan
 * Update:����TypeNameSpace���ҷ�ʽ
 *
 * Revision 1.2  2009/07/21 09:51:38  lvyuan
 * Update:�����������ҵ�ʵ��
 *
 * Revision 1.1  2009/07/20 10:38:50  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 * 
 */
public class FolderLookupParticipant extends AbstractResourceLookupParticipant {

	private IFolderDelegate[] folders;
	/**
	 * 
	 */
	public FolderLookupParticipant(IFolderDelegate[] folders) {
		this.folders = folders;
		Assert.notEmpty(folders, "the folders must not be empty");
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IResourceLookupParticipant#findFile(java.lang.String[])
	 */
	public IFileDelegate findFile(String[] namespaces) {
		Map<String, List<String>> map = RuntimeHelper.analyserNamespace(namespaces);
		for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
			String NS = (String) iter.next();
			List<String> extentionList = map.get(NS);
			
			QueryStatement statement = new QueryStatement();
			statement.setExtensions(extentionList.toArray(new String[extentionList.size()]));
			statement.setNameSpace(new StringMapEntry(IndexConstant.NAMESPACE, NS));
			
			// ���Ӱ�������Ϊ��������
			for (int j = 0; j < folders.length; j++) {
				String sourceRelativePath = folders[j].getSourceRelativePath();
				String packageName = FilenameUtils.removeExtension(sourceRelativePath);
				statement.addKeyWords(new StringMapEntry(IndexConstant.PACKAGE_NAME,packageName));
			}
			
			QueryResult<DocumentItem> result = IndexFinder.getInstance().searchFiles(folders[0].getProject(), statement);
			for (int j = 0; j < result.size(); j++) {
				DocumentItem item = result.get(j);
				if(item.getFile() != null){
					return item.getFile();
				}
			}
		}
		
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IResourceLookupParticipant#findFiles(java.lang.String[])
	 */
	public IFileDelegate[] findFiles(String[] namespaces) {
		List<IFileDelegate> list = new ArrayList<IFileDelegate>();
		Map<String, List<String>> map = RuntimeHelper.analyserNamespace(namespaces);
		for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
			String NS = (String) iter.next();
			List<String> extentionList = map.get(NS);
			
			QueryStatement statement = new QueryStatement();
			statement.setExtensions(extentionList.toArray(new String[extentionList.size()]));
			statement.setNameSpace(new StringMapEntry(IndexConstant.NAMESPACE, NS));
			
			// ���Ӱ�������Ϊ��������
			for (int j = 0; j < folders.length; j++) {
				String sourceRelativePath = folders[j].getSourceRelativePath();
				String packageName = FilenameUtils.removeExtension(sourceRelativePath);
				statement.addKeyWords(new StringMapEntry(IndexConstant.PACKAGE_NAME,packageName));
			}
			
			QueryResult<DocumentItem> result = IndexFinder.getInstance().searchFiles(folders[0].getProject(), statement);
			for (int j = 0; j < result.size(); j++) {
				DocumentItem item = result.get(j);
				IFileDelegate file = item.getFile();
				if(null != file && !list.contains(file)){
					list.add(item.getFile());
				}
			}
		}
		
		return list.toArray(new IFileDelegate[list.size()]);
	}
}
