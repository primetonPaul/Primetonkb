/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/util/ContributionDependencyAnalyser.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-8-2
 *******************************************************************************/


package com.primeton.studio.runtime.util;

import java.util.Vector;

import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.internal.Contribution;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * Contribution��������ϵ����
 *
 * @author Chenxp (mailto:chenxp@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ContributionDependencyAnalyser.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/11/28 09:26:13  wanglei
 * Review:RuntimeManager�еĲ��ַ����Ƶ�RuntimeHelper�У�Ҳ��һЩ��������������
 *
 * Revision 1.1  2007/08/14 06:01:48  chenxp
 * Add:�ύ��ʼ���뵽cvs.
 *
 */
public class ContributionDependencyAnalyser {

	public static DependencyLoop[] findLoops(IContribution root) {
		Object obj = root.getAdapter(IFolderDelegate.class);
		if(obj!=null) {
			return findLoops(((IFolderDelegate)obj).getProject(), root, null);
		}
		return new DependencyLoop[0];
	}

	public static DependencyLoop [] findLoops(IProjectDelegate project, IContribution root, IContribution[] candidates) {
		return findLoops(project, root, candidates, false);
	}

	public static DependencyLoop [] findLoops(IProjectDelegate project, IContribution root, IContribution[] candidates, boolean onlyCandidates) {
		Vector loops = new Vector();
		Vector path = new Vector();
		findLoops(project, loops, path, root, candidates, onlyCandidates, new Vector());
		return (DependencyLoop[])loops.toArray(new DependencyLoop[loops.size()]);
	}

	private static void findLoops(
			IProjectDelegate project,
			Vector loops,
			Vector path,
			IContribution subroot,
			IContribution[] candidates,
			boolean onlyCandidates,
			Vector exploredContributions) {
		if(path.size()>0) {
			// test the path: is the subroot the same as root - if yes, it means loop.
			Contribution root = (Contribution)path.elementAt(0);
			if(isEquivalent(root, subroot)) {
				//Find a loop.
				DependencyLoop loop = new DependencyLoop();
				loop.setMembers((IContribution[])path.toArray(new IContribution[path.size()]));
				int no = loops.size() + 1;
				loop.setName("Loop " + no);
				loops.add(loop);
				return;
			}
			//is the subroot the same as any other node?
			//if yes, abort - local loop that is not ours.
			for(int i=0; i<path.size(); i++) {
				Contribution node = (Contribution)path.elementAt(i);
				if(isEquivalent(subroot, node)) { //local loop
					return;
				}
			}
		}

		Vector newPath = path.size()>0?((Vector)path.clone()):path;
		newPath.add(subroot);

		if(!onlyCandidates) {
			IContribution[] dependencies = findContributions(project, subroot.getRequiredBundles());
			for(int i=0; i<dependencies.length; i++) {
				IContribution contribution = dependencies[i];
				String identifier = contribution.getName();
				if(!exploredContributions.contains(identifier)){
					//is contribution in list of non loop yielding contributions
					//Commenting linear lookup - was very slow
					//when called from here. We will use
					//model manager instead because it
					//has a hash table lookup that is much faster.

					//number of loops before traversing contribution
					int oldLoopSize = loops.size();

					findLoops(project, loops, newPath, contribution, null, false, exploredContributions);

					// number of loops after traversing plugin
					int newLoopsSize = loops.size();

					if (oldLoopSize == newLoopsSize) {// no change in number of loops
						// no loops from going to this node, skip next time
						exploredContributions.add(identifier);
					}
				}
			}
		}

		if (candidates != null) {
			for (int i = 0; i < candidates.length; i++) {
				IContribution candidate = candidates[i];

				// number of loops before traversing plugin
				int oldLoopSize = loops.size();

				findLoops(project, loops, newPath, candidate, null, false, exploredContributions);

				// number of loops after traversing plugin
				int newLoopsSize = loops.size();

				if (oldLoopSize == newLoopsSize) { // no change in number of loops
					// no loops from going to this node, skip next time
					exploredContributions.add(candidate.getName());
				}
			}
		}
	}

	private static boolean isEquivalent(IContribution left, IContribution right) {
		return left.getName().equals(right.getName());
	}

	private static IContribution findContribution(IProjectDelegate project, String identifier) {
		return RuntimeManager.findContribution(project, identifier);//FIXME:�÷���Ŀǰ�ݲ�֧�����ÿ�Ĳ���
	}

	private static IContribution[] findContributions(IProjectDelegate project, String[] identifiers) {
		IContribution[] contributions = RuntimeManager.findContributions(project, identifiers);
		Vector result = new Vector();
		for(int i=0; i<contributions.length; i++) {
			IContribution contribution = contributions[i];
			if(contribution!=null)
				result.add((Contribution)contribution);
		}
		return (IContribution[])result.toArray(new IContribution[result.size()]);
	}

}
