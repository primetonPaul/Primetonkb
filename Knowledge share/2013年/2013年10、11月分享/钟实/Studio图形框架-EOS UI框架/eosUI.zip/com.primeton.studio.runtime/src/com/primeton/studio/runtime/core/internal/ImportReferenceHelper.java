/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/core/internal/ImportReferenceHelper.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-11-23
 *******************************************************************************/


package com.primeton.studio.runtime.core.internal;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * import referneceʵ�����������ṩһЩ���߷�������̬������
 * ˵�����ع�ʱ�½��������studio�д��ڵĴ����ظ����롣
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ImportReferenceHelper.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/12/02 06:43:33  zhuxing
 * New:�������벿�ֵ������������ؼ������߼�����װ
 * 
 */
public class ImportReferenceHelper {
	private ImportReferenceHelper() {}
	
	/**
	 * ����������μ�Import Reference���丸������Ӧ���Զ���
	 * 
	 * @param resourceDelegate
	 * @param parent
	 * @param name                reference name
	 * @return
	 */
	public static ImportReference buildReference(IResourceDelegate resourceDelegate, IEosElement parent, String name) {
		return buildReference(resourceDelegate, parent, name, null);
	}
	
	/**
	 * ����������μ�Import Reference���丸������Ӧ���Զ���
	 * 
	 * @param resourceDelegate
	 * @param parent
	 * @param name
	 * @param referenceContents
	 * @return
	 */
	public static ImportReference buildReference(IResourceDelegate resourceDelegate, IEosElement parent, String name, String[] referenceContents) {
		return buildReference(resourceDelegate, parent, name, RuntimeConstant.FILE, referenceContents);
	}
	
	/**
	 * ����������μ�Import Reference���丸������Ӧ���Զ���
	 * 
	 * @param resourceDelegate   
	 * @param parent
	 * @param name 
	 * @param implementationType 
	 * @param referenceContents
	 * @return
	 */
	public static ImportReference buildReference(IResourceDelegate resourceDelegate, IEosElement parent, String name, String implementationType, String[] referenceContents) {
		ImportReference importReference = new ImportReference(resourceDelegate, parent);
		importReference.setName(name);
		importReference.setImplementationType(implementationType);
		importReference.setReferenceContents(referenceContents);
		return importReference;
	}
	
	/**
	 * �ϲ��ض�import reference��Ӧ��old reference contents��new reference contents
	 * 
	 * @param importReference
	 * @param newReferenceContents
	 * @return
	 */
	public static ImportReference mergeReferenceContents(ImportReference importReference, String[] newReferenceContents) {
		//param check
		if (importReference ==  null || ArrayUtils.isEmpty(newReferenceContents))
			return importReference;
		
		String[] oldReferenceContents = importReference.getReferenceContents();
		if (ArrayUtils.isEmpty(oldReferenceContents)) {
			importReference.setReferenceContents(newReferenceContents);
		}
		else {
			//�ϲ��¾�reference contents��ͬʱ�޳����ظ���Ŀ
			Set<String> contentsSet = new HashSet<String>();
			Collections.addAll(contentsSet, oldReferenceContents);
			Collections.addAll(contentsSet, newReferenceContents);
			
			String[] referenceContents = new String[contentsSet.size()];
			contentsSet.toArray(referenceContents);
			
			importReference.setReferenceContents(referenceContents);
		}
		
		return importReference;
	}
	
	/**
	 * Ϊimport reference����һ��referenceContentItem
	 * ˵�������referenceContentItem�Ѿ�������import reference���ᱻ���ԡ�
	 * 
	 * @param importReference
	 * @param referenceContentItem  �µ�����������Ŀ
	 * @return
	 */
	public static ImportReference mergeReferenceContent(ImportReference importReference, String referenceContentItem) {
		//param check
		if (importReference == null || referenceContentItem == null)
			return importReference;
		
		String[] oldReferenceContents = importReference.getReferenceContents();
		if (ArrayUtils.isEmpty(oldReferenceContents)) {
			importReference.setReferenceContents(new String[]{referenceContentItem});
		}
		else if (!ArrayUtils.contains(oldReferenceContents, referenceContentItem)) {
			String[] newReferenceContents = new String[oldReferenceContents.length + 1];
			System.arraycopy(oldReferenceContents, 0, newReferenceContents, 0, oldReferenceContents.length);
			newReferenceContents[oldReferenceContents.length] = referenceContentItem;
			importReference.setReferenceContents(newReferenceContents);
		}
		return importReference;
	}
	
}
