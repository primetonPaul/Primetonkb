/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.library.base;

import java.io.File;
import java.text.MessageFormat;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.IProgressMonitor;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.library.ILibraryManager;
import com.primeton.studio.runtime.library.internal.LibraryImpl;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.java.JavaFileDelegate;
import com.primeton.studio.runtime.resources.internal.java.JavaFolderDelegate;

/**
 * ILibraryManager�Ļ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractLibraryManager.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/05/16 06:43:40  wanglei
 * Review:�����ӿڽṹ������Ӧ��Java�����.metadataĿ¼�С�
 *
 * Revision 1.2  2008/04/15 12:39:59  wanglei
 * Update:�ع�ILibrary�ĳ������ơ�
 *
 * Revision 1.1  2008/03/06 07:22:31  wanglei
 * Add:�ύ��CVS��
 *
 */

public abstract class AbstractLibraryManager implements ILibraryManager {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractLibraryManager() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean checkValidation(ILibrary library, IProgressMonitor monitor, IMessageCaller messageCaller) {

		IResourceDelegate[] resourceDelegates = this.getResources(library);
		boolean result = true;

		String messageFormat = "the build path is not correct in the library of {0} ,please check it.";

		for (int i = 0; i < resourceDelegates.length; i++) {
			IResourceDelegate delegate = resourceDelegates[i];
			if (!delegate.exists()) {

				String message = MessageFormat.format(messageFormat, new Object[] {
					library.getDisplayName()
				});

				if (null != messageCaller) {
					messageCaller.error(message, null);
				}

				result = false;
			}
		}

		return result;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public IResourceDelegate[] getResources(ILibrary library) {

		IProjectDelegate projectDelegate = library.getProject();

		if (library.getType() == ILibrary.EXTERNAL_LIBRARY) {
			return getExternalResources(projectDelegate, library);
		}

		if (library.getType() == ILibrary.INTERNAL_LIBRARY) {

			return getInternalResources(projectDelegate, library);
		}

		if (library.getType() == ILibrary.PLUGIN_LIBRARY) {

			return getPluginResources(projectDelegate, library);
		}

		return new IResourceDelegate[0];
	}

	/**
	 * @param projectDelegate
	 * @param library
	 * @return
	 */
	protected abstract IResourceDelegate[] getPluginResources(IProjectDelegate projectDelegate, ILibrary library);

	/**
	 * @return
	 */
	protected IResourceDelegate[] getExternalResources(IProjectDelegate projectDelegate, ILibrary library) {
		File file = new File(library.getPath());
		IResourceDelegate resource = null;

		if (StringUtils.equals(library.getKind(), LibraryImpl.FOLDER_RESOURCE)) {
			resource = new JavaFolderDelegate(file);
		}

		if (StringUtils.equals(library.getKind(), LibraryImpl.FILE_RESOURCE)) {
			resource = new JavaFileDelegate(file);
		}

		return new IResourceDelegate[] {
			resource
		};
	}

	protected IResourceDelegate[] getInternalResources(IProjectDelegate projectDelegate, ILibrary library) {
		IResourceDelegate resource = null;

		if (StringUtils.equals(library.getKind(), LibraryImpl.FOLDER_RESOURCE)) {
			resource = projectDelegate.getFolder(library.getPath());
		}

		if (StringUtils.equals(library.getKind(), LibraryImpl.FILE_RESOURCE)) {
			resource = projectDelegate.getFile(library.getPath());
		}

		return new IResourceDelegate[] {
			resource
		};
	}

}
