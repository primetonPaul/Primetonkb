/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.marker;

import java.util.Iterator;
import java.util.Properties;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;

import com.primeton.studio.core.IMessageCaller;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ʹ��Eclipse��Marker����ʾ���������Ϣ<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Show error message and infomation by the marker of eclipse. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-19 ����10:10:06
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 *
 * �޸���ʷ
 *
 * $Log: EclipseMarkerMessageCaller.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.4  2010/05/17 10:20:07  wanglei
 * Review:����޷���Eclipse�����б��м��붨λ���ֵ����⡣
 *
 * Revision 1.3  2010/04/28 03:19:40  wanglei
 * Bug24724:����Ǳ����в��
 *
 * Revision 1.2  2010/03/04 09:25:35  wanglei
 * Update:����EOSP-163,EOSP-169��
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2008/06/26 02:31:08  wanglei
 * UnitTest:����û����ȷ�ж�Marker���ͣ��Ӷ�������Ҳ��Ϊ�����Bug��
 *
 * Revision 1.3  2007/07/27 01:03:13  lvyuan
 * Update:���þ����marker
 *
 * Revision 1.2  2007/06/27 03:45:52  wanglei
 * Review:ֻ����Լ�������Marker���������һ��marker���������ʹ�÷�Problem��text�������͡�
 *
 * Revision 1.1  2007/05/30 08:55:55  wanglei
 * �ύ��CVS��
 *
 *
 */

public class EclipseMarkerMessageCaller implements IMessageCaller
{
	private IResource resource;

	/**
	 * ��Eclipse��ʹ��Marker����Ҫ��Դ�ģ�����ͨ���������������<BR>
	 *
	 * In eclipse, resource is necessary for using marker.<BR>
	 * So a parameter is passed to construct a new object.<BR>
	 *
	 * @param r_Resource
	 *            The parameter can't be <code>null</code>.<BR>
	 */
	public EclipseMarkerMessageCaller(IResource r_Resource)
	{
		super();
		Assert.isNotNull(r_Resource, "the resource can't be null,please check it.");
		this.resource = r_Resource;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#clear()
	 */
	public void clear()
	{
		try
		{
			this.resource.deleteMarkers(IMarker.PROBLEM, false, IResource.DEPTH_ZERO);
			this.resource.deleteMarkers(IMarker.TEXT, false, IResource.DEPTH_ZERO);
		}
		catch (CoreException e)
		{
			// Nothing to do
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#error(java.lang.String)
	 */
	public void error(String r_Message, Properties r_Properties)
	{
		try
		{
			IMarker t_Marker = this.resource.createMarker(IMarker.PROBLEM);

			setAttributes(r_Message, r_Properties, t_Marker);

            //Add by lvyuan 0404 ������Դ·�� start---
            t_Marker.setAttribute(IMarker.LOCATION, this.resource.getFullPath().toOSString());
            //Add by lvyuan 0404 ������Դ·�� end---

			t_Marker.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_HIGH);
			t_Marker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
		}
		catch (CoreException e)
		{
			// Nothing to do
		}
	}

	/**
	 * ����IMarker��������ԡ�<BR>
	 *
	 * Set the attributes of "IMarker".<BR>
	 *
	 * @param r_Message
	 * @param r_Properties
	 * @param t_Marker
	 * @throws CoreException
	 */
	private void setAttributes(String r_Message, Properties r_Properties, IMarker t_Marker) throws CoreException
	{
		t_Marker.setAttribute(IMarker.MESSAGE, r_Message);

		if (null != r_Properties)
		{
			for (Iterator t_Iterator = r_Properties.keySet().iterator(); t_Iterator.hasNext();)
			{
				String t_Key = (String) t_Iterator.next();
//				String t_Value = r_Properties.getProperty(t_Key);
				Object t_Value = r_Properties.get(t_Key);
				if(null == t_Value){
					continue;
				}

				if ((t_Value instanceof String) || NumberUtils.isNumber(t_Value.toString())) {
					//���Է��ַ���������
					t_Marker.setAttribute(t_Key, t_Value);
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#hasError()
	 */
	public boolean hasError()
	{
		try
		{
			IMarker[] t_Markers = this.resource.findMarkers(IMarker.PROBLEM, false, IResource.DEPTH_INFINITE);

			if(ArrayUtils.isEmpty(t_Markers))
			{
				return false;
			}

			for (int i = 0; i < t_Markers.length; i++) {
				IMarker t_Marker = t_Markers[i];

				if(t_Marker.getAttribute(IMarker.SEVERITY, IMarker.SEVERITY_INFO)==IMarker.SEVERITY_ERROR)
				{
					return true;
				}
				//Check the severity
			}

			return false;
		}
		catch (CoreException e)
		{
			// Nothing to do
			return false;
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#info(java.lang.String)
	 */
	public void info(String r_Message, Properties r_Properties)
	{
		try
		{
			IMarker t_Marker = this.resource.createMarker(IMarker.TEXT);

			setAttributes(r_Message, r_Properties, t_Marker);

			t_Marker.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_NORMAL);
			t_Marker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_INFO);
		}
		catch (CoreException e)
		{
			// Nothing to do
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#warn(java.lang.String)
	 */
	public void warn(String r_Message, Properties r_Properties)
	{
		try
		{
			IMarker t_Marker = this.resource.createMarker(IMarker.PROBLEM);

			setAttributes(r_Message, r_Properties, t_Marker);

			t_Marker.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_NORMAL);
			t_Marker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_WARNING);
		}
		catch (CoreException e)
		{
			// Nothing to do
		}

	}

}
