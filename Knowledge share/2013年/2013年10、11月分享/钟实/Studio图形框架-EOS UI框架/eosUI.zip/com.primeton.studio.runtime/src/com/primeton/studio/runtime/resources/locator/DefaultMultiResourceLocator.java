/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/DefaultMultiResourceLocator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-8-19
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ArrayUtils;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * Ĭ�ϵ����ƿռ���ҷ�ʽ��ֱ�Ӹ������ƿռ���������Դ��<BR>
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultMultiResourceLocator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/08/26 02:09:03  hongsq
 * Update:��Ŀ�²���ֻ��Դ��Ŀ¼�²���
 *
 * Revision 1.1  2009/08/20 07:47:03  hongsq
 * Update:�ṩһ��ӿ�֧�ֲ���һ���ļ������޸�xsd,wsdl��ع����������ƿռ��ظ�
 * 
 */
public class DefaultMultiResourceLocator extends AbstractMultiResourceLocator {

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFiles(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFiles(IProjectDelegate project, String[] namespaces) {
		List<IFileDelegate> files = new ArrayList<IFileDelegate>();
		
		//ֻ��src�²���,��Ϊ·����ʽ�����ƿռ������ԴĿ¼��
		IFileDelegate[] srcFiles = findFilesInSourceFolders(project, namespaces);
		files.addAll(Arrays.asList(srcFiles));
		
		IFileDelegate[] libFiles = findFilesInLibraries(project, namespaces);
		files.addAll(Arrays.asList(libFiles));

		return files.toArray(new IFileDelegate[files.size()]);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFiles(com.primeton.studio.runtime.core.IContribution, java.lang.String[], boolean)
	 */
	public IFileDelegate[] findFiles(IContribution contribution, String[] namespaces, boolean includeReference) {
		List<IFileDelegate> files = new ArrayList<IFileDelegate>();
		IContribution[] contributions = includeReference ? ContributionUtil.getAllRelatedContributions(new IContribution[]{contribution}) : new IContribution[]{contribution};
		for (int i = 0; i < contributions.length; i++) {
			IFolderDelegate folder = contributions[i].getFolder();

			IFileDelegate[] fileDelegates = findFilesInFolder(namespaces, folder, false);
			files.addAll(Arrays.asList(fileDelegates));
		}
		return files.toArray(new IFileDelegate[files.size()]);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInFolders(java.lang.String[], com.primeton.studio.runtime.resources.IFolderDelegate[])
	 */
	public IFileDelegate[] findFilesInFolders(String[] namespaces, IFolderDelegate[] folders) {
		List<IFileDelegate> files = new ArrayList<IFileDelegate>();
		for (IFolderDelegate delegate : folders) {
			if (delegate == null)
				continue;
			IFileDelegate[] fileDelegates = findFilesInFolder(namespaces, delegate, false);
			files.addAll(Arrays.asList(fileDelegates));
		}
		return files.toArray(new IFileDelegate[files.size()]);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInLibraries(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFilesInLibraries(IProjectDelegate project, String[] namespaces) {
		return findFilesInLibraries(project, namespaces, true);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInSourceFolders(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFilesInSourceFolders(IProjectDelegate project, String[] namespaces) {
		ISourceFolderDelegate[] srcFolders = project.getSourceFolders();
		return findFilesInFolders(namespaces, srcFolders);
	}
	
	/**
	 * ��ָ��Ŀ¼�²���ָ�����ƿռ���ļ�
	 * @param namespaces
	 * @param folder
	 * @param supportSourceInBinary		�Ƿ�֧�ֶ������ļ�(�������ļ��п��������ÿ��е��ļ�)
	 * @return
	 */
	private IFileDelegate[] findFilesInFolder(String[] namespaces, IFolderDelegate folder, boolean supportSourceInBinary) {
		List<IFileDelegate> files = new ArrayList<IFileDelegate>();
		for (int j = 0; j < namespaces.length; j++) {
			String namespace = namespaces[j];
			String extension = FilenameUtils.getExtension(namespace);
			String filePath = FilenameUtil.toPathInUnixStyle(FilenameUtils.removeExtension(namespace));
			IFileDelegate fileDelegate = folder.getFile(filePath + "." + extension);

			if(!ResourceHelper.isValidResource(fileDelegate)){
				continue;
			}
			
			if(!fileDelegate.isBinary() || supportSourceInBinary){
				files.add(fileDelegate);
			}
		}

		return files.toArray(new IFileDelegate[files.size()]);
	}
	
	/**
	 * �����ÿ��еõ��ļ���<BR>.
	 * @param project
	 * @param namespaces
	 * @param supportSourceInBinary ֧�����ÿ��а���Դ�ļ�
	 * @return
	 */
	private IFileDelegate[] findFilesInLibraries(IProjectDelegate project, String[] namespaces, boolean supportSourceInBinary) {
		List<IFileDelegate> files = new ArrayList<IFileDelegate>();
		ILibrary[] libraries = project.getLibraries();
		
		if (!ArrayUtils.isEmpty(libraries)) {
			for (int i = 0; i < libraries.length; i++) {
				ILibrary library = libraries[i];
				IContribution[] contributions = library.getContributions();
				for (int j = 0; j < contributions.length; j++) {
					IFolderDelegate folder = (IFolderDelegate) contributions[j].getResource();

					IFileDelegate[] fileDelegates = findFilesInFolder(namespaces, folder, supportSourceInBinary);
					files.addAll(Arrays.asList(fileDelegates));
				}
			}
		}
		
		return files.toArray(new IFileDelegate[files.size()]);
	}
}
