/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/eclipse/EclipseResourceDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-29
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.eclipse;

import java.io.File;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.QualifiedName;

import com.primeton.studio.runtime.RuntimePlugin;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.resources.internal.base.AbstractResourceDelegate;

/**
 * Eclipse��Դ���ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EclipseResourceDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 * Revision 1.2  2008/09/01 07:44:42  chenxp
 * Update: ʹ��eclipse��Դ������EclipseResourceDelegate�����д����Լ��ʱ����IResource����nullֵ�жϣ��������ָ���쳣��(yangmd)
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.20  2008/05/05 08:23:49  chenxp
 * UnitTest:��ȡ�־û�����ǰ�����Դ�Ƿ���ڡ�
 *
 * Revision 1.19  2008/04/25 08:56:22  yanfei
 * Update:getLastModifiedȡresource��ʱ�����
 *
 * Revision 1.18  2008/04/14 03:32:00  wanglei
 * Update:���ӶԳ־û����Ե�֧�֡�
 *
 * Revision 1.17  2008/04/08 12:14:17  wanglei
 * Update:����NPE��Bug��
 *
 * Revision 1.16  2008/04/08 03:46:42  wanglei
 * Update:����ʱ�����
 *
 * Revision 1.15  2008/03/13 03:27:02  chenxp
 * Update:�޸�getLastModified����
 *
 * Revision 1.14  2008/01/14 08:02:14  wanglei
 * Review:��Ϊ��FAT32�����ϣ�ʱ���Ҳ����Ч�����Ի��ǻ���Eclipse�Լ���ʱ�����
 *
 * Revision 1.13  2007/11/01 06:45:28  wanglei
 * Review:������isArchive,isEditable,isBinary������
 *
 * Revision 1.12  2007/09/10 01:12:36  wanglei
 * Review:����equals��hashCode������
 *
 * Revision 1.11  2007/09/06 06:40:47  wanglei
 * Review:ԭ��Eclipse����Դʱ������л���ģ���Ҫ������
 *
 * Revision 1.10  2007/07/24 01:13:11  wanglei
 * UnitTest:�����˿��ܳ���NullPointerException��BUG��
 *
 * Revision 1.9  2007/07/05 05:13:08  wanglei
 * Remove:ȥ�����õ�metadata�ֶΡ�
 *
 * Revision 1.8  2007/06/28 09:33:49  wanglei
 * Review:�������࣬��֧��getData��setData������
 *
 * Revision 1.7  2007/05/30 08:58:27  wanglei
 * Refactor:��ΪIResourceDelegate��getSource�ع���getSourceFolder��
 *
 * Revision 1.6  2007/05/28 06:49:56  wanglei
 * Update:������equals������ʹ֮����ݡ�
 *
 * Revision 1.5  2007/05/08 09:02:55  wanglei
 * Refactor:��getSrcFolder��getSrcFolders���ĳ�getSourceFoder��getSourceFoders������
 *
 * Revision 1.4  2007/04/17 09:58:06  wanglei
 * Refactor:��getFile���Ƶ�IResourceDelegate�С�
 *
 * Revision 1.3  2007/04/05 01:06:40  wanglei
 * Add:������toString������
 *
 * Revision 1.2  2007/03/30 02:19:24  wanglei
 * Remove:ȥ����Ԫ���ݷ�����
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public abstract class EclipseResourceDelegate extends AbstractResourceDelegate implements IResourceDelegate {

	/**
	 * eclipse
	 */
	public static final String ECLIPSE = "eclipse";

	private IResource resource;

	/**
	 * ֱ�Ӵ���Eclipse��Resource��<BR>
	 */
	public EclipseResourceDelegate(IResource resource) {
		super();
		this.resource = resource;
	}

	/**
	 * @return Returns the resource.
	 */
	public IResource getResource() {
		return this.resource;
	}

	/**
	 * {@inheritDoc}
	 */
	public void delete() throws ResourceException {
		try {
			this.resource.delete(false, null);
		} catch (CoreException e) {
			throw new ResourceException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean exists() throws ResourceException {
		return resource != null && this.resource.exists();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getFullPath() throws ResourceException {
		return this.resource.getFullPath().toString();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getName() throws ResourceException {
		return this.resource.getName();
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getParent() throws ResourceException {
		return EclipseResourceManager.getInstance().getParent(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate getProject() throws ResourceException {
		return EclipseResourceManager.getInstance().getProject(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProjectRelativePath() throws ResourceException {
		return this.getResource().getProjectRelativePath().toString();
	}

	/**
	 * {@inheritDoc}
	 */
	public final IRootDelegate getRoot() throws ResourceException {
		return EclipseRootDelegate.getInstance();
	}

	/**
	 * {@inheritDoc}
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return EclipseResourceManager.getInstance().getSourceFolder(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getSourceRelativePath() throws ResourceException {
		return EclipseResourceManager.getInstance().getSourceRelativePath(this);
	}

	/**
	 * {@inheritDoc}
	 */
	public int getType() throws ResourceException {
		return this.resource.getType();
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {

		final int PRIME = 31;
		int t_Result = 1;
		t_Result = PRIME * t_Result + ((this.resource == null) ? 0 : this.resource.hashCode());
		return t_Result;
	}

	/**
	 * {@inheritDoc}
	 */
	public long getLastModified() {
		return this.resource.getLocalTimeStamp();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (this.resource == null) {
			return false;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final EclipseResourceDelegate other = (EclipseResourceDelegate) obj;
		return ObjectUtils.equals(this.resource, other.resource);
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getAdapter(Class adapter) {
		if (IResource.class == adapter) {
			return this.getResource();
		}

		if (IProject.class == adapter) {
			return this.resource.getProject();
		}

		return super.getAdapter(adapter);
	}

	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		return this.resource.toString();
	}

	/**
	 * {@inheritDoc}
	 */
	public File getFile() {
		if (null == this.resource) {
			return null;
		}
		else {
			IPath path = this.resource.getLocation();
			if (null == path) {
				return null;
			}
			return path.toFile();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isArchive() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isEditable() {

		if (!this.resource.isAccessible()) {
			return false;
		}

		if (this.resource.isLinked()) {
			return false;
		}

		ResourceAttributes attributes = this.resource.getResourceAttributes();
		if (null == attributes) {
			return false;
		}

		return attributes.isReadOnly();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isBinary() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProtocol() {
		return ECLIPSE;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getPersistentProperty(String key) {
		try {
			if(!this.resource.exists())
				return null;

			return this.resource.getPersistentProperty(new QualifiedName(RuntimePlugin.PLUGIN_ID, key));
		} catch (CoreException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void setPersistentProperty(String key, String value) {
		try {
			QualifiedName name=new QualifiedName(RuntimePlugin.PLUGIN_ID, key);
			this.resource.setPersistentProperty(name,value);
		} catch (CoreException e) {
			//Nothing to do
			e.printStackTrace();
		}
	}
}
