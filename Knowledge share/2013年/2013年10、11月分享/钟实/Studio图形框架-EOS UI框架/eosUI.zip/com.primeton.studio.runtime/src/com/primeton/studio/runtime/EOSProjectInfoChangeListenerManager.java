/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/EOSProjectInfoChangeListenerManager.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-4-2
 *******************************************************************************/


package com.primeton.studio.runtime;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.primeton.studio.runtime.project.internal.EOSProject;

/**
 * TODO�˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EOSProjectInfoChangeListenerManager.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2010/10/29 06:19:33  guwei
 * BUG: 29521 ģ��Ĳ���������޷�ɾ��
 *
 * Revision 1.2  2009/05/18 09:26:40  lvyuan
 * BugFix:Bug18797 �޸�by chenxp
 *
 * Revision 1.1  2008/07/04 11:57:24  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/02 09:26:17  lvyuan
 * Add:������Ŀ��Դ�ı�ļ�����
 *
 */
public class EOSProjectInfoChangeListenerManager {

    /**�������ļ���*/
    private List<IEOSProjectInfoChangeListener> list = new ArrayList<IEOSProjectInfoChangeListener>();


    private static EOSProjectInfoChangeListenerManager INSTANCE = new EOSProjectInfoChangeListenerManager();

    private boolean supportNotify = true;

    private EOSProjectInfoChangeListenerManager() {}

    public static EOSProjectInfoChangeListenerManager getInstance(){
        return INSTANCE;
    }

    /**
     * @param lnfoChangeListener
     */
    public void addListener(IEOSProjectInfoChangeListener lnfoChangeListener) {
        if(!list.contains(lnfoChangeListener)) {
            list.add(lnfoChangeListener);
        }
    }

    public void removeListener(IEOSProjectInfoChangeListener lnfoChangeListener) {
        if(list.contains(lnfoChangeListener)) {
            list.remove(lnfoChangeListener);
        }
    }

    public void setSupportNotify(boolean flag) {
    	this.supportNotify = flag;
    }

    /**
     * ֪ͨ��Ŀ��Ϣ�ĸı䡣<BR>
     *
     * @param project
     * @param changeType
     */
    public void fireProjectInfoChange(EOSProject project,String changeType) {
    	if(!this.supportNotify)
    		return;

        for (Iterator iter = list.iterator(); iter.hasNext();) {
            IEOSProjectInfoChangeListener element = (IEOSProjectInfoChangeListener) iter.next();
            element.fireProjectInfoChange(project, changeType);
        }
    }
}
