/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

import com.eos.system.utility.CollectionUtil;
import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.RuntimeMessages;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IPackage;
import com.primeton.studio.runtime.core.internal.Contribution;
import com.primeton.studio.runtime.core.internal.Package;
import com.primeton.studio.runtime.metadata.IMetadata;
import com.primeton.studio.runtime.metadata.internal.FolderMetadata;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegateSet;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.resources.internal.ResourceDelegateSet;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceManager;

/**
 * Composite�ĳ������ַ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ContributionUtil.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/08/27 09:44:55  hongsq
 * Update:�½�6.1��Ŀ��6.1�汾�Ĺ�����
 *
 * Revision 1.2  2009/05/07 12:55:48  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.13  2008/07/01 07:33:58  hongsq
 * Update:�ṩenableUpdateRequiredBundle���������ж�һ��Contribution�Ƿ������༭���ǵ�MANIFEST.MF�ļ�
 *
 * Revision 1.12  2008/07/01 05:37:12  hongsq
 * Update:��CC���ļ�����֤�ҵ���չ���У���checkFiles�����ŵ�ResourceHelper�У�����������ļ�������֤��
 *
 * Revision 1.11  2008/05/17 09:46:49  chenxp
 * Update:�޸�getAllRelatedContributions�����������Ƿ�֧�ֵݹ���Ҿ���������ϵ�Ĺ�������
 *
 * Revision 1.10  2008/05/17 09:09:40  weizm
 * Update:����һ����ָ���쳣
 *
 * Revision 1.9  2008/05/07 08:50:45  chenxp
 * Update:ȡ���������Ĺ��ʻ���Դǰ׺
 *
 * Revision 1.7  2008/04/22 11:34:23  yangmd
 * Update:�޸��߼�,�ṩ��ȡ��������������
 *
 * Revision 1.6  2008/04/21 12:14:32  yanfei
 * Update:outStreamû�йرա�
 *
 * Revision 1.5  2008/04/17 12:43:52  wanglei
 * Review:�ر�û�йص�����
 *
 * Revision 1.4  2008/04/16 02:38:56  wanglei
 * Review:ѭ����֤��������ÿ��е�Contribution���д�����
 *
 * Revision 1.3  2008/04/14 07:35:13  wanglei
 * Update:��ȡͨ�÷�����ResourceHelper�С�
 *
 * Revision 1.2  2007/12/29 09:42:57  caiwei
 * Update:���ӷ����Ա�����web��Դ
 *
 * Revision 1.1  2007/12/22 01:51:59  wanglei
 * Review:��CompositeUtil������ΪContributionUtil����SCA�����һ�¡�
 *
 * Revision 1.40  2007/12/20 01:18:32  wanglei
 * Review:CollectionUtil�е�addAllӦ����addAllQuietly��
 *
 * Revision 1.39  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.38  2007/12/18 07:39:36  wanglei
 * Review:ʹ��FilenameUtils������PathUtil��
 *
 * Revision 1.37  2007/12/05 06:00:23  lvyuan
 * Update:��������
 *
 * Revision 1.36  2007/12/03 06:21:59  wanglei
 * Review:����֤Contribution������ù�ϵʱ���������Ѻõ���ʾ��
 *
 * Revision 1.35  2007/11/28 09:26:13  wanglei
 * Review:RuntimeManager�еĲ��ַ����Ƶ�RuntimeHelper�У�Ҳ��һЩ��������������
 *
 * Revision 1.34  2007/11/13 09:40:22  wanglei
 * Add:����getWebContext������
 *
 * Revision 1.33  2007/11/12 06:44:05  tenghao
 * Add: ����getAllReferencedContributions
 *
 * Revision 1.32  2007/08/29 06:36:00  caiwei
 * update:add 2 methods
 *
 * Revision 1.31  2007/08/28 08:18:29  wanglei
 * Reivew:����compositeӦ�øĳ�contribution��
 *
 * Revision 1.30  2007/07/23 03:39:20  zhangzh
 * add:�޸�getCompositefile����
 *
 * Revision 1.29  2007/07/20 02:58:01  wanglei
 * Update:��ΪIContribution������getNamespace������ʹ��getName��
 *
 * Revision 1.28  2007/07/18 06:42:34  wanglei
 * UnitTest:����ȡContribution����ʱ��ȡ����ʾ���Ƶ�Bug��
 *
 * Revision 1.27  2007/07/09 03:46:11  zhangzh
 * add:����getWebContent���߷���
 *
 * Revision 1.26  2007/07/04 03:12:11  caiwei
 * update:modify isLoop
 *
 * Revision 1.25  2007/07/03 12:00:20  zhangzh
 * add:����getAllCompoisteFiles����
 * Revision 1.24 2007/07/02 13:04:26 wanglei
 * Add:����(get/set)Version��(get/set)AutoDeploy������
 *
 * Revision 1.23 2007/07/02 03:55:16 zhangzh add:���ӷ���sca-contribution.xml����
 *
 * Revision 1.22 2007/07/02 02:38:24 zhangzh �޸�getRequiredBundles bug
 *
 * Revision 1.21 2007/07/01 11:09:49 zhangzh Add:�޸�getRequiredBundles bug
 *
 * Revision 1.20 2007/06/30 13:11:17 wanglei Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.19 2007/06/28 10:49:52 wanglei Update:����getManifestFile������
 *
 * Revision 1.18 2007/06/28 09:36:48 wanglei
 * Review:����ֱ��ʹ��ISourceFolderDelegate��֧�����ÿ⡣
 *
 * Revision 1.17 2007/06/28 06:39:46 caiwei update:��getManifestFileΪpublic
 *
 * Revision 1.16 2007/06/26 06:42:48 yanfei Update:���Ӱ�סCtrl����˫������ʵ�ֻ�ת��ʵ�ֵĹ��ܡ�
 *
 * Revision 1.15 2007/06/23 05:38:37 zhangzh add:����isComponentTypeDirectory ����
 *
 * Revision 1.14 2007/06/23 01:59:24 yanfei Update:�޸�contribution�����ļ����ɵ�·����
 *
 * Revision 1.13 2007/06/22 12:14:41 caiwei update:add �ݹ��ȡ���������ķ���
 *
 * Revision 1.12 2007/06/22 11:18:40 yanfei Update:�޸Ļ�ȡcomposite basename�ķ�����
 *
 * Revision 1.11 2007/06/21 11:28:40 wanglei Add:����һ��computeResourceSet��
 *
 * Revision 1.10 2007/06/21 03:28:47 yanfei Update: �޸�composite�ļ�������λ�á�
 *
 * Revision 1.9 2007/06/20 01:42:53 yanfei Update:��������ͬ���Ĵ���
 *
 * Revision 1.8 2007/06/20 01:07:10 yanfei Update:����getCompositeBaseName������
 *
 * Revision 1.6 2007/06/16 06:08:09 yanfei
 * Update:�½�ҵ�񹹼�ʱ����eosinf�ļ���exception.properties�ļ�
 *
 * Revision 1.4 2007/06/14 13:20:07 wanglei UnitTest:����ȡ�����ռ��Bug��
 *
 * Revision 1.3 2007/06/14 07:05:17 yanfei UnitTest:
 * �޸�getRrequiredBundles���������splitΪ���򷵻س���Ϊ������顣
 *
 * Revision 1.2 2007/06/13 09:08:09 wanglei
 * Add:�����˼���ֱ�Ӵ�IFileDelegate�ж�ȡManiFest.mf�ļ����ݵĹ��ܡ�
 *
 * Revision 1.1 2007/06/13 06:35:39 wanglei Update:�ύ��CVS��
 *
 */

public final class ContributionUtil {

	private final static String COMPOSITE_FILE_EXT = "composite"; //$NON-NLS-1$

	private final static String CONTRIBUTION_INF_FILE_NAME = "contribution.eosinf"; //$NON-NLS-1$

	private final static String CONTRIBUTION_EXCEPTION_NAME = "exception.properties"; //$NON-NLS-1$

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private ContributionUtil() {
		super();
	}

	/**
	 * ����ָ����������Ҫ��Bundle���ơ�<BR>
	 *
	 * @param contribution
	 * @param bundleNames
	 */
	public static void setRequiredBundles(IContribution contribution, String[] bundleNames) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		String value = StringUtils.join(bundleNames, ","); //$NON-NLS-1$
		boolean flag = setProperty(folder, RuntimeConstant.REQUIRE_BUNDLE, value);
		if(flag == false)
			throw new RuntimeException(""); //$NON-NLS-1$
	}

	/**
	 *
	 * @param contribution
	 * @param bundleName
	 * @return
	 */
	public static String addRequiredBundle(IContribution contribution, String bundleName) {
		if (null == bundleName) {
			return null;
		}
		Set set = new HashSet();
		String[] budnleNames = getRequiredBundles(contribution);
		CollectionUtil.addAllQuietly(set, budnleNames);

		if (set.contains(bundleName)) {
			return null;
		}
		// ���ȼ�������ظ���������ظ������� null����

		set.add(bundleName);
		budnleNames = new String[set.size()];
		set.toArray(budnleNames);

		setRequiredBundles(contribution, budnleNames);
		return bundleName;
		// ��������Bundle
	}

	/**
	 *
	 * @param contribution
	 * @param bundleName
	 * @return
	 */
	public static String removeRequiredBundle(IContribution contribution, String bundleName) {
		if (null == bundleName) {
			return null;
		}
		Set set = new HashSet();
		String[] budnleNames = getRequiredBundles(contribution);
		CollectionUtil.addAllQuietly(set, budnleNames);

		if (!set.contains(bundleName)) {
			return null;
		}
		// ���ȼ�������ظ���������ظ������� null����

		set.remove(bundleName);
		budnleNames = new String[set.size()];
		set.toArray(budnleNames);

		setRequiredBundles(contribution, budnleNames);
		return bundleName;
		// ��������Bundle
	}

	/**
	 * ��֤contribution�Ƿ���Ա༭����manifest�ļ�
	 * @param contributions
	 * @return
	 */
	public static boolean enableUpdateRequiredBundle(IContribution[] contributions){
		IFile[] manifestFiles = new IFile[contributions.length];
		for (int i = 0; i < contributions.length; i++) {
			IContribution contribution = contributions[i];
			IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
			if(null == folder)
				return false;

			IFileDelegate fileDelegate = getManifestFile(folder);
			if(null == fileDelegate || fileDelegate.exists() == false)
				return false;

			manifestFiles[i] = (IFile) fileDelegate.getAdapter(IFile.class);
			if(null == manifestFiles[i])
				return false;
		}

		if(ResourceHelper.checkFiles(manifestFiles) == false)
			return false;

		return true;
	}

	/**
	 * ����ָ����������Ҫ��Bundle���ơ�<BR>
	 *
	 * @param contribution
	 * @return
	 */
	public static String[] getRequiredBundles(IContribution contribution) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		String value = getProperty(folder, RuntimeConstant.REQUIRE_BUNDLE);
		String[] result = StringUtils.split(value, ","); //$NON-NLS-1$

		if (result == null)
			result = new String[0];

		return result;
	}

	/**
	 * �ҳ����е������������Լ���
	 *
	 * @param composites
	 * @return
	 */
	public static IContribution[] getAllRelatedContributions(IContribution[] composites, boolean includingLibrary) {
		return getAllRelatedContributions(composites, includingLibrary, true);
	}

	/**
	 * �ҳ����е������������Լ���
	 * @param composites
	 * @param includingLibrary
	 * @param recursive
	 * @return
	 */
	public static IContribution[] getAllRelatedContributions(IContribution[] composites, boolean includingLibrary, boolean recursive) {
		if (ArrayUtils.isEmpty(composites)) {
			return new IContribution[0];
		}

		List<IContribution> allRelatedContributions = new ArrayList<IContribution>(composites.length);
		for (int i = 0; i < composites.length; i++) {
			IContribution contribution = composites[i];
			if(contribution != null)allRelatedContributions.add(contribution);
		}
		if (CollectionUtils.isEmpty(allRelatedContributions)) {
			return new IContribution[0];
		}
		IProjectDelegate projectDelegate = allRelatedContributions.get(0).getResource().getProject();
		//�õ���ǰ��Ŀ�����й�������ֻȡһ�Σ������������20�����ʱ��ȡһ��Ҫ�ķ�20����롣
		IContribution[] allContributions = RuntimeManager.getAllContributions(projectDelegate, includingLibrary);

		List<IContribution> tempList = null;
		if(recursive){
			tempList = allRelatedContributions;
		}else{
			tempList = Arrays.asList(composites);
		}

		for (int i = 0; i < tempList.size(); i++) {
			IContribution contribution2 = allRelatedContributions.get(i);
			String[] relateds = contribution2.getRequiredBundles();
			for (int j = 0; j < relateds.length; j++) {
				String string = relateds[j];
				for (int k = 0; k < allContributions.length; k++) {
					IContribution contribution3 = allContributions[k];
					if(string.equals(contribution3.getName())
							&& !allRelatedContributions.contains(contribution3)){
						allRelatedContributions.add(contribution3);
					}
				}
			}
		}
		return allRelatedContributions.toArray(new IContribution[allRelatedContributions.size()]);
	}


	/**
	 * �ҳ����е������������Լ���
	 *
	 * @param composites
	 * @return
	 */
	public static IContribution[] getAllRelatedContributions(IContribution[] composites) {
		return getAllRelatedContributions(composites, true);

	}
	/**
	 * ������ߵ���������Ƿ���һ����
	 *
	 * @param contribution1
	 * @param contribution2
	 * @return
	 */
	public static boolean isLoop(IContribution contribution1, IContribution contribution2) {

		if (contribution1.isBinary()) {
			return false;
		}

		if (contribution2.isBinary()) {
			return false;
		}
		//��������ÿ�Ľ��м��

		Set compositeRequired = new HashSet();
		IContribution[] compositeRequiredArray = getAllRelatedContributions(new IContribution[] {
			contribution1
		}, false);
		for (IContribution contribution : compositeRequiredArray) {
			compositeRequired.add(contribution.getName());
		}

		if (compositeRequired.contains(contribution2.getName())) {
			compositeRequiredArray = getAllRelatedContributions(new IContribution[] {
				contribution2
			}, false);
			compositeRequired.clear();
			for (IContribution contribution : compositeRequiredArray) {
				compositeRequired.add(contribution.getName());
			}
			if (compositeRequired.contains(contribution1.getName())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * ����Լ��ĵݹ������Ƿ�����γ���һ����
	 * @param contribution
	 * @return
	 */
	public static boolean isSelfLoop(IContribution contribution, IMessageCaller messageCaller) {
		IContribution[] compositeRequiredArray = getAllRelatedContributions(new IContribution[] {
			contribution
		}, false);
		for (IContribution targetContribution : compositeRequiredArray) {
			if (targetContribution.equals(contribution)) {
				continue;
			}
			//���Ա�contribution���õĹ������ǲ��Ƿ�����Ҳ������contribution������ǣ����γ���һ������
			if (isContributionAReferenceContributionB(targetContribution, contribution)) {
				String message = MessageFormat.format(RuntimeMessages.BETWEEN_CONTRIBUTION + RuntimeMessages.CIRCLE_REFERENCE_EXIST, new Object[] {
					contribution.getName(),
					targetContribution.getName()
				});

				if (null != messageCaller) {
					messageCaller.error(message, null);
				}

				return true;
			}

		}
		return false;
	}

	/**
	 * A�Ƿ�ֱ�ӻ�������B
	 * @param contributionA
	 * @param contributionB
	 * @return
	 */
	public static boolean isContributionAReferenceContributionB(IContribution contributionA, IContribution contributionB) {

		assert StringUtils.equals(contributionA.getName(), contributionB.getName()) : "cannot be same contribution"; //$NON-NLS-1$

		IContribution[] compositeRequiredArray = getAllRelatedContributions(new IContribution[] {
			contributionA
		}, true);
		Set compositeRequired = new HashSet();
		for (IContribution contribution : compositeRequiredArray) {
			compositeRequired.add(contribution.getName());
		}
		return compositeRequired.contains(contributionB.getName());
	}

	/**
	 * �ҳ����������Լ���Contribution��
	 *
	 * @param composites
	 * @param withLibraries �Ƿ���Ҫ������������ͼ�е�Contribution��
	 * @return
	 */
	public static IContribution[] getAllReferencedContributions(IContribution composite, boolean withLibraries) {

		if (composite == null) {
			return new IContribution[0];
		}

		// ��ȡ��Ŀ��ȫ��Contribution
		IProjectDelegate projectDelegate = composite.getResource().getProject();

		IContribution[] allContributions;
		if (withLibraries) {
			allContributions = RuntimeManager.getAllContributions(projectDelegate);
		}
		else {
			allContributions = RuntimeManager.getAllContributionsWithoutLibraries(projectDelegate);
		}

		List list = new ArrayList();
		for (IContribution contribution : allContributions) {

			// �ж��Ƿ����Contribution��������
			if (isContributionAReferenceContributionB(contribution, composite))
				list.add(contribution);
		}

		IContribution[] contributions = new IContribution[list.size()];
		list.toArray(contributions);

		return contributions;
	}

	/*
	 * ����ָ����������Ҫ��Bundle���ơ�<BR>
	 *
	 * @param composite @return
	 */
	public static void loadProperties(IContribution contribution, Map map) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		IFileDelegate fileDelegate = getManifestFile(folder);
		loadProperties(fileDelegate, map);
	}

	/**
	 * ��ManiFest.MF�ļ��ж�ȡָ�����Լ���Ӧ��ֵ��<BR>
	 *
	 * @param fileDelegate
	 * @param map
	 */
	public static void loadProperties(IFileDelegate fileDelegate, Map map) {
		if (null == fileDelegate) {
			return;
		}
		// �����ǶԲ�������Ч�ԶԽ��м��

		Manifest manifest = new Manifest();
		InputStream inStream = null;

		if (fileDelegate.exists()) {

			try {
				inStream = fileDelegate.getContents();
				manifest.read(inStream);
			} catch (Exception e) {
				// Nothing to do
			} finally {
				IOUtils.closeQuietly(inStream);
			}
		}

		Attributes atts = manifest.getMainAttributes();

		for (Iterator iterator = map.keySet().iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			map.put(key, atts.getValue(key));
		}
	}

	/**
	 *
	 * /** ��ManiFest.MF�ļ���д��ָ�����Լ���Ӧ��ֵ��<BR>
	 *
	 * @param fileDelegate
	 * @param names
	 * @param values
	 * @return
	 */
	public static boolean setProperties(IFileDelegate fileDelegate, String[] names, String[] values) {
		if (null == fileDelegate) {
			return false;
		}
		// �����ǶԲ�������Ч�ԶԽ��м��

		Manifest manifest = new Manifest();
		InputStream inStream = null;

		if (fileDelegate.exists()) {

			if(ResourceHelper.checkFiles(new IFile[]{(IFile) fileDelegate.getAdapter(IFile.class)}) == false){
				return false;
			}

			try {
				inStream = fileDelegate.getContents();
				manifest.read(inStream);
			} catch (Exception e) {
				// Nothing to do
			} finally {
				IOUtils.closeQuietly(inStream);
			}
		}

		Attributes atts = manifest.getMainAttributes();

		if (!atts.containsKey(Attributes.Name.MANIFEST_VERSION)) {
			atts.put(Attributes.Name.MANIFEST_VERSION, RuntimeConstant.DEFAULT_MANIFEST_VERSION);
		}
		// ��ΪManifest�ļ�һ����Ҫһ���汾�ţ�����Ҫ��д֮ǰ���汾���Ƿ����

		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			String value = values[i];

			atts.put(new Attributes.Name(name), value);
		}

		ByteArrayOutputStream outStream = null;
		try {
			outStream = new ByteArrayOutputStream();
			manifest.write(outStream);

			ResourceHelper.write(fileDelegate, outStream.toByteArray());
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			IOUtils.closeQuietly(outStream);
		}
	}

	/**
	 * ��ManiFest.MF�ļ���д��ָ�����Լ���Ӧ��ֵ��<BR>
	 *
	 * @param folder
	 * @param names
	 * @param values
	 * @return
	 */
	public static boolean setProperties(IFolderDelegate folder, String[] names, String[] values) {

		if (ArrayUtils.isEmpty(names) || ArrayUtils.isEmpty(values)) {
			return false;
		}

		if (!ArrayUtils.isSameLength(names, values)) {
			return false;
		}

		IFileDelegate fileDelegate = getManifestFile(folder);
		return setProperties(fileDelegate, names, values);
	}

	/**
	 * ��ManiFest.MF�ļ���д��ָ�����Լ���Ӧ��ֵ��<BR>
	 *
	 * @param folder
	 * @param name
	 * @param value
	 * @return
	 */
	public static boolean setProperty(IFolderDelegate folder, String name, String value) {
		if (StringUtils.isEmpty(name)) {
			return false;
		}

		if (null == value) {
			return false;
		}

		IFileDelegate fileDelegate = getManifestFile(folder);
		if (null == fileDelegate) {
			return false;
		}
		// �����ǶԲ�������Ч�ԶԽ��м��

		return setProperties(folder, new String[] {
			name
		}, new String[] {
			value
		});
	}

	/**
	 * ��ManiFest.MF�ļ��ж�ȡָ�����ԡ�<BR>
	 *
	 * @param folder
	 * @param name
	 * @return
	 */
	public static String getProperty(IFolderDelegate folder, String name) {
		if (StringUtils.isEmpty(name)) {
			return null;
		}

		IFileDelegate fileDelegate = getManifestFile(folder);
		return getProperty(fileDelegate, name);
	}

	/**
	 * ��ManiFest.MF�ļ��ж�ȡָ�����ԡ�<BR>
	 *
	 * @param folder
	 * @param name
	 * @return
	 */
	public static String getProperty(IFileDelegate fileDelegate, String name) {
		if (null == fileDelegate) {
			return null;
		}
		// �����ǶԲ�������Ч�ԶԽ��м��

		Manifest manifest = new Manifest();
		InputStream inStream = null;

		try {
			inStream = fileDelegate.getContents();
			manifest.read(inStream);
			return manifest.getMainAttributes().getValue(name);

		} catch (Exception e) {
			return null;
		} finally {
			IOUtils.closeQuietly(inStream);
		}
	}

	/**
	 * ����һ��ָ��Ŀ¼�µ�META-INF/MANIFEST.MF�ļ�
	 *
	 * @param folder
	 * @return
	 */
	public static IFileDelegate getManifestFile(IFolderDelegate folder) {

		if (null == folder) {
			return null;
		}

		IFileDelegate file = folder.getFile(RuntimeConstant.MANIFEST);

		if ((null == file) || (!file.exists())) {
			return null;
		}

		return file;
	}

	/**
	 * ����һ��ָ��Ŀ¼�µ�META-INF/MANIFEST.MF�ļ���Bundle-Name��Ӧ�����ݡ�<BR>
	 *
	 * @param folder
	 *
	 * @return the baseName
	 */
	public static String getSymbolicName(IFolderDelegate folder) {

		String baseName = getProperty(folder, RuntimeConstant.BUNDLE_SYMBOLICNAME);
		if (StringUtils.isEmpty(baseName)) {
			return getDefaultSymbolicNameName(folder);
		}
		else {
			return baseName;
		}
	}

	/**
	 * ����һ��ָ��Ŀ¼�µ�META-INF/MANIFEST.MF�ļ���Bundle-Name��Ӧ�����ݡ�<BR>
	 *
	 * @param folder
	 *
	 * @return the baseName
	 */
	public static String getDisplayName(IFolderDelegate folder) {

		String baseName = getProperty(folder, RuntimeConstant.BUNDLE_NAME);
		if (StringUtils.isEmpty(baseName)) {
			return getDefaultSymbolicNameName(folder);
		}
		else {
			return baseName;
		}
	}

	/**
	 * �õ�Ĭ�ϵ�������<BR>
	 * ��Դ�����ϼ�Ŀ¼������ͬ
	 *
	 * @param folder
	 * @return
	 */
	public static String getDefaultSymbolicNameName(IFolderDelegate folder) {
		IFolderDelegate parentFolder = folder.getParent();
		if (null == parentFolder) {
			return folder.getName();
		}
		else {
			String name = parentFolder.getName();
			return FilenameUtil.toPathInUnixStyle(name);
		}
	}

	/**
	 * ȡ��ָ����������ӦWeb·��
	 *
	 * @param contribution
	 * @return
	 */
	public static String getWebContext(IContribution contribution) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		return getProperty(folder, RuntimeConstant.BUNDLE_WEB_CONTEXT);
	}

	/**
	 * ȡ��ָ������Դ����Ŀ¼����ӦWeb·��
	 *
	 * @param contribution
	 * @return
	 */
	public static String getWebContext(ISourceFolderDelegate folder) {
		return getProperty(folder, RuntimeConstant.BUNDLE_WEB_CONTEXT);
	}

	/**
	 * ����ָ����������ӦWeb·��
	 *
	 * @param contribution
	 * @return
	 */
	public static boolean setWebContext(IContribution contribution, String webPath) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		return setProperty(folder, RuntimeConstant.BUNDLE_WEB_CONTEXT, webPath);
	}

	/**
	 * �õ�EOSԪ�������ڵĹ�������<BR>
	 *
	 * @param element
	 * @return
	 */
	public static IContribution getContribution(IEosElement element) {
		while ((null != element) && (!(element instanceof IContribution))) {
			element = element.getParent();
		}

		if (element instanceof IContribution) {
			return (IContribution) element;
		}
		else {
			return null;
		}
	}

	/**
	 * ����ҵ�񹹼��µ�IResourceDelegate��ȡcomposite file��
	 *
	 * @param file
	 */
	public static IFile getCompositeFile(IResourceDelegate resourceDelegate) {
		IFileDelegate compositeFile = getCompositeFileDelegate(resourceDelegate);
		IFile adapterFile = (IFile) compositeFile.getAdapter(IFile.class);
		return adapterFile;
	}

	/**
	 * ����ҵ�񹹼��µ�IFile��ȡcomposite file��
	 *
	 * @param file
	 */
	public static IFile getCompositeFile(IFile file) {
		String filename = file.getFullPath().lastSegment();
		IPath path = new Path(filename);
		path = path.removeFileExtension();
		path = path.addFileExtension(COMPOSITE_FILE_EXT);
		return file.getParent().getFile(path);
	}

	public static String getCommonBaseName(IFile file) {
		IFolder srcFolder = EclipseResourceManager.getSourceFolder(file);

		StringBuffer buffer = new StringBuffer();
		IResource resource = file;
		while (!resource.getFullPath().equals(srcFolder.getFullPath())) {
			String name = resource.getName();

			name = FilenameUtils.removeExtension(name);
			buffer.insert(0, name);
			buffer.insert(0, '.');
			resource = resource.getParent();
		}
		if (buffer.charAt(0) == '.')
			buffer.deleteCharAt(0);
		return buffer.toString();
	}

	/**
	 * ��ȡҵ�񹹼�������
	 *
	 * @param file
	 * @return
	 */
	public static String getCompositeBaseName(IFile file) {
		IFolder srcFolder = EclipseResourceManager.getSourceFolder(file);

		StringBuffer buffer = new StringBuffer();
		IResource resource = file;
		while (!resource.getFullPath().equals(srcFolder.getFullPath())) {
			String name = resource.getName();

			name = FilenameUtils.removeExtension(name);
			buffer.insert(0, name);
			buffer.insert(0, '.');
			resource = resource.getParent();
		}
		if (buffer.charAt(0) == '.')
			buffer.deleteCharAt(0);
		return buffer.toString();
	}

	public static String getCompositeBaseName(IResourceDelegate delegate) {
		ISourceFolderDelegate srcFolder = delegate.getSourceFolder();

		StringBuffer buffer = new StringBuffer();
		IResourceDelegate resource = delegate;
		while (!resource.getFullPath().equals(srcFolder.getFullPath())) {
			String name = resource.getName();
			name = FilenameUtils.removeExtension(name);
			buffer.insert(0, name);
			buffer.insert(0, '.');
			resource = resource.getParent();
		}
		if (buffer.charAt(0) == '.')
			buffer.deleteCharAt(0);
		return buffer.toString();
	}

	/**
	 * ����ҵ�񹹼��µ�IResourceDelegate��ȡcomposite file��
	 *
	 * @param file
	 */
	public static IFileDelegate getCompositeFileDelegate(IResourceDelegate delegate) {
		IFolderDelegate parent = delegate.getParent();
		String name = delegate.getName();
		int index = name.lastIndexOf("."); //$NON-NLS-1$
		if (index != -1)
			name = name.substring(0, name.lastIndexOf(".")); //$NON-NLS-1$

		IFileDelegate compositeFile = parent.getFile(name + "." + COMPOSITE_FILE_EXT); //$NON-NLS-1$
		return compositeFile;
	}

	/**
	 * ����ҵ�񹹼��µ�IFile��ȡconfig/resources/�µ�eosinf�ļ���
	 *
	 * @param file
	 */
	public static IFile getCompositeConfigFile(IFolder srcFolder) {
		//IFolder srcFolder = EclipseResourceManager.getSourceFolder(file);
		return srcFolder.getFile(new Path(RuntimeConstant.META_INF + "/" + CONTRIBUTION_INF_FILE_NAME)); //$NON-NLS-1$

	}

	/**
	 * ����ҵ�񹹼��µ�IFile��ȡconfig/resources/exception�µ������ļ���
	 *
	 * @param file
	 * @return
	 */
	public static IFile getCompositeExceptionFile(IFolder srcFolder) {

		return srcFolder.getFile(new Path(RuntimeConstant.META_INF + "/" + CONTRIBUTION_EXCEPTION_NAME)); //$NON-NLS-1$
	}

	/**
	 * �õ�webcontentĿ¼
	 * @param file
	 * @return
	 */
	public static IFolder getWebContentFolder(IResource file) {
		IFolder srcFolder = EclipseResourceManager.getSourceFolder(file);
		return srcFolder.getFolder(RuntimeConstant.WEB_CONTENT);
	}

	/**
	 * ����һ��Composite��ص���Դ��<BR>
	 *
	 * @param project
	 * @param contribution
	 * @return
	 */
	public static IResourceDelegateSet computeResourceSet(IProjectDelegate project, IContribution contribution) {
		IContribution[] composites = RuntimeManager.findContributions(project, contribution.getRequiredBundles());
		ResourceDelegateSet resourceSet = new ResourceDelegateSet();
		resourceSet.addFolder((IFolderDelegate) contribution.getResource());

		if (!ArrayUtils.isEmpty(composites)) {
			for (int i = 0; i < composites.length; i++) {
				IContribution requiredContribution = composites[i];
				resourceSet.addFolder((IFolderDelegate) requiredContribution.getResource());
			}
		}

		return resourceSet;
	}

	/**
	 * ��ȡ����contribution��Դ�ļ���
	 * @param contributions
	 * @return
	 */
	public static ISourceFolderDelegate[] getSourceFolderDelegates(IContribution[] contributions) {
		List<ISourceFolderDelegate> sources = new ArrayList<ISourceFolderDelegate>();
		for (IContribution contribution : contributions) {
			ISourceFolderDelegate tmp = ((Contribution) contribution).getSourceFolder();
			sources.add(tmp);

		}
		return sources.toArray(new ISourceFolderDelegate[0]);
	}

	/**
	 * ��ȡ���е�webContext
	 * @param contributions
	 * @return
	 */
	public static IFolderDelegate[] getWebContentFolderDelegates(IContribution[] contributions) {
		ISourceFolderDelegate[] sourceFolderDelegates = ContributionUtil.getSourceFolderDelegates(contributions);
		List al = new ArrayList();
		for (ISourceFolderDelegate srcFolder : sourceFolderDelegates) {
			IFolderDelegate folderDelegate = getWebContentFolderDelegate(srcFolder);
			if (folderDelegate != null)
				al.add(folderDelegate);
		}

		return (IFolderDelegate[]) al.toArray(new IFolderDelegate[0]);
	}

	/**
	 * ��ȡwebContextĿ¼
	 * @param contributions
	 * @return
	 */
	public static IFolderDelegate getWebContentFolderDelegate(ISourceFolderDelegate srcFolder) {
		if (srcFolder != null) {
			IFolderDelegate folderDelegate = srcFolder.getFolder(RuntimeConstant.WEB_CONTENT);
			if (ResourceHelper.isValidResource(folderDelegate)) {
				return folderDelegate;
			}
		}
		return null;
	}

	/**
	 * �Ƿ���һ��ComponentTypeĿ¼
	 *
	 * @param packge
	 * @return
	 */

	public static boolean isComponentTypeDirectory(IPackage packge) {
		Package pkg = (Package) packge;
		IFolderDelegate folderDelegate = pkg.getFolder();
		FolderMetadata metadata = FolderMetadata.newInstance(folderDelegate, false);
		if (metadata == null)
			return false;
		String type = metadata.getString(RuntimeConstant.COMPONENT_TYPE);
		if (type.equals(RuntimeConstant.EOS_COMPONENT)) {
			return true;
		}
		return false;
	}

	/**
	 * ����һ��ָ��Ŀ¼�µ�META-INF/sca-contribution.xml�ļ�
	 *
	 * @param folder
	 * @return
	 */
	public static IFile getSCAContributionXmlFile(IResource resource) {
		if (null == resource) {
			return null;
		}
		IFolder srcFolder = EclipseResourceManager.getSourceFolder(resource);

		IFile file = srcFolder.getFile(RuntimeConstant.SCA_CONTRIBTUION_XML);

		if ((null == file) || (!file.exists())) {
			return null;
		}

		return file;
	}

	/**
	 * ����ָ����contribution�Ƿ�"�Զ�����"��<BR>
	 *
	 * @param contribution
	 * @return
	 */
	public static boolean isAutoDeploy(IContribution contribution) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		IMetadata metadata = FolderMetadata.newInstance(folder, false);

		if (null == metadata) {
			return true;
		}
		else {

			// System.err.println(metadata.getString(RuntimeConstant.AUTO_DEPLOY));

			return Boolean.valueOf(metadata.getString(RuntimeConstant.AUTO_DEPLOY));
		}
	}

	/**
	 * ����ָ����contribution�Ƿ�"�Զ�����"��<BR>
	 *
	 * @param contribution
	 * @param autoDeploy
	 * @return
	 */
	public static void setAutoDeploy(IContribution contribution, boolean autoDeploy) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		IMetadata metadata = FolderMetadata.newInstance(folder, true);

		metadata.setString(RuntimeConstant.AUTO_DEPLOY, Boolean.toString(autoDeploy));

	}

	/**
	 * ȡ��ָ�������İ汾��
	 *
	 * @param contribution
	 * @return
	 */
	public static String getVersion(IContribution contribution) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		return getProperty(folder, RuntimeConstant.BUNDLE_VERSION);
	}

	/**
	 * ����ָ�������İ汾��
	 *
	 * @param contribution
	 * @return
	 */
	public static boolean setVersion(IContribution contribution, String version) {
		IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
		return setProperty(folder, RuntimeConstant.BUNDLE_VERSION, version);
	}

	/**
	 * ����ָ��Ŀ¼������composite�ļ�,û�еĻ����ؿգ�
	 *
	 * @return
	 */
	public static IFileDelegate[] getAllCompositeFileDelegate(IFolderDelegate parentFolder) {
		if (null == parentFolder) {
			return null;
		}
		List fileList = new ArrayList();
		IFileDelegate[] fileDelegates = ResourceHelper.getFiles(parentFolder, (String) null);
		if (null == fileDelegates) {
			return null;
		}
		for (int i = 0; i < fileDelegates.length; i++) {
			if(null != fileDelegates[i].getExtension()){
				if (fileDelegates[i].getExtension().toLowerCase().equals(COMPOSITE_FILE_EXT)) {
					fileList.add(fileDelegates[i]);
				}
			}
		}
		if (CollectionUtils.isEmpty(fileList)) {
			return null;
		}
		IFileDelegate[] delegates = new IFileDelegate[fileList.size()];
		return (IFileDelegate[]) fileList.toArray(delegates);
	}

	/**
	 * ����һ��ָ��Ŀ¼�µ�META-INF/sca-contribution.xml�ļ�
	 *
	 * @param srcfolder
	 * @return
	 */
	public static IFileDelegate getSCAContributionXmlFile(IFolderDelegate srcfolder) {
		if (null == srcfolder) {
			return null;
		}

		IFileDelegate file = srcfolder.getFile(RuntimeConstant.SCA_CONTRIBTUION_XML);

		if ((null == file) || (!file.exists())) {
			return null;
		}

		return file;
	}
}
