/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/base/AbstractIndexKeyCreator.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-11-20
 *******************************************************************************/


package com.primeton.studio.runtime.index.base;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.IAdaptable;

import com.eos.system.utility.FilenameUtil;
import com.eos.system.utility.StringUtil;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.index.IIndexKeyCreator;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * IIndexKeyCreator��������ʵ�֡�
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: AbstractIndexKeyCreator.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.4  2009/11/04 09:32:35  youqh
 * BUG 22722  1.  ������������ʱ����������ת��Ϊ��^��
 * 2.  �ڵ��õĵط����ӿ�ָ���жϡ�
 *
 * Revision 1.3  2009/09/10 07:04:34  hongsq
 * Review��
 * ����CodeReview��
 * 1.  IIndexKeyCreator
 * ȥ����public String createIndexKey(Object target);
 * 2.  XSDModelParser��WSDLModelParser
 * ��import�е�schemaLocation������ʱ����Ҫ�޸����·���ļ��㷽ʽ
 *
 * Revision 1.2  2008/12/16 07:49:14  liu-jun
 * ���ӷ����������
 * �޸��ߣ�����
 *
 * Revision 1.1  2008/12/02 06:43:33  zhuxing
 * New:�������벿�ֵ������������ؼ������߼�����װ
 *
 */
public abstract class AbstractIndexKeyCreator implements IIndexKeyCreator {
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.index.IIndexKeyCreator#isAccept(java.lang.Object)
	 */
	public boolean isAccept(Object target) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * index key = namespace + appendix
	 *
	 * @see com.primeton.studio.runtime.index.IIndexKeyCreator#createIndexKey(java.lang.String)
	 */
	public String createIndexKey(String namespace) {
		String appendix = this.getAppendix();
		//��":"ת��Ϊ"^"
		namespace = StringUtils.replaceChars(namespace, ':', '^');
		return FilenameUtil.toPackage((appendix == null) ? namespace : (namespace + "." + appendix));
	}

	public String createIndexKey(Object target) {
		if (!this.isAccept(target))
			return null;

		String namespace = this.getNamesapce(target);
		return namespace != null ? this.createIndexKey(namespace) : null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.index.IIndexKeyCreator#getReferenceImplementation()
	 */
	public String getReferenceImplementation() {
		return RuntimeConstant.FILE;
	}

	/**
	 * ���غ�׺
	 *
	 * @return
	 */
	protected abstract String getAppendix();

	/**
	 * ���ض�����ת��Ϊeos��ָ�����ø�ʽ
	 *
	 * @param target
	 * @return
	 */
	protected String getNamesapce(Object target) {
		return "";
	}

	/**
	 * ��ȡIResourceDelegate���
	 *
	 * @param target
	 * @return
	 */
	protected final IResourceDelegate getResourceDelegate(Object target) {
		if (target instanceof IResourceDelegate)
			return (IResourceDelegate)target;

		if (target instanceof IEosElement)
			return ((IEosElement)target).getResource();

		if (target instanceof IAdaptable)
			return (IResourceDelegate)((IAdaptable)target).getAdapter(IResourceDelegate.class);

		return null;
	}

}
