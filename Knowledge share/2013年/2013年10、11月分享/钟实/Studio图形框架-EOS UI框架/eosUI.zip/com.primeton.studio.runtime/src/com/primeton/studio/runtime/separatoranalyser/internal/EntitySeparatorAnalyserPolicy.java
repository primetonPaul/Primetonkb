/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/internal/EntitySeparatorAnalyserPolicy.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-23
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.internal;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.separatoranalyser.IComplexSeparatorAnalyser;
import com.primeton.studio.runtime.separatoranalyser.ISeparatorAnalyserPolicy;
import com.primeton.studio.runtime.separatoranalyser.SeparatorModel;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EntitySeparatorAnalyserPolicy.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:46  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.2  2008/05/23 01:37:18  yangmd
 * Update:������ʵ��������⴦��
 *
 * Revision 1.1  2008/05/23 01:36:29  yangmd
 * Update:������ʵ��������⴦��
 * 
 */
public class EntitySeparatorAnalyserPolicy implements ISeparatorAnalyserPolicy{
	private IComplexSeparatorAnalyser javaSeparatorAnalyser;
	private IComplexSeparatorAnalyser entitySeparatorAnalyser;
	/**
	 * 
	 * @param javaSeparatorAnalyser
	 * @param entitySeparatorAnalyser
	 */
	public EntitySeparatorAnalyserPolicy(IComplexSeparatorAnalyser javaSeparatorAnalyser,
			IComplexSeparatorAnalyser entitySeparatorAnalyser) {
		this.javaSeparatorAnalyser = javaSeparatorAnalyser;
		this.entitySeparatorAnalyser = entitySeparatorAnalyser;
	}
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.ISeparatorAnalyserPolicy#getSeparatorAnalyzer(com.primeton.studio.runtime.helper.SeparatorModel)
	 */
	public IComplexSeparatorAnalyser getSeparatorAnalyzer(SeparatorModel model) {
		Object obj = model.getThisModel();
		if(obj instanceof IField){
			IField field = (IField)obj;
			IType type = field.getDeclaringType();
			boolean isJava = RuntimeConstant.JAVA.equals(field.getImplementationType());
			if(!isJava && type != null) isJava = RuntimeConstant.JAVA.equals(type.getImplementationType());
			if(isJava)
				return this.javaSeparatorAnalyser;
			else 
				return this.entitySeparatorAnalyser;
		}
		return this.entitySeparatorAnalyser;//Ĭ��ʹ��entitySeparatorAnalyser
	}

}
