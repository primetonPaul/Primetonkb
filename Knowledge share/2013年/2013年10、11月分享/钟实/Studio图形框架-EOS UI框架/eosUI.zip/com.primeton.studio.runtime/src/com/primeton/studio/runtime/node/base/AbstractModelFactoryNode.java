/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.node.base;

import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.runtime.core.IEosContainer;
import com.primeton.studio.runtime.core.IModelFactoryContainer;
import com.primeton.studio.runtime.model.IModelFactory;

/**
 * ������PackageRootӳ�䵽���ModelFactory<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractModelFactoryNode.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/03/19 05:05:44  wanglei
 * Review:�������,��ģ�͵����ݴ�navigator����г�ȡ��runtime����С�
 *
 * Revision 1.4  2008/01/10 09:36:08  wanglei
 * Review:����equals��hashCode������
 *
 * Revision 1.3  2008/01/09 06:55:01  wanglei
 * Update:����hashCode��equals������
 *
 * Revision 1.2  2008/01/09 06:37:32  zhuxing
 * Update:��model resource node��eos element�ķ�����Ϊpublic
 *
 * Revision 1.1  2008/01/09 01:16:04  wanglei
 * Review:�ع��ײ�ģ�ͣ���ԭ�д���Դ�������������getModelFactory������ȥ��
 *
 */

public abstract class AbstractModelFactoryNode extends AbstractFolderNode implements IModelFactoryContainer {

	private IModelFactory modelFactory;

	private IEosContainer eosContainer;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param folder
	 */
	public AbstractModelFactoryNode(IEosContainer eosContainer, IModelFactory modelFactory) {
		super(eosContainer.getFolder());
		this.eosContainer = eosContainer;
		this.modelFactory = modelFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getType() {
		if (null == this.modelFactory) {
			return null;
		}
		else {
			return this.modelFactory.getName();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IModelFactory getModelFactory() {
		return this.modelFactory;
	}

	/**
	 * @return the eosContainer
	 */
	public IEosContainer getEosContainer() {
		return this.eosContainer;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object other) {

		if (super.equals(other)) {
			AbstractModelFactoryNode otherNode = (AbstractModelFactoryNode) other;
			if (ObjectUtils.equals(this.eosContainer, otherNode.eosContainer)) {
				return ObjectUtils.equals(this.modelFactory, otherNode.modelFactory);
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.modelFactory == null) ? 0 : this.modelFactory.hashCode());
		result = PRIME * result + ((this.eosContainer == null) ? 0 : this.eosContainer.hashCode());
		return result;
	}
}
