/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/java/JavaFolderDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-30
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.java;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.metadata.internal.FolderMetadata;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ����Java�ļ���Դʵ��IFolderDelegate�ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/04/14 03:32:00  wanglei
 * Update:���ӶԳ־û����Ե�֧�֡�
 *
 * Revision 1.6  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.5  2007/08/08 07:10:58  wanglei
 * Update:����ʵ�����еĹ��ܡ�
 *
 * Revision 1.4  2007/04/18 08:38:45  wanglei
 * Update:�����еķ������ö�ת����JavaResourceManager��������
 *
 * Revision 1.3  2007/03/30 09:29:08  wanglei
 * Add:����isPrefixOf�����������ж�������Դ�Ƿ���ڸ��ӹ�ϵ��
 *
 * Revision 1.2  2007/03/30 02:19:24  wanglei
 * Remove:ȥ����Ԫ���ݷ�����
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public class JavaFolderDelegate extends JavaResourceDelegate implements IFolderDelegate {
	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param file
	 */
	public JavaFolderDelegate(File file) {
		super(file);

	}

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param fileName
	 */
	public JavaFolderDelegate(String fileName) {
		super(fileName);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getChildren()
	 */
	public IResourceDelegate[] getChildren() {

		if (!this.getFile().exists()) {
			return new IResourceDelegate[0];
		}

		File[] childrenFiles = this.getFile().listFiles();
		if (null == childrenFiles) {
			return new IResourceDelegate[0];
		}

		IResourceDelegate[] results = new IResourceDelegate[childrenFiles.length];
		for (int i = 0; i < childrenFiles.length; i++) {
			File file = childrenFiles[i];
			if (file.isDirectory()) {
				results[i] = new JavaFolderDelegate(file);
			}
			else {
				results[i] = new JavaFileDelegate(file);
			}
		}
		return results;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getFile(java.lang.String)
	 */
	public IFileDelegate getFile(String path) {

		if (StringUtils.isEmpty(path)) {
			return null;
		}

		String newFileName = this.getFile().getAbsolutePath() + "/" + path;
		newFileName = FilenameUtil.normalizeInUnixStyle(newFileName);
		return new JavaFileDelegate(newFileName);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getFolder(java.lang.String)
	 */
	public IFolderDelegate getFolder(String path) {
		if (StringUtils.isEmpty(path)) {
			return null;
		}

		String newFileName = this.getFile().getAbsolutePath() + "/" + path;
		newFileName = FilenameUtil.normalizeInUnixStyle(newFileName);
		return new JavaFolderDelegate(newFileName);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#create()
	 */
	public void create() {
		try {
			FileUtils.forceMkdir(getFile());
		} catch (IOException e) {
			throw new ResourceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#delete()
	 */
	public void delete() throws ResourceException {
		try {
			FileUtils.deleteDirectory(this.getFile());
		} catch (IOException e) {
			throw new ResourceException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#getType()
	 */
	public int getType() throws ResourceException {
		return FOLDER;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isPrefixOf(IResourceDelegate resourceDelegate) {

		if (null == resourceDelegate) {
			return false;
		}

		return FilenameUtil.isPrefixOf(this.getFullPath(), resourceDelegate.getFullPath());
	}

	/**
	 * {@inheritDoc}
	 */
	public String getPersistentProperty(String key) {
		FolderMetadata folderMetadata = FolderMetadata.newInstance(this, false);
		if (null == folderMetadata) {
			return null;
		}
		else {
			return folderMetadata.getString(key);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void setPersistentProperty(String key, String value) {
		FolderMetadata folderMetadata = FolderMetadata.newInstance(this, true);
		if (null != folderMetadata) {
			folderMetadata.setString(key, value);
		}
	}
}
