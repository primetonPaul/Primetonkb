/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/project/EosProjectValidator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-1-24
 *******************************************************************************/

package com.primeton.studio.runtime.project;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.WorkspaceJob;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.RuntimeMessages;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.library.ILibraryManager;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseFileDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseProjectDelegate;

/**
 *
 * EOS��Ŀ����Ч����֤
 *
 * @author Chenxp (mailto:chenxp@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EosProjectValidator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.4  2009/05/07 12:55:48  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.3  2008/07/21 02:08:03  hongsq
 * Update:�޸�һ����ָ���쳣
 *
 * Revision 1.2  2008/07/18 07:48:57  yujl
 * update:
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2008/06/06 02:13:38  yujl
 * Fix BUG:8533[ʾ����Ŀ]�½�helloworld��ʾ����Ŀ����뱨��,��ʾwebӦ��eos-default�Ƿ�
 *
 * Revision 1.7  2008/05/16 06:43:40  wanglei
 * Review:�����ӿڽṹ������Ӧ��Java�����.metadataĿ¼�С�
 *
 * Revision 1.6  2008/04/21 11:56:28  yanfei
 * Update:��validateProject��Job�ŵ�ѭ�����⡣
 *
 * Revision 1.5  2008/04/15 12:39:59  wanglei
 * Update:�ع�ILibrary�ĳ������ơ�
 *
 * Revision 1.4  2008/03/06 02:59:44  wanglei
 * Update:����ĿFull-Build��ʱ���Զ���鹹�����Ӧ�����ÿ⡣
 *
 * Revision 1.3  2008/01/31 06:00:06  chenxp
 * Update:��Ӧ��ɾ��project������marker.
 *
 * Revision 1.2  2008/01/30 06:23:03  chenxp
 * Update:ɾ����ӡ��Ϣ
 *
 * Revision 1.1  2008/01/28 10:00:01  chenxp
 * Add:�ύ���뵽cvs.
 *
 */
public class EosProjectValidator implements IResourceChangeListener {

	private static EosProjectValidator instance;

	/**
	 * ��ʵ��
	 *
	 * @return
	 */
	public static EosProjectValidator getInstance() {
		if (instance == null) {
			instance = new EosProjectValidator();
		}

		return instance;
	}

	/**
	 * ˽�й�����,��֤��ʵ��
	 *
	 */
	private EosProjectValidator() {

	}

	/**
	 * .library�ļ���Դ�����仯
	 * .eos_libraryĿ¼�е���Դ�б仯
	 */
	public void resourceChanged(IResourceChangeEvent event) {
		if (event.getDelta() == null) {
			return;
		}

		final Collection libraryFiles = new ArrayList();
		final Collection eosLibraryFolderFiles = new ArrayList();

		try {
			event.getDelta().accept(new IResourceDeltaVisitor() {
				public boolean visit(IResourceDelta delta) throws CoreException {
					int deltaType = delta.getKind();
					IResource resource = delta.getResource();
					//interest in .library file
					if (resource instanceof IFile && RuntimeConstant.LIBRARY_FILE.equals(resource.getName())) {
						if (IResourceDelta.ADDED == deltaType || IResourceDelta.CHANGED == deltaType || IResourceDelta.REMOVED == deltaType) {
							libraryFiles.add(resource);
						}
					}
					if(resource.getType() == IResource.FILE
							&& "ecd".equals(((IFile)resource).getFileExtension()) //$NON-NLS-1$
							&& (((deltaType & IResourceDelta.ADDED) != 0)
									|| ((deltaType & IResourceDelta.REMOVED) != 0)
									|| ((deltaType & IResourceDelta.CHANGED) != 0))){
						//�жϵ�ǰecd�Ƿ�Ϊ��ǰ��project���ã���������ã�����Ҫ
						libraryFiles.add(resource.getProject().getFile(RuntimeConstant.LIBRARY_FILE));
					}
					//interest in eos_library folder
					if (resource != null && resource.getParent() != null && ("." + RuntimeConstant.EOS_LIBRARY).equals(resource.getParent().getName())) { //$NON-NLS-1$
						eosLibraryFolderFiles.add(resource);
					}

					return true;
				}
			});
		} catch (CoreException e) {
			e.printStackTrace();
		}

		//�����Ҫ��֤��.library�ļ�
		if (eosLibraryFolderFiles.size() > 0) {
			for (int i = 0; i < eosLibraryFolderFiles.size(); i++) {
				for (Object object : eosLibraryFolderFiles) {
					IResource resource = (IResource) object;
					if (resource instanceof IFile) {
						IFileDelegate fileDelegate = new EclipseFileDelegate((IFile) resource);
						IFileDelegate libraryFile = fileDelegate.getProject().getFile(RuntimeConstant.LIBRARY_FILE);
						if (!libraryFiles.contains(libraryFile)) {
							libraryFiles.add(libraryFile.getAdapter(IResource.class));
						}
					}
				}
			}
		}

		if (libraryFiles.size() > 0) {
			validateLibraryFiles(libraryFiles);
		}
	}

	/**
	 * ����.library�ļ���Դ�ı仯
	 *
	 * @param libraryFiles
	 * @param flag
	 */
	private void validateLibraryFiles(final Collection libraryFiles) {

		if (CollectionUtils.isEmpty(libraryFiles)) {
			return;
		}

		new WorkspaceJob(RuntimeMessages.CHECK_REFERENCE_LIBRARY) {

			/**
			 * {@inheritDoc}
			 */
			@Override
			public IStatus runInWorkspace(IProgressMonitor monitor) {
				for (Object object : libraryFiles) {
					IResource resource = (IResource) object;
					if (resource instanceof IFile) {
						IFileDelegate fileDelegate = new EclipseFileDelegate((IFile) resource);

						Object proj = fileDelegate.getAdapter(IProject.class);
						if (proj instanceof IProject) {
							validateProject((IProject) proj, monitor);
						}
					}
				}

				return Status.OK_STATUS;

			}

		}.schedule();
	}

	/**
	 * @param project
	 */
	public boolean validateProject(IProject project, IProgressMonitor monitor) {
		try {
			project.deleteMarkers(RuntimeConstant.MARKER_PROJECT_LIBRARY, false, IResource.DEPTH_ZERO);
		}catch(CoreException ex) {}

		ILibraryManager libraryManager = RuntimeManager.getLibraryManager();

		EclipseProjectDelegate projectDelegate = new EclipseProjectDelegate(project);
		ILibrary[] libraries = projectDelegate.getLibraries();

		IFolderDelegate libraryFolder = projectDelegate.getFolder("." + RuntimeConstant.EOS_LIBRARY); //$NON-NLS-1$
		boolean flag = true;
		for (int i = 0; i < libraries.length; i++) {
			ILibrary library = libraries[i];
			IResourceDelegate[] resourceDelegates = libraryManager.getResources(library);

			String kind = library.getKind();
			if (ILibrary.FILE_RESOURCE.equals(kind)) {//resourceDelegatesӦ������һЩ.ecd�����
				for (int j = 0; j < resourceDelegates.length; j++) {
					IResourceDelegate ecdResource = resourceDelegates[j];
					if (ecdResource.getType() == IResourceDelegate.FILE) {
						IFileDelegate ecdFile = (IFileDelegate) ecdResource;
						if(!ecdFile.getExtension().equals("ecd")){ //$NON-NLS-1$
							String formatString = RuntimeMessages.FUNDATION_NAME_ILLEGAL;
							String message = MessageFormat.format(formatString, project.getName(),library.getDisplayName());
							markError(project, message);
							flag = false;
							continue;
						}
						if(ecdFile == null || !ecdFile.exists()){
							String formatString = RuntimeMessages.FUNDATION_NAME_NOT_EXIST;
							String message = MessageFormat.format(formatString, project.getName(),library.getDisplayName());
							markError(project, message);
							flag = false;
							continue;
						}

						if (!validateEcdLibrary(ecdFile, libraryFolder)) {
							String formatString = RuntimeMessages.FUNDATION_NAME_PARSER_WRONG;
							String message = MessageFormat.format(formatString, project.getName(),library.getDisplayName());
							markError(project, message);
							flag = false;
						}
					}
				}
			}
			else if (ILibrary.FOLDER_RESOURCE.equals(kind)) {//resourceDelegatesӦ������һЩ�ļ������
				for (int j = 0; j < resourceDelegates.length; j++) {
					IFolderDelegate folderDelegate = libraryFolder.getFolder(resourceDelegates[j].getName());
					if (folderDelegate != null && !folderDelegate.exists()) {
						String formatString = RuntimeMessages.PROJECT_VALIDATE_WRONG;
						String message = MessageFormat.format(formatString, project.getName());
						markError(project, message);
						flag = false;
					}
				}
			}
			else if (ILibrary.PROJECT_RESOURCE.equals(kind)) {
				//TODO:�ݲ�֧��
			}
		}

		return flag;
	}

	/**
	 * ��Ǵ�����Ϣ
	 * @param project
	 * @param message
	 */
	private void markError(IProject project,String message) {
		EosProjectMarkHelper.markError(project,
				message,
				RuntimeConstant.MARKER_PROJECT_LIBRARY,
				IMarker.PRIORITY_HIGH,
				IMarker.SEVERITY_ERROR);
	}

	/**
	 * ��֤Ecd�ļ��а�����jar��zip�Ƿ���.eos_libraryĿ¼�д���
	 *
	 * @param ecdFileDelegate
	 * @param libraryFolder
	 * @return
	 */
	private boolean validateEcdLibrary(IFileDelegate ecdFileDelegate, IFolderDelegate libraryFolder) {
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(ecdFileDelegate.getFile());
			Enumeration enumeration = zipFile.entries();
			if(zipFile.size() < 1){
				return false;
			}
			while (enumeration.hasMoreElements()) {
				ZipEntry zipEntry = (ZipEntry) enumeration.nextElement();
				String extensionName = FilenameUtils.getExtension(zipEntry.getName());
				/*if ("jar".equals(extensionName) || "zip".equals(extensionName)) {
					IFileDelegate jarFile = libraryFolder.getFile(zipEntry.getName());
					if (jarFile == null || !jarFile.exists()) {
						return false;
					}
				}TODO:�¹���Ϊ����������ʱ���޸�*/
			}
		} catch (Exception ex) {
			return false;
		} finally {
			if (zipFile != null) {
				try {
					zipFile.close();
				} catch (Exception e) {}
			}
		}

		return true;
	}
}