/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/eclipse/EclipseProjectDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-29
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.eclipse;

import org.eclipse.core.resources.IProject;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * Eclipseƽ̨����Ŀ��ʵ�֡�
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EclipseProjectDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/10/20 10:39:38  chenxp
 * BUG: 22301 �½�sample��Ŀ��������Ҳ��������������criteriaType�� (hongsq)
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.9  2007/09/13 02:13:46  wanglei
 * Review:��ȥ���õĵ��롣
 *
 * Revision 1.8  2007/08/23 03:11:07  wanglei
 * Review:��IEOSProject�е�getLibraries�ƶ���IProjectDelegate�С�
 *
 * Revision 1.7  2007/08/08 07:08:10  wanglei
 * Update:����getSourceFolder������
 *
 * Revision 1.6  2007/08/08 01:48:13  wanglei
 * Remove:ȥ��addSourceFolder������
 *
 * Revision 1.5  2007/06/21 13:58:06  wanglei
 * Review:IProjectDelegateӦ��֧��isOpen�����ж�����Ч�ԡ�
 *
 * Revision 1.4  2007/05/08 09:02:55  wanglei
 * Refactor:��getSrcFolder��getSrcFolders���ĳ�getSourceFoder��getSourceFoders������
 *
 * Revision 1.3  2007/04/18 08:39:27  wanglei
 * Update:��ɸ���Ĺ��ܡ�
 *
 * Revision 1.2  2007/03/30 09:27:11  wanglei
 * UnitTest:����ȡԴ����Ŀ¼�Ĵ���
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public class EclipseProjectDelegate extends EclipseFolderDelegate implements IProjectDelegate {

	private transient long timestamp;

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param project
	 */
	public EclipseProjectDelegate(IProject project) {
		super(project);
	}

	/**
	 * ����������Eclipse��Ŀ��<BR>
	 *
	 * @return
	 */
	public IProject getEclipseProject() {
		return (IProject) this.getResource();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IProjectDelegate#getSourceFolders()
	 */
	public ISourceFolderDelegate[] getSourceFolders() {
		return EclipseResourceManager.getInstance().getSourceFolders(this);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.eclipse.EclipseFolderDelegate#getAdapter(java.lang.Class)
	 */
	public Object getAdapter(Class adapter) {
		if (IProject.class == adapter) {
			return this.getEclipseProject();
		}

		return super.getAdapter(adapter);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceDelegate#delete()
	 */
	@Override
	public void delete() throws ResourceException {
		EclipseRootDelegate.getInstance().unLoadLibraries(this);
		super.delete();
	}
	
	/**
	 *
	 * {@inheritDoc}
	 */
	public boolean isOpen() {
		return this.getEclipseProject().isOpen();
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public ILibrary[] getLibraries() {
		return EclipseRootDelegate.getInstance().getLibraries(this);
	}

}
