/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/EosEnvironmentManager.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on May 22, 2010
 *******************************************************************************/


package com.primeton.studio.runtime;

import com.primeton.platform.Kernel;
import com.primeton.studio.runtime.extension.AbstractEosEnvironmentProvider;
import com.primeton.studio.runtime.internal.DefaultEnvironmentProvider;

/**
 * ����EOS��Studio�İ汾��
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EosEnvironmentManager.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/05/24 08:35:44  wanglei
 * Jira:����EOSP-259��
 *
 */
public class EosEnvironmentManager {
	private static AbstractEosEnvironmentProvider currentProvider;

	private static void doLoadProviders(){
		Object object = Kernel.getServiceManager().findService(AbstractEosEnvironmentProvider.class, null, null, null);
		if (object instanceof AbstractEosEnvironmentProvider) {
			currentProvider = (AbstractEosEnvironmentProvider) object;
		}

		if(null == currentProvider)
			currentProvider = DefaultEnvironmentProvider.getInstance();
	}

	public static String getVersion(){
		if(null == currentProvider)
			doLoadProviders();

		return currentProvider.getVersion();
	}
}
