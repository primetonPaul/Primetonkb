/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/query/IndexFinder.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-6-3
 *******************************************************************************/

package com.primeton.studio.runtime.index.query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BooleanClause.Occur;

import com.eos.system.utility.Assert;
import com.eos.system.utility.CollectionUtil;
import com.primeton.studio.core.util.entry.StringMapEntry;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.exception.IndexException;
import com.primeton.studio.runtime.index.IndexConstant;
import com.primeton.studio.runtime.index.model.DocumentItem;
import com.primeton.studio.runtime.index.model.TypeItem;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * ������������<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IndexFinder.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.13  2009/10/22 12:36:36  chenxp
 * Update: �Ż�ȫ����������ܡ�
 *
 * Revision 1.12  2009/10/21 12:43:01  chenxp
 * Update:fix a bug of the method for getAllRelatedContributions.
 *
 * Revision 1.11  2009/10/21 08:45:44  chenxp
 * Update: �Ż�studio����
 *
 * Revision 1.10  2009/10/15 07:46:16  chenxp
 * Update:�Լ�����Query���ʱ������Ҫ�������ַ�����ת�塣
 *
 * Revision 1.9  2009/10/14 08:03:28  chenxp
 * Update: studio�����Ż�
 *
 * Revision 1.8  2009/10/14 01:37:16  chenxp
 * Update: ���ӷǿ��ж�
 *
 * Revision 1.7  2009/10/13 12:31:56  chenxp
 * Update:�����������ֹ�����Query,�����������ܡ�
 *
 * Revision 1.6  2009/07/22 08:06:51  lvyuan
 * Update:ƴװContributionName�Ĳ�ѯ����
 *
 * Revision 1.5  2009/07/22 07:03:50  lvyuan
 * Update:�޸Ĳ�ѯ������ת��Ĵ���
 *
 * Revision 1.4  2009/07/22 05:09:17  lvyuan
 * Update:�ع�����namespace��Ϊһ��StringEntry
 *
 * Revision 1.3  2009/07/21 09:51:19  lvyuan
 * Update:�ع��������ҽӿڣ��������ö���ؼ���
 *
 * Revision 1.2  2009/07/21 07:14:17  lvyuan
 * Update:����������֧�ֺ�׺��
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
public final class IndexFinder {

	private static IndexFinder instance = new IndexFinder();

	private LRUMap typePool = new LRUMap(20);

	private LRUMap filePool = new LRUMap(20);

	private LRUMap contributionPool = new LRUMap(100);

	/**
	 *
	 */
	private IndexFinder() {
		super();
	}

	/**
	 * @return Returns the instance.
	 */
	public static IndexFinder getInstance() {
		return instance;
	}

	/**
	 * ���ݲ�ѯ�������Ŀ�в���ָ��������Ϣ��<BR>
	 *
	 * @param projectDelegate
	 * @param statement
	 * @return
	 */
	public QueryResult<TypeItem> searchTypes(final IProjectDelegate projectDelegate, final QueryStatement statement) {
		validateProjectQuery(projectDelegate, statement);

		try {

			String identity = projectDelegate.getName() + "$" + statement;

			TypeQueryResult result = (TypeQueryResult) this.typePool.get(identity);
			if (null == result) {
				Query query = this.buildQuery(null, statement);
				result = new TypeQueryResult<DocumentItem>(projectDelegate, query, statement);
				this.typePool.put(identity, result);
			}

			return result;

		} catch (ParseException e) {
			throw new IndexException(e);
		}
	}

	/**
	 * ���ݲ�ѯ����ӹ������в���������Ϣ��<BR>
	 *
	 * @param projectDelegate
	 * @param statement
	 * @return
	 */
	public QueryResult<TypeItem> searchTypes(final IContribution contribution, final QueryStatement statement) {
		validateContributionQuery(contribution, statement);

		try {
			String[] contributionNames = computeContributionNames(contribution);

			IProjectDelegate projectDelegate = contribution.getResource().getProject();
			Arrays.sort(contributionNames);
			String identity = projectDelegate.getName() + "$" + StringUtils.join(contributionNames, "$") + "&" + statement;

			TypeQueryResult result = (TypeQueryResult) this.typePool.get(identity);
			if (null == result) {
				Query query = this.buildQuery(contributionNames, statement);
				result = new TypeQueryResult<DocumentItem>(projectDelegate, query, statement);
				this.typePool.put(identity, result);
			}
			return result;

		} catch (ParseException e) {
			throw new IndexException(e);
		}
	}

	/**
	 * ���ݲ�ѯ�������Ŀ�в��Ұ���ָ��������Ϣ��ģ���ļ���<BR>
	 *
	 * @param projectDelegate
	 * @param statement
	 * @return
	 */
	public QueryResult<DocumentItem> searchFilesWithType(final IProjectDelegate projectDelegate, final QueryStatement statement) {
		validateProjectQuery(projectDelegate, statement);

		try {

			String identity = projectDelegate.getName() + "$" + statement;

			DocumentQueryResult result = (DocumentQueryResult) this.filePool.get(identity);
			if (null == result) {
				Query query = this.buildQuery(null, statement);
				result = new DocumentQueryResult<DocumentItem>(projectDelegate, query, statement);
				this.filePool.put(identity, result);
			}

			return result;

		} catch (ParseException e) {
			throw new IndexException(e);
		}
	}

	/**
	 * ���ݲ�ѯ����ӹ������в��Ұ���ָ��������Ϣ��ģ���ļ���<BR>
	 *
	 * @param projectDelegate
	 * @param statement
	 * @return
	 */
	public QueryResult<DocumentItem> searchFilesWithType(final IContribution contribution, final QueryStatement statement) {
		validateContributionQuery(contribution, statement);

		try {

			IProjectDelegate projectDelegate = contribution.getResource().getProject();
			String[] contributionNames = computeContributionNames(contribution);
			Arrays.sort(contributionNames);
			String identity = projectDelegate.getName() + "$" + StringUtils.join(contributionNames, "$") + "&" + statement;

			DocumentQueryResult result = (DocumentQueryResult) this.filePool.get(identity);
			if (null == result) {
				Query query = this.buildQuery(contributionNames, statement);
				result = new DocumentQueryResult<DocumentItem>(projectDelegate, query, statement);
				this.filePool.put(identity, result);
			}

			return result;

		} catch (ParseException e) {
			throw new IndexException(e);
		}
	}

	/**
	 * ���ݲ�ѯ�������Ŀ�в��Ұ���ָ��������Ϣ��ģ���ļ���<BR>
	 *
	 * @param projectDelegate
	 * @param statement
	 * @return
	 */
	public QueryResult<DocumentItem> searchFiles(final IProjectDelegate projectDelegate, final QueryStatement statement) {
		validateProjectQuery(projectDelegate, statement);

		try {

			String identity = projectDelegate.getName() + "$" + statement;

			DocumentQueryResult result = (DocumentQueryResult) this.filePool.get(identity);
			if (null == result) {
				Query query = this.buildQuery(null, statement);
				result = new DocumentQueryResult<DocumentItem>(projectDelegate, query, statement);
				this.filePool.put(identity, result);
			}

			return result;

		} catch (ParseException e) {
			throw new IndexException(e);
		}
	}

//	/**
//	 * ���ݲ�ѯ�������Ŀ�в��Ұ���ָ��������Ϣ��ģ���ļ���<BR>
//	 *
//	 * @param projectDelegate
//	 * @param statement
//	 * @return
//	 */
//	public QueryResult<DocumentItem> searchFiles(final IContribution contribution, final QueryStatement statement) {
//
//		validateContributionQuery(contribution, statement);
//
//		try {
//			String[] contributionNames = computeContributionNames(contribution);
//			Query query = this.buildQuery(contributionNames, statement);
//			return new DocumentQueryResult<DocumentItem>(contribution.getResource().getProject(), query, statement);
//
//		} catch (ParseException e) {
//			throw new IndexException(e);
//		}
//	}


	/**
	 * ���ݲ�ѯ�������Ŀ�в��Ұ���ָ��������Ϣ��ģ���ļ���<BR>
	 *
	 * @param projectDelegate
	 * @param statement
	 * @return
	 */
	public QueryResult<DocumentItem> searchFiles(IContribution[] contributions, final QueryStatement statement) {
		IProjectDelegate projectDelegate = contributions[0].getResource().getProject();

		validateContributionQuery(contributions[0], statement);
		try {
			String[] contributionNames = new String[contributions.length];
			for (int i = 0; i < contributions.length; i++) {
				contributionNames[i] = contributions[i].getName();
			}

			Arrays.sort(contributionNames);
			String identity = projectDelegate.getName() + "$" + StringUtils.join(contributionNames, "$") + "&" + statement;

			DocumentQueryResult result = (DocumentQueryResult) this.filePool.get(identity);
			if (null == result) {
				Query query = this.buildQuery(contributionNames, statement);
				result = new DocumentQueryResult<DocumentItem>(projectDelegate, query, statement);
				this.filePool.put(identity, result);
			}

			return result;
		} catch (ParseException e) {
			throw new IndexException(e);
		}
	}

	/**
	 * ��֤��ѯ�����Ƿ���Ч��<BR>
	 *
	 * @param projectDelegate
	 * @param statement
	 */
	private void validateProjectQuery(final IProjectDelegate projectDelegate, final QueryStatement statement) {
		Assert.isTrue(ResourceHelper.isValidProject(projectDelegate), "the project must be valid");
		Assert.notNull(statement, "the statement must not be null");
		Assert.notNull(statement.getNameSpace(), "the nameSpace of the statement should not be null");

		boolean includeElements = ((!statement.isIncludeLibrary()) && (!statement.isIncludeSource()));
		Assert.state(!includeElements, "the query statement must include at least one of libraries or sources");
	}

	/**
	 * ��֤��ѯ�����Ƿ���Ч��<BR>
	 *
	 * @param contribution
	 * @param statement
	 */
	private void validateContributionQuery(final IContribution contribution, final QueryStatement statement) {
		Assert.notNull(contribution, "the contribution must not be null");
		Assert.notNull(statement, "the statement must not be null");
		Assert.notNull(statement.getNameSpace(), "the nameSpace of the statement should not be null");

		boolean includeElements = ((!statement.isIncludeLibrary()) && (!statement.isIncludeSource()));
		Assert.state(!includeElements, "the query statement must include at least one of libraries or sources");
	}

	/**
	 * ����һ����������������ʹ�õĹ��������ơ�<BR>
	 *
	 * @param contribution
	 * @return
	 */
	private String[] computeContributionNames(final IContribution contribution) {
		String[] contributionNames = contribution.getRequiredBundles();
		List list = new ArrayList(5);
		list.add(contribution.getName());
		CollectionUtil.addAllQuietly(list, contributionNames);

		contributionNames = new String[list.size()];
		list.toArray(contributionNames);
		return contributionNames;
	}

	/**
	 * ��������Ļ��档<BR>
	 *
	 */
	public void clearIndexPool() {
		this.typePool.clear();
		this.filePool.clear();
	}

	/**
	 * ���Contribution�Ļ��档<BR>
	 *
	 */
	public void clearContributionPool() {
		this.contributionPool.clear();
	}

	/**
	 * �õ�ָ��Contribution�������Contribution��<BR>
	 * @param contributions
	 * @return
	 */
	public IContribution[] getAllRelatedContributions(IContribution[] contributions) {
		IProjectDelegate projectDelegate = contributions[0].getResource().getProject();
		String[] contributionNames = new String[contributions.length];
		for (int i = 0; i < contributions.length; i++) {
			contributionNames[i] = contributions[i].getName();
		}

		Arrays.sort(contributionNames);
		String identity = projectDelegate.getName() + "$" + StringUtils.join(contributionNames, "$");

		IContribution[] results = (IContribution[]) this.contributionPool.get(identity);
		if (null == results) {
			results = ContributionUtil.getAllRelatedContributions(contributions);
			this.contributionPool.put(identity, results);
		}
		return results;

	}

//	/**
//	 * ����һ��Lucene��Query���������͡�<BR>
//	 *
//	 * @param contributionNames
//	 * @param queryStatement
//	 * @return
//	 * @throws ParseException
//	 */
//	private Query buildTypeQuery(String[] contributionNames, final QueryStatement queryStatement) throws ParseException {
//		StringBuilder stringBuilder = new StringBuilder();
//		List list = queryStatement.getKeyWords();
//		if(list != null  && list.size() > 0){
//			stringBuilder.append("(");
//			for (Iterator iter = list.iterator(); iter.hasNext();) {
//				StringMapEntry entry = (StringMapEntry) iter.next();
//				stringBuilder.append(entry.getKey());
//				stringBuilder.append(":");
//				stringBuilder.append(entry.getValue());
//				if (iter.hasNext()) {
//					stringBuilder.append(" OR ");
//				} else {
//					stringBuilder.append(")");
//				}
//			}
//		}
////		stringBuilder.append("(");
////		stringBuilder.append(IndexConstant.TYPE_NAMESPACE);
////		stringBuilder.append(":");
////		stringBuilder.append(queryStatement.getKeyWord());
////		stringBuilder.append(" OR ");
////		stringBuilder.append(IndexConstant.TYPE_NAME);
////		stringBuilder.append(":");
////		stringBuilder.append(queryStatement.getKeyWord());
////		stringBuilder.append(")");
//		return doBuildQuery(queryStatement, contributionNames, stringBuilder);
//	}


	private Query buildQuery(String[] contributionNames, final QueryStatement queryStatement) throws ParseException {
		BooleanQuery query = new BooleanQuery();

		// ��װ���ƿռ��ѯ����
		String namespace = (String)queryStatement.getNameSpace().getValue();
		TermQuery nsQuery = new TermQuery(new Term(queryStatement.getNameSpace().getKey(),
				namespace.toLowerCase()));
		query.add(nsQuery, Occur.MUST);


		// ��װ����������
		List list = queryStatement.getKeyWords();
		if(list != null  && list.size() > 0){
			BooleanQuery otherQuery = new BooleanQuery();
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				StringMapEntry entry = (StringMapEntry) iter.next();
				if(entry.getValue()!=null) {
					String value = entry.getValue().toString();
					String key = entry.getKey();
					if(IndexConstant.NAME.equals(key)
							|| IndexConstant.PACKAGE_NAME.equals(key)
							|| IndexConstant.TYPE_NAME.equals(key)
							|| IndexConstant.TYPE_NAMESPACE.equals(key)) {
						value = value.toLowerCase();
					}
					TermQuery qs = new TermQuery(new Term(entry.getKey(), value));
					otherQuery.add(qs, Occur.SHOULD);
				}
			}
			query.add(otherQuery, Occur.MUST);
		}

//		StringMapEntry keyword = queryStatement.getKeyWord();
//		if(keyword != null ){
//			stringBuilder.append("(");
//			stringBuilder.append(keyword.getKey());
//			stringBuilder.append(":");
//			stringBuilder.append(keyword.getValue());
//			stringBuilder.append(")");
//		}

		return doBuildQuery(queryStatement, contributionNames, query);
	}


	/**
	 * ����һ��Lucene��Query�������ļ���<BR>
	 * ����ContributionԼ���Ͷ����������Լ��Ƿ��ڶ����ƿ��ڲ��ҡ�<BR>
	 *
	 * @param queryStatement
	 * @param contributionNames
	 * @param stringBuilder
	 * @return
	 * @throws ParseException
	 */
	private Query doBuildQuery(QueryStatement queryStatement, String[] contributionNames, BooleanQuery query) throws ParseException {

		String[] binaryTypes = queryStatement.getBinaryTypes();
		if (!ArrayUtils.isEmpty(binaryTypes)) {
			query.add(buildCompositeQuery(IndexConstant.BINARY_TYPE, binaryTypes), Occur.MUST);
		}

		String[] extensions = queryStatement.getExtensions();
		if (!ArrayUtils.isEmpty(extensions)) {
			query.add(buildCompositeQuery(IndexConstant.EXTENSION, extensions), Occur.MUST);
		}

		if (queryStatement.isIncludeContributions() && (!ArrayUtils.isEmpty(contributionNames))) {
			query.add(buildCompositeQuery(IndexConstant.CONTRIBUTION_NAME, contributionNames), Occur.MUST);
		}

		boolean supportAllResources = queryStatement.isIncludeLibrary() && queryStatement.isIncludeSource();
		if (!supportAllResources) {
			TermQuery includeLibQuery = new TermQuery(new Term(IndexConstant.BINARY_FILE, queryStatement.isIncludeLibrary()?"true":"false"));
			query.add(includeLibQuery, Occur.MUST);
		}

		return query;
	}

	private Query buildCompositeQuery(String key, String[] values) {
		BooleanQuery query = new BooleanQuery();

		for(int i=0; i<values.length; i++) {
			String value = values[i];
			if(IndexConstant.CONTRIBUTION_NAME.equals(key)) {
				value = value.toLowerCase();
			}
			TermQuery termQuery = new TermQuery(new Term(key, value));
			query.add(termQuery, Occur.SHOULD);
		}

		return query;
	}

//	/**
//	 * ����һ��Lucene��Query�������ļ���<BR>
//	 *
//	 * @param contributionNames
//	 * @param queryStatement
//	 * @return
//	 * @throws ParseException
//	 */
//	private Query buildFileQuery(String[] contributionNames, final QueryStatement queryStatement) throws ParseException {
//
//		StringBuilder stringBuilder = new StringBuilder();
//		stringBuilder.append("(");
//		stringBuilder.append(IndexConstant.PACKAGE_NAME);
//		stringBuilder.append(":");
//		stringBuilder.append(queryStatement.getKeyWord());
//		stringBuilder.append(" OR ");
//		stringBuilder.append(IndexConstant.NAME);
//		stringBuilder.append(":");
//		stringBuilder.append(queryStatement.getKeyWord());
//		stringBuilder.append(")");
//
//		return doBuildQuery(queryStatement, contributionNames, stringBuilder);
//	}
}
