/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.exception;

/**
 * ��¼Java���з���ʱ���ֵĴ���<BR>
 * ΪUnchecked Exception��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaException.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/10/31 08:31:52  wanglei
 * Add:�ύ��CVS��
 *
 */

public class JavaException extends RuntimeException {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public JavaException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public JavaException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public JavaException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public JavaException(Throwable cause) {
		super(cause);
	}

}
