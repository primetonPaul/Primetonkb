/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/event/StudioEvent.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2004 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2004-7-30
 *******************************************************************************/

package com.primeton.studio.runtime.event;

import java.util.Hashtable;

/**
 * Studio �����¼��Ļ���, EventManager ���� event��name, ȷ���¼��ļ�����
 * @author jiaoly (mailto:jiaoly@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: StudioEvent.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/06/21 14:08:18  wanglei
 * Review:������ʽ��
 *
 * Revision 1.1  2007/05/12 07:52:10  jiaoly
 * Add���� 5 �汾Ǩ���¼�����ģ��
 *
 * Revision 1.1  2005/04/07 01:15:02  yanfei
 * Create 5.1 Project
 *
 * Revision 1.2  2004/09/13 10:12:31  jiaoly
 * *** empty log message ***
 *
 * Revision 1.1  2004/07/30 06:50:47  jiaoly
 * �½� �¼����� ģ��
 *
 */
public class StudioEvent {

	private String name = null;

	private String eventID = null;

	private Hashtable params = new Hashtable();

	/**
	 *
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public StudioEvent() {
		super();
	}

	/**
	 *
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param name
	 */
	public StudioEvent(String name) {
		super();
		this.name = name;
	}

	public void setParam(String name, Object value) {
		this.params.put(name, value);
	}

	public Object getParam(String name) {
		return this.params.get(name);
	}

	/**
	 * @return the eventID
	 */
	public String getEventID() {
		return this.eventID;
	}

	/**
	 * @param eventID the eventID to set
	 */
	public void setEventID(String eventID) {
		this.eventID = eventID;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the params
	 */
	public Hashtable getParams() {
		return this.params;
	}

	/**
	 * @param params the params to set
	 */
	public void setParams(Hashtable params) {
		this.params = params;
	}

}
