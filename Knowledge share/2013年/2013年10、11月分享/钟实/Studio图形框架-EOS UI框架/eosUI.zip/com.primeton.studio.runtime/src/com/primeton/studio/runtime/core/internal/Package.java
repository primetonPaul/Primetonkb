/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.runtime.MetadataManager;
import com.primeton.studio.runtime.MetadataRepository;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.core.IFilter;
import com.primeton.studio.runtime.core.IPackage;
import com.primeton.studio.runtime.core.IPackageRoot;
import com.primeton.studio.runtime.core.base.AbstractFolderElement;
import com.primeton.studio.runtime.core.internal.filter.ConfigurationFilter;
import com.primeton.studio.runtime.exception.EosModelException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ����Ŀ¼��Դ�İ����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: Package.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.15  2008/04/09 06:52:56  wanglei
 * Review:֧��FAT������
 *
 * Revision 1.14  2008/04/07 12:04:49  wanglei
 * Update:�̶�ֻʹ��NTFS֮�����Դʱ���,������Դ���ӻ���ɾ��ʱ���Ը��¸�Ŀ¼��ʱ�����
 *
 * Revision 1.13  2008/01/14 08:01:40  wanglei
 * Review:��Ϊ��ͬƽ̨�ϵ�ʱ���ʵ�ַ�ʽ��һ�£�����Package����isCacheValid���������������ÿ���Դ���⣬�������л��档
 *
 * Revision 1.12  2008/01/09 05:52:12  wanglei
 * Update:�����˶�META-INFĿ¼�Ĺ��ˡ�
 *
 * Revision 1.11  2008/01/09 01:19:07  wanglei
 * Review:�ع��ײ�ģ�ͣ���ԭ�д���Դ�������������getModelFactory������ȥ��
 *
 * Revision 1.10  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.9  2007/08/29 02:47:40  hongsq
 * Review:Fixһ����ָ������
 *
 * Revision 1.8  2007/07/01 05:57:09  wanglei
 * Add:���ӹ��캯����
 *
 * Revision 1.7  2007/06/30 13:11:16  wanglei
 * Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.6  2007/06/28 09:22:22  wanglei
 * Review:�������캯����֧�ִ���IModelFactory��
 *
 * Revision 1.5  2007/06/01 03:50:00  wanglei
 * UnitTest:������ȡĿ¼ʱ���˵Ĵ���
 *
 * Revision 1.4  2007/05/08 09:00:39  wanglei
 * Remove:getDefaultName��������Ҫ�̳С�
 *
 * Revision 1.3  2007/04/28 09:37:06  wanglei
 * UnitTest:������getParent�д�����ѭ����Bug��
 *
 * Revision 1.2  2007/04/27 10:08:38  wanglei
 * Add:����setExtensionNames����֤����������ȷ��
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public class Package extends AbstractFolderElement implements IPackage {

	private IPackageRoot root;

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param folder
	 * @param parent
	 * @param packageRoot
	 */
	public Package(IFolderDelegate folder, IEosElement parent, IPackageRoot packageRoot) {
		super(folder, parent);
		this.root = packageRoot;

		this.setFilter(ConfigurationFilter.instance);
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosModel[] getModels() {
		Collection col = this.getChildrenOfType(MODEL);
		IEosModel[] results = new IEosModel[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IPackage[] getPackages() {
		Collection col = this.getChildrenOfType(PACKAGE);
		IPackage[] results = new IPackage[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IPackageRoot getPackageRoot() {
		return this.root;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getElementType() {
		return PACKAGE;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + ((this.root == null) ? 0 : this.root.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (!super.equals(obj)) {
			return false;
		}

		final Package other = (Package) obj;
		if (!ObjectUtils.equals(this.root, other.root)) {
			return false;
		}

		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosElement getParent() {
		IEosElement parent = super.getParent();
		if (null == parent) {
			return this.getPackageRoot();
		}
		else {
			return parent;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosElement[] doLoadChildren(IEosElement[] oldChildren) throws EosModelException {

		List list = null;
		if (this.isBinary()) {
			list = this.doLoadBinaryChildren();
		}
		else {
			list = doLoadSourceChildren(oldChildren);
		}

		IEosElement[] results = new IEosElement[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	protected IResourceDelegate[] getChildrenResources() {
		IFilter filter = this.getFilter();
		IResourceDelegate[] resources = ResourceHelper.getResources(getFolder(), (String[]) null);
		List list = new ArrayList();

		for (int i = 0; i < resources.length; i++) {
			IResourceDelegate resource = resources[i];

			if ((null == filter || filter.accept(this, resource))) {
				//				û�б�����
				if (resource.getType() == IResourceDelegate.FOLDER) {
					IFolderDelegate folder = (IFolderDelegate) resource;
					list.add(folder);
					continue;
					//����ΪPackage
				}
				if (resource.getType() == IResourceDelegate.FILE) {
					IFileDelegate file = (IFileDelegate) resource;
					if (RuntimeHelper.support(file)) {
						list.add(file);
					}
				}
			}
		}

		resources = new IResourceDelegate[list.size()];
		list.toArray(resources);
		return resources;
	}

	/**
	 * {@inheritDoc}
	 */
	protected IEosElement loadChild(IResourceDelegate childResource) {
		if (childResource.getType() == IResourceDelegate.FOLDER) {
			IFolderDelegate folder = (IFolderDelegate) childResource;
			return new Package(folder, this, this.root);
			//����ΪPackage
		}
		if (childResource.getType() == IResourceDelegate.FILE) {
			IFileDelegate file = (IFileDelegate) childResource;
			if (RuntimeHelper.support(file)) {
				return new EosModel(file, this);
			}
		}

		return null;
	}

	/**
	 * @return
	 */
	private List doLoadSourceChildren(IEosElement[] oldChildren) {

		List list = new ArrayList();
		Map oldResources = new HashMap();

		if (!ArrayUtils.isEmpty(oldChildren)) {
			for (int i = 0; i < oldChildren.length; i++) {
				IEosElement element = oldChildren[i];
				IResourceDelegate resource = element.getResource();

				if (ResourceHelper.isValidResource(resource)) {
					oldResources.put(resource, element);
					list.add(element);
				}
			}
		}

		IFilter filter = this.getFilter();
		IResourceDelegate[] resources = ResourceHelper.getResources(getFolder(), (String[]) null);

		for (int i = 0; i < resources.length; i++) {
			IResourceDelegate resource = resources[i];

			boolean flag = (null == filter || filter.accept(this, resource));
			//û�б�����
			flag = flag && (!oldResources.containsKey(resource));
			//���Ҳ����Ѿ��������Դ��

			if (flag) {
				if (resource.getType() == IResourceDelegate.FOLDER) {
					IFolderDelegate folder = (IFolderDelegate) resource;
					list.add(new Package(folder, this, this.root));
					continue;
					//����ΪPackage
				}
				if (resource.getType() == IResourceDelegate.FILE) {
					IFileDelegate file = (IFileDelegate) resource;
					if (RuntimeHelper.support(file)) {
						list.add(new EosModel(file, this));
					}
				}
			}
		}

		return list;
	}

	/**
	 * @return
	 */
	private List doLoadBinaryChildren() {
		List list = new ArrayList();

		doLoadBinaryFolders(list);
		doLoadBinaryModels(list);

		return list;
	}

	/**
	 * @param list
	 * @param filter
	 */
	private void doLoadBinaryModels(List list) {

		MetadataRepository metadataRepository = this.getMetadata();

		if (null != metadataRepository) {
			IEosModel[] models = metadataRepository.getModels();

			for (int i = 0; i < models.length; i++) {
				IEosModel model = models[i];
				if (model instanceof EosModel) {
					list.add(model);
				}
			}
			return;
		}
	}

	private MetadataRepository getMetadata() {
		IFolderDelegate folder = this.getFolder();
		Object metadata = folder.getData(MetadataManager.METADATA);

		if (metadata instanceof MetadataRepository) {
			return (MetadataRepository) metadata;
		}

		IFileDelegate fileDelegate = folder.getFile("." + MetadataManager.METADATA);
		if (null != fileDelegate && fileDelegate.exists()) {
			InputStream inputStream = null;

			try {
				inputStream = fileDelegate.getContents();
				MetadataRepository repository = MetadataManager.parseToMetadata(folder, this, inputStream);

				folder.setData(MetadataManager.METADATA, repository);
				return repository;

			} catch (Exception e) {
				RuntimeManager.getLogger().error(e);
				return null;
			} finally {
				IOUtils.closeQuietly(inputStream);
			}
		}
		else {
			return null;
		}
	}

	/**
	 * @param list
	 * @param filter
	 */
	private void doLoadBinaryFolders(List list) {
		IFilter filter = this.getFilter();
		IFolderDelegate[] folders = ResourceHelper.getFolders(getFolder(), (String[]) null);

		for (int i = 0; i < folders.length; i++) {
			IFolderDelegate folder = folders[i];

			if (null == filter) {
				list.add(new Package(folder, this, this.root));
				continue;
			}

			if (filter.accept(this, folder)) {
				list.add(new Package(folder, this, this.root));
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void setFilter(IFilter filter) {

		if (filter != ConfigurationFilter.instance) {
			throw new RuntimeException("The filter in package is not supported.");
		}

		super.setFilter(filter);
	}
}
