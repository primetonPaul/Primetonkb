/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/DefaultResourceLocator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-7-20
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.runtime.Assert;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * Ĭ�ϵ����ƿռ���ҷ�ʽ��ֱ�Ӹ������ƿռ���������Դ��<BR>
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultResourceLocator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/07/20 10:38:50  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 * 
 */
public class DefaultResourceLocator implements IEOSResourceLocator {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 */
	public DefaultResourceLocator() {
	}

	/**
	 * ��ָ���ķ�Χ�в���һ��ָ�����Ƶ���Դ��<BR>.
	 *
	 * @param project ָ����Ŀ
	 * @param namespaces the namespaces
	 *
	 * @return the i file delegate
	 */
	public IFileDelegate findFile(IProjectDelegate project, String[] namespaces) {

		IFileDelegate file = findFileInSourceFolders(project, namespaces);
		if (null != file) {
			return file;
		}

		return findFileInLibraries(project, namespaces);
	}

	/**
	 * ��contribution��Ѱ���ļ�
	 * @param contribution
	 * @param namespaces ���ƿռ�
	 * @param includeReference �Ƿ��������
	 * @return
	 */
	public IFileDelegate findFile(IContribution contribution, String[] namespaces, boolean includeReference) {
		IFileDelegate file;

		IContribution[] contributions = includeReference ? ContributionUtil.getAllRelatedContributions(new IContribution[] { contribution }) : new IContribution[] { contribution };
		for (int j = 0; j < contributions.length; j++) {
			IFolderDelegate folder = (IFolderDelegate) contributions[j].getResource();

			file = findFile(namespaces, folder);
			if (null != file) {
				return file;
			}
		}
		return null;
	}

	/**
	 * �����ÿ��еõ��ļ���<BR>.
	 *
	 * @param project the project
	 * @param namespaces the namespaces
	 *
	 * @return the i file delegate
	 */
	public IFileDelegate findFileInLibraries(IProjectDelegate project, String[] namespaces) {
		boolean supportSourceInBinary = false;
		return findFileInLibraries(project, namespaces, supportSourceInBinary);
	}
	
	/**
	 * �����ÿ��еõ��ļ���<BR>.
	 * @param project
	 * @param namespaces
	 * @param supportSourceInBinary ֧�����ÿ��а���Դ�ļ�
	 * @return
	 */
	private IFileDelegate findFileInLibraries(IProjectDelegate project, String[] namespaces, boolean supportSourceInBinary) {
		IFileDelegate file;
		ILibrary[] libraries = project.getLibraries();
		if (ArrayUtils.isEmpty(libraries)) {
			return null;
		}

		for (int i = 0; i < libraries.length; i++) {
			ILibrary library = libraries[i];
			IContribution[] contributions = library.getContributions();
			for (int j = 0; j < contributions.length; j++) {
				IFolderDelegate folder = (IFolderDelegate) contributions[j].getResource();

				file = findFile(namespaces, folder);
				if ((null != file && supportSourceInBinary) || ResourceHelper.notSourceInBinary(file) ) {
					return file;
				}
			}

		}
		return null;
	}
	
	/**
	 * Find file.
	 *
	 * @param namespaces the namespaces
	 * @param folder the folder
	 *
	 * @return the i file delegate
	 */
	private IFileDelegate findFile(String[] namespaces, IFolderDelegate folder) {
		boolean supportSourceInBinary = false;
		return findFile(namespaces, folder, supportSourceInBinary);
	}
	/**
	 *
	 * @param namespaces
	 * @param folder
	 * @param supportSourceInBinary
	 * @return
	 */
	private IFileDelegate findFile(String[] namespaces, IFolderDelegate folder, boolean supportSourceInBinary) {
		for (int j = 0; j < namespaces.length; j++) {
			String namespace = namespaces[j];
			String extension = FilenameUtils.getExtension(namespace);
			String filePath = FilenameUtil.toPathInUnixStyle(FilenameUtils.removeExtension(namespace));
			IFileDelegate fileDelegate = folder.getFile(filePath + "." + extension);

			if ((supportSourceInBinary && ResourceHelper.isValidResource(fileDelegate))
					|| ResourceHelper.notSourceInBinary(fileDelegate)) {
				return fileDelegate;
			}
		}

		return null;
	}
	
	/**
	 * ��ָ���ķ�Χ�в���һ��ָ�����Ƶ���Դ��<BR>.
	 *
	 * @param project ָ����Ŀ
	 * @param namespaces the namespaces
	 *
	 * @return the i file delegate
	 */
	public IFileDelegate findFileInSourceFolders(IProjectDelegate project, String[] namespaces) {
		Assert.isNotNull(project, "The project parameter must not be null.");
		Assert.isTrue(!ArrayUtils.isEmpty(namespaces), "The namespaces parameter must not be emtpy.");

		ISourceFolderDelegate[] sourceFolders = project.getSourceFolders();
		if (ArrayUtils.isEmpty(sourceFolders)) {
			return null;
		}

		for (int i = 0; i < sourceFolders.length; i++) {
			ISourceFolderDelegate folder = sourceFolders[i];

			IFileDelegate file = findFile(namespaces, folder);
			if (null != file) {
				return file;
			}
		}

		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInFolders(java.lang.String[], com.primeton.studio.runtime.resources.IFolderDelegate[])
	 */
	public IFileDelegate findFileInFolders(String[] namespaces, IFolderDelegate[] folders) {
		IFileDelegate fileDelegate = null;
		for (IFolderDelegate delegate : folders) {
			if (delegate == null)
				continue;
			fileDelegate = findFile(namespaces, delegate);
			if (fileDelegate != null)
				return fileDelegate;
		}
		return null;
	}
}
