/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/ManifestCacheManager.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-12-4
 *******************************************************************************/

package com.primeton.studio.runtime;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubProgressMonitor;

import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.internal.Contribution;
import com.primeton.studio.runtime.project.EOSProjectBuilder;
import com.primeton.studio.runtime.project.EOSProjectNature;
import com.primeton.studio.runtime.project.IEOSProject;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseFileDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseProjectDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceManager;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseSourceFolderDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * �����������桢����contribution��Manifest�ļ���<BR>
 * �Ա���Manifest�ļ��ı�ʱ����contributionһ���ı��롣<BR>
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ManifestCacheManager.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2010/02/04 10:09:22  wanglei
 * Update:���Jira-EOSP-156���⡣
 *
 * Revision 1.2  2008/12/25 05:45:53  lvyuan
 * BugFix:fix bug 6175
 *
 * Revision 1.1  2008/07/04 11:57:24  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2008/04/11 11:08:43  lvyuan
 * Update:�ų��ǹ�����Ĺ���
 *
 * Revision 1.7  2008/01/18 07:07:51  lvyuan
 * UnitTest:�޸�һ����Դ��Ч�Ĵ���
 *
 * Revision 1.6  2008/01/16 07:48:41  wanglei
 * Review:������������
 *
 * Revision 1.5  2007/12/26 06:13:22  tenghao
 * Update:�����ļ��Ƿ���Ч���ж�
 *
 * Revision 1.4  2007/12/22 01:51:59  wanglei
 * Review:��CompositeUtil������ΪContributionUtil����SCA�����һ�¡�
 *
 * Revision 1.3  2007/12/19 05:23:21  wanglei
 * Review:Ϊ���������ͱ���ķ���������һ��buildKind������
 *
 * Revision 1.2  2007/12/07 05:48:50  wanglei
 * Update:IModelValidator�Ľӿ�����������
 *
 * Revision 1.1  2007/12/06 05:19:13  lvyuan
 * Update:���ӹ�����һ���ı���
 *
 */
public class ManifestCacheManager implements IResourceChangeListener, IResourceDeltaVisitor {

	private static ManifestCacheManager instance = new ManifestCacheManager();

	private Map<String, ManufestHolder> registry = new HashMap<String, ManufestHolder>();

	private List<IContribution> buildList = new ArrayList<IContribution>();

	private List<IContribution> hasSearchedList = new ArrayList<IContribution>();

	//����
	private ManifestCacheManager() {
		super();
	}

	/**
	 * @return Ψһ��ʵ��
	 */
	public static ManifestCacheManager getInstance() {
		return instance;
	}

	// �½�contibutionʱ��ע��
	public void registeManifest(IFileDelegate fileDelegate) {
		Assert.isTrue(fileDelegate != null, "The resource is null");
		Assert.isTrue(!RuntimeConstant.MANIFEST.equals(fileDelegate.getName()), "The resource is not a manifest file");
		String path = fileDelegate.getFullPath();
		ManufestHolder hodler = this.registry.get(path);
		if (hodler == null) {
			hodler = new ManufestHolder(fileDelegate);
		}
		else {
			hodler = hodler.getManufestObject(fileDelegate);
		}
		this.registry.put(fileDelegate.getFullPath(), hodler);
	}

	// ɾ��contibutionʱ��ȡ��ע��
	public void unRegisteManifest(IFileDelegate fileDelegate) {
		Assert.isTrue(fileDelegate != null, "The resource is null");
		Assert.isTrue(!RuntimeConstant.MANIFEST.equals(fileDelegate.getName()), "The resource is not a manifest file");
		this.registry.remove(fileDelegate.getFullPath());
	}

	// ɾ����Ŀʱ��ɾ����Ӧ��ע����Ϣ
	public void deleteAllManifestsinProject(String projectName) {
		if (!StringUtils.isEmpty(projectName)) {
			for (Iterator iter = this.registry.keySet().iterator(); iter.hasNext();) {
				String element = (String) iter.next();
				if (element.startsWith("/" + projectName + "/")) {
					this.registry.remove(element);
				}
			}
		}
	}

	// ɾ����Ŀʱ��ɾ����Ӧ��ע����Ϣ
	public ManufestHolder getManifest(IFileDelegate fileDelegate) {
		return getManifest(fileDelegate, false);
	}

	// ɾ����Ŀʱ��ɾ����Ӧ��ע����Ϣ
	public ManufestHolder getManifest(IFileDelegate fileDelegate, boolean compare) {
		Assert.isTrue(fileDelegate != null, "The resource is null");
		Assert.isTrue(!RuntimeConstant.MANIFEST.equals(fileDelegate.getName()), "The resource is not a manifest file");
		ManufestHolder hodler = this.registry.get(fileDelegate.getFullPath());
		if (hodler == null) {
			hodler = new ManufestHolder(fileDelegate);
		}
		else {
			hodler = compare ? hodler.getManufestObject(fileDelegate) : hodler;
		}
		return hodler;
	}

	// ����Ŀʱ�������е�contribution�ļ���manifest��Ϣע��
	public void registeManifestinProject(IEOSProject project) {
		Assert.isTrue(project != null, "The project is null");
		IContribution[] contributions = RuntimeManager.getAllContributionsWithoutLibraries(new EclipseProjectDelegate(project.getProject()));
		for (int i = 0; i < contributions.length; i++) {
			IContribution contribution = contributions[i];
			IFolderDelegate folder = (IFolderDelegate) contribution.getResource();
			IFileDelegate fileDelegate = ContributionUtil.getManifestFile(folder);
			if(null != fileDelegate)
				registeManifest(fileDelegate);
		}
	}

	/* (non-Javadoc)
	 * shutdown
	 */
	public void shutdown() {
		ResourcesPlugin.getWorkspace().removeResourceChangeListener(instance);
		this.registry.clear();
		this.buildList.clear();
	}

	/* (non-Javadoc)
	 * startup
	 */
	public void startup() {
		ResourcesPlugin.getWorkspace().addResourceChangeListener(instance);
		IEOSProject[] eosProjects = RuntimePlugin.getEOSProjects();
		for (int i = 0; i < eosProjects.length; i++) {
			IEOSProject project = eosProjects[i];
			registeManifestinProject(project);
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.core.resources.IResourceChangeListener#resourceChanged(org.eclipse.core.resources.IResourceChangeEvent)
	 */
	public void resourceChanged(IResourceChangeEvent event) {
		IResourceDelta delta = event.getDelta();
		try {
			if (delta != null) {
				delta.accept(instance);
			}
		} catch (CoreException x) {
			ExceptionUtil.getInstance().handleException(x);
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.core.resources.IResourceDeltaVisitor#visit(org.eclipse.core.resources.IResourceDelta)
	 */
	public boolean visit(IResourceDelta delta) throws CoreException {
		IResource resource = delta.getResource();
		if (condition(delta)) {
			switch (delta.getKind()) {
				case IResourceDelta.ADDED:
				case IResourceDelta.CHANGED:
					registeManifest(new EclipseFileDelegate((IFile) resource));
					break;
				case IResourceDelta.REMOVED:
					unRegisteManifest(new EclipseFileDelegate((IFile) resource));
					break;
			}
		}
		return true;
	}

	/**
	 * ��¼Ҫ�����contribution��<BR>
	 *
	 * @param delta
	 */
	public void record(IResourceDelta delta) {
		IResource resource = delta.getResource();
		if (condition(delta)) {
			ManufestHolder holder = getManifest(new EclipseFileDelegate((IFile) resource));
			if (holder.hasChange()) {
				IContribution[] contribution = holder.getAffectContributions();
				for (int i = 0; i < contribution.length; i++) {
					IContribution contribution2 = contribution[i];
					if (!this.buildList.contains(contribution2)) {
						this.buildList.add(contribution2);
					}
				}
			}
		}

        ifRemoveAndCollectref(delta);
	}


    /**
     * �����ɾ������������Ҫ���������Ĺ�����Ҳ����һ�¡�<BR>
     */
    private void ifRemoveAndCollectref(IResourceDelta delta) {
        IResource resource = delta.getResource();
        int type = resource.getType();
        try {
            if (delta.getKind() == IResourceDelta.REMOVED) {

                if ((type == IResource.FILE) && EOSProjectNature.isEOSProject(resource.getProject())
                        && RuntimeConstant.MANIFEST_FILE.equals(resource.getName())) {
                	IContribution[] contributions = RuntimeManager.getAllContributions(new EclipseProjectDelegate(resource.getProject()));
    				for (int i = 0; i < contributions.length; i++) {
    					if(this.hasSearchedList.contains(contributions[i])){
    						continue;
    					}

    					this.hasSearchedList.add(contributions[i]);

    					if (contributions[i].isBinary()) {
    						continue;
    					}

                		String[] requireBundles = ContributionUtil.getRequiredBundles(contributions[i]);
                		for (int j = 0; j < requireBundles.length; j++) {
                			String requireBundle = requireBundles[j];
                			IContribution requireContribution = RuntimeManager.findContribution(contributions[i].getResource().getProject(), requireBundle);
                			if (requireContribution == null && !this.buildList.contains(contributions[i])) {
                				this.buildList.add(contributions[i]);
                				continue;
                			}
                		}
    				}
                }
            }
        } catch (Exception e) {
            RuntimePlugin.getDefault().getLogger().error(e);
        }
    }


	/**
	 * �����MANIFEST�ļ����ı䣬����contributionһ���ı��롣<BR>
	 *
	 * @param delta
	 */
	public boolean accept(IResourceDelta delta) {
		record(delta);

		IResourceDelta[] deltas = delta.getAffectedChildren();
		for (int i = 0; i < deltas.length; i++) {
			accept(deltas[i]);
		}

		// ��������¼���
		this.hasSearchedList.clear();
		return this.buildList.size() > 0;
	}

	/**
	 * ���롣<BR>
	 *
	 * @param delta
	 * @param builder
	 */
	public void build(IResourceDelta delta, EOSProjectBuilder builder, IProgressMonitor monitor) {

		IFolder[] folders = getSourceFolders(this.buildList.toArray(new IContribution[0]));
		if (ArrayUtils.isEmpty(folders)) {
			return;
		}

		monitor.beginTask(null, folders.length * EOSProjectBuilder.SCALE);

		for (int i = 0; i < folders.length; i++) {
			IFolder folder = folders[i];

			IProgressMonitor subMonitor = new SubProgressMonitor(monitor, EOSProjectBuilder.SCALE);

			if (null != folder && folder.exists()) {
				try {
					builder.buildFolder(delta, folder, IncrementalProjectBuilder.FULL_BUILD, subMonitor);
				} catch (CoreException e) {
					ExceptionUtil.getInstance().handleException(e);
				}
			}
		}

		this.buildList.clear();
	}

	/**
	 * @param contributions
	 * @return
	 */
	public IFolder[] getSourceFolders(IContribution[] contributions) {
		List<IFolder> sources = new ArrayList<IFolder>();
		for (IContribution contribution : contributions) {
            if(!contribution.isBinary()) {
    			IFolder tmp = (IFolder) ((Contribution) contribution).getSourceFolder().getAdapter(IFolder.class);
    			sources.add(tmp);
            }
		}
		return sources.toArray(new IFolder[0]);
	}

	// �����ж���
	private boolean condition(IResourceDelta delta) {
		IResource resource = delta.getResource();
		int type = resource.getType();
		try {
			if ((type == IResource.FILE) && EOSProjectNature.isEOSProject(resource.getProject()) && RuntimeConstant.MANIFEST_FILE.equals(resource.getName())) {
				// ��binĿ¼��
				IFileDelegate fileDelegate = new EclipseFileDelegate((IFile) resource);
				EclipseSourceFolderDelegate sourceFolderDelegate = (EclipseSourceFolderDelegate) fileDelegate.getSourceFolder();
                if(sourceFolderDelegate != null &&EclipseResourceManager.isPrefixOf(sourceFolderDelegate.getEclipseFolder(), resource)) {
                    return true;
                }
//				if (ResourceHelper.isValidResource(fileDelegate)) {
//					IContribution contribution = RuntimeManager.createContribution(new EclipseFileDelegate((IFile) resource));
//					if (contribution != null) {
//						return true;
//					}
//				}
			}
		} catch (Exception e) {
			RuntimePlugin.getDefault().getLogger().error(e);
		}
		return false;
	}

	public IResourceDelta[] getOutScopeData(IResourceDelta delta) {
		if (this.buildList.isEmpty()) {
			return new IResourceDelta[] {
				delta
			};
		}

		List<IResourceDelta> outScopes = new ArrayList<IResourceDelta>();

		outScropeCollect(delta, outScopes);

		return outScopes.toArray(new IResourceDelta[0]);
	}

	/**
	 * �ռ�û���ڵ�ǰbuildList��IResourceDelta��
	 *
	 * @param delta
	 * @param list
	 */
	private void outScropeCollect(IResourceDelta delta, List<IResourceDelta> list) {
		Assert.isNotNull(list);
		IResource resource = delta.getResource();
		if (IResource.FILE == resource.getType()) {
            IResourceDelegate delegate = new EclipseFileDelegate((IFile) resource);
            if(ResourceHelper.isValidResource(delegate)) {
                IContribution contribution = RuntimeManager.createContribution(new EclipseFileDelegate((IFile) resource));
                if ((contribution != null) && !this.buildList.contains(contribution) && !list.contains(delta)) {
                    list.add(delta);
                }
            }
		}

		for (int i = 0; i < delta.getAffectedChildren().length; i++) {
			IResourceDelta child = delta.getAffectedChildren()[i];
			outScropeCollect(child, list);
		}

	}

}
