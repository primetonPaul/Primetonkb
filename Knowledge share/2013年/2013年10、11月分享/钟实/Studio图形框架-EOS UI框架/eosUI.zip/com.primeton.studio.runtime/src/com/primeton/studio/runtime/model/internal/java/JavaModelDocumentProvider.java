/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.internal.java;

import java.util.Collection;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.model.IJavaAnalyser;
import com.primeton.studio.runtime.model.IJavaAnalyserFactory;
import com.primeton.studio.runtime.model.internal.DefaultJavaAnalyserFactory;
import com.primeton.studio.runtime.model.internal.DefaultMethodDocumentProvider;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * ֧�ֶ�Java��������JavaDoc<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaModelDocumentProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.11  2010/04/28 03:59:17  wanglei
 * Review:����û���ж�null�����⡣
 *
 * Revision 1.10  2009/09/23 03:29:55  chenty
 * BUG��21676
 * �������ɵ�bizlet��edoc��,methodȱ����ʾ����
 *
 * Revision 1.9  2009/05/13 07:30:13  lvyuan
 * Update:�ع�EDOC�����ɷ�ʽ
 *
 * Revision 1.8  2009/05/06 03:48:25  lvyuan
 * Update:��Ӧ������EOS��Դ�Ĺ��ʻ��ṩ֧�֣���ҵ���߼���������ԴҲ������edoc
 *
 * Revision 1.7  2009/04/17 01:21:49  wanglei
 * Update:ʵ����createDocumentFile������
 *
 * Revision 1.6  2009/01/04 03:36:31  zhuxing
 * Update:EOS Studio�ڶ��������Ż�
 *
 * Revision 1.5  2008/09/03 10:42:36  yanfei
 * Update:���ӿ�ָ���жϡ�
 *
 * Revision 1.4  2008/08/21 06:39:04  yujl
 * Update:���һ����ָ���쳣
 *
 * Revision 1.3  2008/07/16 06:39:42  hongsq
 * Update:�޸������߼���keyΪ����������ǩ��
 *
 * Revision 1.2  2008/07/15 09:19:55  hongsq
 * Update:�ع��Զ����(jira����EOS-1654)
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/05/16 07:01:04  yanfei
 * BugFix 8609 �ڼ��ɱ��뻷���£�ִ��eos��Ŀ����ű��������ecdȱ��edoc�ļ�
 *
 * Revision 1.5  2008/05/05 09:27:21  yangmd
 * Update:�޸�������ȷ����javadoc��bug
 *
 * Revision 1.4  2008/04/15 06:33:40  wanglei
 * Update:����EOS�ĵ��������Ŀ¼��������Դ����Ŀ¼��
 *
 * Revision 1.3  2008/04/14 12:43:31  wanglei
 * Add:����getDocumentFile������
 *
 * Revision 1.2  2008/04/14 11:56:26  wanglei
 * Update:֧������JavaDoc��
 *
 * Revision 1.1  2008/04/11 08:27:54  wanglei
 * Add:�ύ��CVS��
 *
 */

public class JavaModelDocumentProvider extends DefaultMethodDocumentProvider {

	private static final JavaModelDocumentProvider instance = new JavaModelDocumentProvider();

	private static final String EXTENSION_NAME = RuntimeConstant.CLASS + "." + RuntimeConstant.EOS_DOCUMENT;

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private JavaModelDocumentProvider() {
		super();
	}

	/**
	 * @return Returns the instance.
	 */
	public static JavaModelDocumentProvider getInstance() {
		return instance;
	}

	/**
	 * {@inheritDoc}
	 */
	protected String getExtension(IFileDelegate fileDelegate) {
		return RuntimeConstant.CLASS;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.internal.HtmlToolTipProvider#getHtml(com.primeton.studio.runtime.core.IEosElement)
	 */
	public String getHtml(IEosElement eosElememnt) {
		IFileDelegate fileDelegate = (IFileDelegate) eosElememnt.getResource();
		String path = fileDelegate.getSourceRelativePath();
		path = FilenameUtil.toPackageWithoutExtension(path);
		if(path == null || "".equals(path.trim())){
			return null;
		}
		IJavaAnalyserFactory javaAnalyserFactory = RuntimeManager.getJavaAnalyserFactory();
		if(javaAnalyserFactory instanceof DefaultJavaAnalyserFactory){
			ISourceFolderDelegate sourceFolderDelegate = fileDelegate.getSourceFolder();
			if(sourceFolderDelegate != null){
				String srcPath = sourceFolderDelegate.getFile().getPath();
				((DefaultJavaAnalyserFactory)javaAnalyserFactory).addSrcPath(srcPath);
			}
		}
		IJavaAnalyser javaAnalyser = javaAnalyserFactory.createAnalyser(fileDelegate.getProject(), path);
		if (null == javaAnalyser) {
			return null;
		}

		String html = null;
		if(eosElememnt.getElementType() == IEosElement.TYPE){
			html =  javaAnalyser.getJavaDocForClass();
		} else if (eosElememnt.getElementType() == IEosElement.METHOD){
			html =  javaAnalyser.getJavaDocForMethod((IMethod) eosElememnt);
			if(null==html){
				return null;
			}

			Pattern pattern  = Pattern.compile("(?<=<p>).*?(?=(<br>|<dl>|<p>|</body>))",Pattern.DOTALL);
			Matcher matcher = pattern.matcher(html);
			boolean matchFound = matcher.find();
			if(matchFound){
				if(matcher.group(0).trim().length() == 0){
					html = html.replaceFirst(pattern.toString(),  eosElememnt.getDisplayName());
				}
			}
		}

		return html;
	}

	@Override
	protected Map configDocMap(IEosElement model) {
		Collection collection = model.getChildrenOfType(IEosElement.TYPE);
		if(!collection.isEmpty() && collection.size() >0){
			return super.configDocMap((IEosElement)collection.iterator().next());
		}
		return super.configDocMap(model);
	}
}
