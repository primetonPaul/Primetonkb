/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/DefaultJavaDocHelper.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-4-29
 *******************************************************************************/


package com.primeton.studio.runtime.model.internal;

import java.util.HashMap;
import java.util.Map;

import xjavadoc.XProgramElement;

import com.primeton.studio.runtime.RuntimeMessages;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultJavaDocHelper.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/07/22 13:20:55  yangmd
 * Update:10007 ��������ͼ�������߼���Ӧjavadoc��ʽ����ȷ
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/05 09:27:21  yangmd
 * Update:�޸�������ȷ����javadoc��bug
 * 
 */
public class DefaultJavaDocHelper {
	public final static Map<String,String> TAG_NL = new HashMap<String,String>();
	private final static String JAVADOC_PARAM_STR = "param";
	static{
		TAG_NL.put(JAVADOC_PARAM_STR, RuntimeMessages.JAVADOC_PARAM);
		TAG_NL.put("author", RuntimeMessages.JAVADOC_AUTHOR);
		TAG_NL.put("return", RuntimeMessages.JAVADOC_RETURN);
		TAG_NL.put("see", RuntimeMessages.JAVADOC_SEE);
		TAG_NL.put("since", RuntimeMessages.JAVADOC_SINCE);
		TAG_NL.put("throws", RuntimeMessages.JAVADOC_THROWS);
		TAG_NL.put("exception", RuntimeMessages.JAVADOC_THROWS);
	}
	
	/** Javadoc general tags */
	public static final String[] JAVADOC_GENERAL_TAGS= new String[] { "author", "category", "deprecated", 
		"docRoot", "exception", "inheritDoc", "link", "linkplain", JAVADOC_PARAM_STR, 
		"return", "see", "serial", "serialData", "serialField", "since", 
		"throws", "value", "version" };  
	/**
	 * ���캯��˽��
	 *
	 */
	private DefaultJavaDocHelper() {
		// todo nothing
	}
	/**
	 * ����javadoc,XProgramElement�������࣬�������ֶ�
	 * @param element
	 * @return
	 */
	public static String getJavadoc(XProgramElement element){
		xjavadoc.TagMessage tagMessage = new xjavadoc.TagMessage(RuntimeMessages.JAVADOC_SEE,
				RuntimeMessages.JAVADOC_PARAM,RuntimeMessages.JAVADOC_RETURN,
				RuntimeMessages.JAVADOC_THROWS,RuntimeMessages.JAVADOC_AUTHOR,
				RuntimeMessages.JAVADOC_SINCE);
		return element.getDoc().getJavaDoc(tagMessage);
	}
	
}
