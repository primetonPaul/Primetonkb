/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/DefaultSeparatorPolicy.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-21
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser;

/**
 * Ĭ�ϵķָ�������
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultSeparatorPolicy.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:45  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class DefaultSeparatorPolicy implements ISeparatorPolicy {
	/**
	 * ���õ�ָ�������.����
	 */
	public static final DefaultSeparatorPolicy DotSeparatorPolicy = new DefaultSeparatorPolicy(".");
	/**
	 * ����б�߷ָ�������/����
	 */
	public static final DefaultSeparatorPolicy PathSeparatorPolicy = new DefaultSeparatorPolicy("/");
	
	private String separator;
	
	/**
	 * 
	 * @param separator
	 */
	public DefaultSeparatorPolicy(String separator) {
		this();
		this.separator = separator;
	}
	/**
	 * 
	 *
	 */
	public DefaultSeparatorPolicy(){
		super();
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.ISeparatorPolicy#getSeparator(com.primeton.studio.runtime.helper.SeparatorModel)
	 */
	public String getSeparator(SeparatorModel model) {
		return this.separator;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.ISeparatorFilter#accept(com.primeton.studio.runtime.helper.SeparatorModel)
	 */
	public boolean accept(SeparatorModel separatorModel) {
		return true;
	}

}
