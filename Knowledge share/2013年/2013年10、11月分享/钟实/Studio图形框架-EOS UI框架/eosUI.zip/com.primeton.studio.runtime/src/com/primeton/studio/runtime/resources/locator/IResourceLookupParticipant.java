/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/IResourceLookupParticipant.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-7-20
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * TODO�˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IResourceLookupParticipant.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/08/20 07:47:03  hongsq
 * Update:�ṩһ��ӿ�֧�ֲ���һ���ļ������޸�xsd,wsdl��ع����������ƿռ��ظ�
 *
 * Revision 1.1  2009/07/20 10:38:50  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 * 
 */
public interface IResourceLookupParticipant {
	
	public IFileDelegate findFile(String[] namespaces);
	
	public IFileDelegate[] findFiles(String[] namespaces);
}
