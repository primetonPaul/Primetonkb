/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.runtime/src/com/primeton/studio/workbench/core/internal/build/EOSProjectNature.java,v
 * 1.2 2007/01/19 09:58:45 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2006-12-15
 **********************************************************************************************************************/

package com.primeton.studio.runtime.project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;

import com.eos.system.utility.CollectionUtil;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.exception.ResourceException;

/**
 * EOS��Ŀ����Ϣ
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EOSProjectNature.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.9  2008/04/30 02:38:53  yanfei
 * Update:IProject.setDescription����FORCE����������ļ���ͬ��������
 *
 * Revision 1.8  2008/04/28 06:21:20  yanfei
 * Update:����JavaBuilder��EOSBuilder��˳��
 *
 * Revision 1.7  2008/04/23 02:28:13  yanfei
 * Update:����.project�ļ���JavaBuilder��EOSBuilder��˳��
 *
 * Revision 1.6  2007/12/20 01:18:32  wanglei
 * Review:CollectionUtil�е�addAllӦ����addAllQuietly��
 *
 * Revision 1.5  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.4  2007/05/10 05:20:36  wanglei
 * UnitTest:�����˵���Ŀ�ǹر�ʱ��������쳣��Bug��
 *
 * Revision 1.3  2007/04/23 09:02:06  wanglei
 * UnitTest:�����˴�����Ŀʱ��û�м���Ĭ�ϵ�JRE���Bug����Bug�����ڿ����½���Java���޷����롣
 *
 * Revision 1.2  2007/04/05 01:05:37  wanglei
 * UnitTest:������Ϊ��Ŀ����Nature��˳�򣬴Ӷ�����Ŀ��ʶΪEOS��Ŀ������JDT��Ŀ��
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 *
 */
public class EOSProjectNature implements IProjectNature {

	private IProject project;

	/**
	 * Ĭ�Ϲ��캯��
	 */
	public EOSProjectNature() {
		super();

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.resources.IProjectNature#configure()
	 */
	public void configure() throws CoreException {
		IProjectDescription description = this.project.getDescription();

		if (!isEOSProject(description)) {

			this.addNature(description);
			this.addBuilder(description);
			this.updatePaths();
		}
	}



	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.resources.IProjectNature#deconfigure()
	 */
	public void deconfigure() throws CoreException {
		removeFromBuildSpec(JavaCore.BUILDER_ID);
		removeFromBuildSpec(RuntimeConstant.BUILDER_ID);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.resources.IProjectNature#getProject()
	 */
	public IProject getProject() {
		return this.project;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.resources.IProjectNature#setProject(org.eclipse.core.resources.IProject)
	 */
	public void setProject(IProject project) {
		this.project = project;
	}

	/**
	 * �ṩһ����̬��ʽ���ж�һ����Ŀ�Ƿ���EOS��Ŀ��<BR>
	 */
	public static boolean isEOSProject(IProjectDescription description) {
		return description.hasNature(RuntimeConstant.NATURE_ID);
	}

	/**
	 * �ṩһ����̬��ʽ���ж�һ����Ŀ�Ƿ���EOS��Ŀ��<BR>
	 *
	 * @throws CoreException
	 */
	public static boolean isEOSProject(IProject project) throws CoreException {
		if ((null == project) ||(!project.isOpen())){
			return false;
		}
		else {
			return project.hasNature(RuntimeConstant.NATURE_ID);
		}
	}

	/**
	 * ����ǰ��Ŀ�趨ΪEOS��Ŀ����������һ��Java��Ŀ��<BR>
	 *
	 * @param description
	 * @throws CoreException
	 */
	private void addNature(IProjectDescription description) throws CoreException {
		Set natureSet = new TreeSet();
		CollectionUtil.addAllQuietly(natureSet, description.getNatureIds());

		if (!natureSet.contains(JavaCore.NATURE_ID)) {
			natureSet.add(JavaCore.NATURE_ID);
		}

		if (!natureSet.contains(RuntimeConstant.NATURE_ID)) {
			natureSet.add(RuntimeConstant.NATURE_ID);
		}

		String[] natures = new String[natureSet.size()];
		natureSet.toArray(natures);
		description.setNatureIds(natures);

		this.project.setDescription(description, IProject.FORCE, null);
	}

	/**
	 * ɾ��Ĭ�ϵ��������·����<BR>
	 *
	 * @param project
	 */
	private void updatePaths() {
		List list = new ArrayList();
		IJavaProject javaProject = JavaCore.create(this.project);

		try {
			IFolder outputFolder = project.getFolder("bin");
			javaProject.setOutputLocation(outputFolder.getFullPath(), null);
			//TODO Ĭ�������Ӧ��û�����Ŀ¼��<BR>

			IClasspathEntry[] classEntries = javaProject.getRawClasspath();
			for (int i = 0; i < classEntries.length; i++) {
				IClasspathEntry entry = classEntries[i];
				if (entry.getEntryKind() != IClasspathEntry.CPE_SOURCE) {
					list.add(entry);
				}
			}

			IClasspathEntry entry = JavaCore.newContainerEntry(new Path("org.eclipse.jdt.launching.JRE_CONTAINER"));
			list.add(entry);
			//��ΪEOS��ĿҲ��Java��Ŀ������Ҫ����Ĭ�Ͽ�

			IClasspathEntry[] newEntries = new IClasspathEntry[list.size()];
			list.toArray(newEntries);
			javaProject.setRawClasspath(newEntries, null);

		} catch (JavaModelException e) {
			throw new ResourceException(e);
		}
	}

	/**
	 * ����EOS��Java��Builder��<BR>
	 *
	 * @param description
	 * @throws CoreException
	 */
	private void addBuilder(IProjectDescription description) throws CoreException {
		Map builderMap = new HashMap();
		ICommand[] buildSpec = description.getBuildSpec();
		for (int i = 0; i < buildSpec.length; i++) {
			ICommand command = buildSpec[i];
			builderMap.put(command.getBuilderName(), command);
		}

		if (!builderMap.containsKey(JavaCore.BUILDER_ID)) {
			ICommand newCommand = description.newCommand();
			newCommand.setBuilderName(JavaCore.BUILDER_ID);
			builderMap.put(newCommand.getBuilderName(), newCommand);
		}
		//����Java��Builder��ʶ��

		if (!builderMap.containsKey(RuntimeConstant.BUILDER_ID)) {
			ICommand newCommand = description.newCommand();
			newCommand.setBuilderName(RuntimeConstant.BUILDER_ID);
			builderMap.put(newCommand.getBuilderName(), newCommand);
		}
		//����EOS��Builder��ʶ��


		ICommand[] newCommands = new ICommand[builderMap.size()];
		builderMap.values().toArray(newCommands);

		description.setBuildSpec(newCommands);

		this.project.setDescription(description, null);
	}

	/**
	 * �ӵ�ǰ��Ŀ����ȥָ��Builder��ʶ�ŵ�Builder��<BR>
	 *
	 * @param builderID
	 * @throws CoreException
	 */
	protected void removeFromBuildSpec(String builderID) throws CoreException {
		IProjectDescription description = this.project.getDescription();
		ICommand[] commands = description.getBuildSpec();
		for (int i = 0; i < commands.length; ++i) {
			if (commands[i].getBuilderName().equals(builderID)) {
				ICommand[] newCommands = new ICommand[commands.length - 1];
				System.arraycopy(commands, 0, newCommands, 0, i);
				System.arraycopy(commands, i + 1, newCommands, i, commands.length - i - 1);
				description.setBuildSpec(newCommands);
				this.project.setDescription(description, null);
				return;
			}
		}
	}
}
