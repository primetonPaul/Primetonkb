/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.archive;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.Assert;

import com.eos.system.utility.FilenameUtil;
import com.eos.system.utility.StringUtil;
import com.primeton.studio.core.util.entry.MapEntry;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * ѹ���ļ���ӳ����<BR>
 * �ܹ���һ��ѹ���ļ�ӳ�䵽һ��Ŀ¼��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ArchiveRootFileDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/09/30 11:07:32  chenty
 * BUG��21899
 * ��NPE���µ�WSDLģ�ͽ�������
 *
 * Revision 1.2  2009/09/16 07:02:14  lvyuan
 * BugFix:�޸�һ����ָ�����
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.13  2008/07/03 08:41:39  yangmd
 * Update:��chidren��resources���������ࡣ
 *
 * Revision 1.12  2008/03/19 01:29:04  wanglei
 * Update:ȥ�����õķ�����
 *
 * Revision 1.11  2008/01/15 05:03:13  wanglei
 * UnitTest:����isPrefixOf������
 *
 * Revision 1.10  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.9  2007/11/06 08:51:26  chenxp
 * UnitTest:fix a bug inside getFolder method.
 *
 * Revision 1.8  2007/09/25 07:15:07  wanglei
 * Review:���ѹ�����л�����ѹ������Ҫ�ж���Ӧ�Ĳ��,�پ����Ƿ���Ҫ���д�����
 *
 * Revision 1.7  2007/08/29 08:53:40  wanglei
 * UnitTest:����getFolder�õ�Bug��
 *
 * Revision 1.6  2007/07/20 03:15:59  yangjun
 * Update:ȥ��ResourceHelper.isValidResource(parentFolder)��֤
 *
 * Revision 1.5  2007/07/19 02:43:36  wanglei
 * Refactor:ResourceHelper�е�isResourceValid������ΪisValidResource.
 *
 * Revision 1.4  2007/07/18 06:43:43  wanglei
 * Update:ȡ���˶��ļ���Դ���жϣ����Ǵ���isValid�������ж��ļ���Դ�Ƿ���Ч��
 *
 * Revision 1.3  2007/07/05 06:58:03  wanglei
 * Review:ͨ��NullObjectģʽ����������NPE�ĳ��֡�
 *
 * Revision 1.2  2007/06/28 09:32:43  wanglei
 * Review:���ӹ��������������Խ�ʡ����Ҫ�Ŀ�����
 *
 * Revision 1.1  2007/06/26 07:53:56  wanglei
 * �ύ��CVS��
 *
 */

public class ArchiveRootFileDelegate extends AbstractArchiveResourceDelegate implements IFolderDelegate {

	public static final int ONE_LEVEL = 1;

	public static final int ZERO_LEVEL = 0;

	public static final int INFINITE_LEVEL = Integer.MAX_VALUE;

	private String projectName;

	IFileDelegate file;

	private ISourceFolderDelegate sourceFolder;

	private String name;

	private IFolderDelegate parentFolder;

	protected Map resources = new TreeMap();

	protected Set children = new HashSet();

	private String[] archiveFileExtensions = new String[] {
		"jar",
		"zip"
	};

	private InputStream inputStream;

	private InternalArchiveFilter filter;

	private IArchiveResourceFilter resourceFilter;

	private int level = INFINITE_LEVEL;

	private boolean supportInnerArchive = true;

	private String encoding;

	private boolean valid = true;

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param projectName
	 * @param inputStream
	 * @throws IOException
	 */
	public ArchiveRootFileDelegate(String projectName, IFolderDelegate parentFolder, InputStream inputStream, String name) throws IOException {
		super();
		//this.assertProject(projectName);
		Assert.isNotNull(inputStream, "the input stream can't be null.");
		Assert.isNotNull(name, "the name can't be null.");

		if ((null != inputStream) && (null != name)) {
			this.name = name;
			this.parentFolder = parentFolder;
			this.projectName = projectName;
			this.inputStream = inputStream;
		}
		else {
			this.valid = false;
		}
	}

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param projectName
	 * @param file
	 */
	public ArchiveRootFileDelegate(String projectName, IFileDelegate file) {
		super();

		if (ResourceHelper.isValidResource(file)) {
			this.projectName = projectName;
			this.file = file;
			this.parentFolder = file.getParent();

			InputStream fileInputStream = null;

			try {
				fileInputStream = file.getContents();
				byte[] bytes = IOUtils.toByteArray(fileInputStream);
				this.inputStream = new ByteArrayInputStream(bytes);
			} catch (Exception e) {
				RuntimeManager.getLogger().error(e);
			} finally {
				IOUtils.closeQuietly(fileInputStream);
			}
		}
		else {
			this.valid = false;
		}
	}

	/**
	 *
	 * @param inputStream
	 * @throws IOException
	 */
	public void load() throws IOException {

		ZipInputStream zipInputStream = new ZipInputStream(this.inputStream);
		Map map = new TreeMap();

		try {
			while (true) {
				ZipEntry zipEntry = zipInputStream.getNextEntry();
				if (zipEntry == null) {
					break;
				}

				if ((null != this.resourceFilter) && (!this.resourceFilter.accept(this, zipEntry))) {
					continue;
				}
				//���ѹ�������������������zipEntry����ֱ�ӽ�����һ��ѭ��

				long size = zipEntry.getSize();
				if (size != (int) size) {
					throw new IOException("Corrupt Zip File.");
				}

				String entryName = zipEntry.getName();
				ByteArrayInputStream contents = null;

				if (!zipEntry.isDirectory()) {
					byte[] bytes = IOUtils.toByteArray(zipInputStream);
					contents = new ByteArrayInputStream(bytes);
				}

				map.put(entryName, new MapEntry(zipEntry, contents));
			}

			this.loadResources(map);
		} finally {
			IOUtils.closeQuietly(zipInputStream);
		}
	}

	/**
	 * @param map
	 * @throws IOException
	 */
	private void loadResources(Map map) throws IOException {

		for (Iterator iterator = map.keySet().iterator(); iterator.hasNext();) {
			String entryName = (String) iterator.next();
			MapEntry mapEntry = (MapEntry) map.get(entryName);
			ZipEntry zipEntry = (ZipEntry) mapEntry.getKey();

			IResourceDelegate delegate = null;

			if (zipEntry.isDirectory()) {
				delegate = new ArchiveFolderDelegate(this, entryName);
			}
			else {
				int entryLevel = StringUtils.countMatches(entryName, "/");
				InputStream inStream = (InputStream) mapEntry.getValue();

				if (this.isArchive(entryName, entryLevel)) {

					if (this.isArchiveAcceptable(entryName, entryLevel)) {
						String parentName = getParentName(entryName);

						ArchiveFolderDelegate parentFolderder = (ArchiveFolderDelegate) this.resources.get(parentName);
						ArchiveRootFileDelegate rootFile = new ArchiveRootFileDelegate(this.projectName, parentFolderder, inStream, entryName);

						if (this.level != Integer.MAX_VALUE) {
							rootFile.setLevel(this.level - 1);
						}

						rootFile.setResourceFilter(this.resourceFilter);
						rootFile.name = entryName;
						rootFile.file = this.file;
						rootFile.load();
						delegate = rootFile;
					}
				}
				else {
					ArchiveFileDelegate archiveFile = new ArchiveFileDelegate(this, entryName);
					archiveFile.setContents(inStream);
					delegate = archiveFile;
				}
			}
			if (null != delegate) {
				this.resources.put(entryName, delegate);
			}
		}

		for (Iterator iterator = this.resources.keySet().iterator(); iterator.hasNext();) {
			String entryName = (String) iterator.next();
			IResourceDelegate delegate = (IResourceDelegate) this.resources.get(entryName);

			String parentName = getParentName(entryName);
			IResourceDelegate resource = (IResourceDelegate) this.resources.get(parentName);

			if (resource instanceof ArchiveFolderDelegate) {
				ArchiveFolderDelegate folder = (ArchiveFolderDelegate) resource;
				folder.addChild(delegate);
			}
			else {
				this.children.add(delegate);
			}
		}
	}

	/**
	 * �����Ƿ�֧��һ���ļ���Ϊѹ���ļ�����<BR>
	 *
	 * @param fileName
	 * @param fileLevel
	 * @return
	 */
	private boolean isArchive(String fileName, int fileLevel) {

		if (!this.isSupportInnerArchive()) {
			return false;
		}

		if (null != this.filter) {
			return this.filter.isArchive(fileName);
		}

		String extension = FilenameUtils.getExtension(fileName);
		if (null == extension) {
			return false;
		}
		if (ArrayUtils.isEmpty(this.archiveFileExtensions)) {
			return false;
		}

		return StringUtil.isIn(extension, this.archiveFileExtensions, false);
	}

	/**
	 * �����ѹ�������Ƿ�Ҫ���ܡ�<BR>
	 * Ŀǰ�Ǹ��ݲ���жϡ�<BR>
	 * ��Ҫ�ǿ��ǵ����ܷ�������⡣<BR>
	 *
	 * @param fileName
	 * @param fileLevel
	 * @return
	 */
	private boolean isArchiveAcceptable(String fileName, int fileLevel) {
		return fileLevel < this.level;
	}

	/**
	 * @param path
	 * @return
	 */
	public String getParentName(String path) {

		int count = StringUtils.countMatches(path, "/");
		if (count == 0) {
			return "/";
		}

		if ((count == 1) && path.endsWith("/")) {
			return "/";
		}

		if (path.endsWith("/")) {
			path = StringUtils.substringBeforeLast(path, "/");
			path = StringUtils.substringBeforeLast(path, "/");
		}
		else {
			path = StringUtils.substringBeforeLast(path, "/");
		}
		return FilenameUtil.normalizeInUnixStyle(path + "/");
	}

	/**
	 * {@inheritDoc}
	 */
	public IResourceDelegate[] getChildren() {
		IResourceDelegate[] delegates = new IResourceDelegate[this.children.size()];
		this.children.toArray(delegates);
		return delegates;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate getFile(String path) {
		path = FilenameUtil.normalizeInUnixStyle(path);
		
		if(null == path){
			return new NullArchiveFileDelegate(this, path);
		}
		IFileDelegate fileDelegate = (IFileDelegate) this.resources.get(path);
		if (null == fileDelegate) {
			return new NullArchiveFileDelegate(this, path);
		}
		else {
			return fileDelegate;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getFolder(String path) {

		if (null == path) {
			return null;
		}

		int count = StringUtils.countMatches(path, "/") + StringUtils.countMatches(path, "\\");
		if (count == path.length()) {
			return this;
		}

		path = FilenameUtil.normalizeInUnixStyle(path + "/");
		IFolderDelegate folderDelegate = (IFolderDelegate) this.resources.get(path);

		if (null == folderDelegate) {
			return new NullArchiveFolderDelegate(this, path);
		}
		else {
			return folderDelegate;
		}
	}

	/**
	 * �õ�ĳһ����Դ�ĸ��ס�<BR>
	 *
	 * @param resource
	 * @return
	 */
	public IFolderDelegate getParent(ArchiveResourceDelegate resource) {
		String path = this.getParentName(resource.getPath());
		return (IFolderDelegate) this.resources.get(path);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isPrefixOf(IResourceDelegate resourceDelegate) {
		if (null == resourceDelegate) {
			return false;
		}

		if (!(resourceDelegate instanceof AbstractArchiveResourceDelegate)) {
			return false;
		}

		ArchiveResourceDelegate archiveResource = (ArchiveResourceDelegate) resourceDelegate;

		return archiveResource.getArchiveFile() == this;
	}

	/**
	 * {@inheritDoc}
	 */
	public File getFile() {
		if (null == this.file) {
			return null;
		}
		else {
			return this.file.getFile();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public String getFullPath() throws ResourceException {
		if (null == this.file) {
			return null;
		}
		else {
			return this.file.getFullPath();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public long getLastModified() {
		if (null == this.file) {
			return 0;
		}
		else {
			return this.file.getLastModified();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public String getName() throws ResourceException {

		if (null != this.name) {
			return this.name;
		}

		if (null == this.file) {
			return this.name;
		}
		else {
			return this.file.getName();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getParent() throws ResourceException {
		return this.parentFolder;
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate getProject() throws ResourceException {
		return RuntimeManager.getRoot().getProject(this.projectName);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProjectRelativePath() throws ResourceException {
		if(this.parentFolder == null){
			this.parentFolder = this.file.getParent();
		}
		
		String relativePath = this.parentFolder.getProjectRelativePath() + this.getName();
		relativePath = FilenameUtil.normalizeInUnixStyle(relativePath);
		return relativePath;
	}

	/**
	 * {@inheritDoc}
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return this.sourceFolder;
	}

	/**
	 * @param sourceFolder the sourceFolder to set
	 */
	public void setSourceFolder(ISourceFolderDelegate sourceFolder) {
		this.sourceFolder = sourceFolder;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getSourceRelativePath() throws ResourceException {
		//		String sourceRelativePath = this.parentFolder.getSourceRelativePath() + this.getName();
		//		sourceRelativePath = FileUtil.normalize(sourceRelativePath);
		//		return sourceRelativePath;

		return "/";
	}

	/**
	 * {@inheritDoc}
	 */
	public int getType() throws ResourceException {
		return IResourceDelegate.FOLDER;
	}

	/**
	 * �ж�ָ����Դ�Ƿ���ָ��Ŀ¼�²㡣<BR>
	 *
	 * @param folder
	 * @param resourceDelegate
	 * @return
	 */
	boolean isPrefixOf(ArchiveFolderDelegate folder, IResourceDelegate resourceDelegate) {

		if (!(resourceDelegate instanceof ArchiveResourceDelegate)) {
			return false;
		}

		ArchiveResourceDelegate archiveResource = (ArchiveResourceDelegate) resourceDelegate;
		if (!(archiveResource.getArchiveFile() == this)) {
			return false;
		}

		String folderPath = folder.getFullPath();
		String resourcePath = archiveResource.getFullPath();

		return (folderPath.length() != resourcePath.length()) && resourcePath.startsWith(folderPath);
	}

	/**
	 * @return the archiveFileExtensions
	 */
	public String[] getArchiveFileExtensions() {
		return this.archiveFileExtensions;
	}

	/**
	 * @param archiveFileExtensions the archiveFileExtensions to set
	 */
	public void setArchiveFileExtensions(String[] archiveFileExtensions) {
		this.archiveFileExtensions = archiveFileExtensions;
	}

	/**
	 * @return the level
	 */
	public int getLevel() {
		return this.level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * @return the supportInnerArchive
	 */
	public boolean isSupportInnerArchive() {
		return this.supportInnerArchive;
	}

	/**
	 * @param supportInnerArchive the supportInnerArchive to set
	 */
	public void setSupportInnerArchive(boolean supportInnerArchive) {
		this.supportInnerArchive = supportInnerArchive;
	}

	/**
	 * @return the encoding
	 */
	public String getEncoding() {
		return this.encoding;
	}

	/**
	 * @param encoding the encoding to set
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate getFile(ArchiveFolderDelegate folder, String name) {
		String fullPath = folder.getPath() + name;
		fullPath = FilenameUtil.normalizeInUnixStyle(fullPath);
		return this.getFile(fullPath);

	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getFolder(ArchiveFolderDelegate folder, String path) {
		//String fullPath = this.getFullPath()+ "/"+folder.getPath() + path + "/";
		String fullPath = folder.getPath() + path + "/";
		fullPath = FilenameUtil.normalizeInUnixStyle(fullPath);
		return this.getFolder(fullPath);
	}

	/**
	 * @return the resourceFilter
	 */
	public IArchiveResourceFilter getResourceFilter() {
		return this.resourceFilter;
	}

	/**
	 * @param resourceFilter the resourceFilter to set
	 */
	public void setResourceFilter(IArchiveResourceFilter resourceFilter) {
		this.resourceFilter = resourceFilter;
	}

	/**
	 * @return the valid
	 */
	public final boolean isValid() {
		return this.valid;
	}

}
