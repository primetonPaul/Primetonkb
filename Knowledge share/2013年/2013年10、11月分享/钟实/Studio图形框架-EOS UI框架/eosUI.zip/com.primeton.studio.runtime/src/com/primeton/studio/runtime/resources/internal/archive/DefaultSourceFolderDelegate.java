/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/DefaultSourceFolderDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-11
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IOutputFolderDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultSourceFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 * 
 */
public class DefaultSourceFolderDelegate extends DefaultFolderDelegate
		implements ISourceFolderDelegate {

	/**
	 * @param parent
	 * @param path
	 */
	public DefaultSourceFolderDelegate(IFolderDelegate parent, String path) {
		super(parent, path);
	}

	/**
	 * @param sourceFolder
	 * @param parent
	 * @param path
	 */
	public DefaultSourceFolderDelegate(ISourceFolderDelegate sourceFolder,
			IFolderDelegate parent, String path) {
		super(sourceFolder, parent, path);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.ISourceFolderDelegate#getOutputFolder()
	 */
	public IOutputFolderDelegate getOutputFolder() {
		return null;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.DefaultFolderDelegateEx#getSourceFolder()
	 */
	@Override
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return this;
	}

}
