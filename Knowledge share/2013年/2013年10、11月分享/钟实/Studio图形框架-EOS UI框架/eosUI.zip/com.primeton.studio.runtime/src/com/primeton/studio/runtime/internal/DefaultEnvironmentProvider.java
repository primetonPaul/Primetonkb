/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/internal/DefaultEnvironmentProvider.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on May 22, 2010
 *******************************************************************************/


package com.primeton.studio.runtime.internal;

import com.primeton.studio.runtime.extension.AbstractEosEnvironmentProvider;


/**
 * Ĭ�ϵİ汾�ṩ��
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultEnvironmentProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/05/24 08:35:44  wanglei
 * Jira:����EOSP-259��
 *
 */
public class DefaultEnvironmentProvider extends AbstractEosEnvironmentProvider {
	private final static DefaultEnvironmentProvider instance = new DefaultEnvironmentProvider();

	/**
	 * @return Returns the instance.
	 */
	public static DefaultEnvironmentProvider getInstance() {
		return instance;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.core.IPriority#getPriority()
	 */
	public int getPriority() {
		return 100;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.extension.AbstractEosEnvironmentProvider#getVersion()
	 */
	@Override
	public String getVersion() {
		return "6.1";
	}

}
