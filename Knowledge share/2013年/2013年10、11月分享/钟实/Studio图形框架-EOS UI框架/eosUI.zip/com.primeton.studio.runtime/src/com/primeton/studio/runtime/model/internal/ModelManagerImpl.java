/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/ModelManagerImpl.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-25
 **********************************************************************************************************************/

package com.primeton.studio.runtime.model.internal;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.core.util.comparator.PropertyComparator;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IProjectElement;
import com.primeton.studio.runtime.core.internal.ProjectElement;
import com.primeton.studio.runtime.model.IModelChangeListener;
import com.primeton.studio.runtime.model.IModelFactory;
import com.primeton.studio.runtime.model.IModelManager;
import com.primeton.studio.runtime.model.IModelPool;
import com.primeton.studio.runtime.model.IModelStateTracker;
import com.primeton.studio.runtime.model.IResourceFinder;
import com.primeton.studio.runtime.model.ModelChangeEvent;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * IModelManager��ʵ�֡�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ModelManagerImpl.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.9  2010/06/19 08:56:09  hongsq
 * Update:�������е�modelfactoryʱӦ�ð������е�modelfactory
 *
 * Revision 1.8  2010/04/14 10:17:42  wanglei
 * Jira:����EOSP-197��
 *
 * Revision 1.7  2009/06/02 08:20:47  liu-jun
 * bug:18992,���ʻ������޸�
 *
 * Revision 1.6  2008/09/01 10:10:45  chenxp
 * Bug: 11651:����Ŀ�ϸ���classpath��classpath�ļ�������ȷ�����ǹ�������״̬�������仯 (hongsq)
 *
 * Revision 1.5  2008/08/12 09:29:36  yujl
 * Update:ɾ��ʱҲִ�и÷���
 *
 * Revision 1.4  2008/08/12 09:03:49  yanfei
 * Update:�������ʱ������󣬵��²����½���Ŀ�����⡣
 *
 * Revision 1.3  2008/08/12 01:40:08  zhuxing
 * Update:�������ύ�����������ģ�ͱ���������������
 *
 * Revision 1.2  2008/07/09 00:48:30  yujl
 * update:�޸Ĺ�������ͼ��ʾ����
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.18  2008/07/03 04:15:21  wanglei
 * Update:ʵ��isCacheValid������������Eclipse��Դ�¼����Ա�ͬ������ʱ�����
 *
 * Revision 1.17  2008/01/14 01:20:25  wanglei
 * Add:���Ӷ�ģ��״̬���ٵĽӿڷ�����
 *
 * Revision 1.16  2008/01/07 06:15:36  wanglei
 * Add:��������Ŀģ�͵����ݡ�
 *
 * Revision 1.15  2008/01/07 05:55:47  wanglei
 * Review:IModelPool��ȥisSupport������
 *
 * Revision 1.14  2008/01/07 02:17:48  wanglei
 * Review:IJavaTypeFinder����ʹ�á�
 *
 * Revision 1.13  2007/12/19 03:41:05  wanglei
 * Remove:��ȥIFileIndexer�����ݣ��ŵ�IndexManager�С�
 *
 * Revision 1.12  2007/06/11 08:07:38  lvyuan
 * UnitTest:��ʼ��
 *
 * Revision 1.11  2007/06/06 10:50:18  wanglei
 * Update:��DefaultJavaTypeFinder�ĳɵ�����
 *
 * Revision 1.10  2007/06/06 10:37:19  wanglei
 * Add:������JavaѰ������<BR>
 *
 * Revision 1.9  2007/06/01 07:32:43  wanglei
 * Update:��ΪHashtable����������null��Keyֵ�����Ի���HashMap��
 *
 * Revision 1.8  2007/05/31 10:17:40  wanglei
 * Update:����MocelChangedEvent��ʵ�ֽ��е�����
 *
 * Revision 1.7  2007/05/24 08:46:38  wanglei
 * Add:������getModelFactory������
 *
 * Revision 1.6  2007/05/08 09:02:16  wanglei
 * UnitTest:������getModelFactory��isSupported�����в���Ϊnullʱ�����쳣��Bug��
 *
 * Revision 1.5  2007/04/24 09:18:22  wanglei
 * UnitTest:��������ѭ����Bug��
 *
 * Revision 1.4  2007/04/24 02:15:59  wanglei
 * Add:��������Դ���ҽӿڡ�
 *
 * Revision 1.3  2007/04/05 01:04:56  wanglei
 * Add:������ģ�͸ı��֪ͨ�¼���
 *
 * Revision 1.2  2007/03/30 02:20:32  wanglei
 * Remove:ȥ����Ŀ¼��֧�֡�
 *
 * Revision 1.1  2007/03/05 11:32:13  wanglei
 * �ύ��CVS
 *
 */

public class ModelManagerImpl implements IModelManager, IResourceChangeListener, IResourceDeltaVisitor {
	/**
	 * Ψһʵ��
	 */
	private static final ModelManagerImpl instance = new ModelManagerImpl();

	/**
	 * ����ļ�ģ��Factory<BR>
	 * ��<Type,Factory>�ļ�ֵ�Խ��д�š�<BR>
	 *
	 */
	private Map modelFactories = new HashMap();

	private Set factories = new TreeSet(new PropertyComparator(IConstant.PRIORITY));

	private IModelPool pool = new StackModelPool();

	private IModelStateTracker stateTracker;

	private Set listeners = new HashSet();

	private IResourceFinder resourceFinder = new DefaultResourceFinder();

	private Map projects = new HashMap();

	private Map timestamps = new HashMap();

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 */
	private ModelManagerImpl() {
		super();
	}

	/**
	 * @return ����Ψһʵ����
	 */
	public static ModelManagerImpl getInstance() {
		return instance;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized IModelFactory[] getAllModelFactories() {
		Set<IModelFactory> set = new HashSet<IModelFactory>();
		set.addAll(this.modelFactories.values());
		set.addAll(this.factories);
		return set.toArray(new IModelFactory[set.size()]);
	}

	/**
	 * {@inheritDoc}
	 */
	public IModelFactory getModelFactory(String extension) {
		IModelFactory factory = (IModelFactory) this.modelFactories.get(extension);
		return factory;
	}

	/**
	 * {@inheritDoc}
	 */
	public IModelFactory getModelFactory(IFileDelegate fileDelegate) {
		if (null == fileDelegate) {
			return null;
		}

		String extension = fileDelegate.getExtension();

		if (null == extension) {
			return null;
		}

		IModelFactory modelFactory = this.getModelFactory(extension);
		if(null!=modelFactory){
			return modelFactory;
		}else{
			for (Iterator iterator = this.factories.iterator(); iterator.hasNext();) {
				modelFactory = (IModelFactory) iterator.next();

				if(modelFactory.isAcceptable(fileDelegate)){
					return modelFactory;
				}
			}

			return null;
		}
	}

	/**
	 * @param Ҫ���õ���Դ������
	 */
	public void setResourceFinder(IResourceFinder resourceFinder) {
		this.resourceFinder = resourceFinder;
	}

	/**
	 * {@inheritDoc}
	 */
	public IResourceFinder getResourceFinder() {
		return this.resourceFinder;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized IModelPool getPool() {
		return this.pool;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void registerFileFactory(String type, IModelFactory factory) {
		Assert.isLegal(StringUtils.isNotEmpty(type), "The type cannot be null");
		Assert.isNotNull(factory, "The factory cannot be null");
		// ֻ�в�����Ч��������ע�ᡣ

		if(factory.supportIdenticalExtension())	{
			IModelFactory oldFactory = (IModelFactory) this.modelFactories.get(type);
			if ((null == oldFactory) || (factory.getPriority() > oldFactory.getPriority())) {
				this.modelFactories.put(type, factory);
			}
			// ���ԭ��û��ע��Factory����ʹ�ò���ָ����
			// �����ڱȽ����ȼ��Ժ��پ����Ƿ�ע���µ�Factory.
		}else{
			this.factories.add(factory);
		}



	}

	/**
	 * {@inheritDoc}
	 */
	public String[] getAllTypes() {
		String[] types = new String[this.modelFactories.size()];
		this.modelFactories.keySet().toArray(types);
		return types;
	}

	/**
	 * {@inheritDoc}
	 */
	public void addModelChangeListener(IModelChangeListener listener) {
		if (null != listener) {
			this.listeners.add(listener);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void fireModelChanged(ModelChangeEvent event) {
		for (Iterator iterator = this.listeners.iterator(); iterator.hasNext();) {
			IModelChangeListener listener = (IModelChangeListener) iterator.next();

			try {
				listener.modelChanged(event);
			} catch (Exception e) {
				ExceptionUtil.getInstance().logException(e);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IModelChangeListener[] getModelChangeListeners() {
		IModelChangeListener[] results = new IModelChangeListener[this.listeners.size()];
		this.listeners.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public void removeModelChangeListener(IModelChangeListener listener) {
		if (null != listener) {
			this.listeners.remove(listener);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectElement[] getAllProjectElements() {
		IProjectElement[] elements = new IProjectElement[this.projects.size()];
		this.projects.values().toArray(elements);
		return elements;
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectElement getProjectElement(IProjectDelegate projectDelegate) {

		if (ResourceHelper.isValidProject(projectDelegate)) {
			String projectName = projectDelegate.getName();

			IProjectElement project = (IProjectElement) (this.projects.get(projectName));
			if (null != project) {
				return project;
			} else {
				return loadProjectElement(projectDelegate);
			}
		} else {
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectElement getProjectElement(String projectName) {
		if (StringUtils.isEmpty(projectName)) {
			return null;
		} else {
			IProjectDelegate project = RuntimeManager.getRoot().getProject(projectName);
			return getProjectElement(project);
		}
	}

	/**
	 * ������Ŀģ�͡�<BR>
	 *
	 * @param projectDelegate
	 * @return
	 */
	private IProjectElement loadProjectElement(IProjectDelegate projectDelegate) {
		ProjectElement projectElement = new ProjectElement(projectDelegate);
		this.projects.put(projectDelegate.getName(), projectElement);
		return projectElement;
	}

	/**
	 * �����Ŀ����Ч�ԡ�<BR>
	 * ���һ����Ŀ�����ڣ����߱��ر��ˣ�����ӻ������Ƴ���<BR>
	 *
	 */
	public void checkProjectElements() {

		IProjectElement[] elements = this.getAllProjectElements();
		for (int i = 0; i < elements.length; i++) {
			IProjectElement element = elements[i];
			IProjectDelegate projectDelegate = element.getProject();

			if (!ResourceHelper.isValidProject(projectDelegate)) {
				this.projects.remove(projectDelegate.getName());
			}
		}
		//��ȥ��Ч����Ŀģ�͡�
	}

	/**
	 * {@inheritDoc}
	 */
	public IModelStateTracker getStateTracker() {
		return this.stateTracker;
	}

	/**
	 * @param stateTracker the stateTracker to set
	 */
	public void setStateTracker(IModelStateTracker stateTracker) {
		this.stateTracker = stateTracker;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.IModelManager#getLastModified(com.primeton.studio.runtime.resources.IFolderDelegate)
	 */
	public long getLastModified(IFolderDelegate folderDelegate) {
		if (!ResourceHelper.isValidResource(folderDelegate)) {
			return 0;
		}

		Long oldTimestamp = (Long) this.timestamps.get(folderDelegate.getFullPath());
		if (null == oldTimestamp) {
			/*��Ϊ2������ʱ��ֱ�Ӷ�ȡ����*/
			return folderDelegate.getLastModified();
		} else {
			return oldTimestamp.longValue();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void resourceChanged(IResourceChangeEvent event) {
		if (null == event.getDelta()) {
			return;
		}

		try {
			event.getDelta().accept(this);
		} catch (CoreException e) {
			e.printStackTrace();
		}
	}

	/**
	 * add by zhuxing:
	 * �˷�������Ĵ����޸�ʱҪ���أ�
	 *
	 * {@inheritDoc}
	 */
	public boolean visit(IResourceDelta delta) throws CoreException {
		if (delta == null) {
			return true;
		}
		IResource resource = delta.getResource();

		int kind = delta.getKind();

		if (resource.getType() == IResource.FILE) {
			if (RuntimeConstant.PROJECT_FILE.equals(resource.getName()) || RuntimeConstant.CLASSPATH_FILE.equals(resource.getName()) || RuntimeConstant.LIBRARY_FILE.equals(resource.getName())) {
				ModelManagerImpl.getInstance().checkProjectElements();

				updateParent(resource, false);
				return true;
			}
		}

		if (IResourceDelta.ADDED == kind) {
			updateParent(resource, true);
			return false;
		}

		// ��Ŀɾ����ʱ�� ��黺��
		if ((IResourceDelta.REMOVED == kind)) {
			updateParent(resource, false);
			return true;
		}

		return true;
	}

	/**
	 * @param resource
	 */
	private void updateParent(IResource resource, boolean add) {
		IContainer container = resource.getParent();
		String fullPath = container.getFullPath().toString();

		Long currentTimestamp = (Long) this.timestamps.remove(fullPath);

		if (null == currentTimestamp) {
			currentTimestamp = Long.valueOf(container.getLocalTimeStamp());
		}
		currentTimestamp = Long.valueOf(container.getLocalTimeStamp() + 100);
		this.timestamps.put(fullPath, currentTimestamp);
	}
}
