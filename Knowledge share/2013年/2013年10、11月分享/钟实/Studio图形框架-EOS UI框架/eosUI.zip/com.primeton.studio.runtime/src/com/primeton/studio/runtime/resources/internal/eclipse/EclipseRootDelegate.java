/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/eclipse/EclipseRootDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-29
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.eclipse;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.service.impl.DefaultXmlStoreService;
import com.primeton.studio.core.util.entry.StringMapEntry;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimePlugin;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.library.internal.LibraryImpl;
import com.primeton.studio.runtime.project.IEOSProject;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;

/**
 * ����Դ��ʵ�֡�<BR>
 * ��Ӧ��Eclipse�й������ĸ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EclipseRootDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.5  2009/10/20 10:39:38  chenxp
 * BUG: 22301 �½�sample��Ŀ��������Ҳ��������������criteriaType�� (hongsq)
 *
 * Revision 1.4  2009/01/06 07:38:24  lvyuan
 * BugFix:�޸�һ������
 *
 * Revision 1.3  2008/07/18 07:48:57  yujl
 * update:
 *
 * Revision 1.2  2008/07/18 05:23:34  yujl
 * fix :EOS-1965  [LA2]����������ͼ���ⲿ���ÿ��ļ���ɾ��,�Ƿ���Ҫ�Զ����
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2008/06/20 06:55:10  hongsq
 * Update:����doGetLibraries��ȡlibraryʱ,��������쳣���ؿ�����,������null
 *
 * Revision 1.7  2008/06/03 02:42:04  wanglei
 * Add:����checkLibraries������
 *
 * Revision 1.6  2008/01/03 01:52:11  wanglei
 * Review:��չ����Ӧ�ú���.�š�
 *
 * Revision 1.5  2007/12/11 05:38:44  wanglei
 * UnitTest:��XML�ļ�ǿ��ʹ��UTF-8���롣
 *
 * Revision 1.4  2007/09/13 02:14:11  wanglei
 * Review:��.library�óɳ��� ��
 *
 * Revision 1.3  2007/08/23 03:11:07  wanglei
 * Review:��IEOSProject�е�getLibraries�ƶ���IProjectDelegate�С�
 *
 * Revision 1.2  2007/07/12 07:22:19  wanglei
 * Add:����getEOSProjects������
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */
public class EclipseRootDelegate extends EclipseFolderDelegate implements IRootDelegate {
	private static final EclipseRootDelegate instance = new EclipseRootDelegate();

	private Map libraries = new HashMap();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * ֱ��ʹ��IWorkspaceRoot��Ϊ����<BR>
	 */
	private EclipseRootDelegate() {
		super(ResourcesPlugin.getWorkspace().getRoot());
	}

	/**
	 * @return Returns the instance.
	 */
	public static EclipseRootDelegate getInstance() {
		return instance;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IRootDelegate#getProject(java.lang.String)
	 */
	public IProjectDelegate getProject(String name) {
		return EclipseResourceManager.getInstance().getProject(name);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IRootDelegate#getProjects()
	 */
	public IProjectDelegate[] getProjects() {
		return EclipseResourceManager.getInstance().getProjects();
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate[] getEOSProjects() {
		IEOSProject[] projects = RuntimePlugin.getEOSProjects();
		List list = new ArrayList();
		for (int i = 0; i < projects.length; i++) {
			IProject project = (IProject) projects[i].getAdapter(IResource.class);
			if (project.isOpen()) {
				list.add(new EclipseProjectDelegate(project));
			}
		}

		IProjectDelegate[] results = new IProjectDelegate[list.size()];
		list.toArray(results);
		return results;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceDelegate#getAdapter(java.lang.Class)
	 */
	public Object getAdapter(Class adapter) {
		if (IWorkspaceRoot.class == adapter) {
			return ResourcesPlugin.getWorkspace().getRoot();
		}

		return super.getAdapter(adapter);
	}

	/**
	 * �õ����ÿ⡣<BR>
	 *
	 * @param project
	 * @return
	 */
	public ILibrary[] getLibraries(EclipseProjectDelegate project) {
		if(!ResourceHelper.isValidProject(project)){
			return new ILibrary[0];
		}
		
		StringMapEntry entry = (StringMapEntry) this.libraries.get(project.getName());

		if (null == entry) {
			entry = this.loadLibraries(project);
			this.libraries.put(project.getName(), entry);
		} else {
			String timestamp = entry.getKey();

			IFile file = project.getEclipseProject().getFile(RuntimeConstant.LIBRARY_FILE);
			String newTimestamp = "" + file.getLocalTimeStamp();

			ILibrary[] checkLibraries = this.changedLibraries(project);
			if (!(newTimestamp).equals(timestamp)
					|| (checkLibraries != null && checkLibraries.length > 0)) {
				entry = this.loadLibraries(project);
				this.libraries.put(project.getName(), entry);
			}
			//���ʱ�����ƥ�䣬������Դ�Ѿ����£�������load
		}

		return (ILibrary[]) entry.getValue();
	}

	/**
	 * �ҳ���Դ�����仯�����ÿ�
	 *
	 * @param project
	 * @return
	 */
	public ILibrary[] changedLibraries(EclipseProjectDelegate project) {
		StringMapEntry entry = (StringMapEntry) this.libraries.get(project.getName());
		ILibrary[] libraries;
		if(entry == null){
			libraries = doGetLibraries(project);
		}else{
			libraries = (ILibrary[]) entry.getValue();
		}
		List list = new ArrayList();

		if (null != libraries) {
			for (int i = 0; i < libraries.length; i++) {
				LibraryImpl library = (LibraryImpl) libraries[i];
				library.setProject(project);
				if (library.isResourceChanged()) {
					list.add(library);
				}
			}
		}

		if (list.isEmpty()) {
			return null;
		} else {
			ILibrary[] results = new ILibrary[list.size()];
			list.toArray(results);
			return results;
		}
	}

	private ILibrary[] doGetLibraries(EclipseProjectDelegate project) {
		IFile file = project.getEclipseProject().getFile(RuntimeConstant.LIBRARY_FILE);

//		if (!file.exists()) {
//			return new ILibrary[0];
//		}

		InputStream inStream = null;
		try {
			if(file.exists()){
				inStream = file.getContents();
			} else if(file.getLocation().toFile().exists()) {
				//�п����ļ����ڣ�����Eclipse��Դϵͳ��û������
				inStream = new FileInputStream(file.getLocation().toFile());
			} else {
				return new ILibrary[0];
			}
			
			String xml = IOUtils.toString(inStream, IConstant.UTF8);
			List list = (List) DefaultXmlStoreService.getInstance().fromXML(xml);

			ILibrary[] results = new ILibrary[list.size()];
			list.toArray(results);

			return results;
		} catch (Exception e) {
			return new ILibrary[0];
		} finally {
			IOUtils.closeQuietly(inStream);
		}
	}

	/**
	 * @param project
	 * @return
	 */
	private StringMapEntry loadLibraries(EclipseProjectDelegate project) {

		StringMapEntry entry = new StringMapEntry();
		IFile file = project.getEclipseProject().getFile(RuntimeConstant.LIBRARY_FILE);
		entry.setKey("" + file.getLocalTimeStamp());

		ILibrary[] results = this.doGetLibraries(project);

		for (int i = 0; i < results.length; i++) {
			LibraryImpl library = (LibraryImpl) results[i];
			library.setProject(project);
		}

		entry.setValue(results);
		return entry;
	}
	
	/**
	 * ж�ػ����е����ÿ�
	 * @param project
	 */
	public void unLoadLibraries(IProjectDelegate project) {
		if(null != project){
			this.libraries.remove(project.getName());
		}
	}
}
