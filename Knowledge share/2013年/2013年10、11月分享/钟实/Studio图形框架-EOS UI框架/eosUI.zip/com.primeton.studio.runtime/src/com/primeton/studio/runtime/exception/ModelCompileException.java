/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.runtime/src/com/primeton/studio/workbench/core/exception/ModelParseException.java,v
 * 1.1 2006/12/31 09:50:01 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 * 
 * ==============================================================================
 * 
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 * 
 * Created on 2006-12-29
 **********************************************************************************************************************/

package com.primeton.studio.runtime.exception;

/**
 * ����ģ��ʱ���ֵ��쳣��<BR>
 * 
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 * 
 * $Log: ModelCompileException.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 * 
 */
public final class ModelCompileException extends RuntimeException {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public ModelCompileException() {
		super();

	}

	/**
	 * @param message
	 * @param cause
	 */
	public ModelCompileException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 */
	public ModelCompileException(String message) {
		super(message);

	}

	/**
	 * @param cause
	 */
	public ModelCompileException(Throwable cause) {
		super(cause);

	}

}
