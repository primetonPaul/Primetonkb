/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/ArchiveRootDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-10
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.apache.commons.io.IOUtils;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeMessages;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;


/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ArchiveRootDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.5  2009/05/07 12:55:48  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.4  2008/10/06 03:38:35  yangmd
 * Update:���ӽ��ȼ��㣬��߿����ԡ�
 *
 * Revision 1.3  2008/08/19 10:08:23  yanfei
 * BugFix 11181 �ڵ���Դ����ʱ��Java��Դѡ���޷���ѡ�У���������,Ȼ��ȡ���Ĳ������ߵ�����ɺ�ɾ��ԭ�������Դ�ļ�������޷�ɾ���Ĵ���
 *
 * ԭ��
 * ��zip�ļ�������û�йر�
 *
 * Revision 1.2  2008/07/13 14:05:22  yangmd
 * Update:�ع�
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 * 
 */
public class ArchiveRootDelegate extends DefaultFolderDelegate implements IRootDelegate{
	private Set<IProjectDelegate> projects = new HashSet<IProjectDelegate>();
	private Map<String, IProjectDelegate> projectMap = new HashMap<String, IProjectDelegate>();
	private IArchiveProvider zipProvider;
	private File archiveFile;
	/**
	 * 
	 * @param projectName
	 * @param file
	 * @throws IOException 
	 * @throws ZipException 
	 */
	public ArchiveRootDelegate(IFileDelegate file) throws ZipException, IOException {
		super(null, file.getName());
		archiveFile = file.getFile();
		zipProvider = new ZipArchiveProvider(new ZipFile(archiveFile));
	}
	
	/**
	 * 
	 * @throws IOException
	 */
	public void load(IProgressMonitor monitor) throws IOException {
		if(monitor == null){
			monitor = new NullProgressMonitor();
		}
		List list = zipProvider.getChildren(zipProvider.getRoot());
		this.children.clear();
		try {
			long size = archiveFile.length();
			long count = size/1500;//����ÿ���ļ���СΪ1.5Kbytes,���ԵĹ���ѹ�������ļ�����
			int countInt = 1;
			if(count >=Integer.MAX_VALUE){
				countInt = Integer.MAX_VALUE;
			} else {
				countInt = (int) count;
			}
			monitor.beginTask(RuntimeMessages.UNZIP_FILE, countInt);
			this.load(zipProvider.getRoot(),this.getName(),list,monitor);			
		} finally {			
			monitor.done();
		}
	}
	/**
	 * 
	 * @param monitor
	 */
	private void load(Object rootElement,String name, List list,IProgressMonitor monitor){
		if(monitor == null){
			monitor = new NullProgressMonitor();
		}
		monitor.worked(1);
		boolean isRootProject = false;
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			Object element = iter.next();
			if(!zipProvider.isFolder(element)){
				if(RuntimeConstant.PROJECT_FILE.equals(zipProvider.getLabel(element))){
					isRootProject = true;
					break;
				}
			}
		}
		if(isRootProject){
			ArchiveProjectDelegate projectDelegate = new ArchiveProjectDelegate(this,name);
			projectDelegate.setModel(rootElement);
			this.addProject(projectDelegate);
			itereteResources(projectDelegate,list, true, monitor);
		} else {
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Object element = iter.next();
				List temp = zipProvider.getChildren(element);
				if(temp != null){
					load(rootElement,zipProvider.getLabel(element),temp,monitor);
				}
					
			}
		}
		close();
		monitor.done();
	}
	/**
	 * 
	 * @param parent
	 * @param zipEntrys
	 * @param isRoot
	 * @param monitor
	 */
	private void itereteResources(IFolderDelegate parent,
			List zipEntrys,boolean isRoot,IProgressMonitor monitor){
		for (Iterator iter = zipEntrys.iterator(); iter.hasNext();) {
			Object element = iter.next();
			String path = zipProvider.getFullPath(element);
			String name = zipProvider.getLabel(element);
			DefaultResourceDelegate resourceDelegate = null;
			if(monitor.isCanceled()){
				return;
			}
			monitor.setTaskName(RuntimeMessages.UNZIPING+path);
			monitor.worked(1);
			if(zipProvider.isFolder(element)){
				ImportContributionValidator validator = new ImportContributionValidator(this.zipProvider);
				boolean isContribution = validator.validate(element);
				if(isContribution){
					resourceDelegate = new DefaultSourceFolderDelegate(parent,name);
					((ArchiveProjectDelegate)parent.getProject()).addSourceFolder((ISourceFolderDelegate) resourceDelegate);
				} else {
					resourceDelegate = new DefaultFolderDelegate(parent.getSourceFolder(),parent,name);
				}
				List children = zipProvider.getChildren(element);
				itereteResources((IFolderDelegate) resourceDelegate,children,false,monitor);
			} else {
				InputStream inputStream = zipProvider.getContents(element);
				resourceDelegate = new DefaultFileDelegate(parent,name);
				byte[] bytes;
				try {
					bytes = IOUtils.toByteArray(inputStream);
					inputStream = new ByteArrayInputStream(bytes);
					((DefaultFileDelegate)resourceDelegate).setContents(inputStream);
				} catch (IOException e) {
				}
			}
			resourceDelegate.setModel(element);
			((DefaultFolderDelegate)parent).addChild(resourceDelegate);
		}
	}
	/**
	 * ����һ��EOS��Ŀ��<BR>
	 *
	 * @param project
	 */
	public void addProject(IProjectDelegate project) {
		if (null != project) {
			this.projects.add(project);
			this.projectMap.put(project.getName(), project);
		}
	}

	/**
	 * ɾ��һ��EOS��Ŀ��<BR>
	 *
	 * @param project
	 */
	public void removeProject(IProjectDelegate project) {
		if (null != project) {
			this.projects.remove(project);
			this.projectMap.remove(project.getName());
		}
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IRootDelegate#getProject(java.lang.String)
	 */
	public IProjectDelegate getProject(String name) {
		return (IProjectDelegate) this.projectMap.get(name);
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.AbstractArchiveResourceDelegate#getRoot()
	 */
	@Override
	public IRootDelegate getRoot() throws ResourceException {
		return this;
	}
	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IRootDelegate#getProjects()
	 */
	public IProjectDelegate[] getProjects() {
		IProjectDelegate[] results = new IProjectDelegate[this.projects.size()];
		this.projects.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate[] getEOSProjects() {
		return this.getProjects();
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.DefaultResourceDelegate#getFullPath()
	 */
	@Override
	public String getFullPath() throws ResourceException {
		return Path.ROOT.toString();
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.DefaultResourceDelegate#getFile()
	 */
	@Override
	public File getFile() {
		return this.archiveFile;
	}
	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.java.JavaFolderDelegate#getType()
	 */
	public int getType() throws ResourceException {
		return ROOT;
	}
	/**
	 * 
	 *
	 */
	public void close(){
		if(this.zipProvider != null){
			this.zipProvider.closeArchive();
		}
	}
}
