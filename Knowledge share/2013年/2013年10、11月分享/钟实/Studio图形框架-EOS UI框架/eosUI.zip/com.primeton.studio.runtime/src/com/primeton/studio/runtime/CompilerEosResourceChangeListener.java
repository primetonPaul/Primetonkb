/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/CompilerEosResourceChangeListener.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Jul 31, 2008
 *******************************************************************************/


package com.primeton.studio.runtime;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.runtime.CoreException;

import com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceManager;

/**
 * ��Ҫ��Ϊbin��eosdebug�µ�������Դ����resource.setDerived(true);��ʶΪ������ļ�
 *
 * @author hongsq (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: CompilerEosResourceChangeListener.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/08/01 08:51:06  yanfei
 * Update:CompilerEosResourceChangeListenert�ع�����Ϊԭ��д�ò��ԣ���Զ��������±�־�ķ�����
 *
 * Revision 1.1  2008/07/31 09:41:20  yanfei
 * Update:���ֱ������ļ�����ȫ������
 * resource.setDerived(true)
 * ��������һ��resourcechangeListener���д�����
 *
 */
public class CompilerEosResourceChangeListener implements IResourceChangeListener {

	private final static CompilerEosResourceChangeListener instance = new CompilerEosResourceChangeListener();

	/**
	 * ������
	 */
	private CompilerEosResourceChangeListener() {
		super();
	}

	public static CompilerEosResourceChangeListener getInstance(){
		return instance;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.core.resources.IResourceChangeListener#resourceChanged(org.eclipse.core.resources.IResourceChangeEvent)
	 */
	public void resourceChanged(IResourceChangeEvent event) {
		if(event.getType() != IResourceChangeEvent.POST_CHANGE)
			return;

		IResourceDelta rootDelta = event.getDelta();
		if (null == rootDelta) {
			return;
		}

		IResourceDeltaVisitor visitor = new IResourceDeltaVisitor() {
			public boolean visit(IResourceDelta delta) {
				//only interested in changed, removed resources
				//����ֻ��ע��������Դ
				if (/*delta.getKind()!=IResourceDelta.CHANGED && delta.getKind()!=IResourceDelta.REMOVED && */delta.getKind() != IResourceDelta.ADDED)
					return true;
				//only interested in file resource
				IResource resource = delta.getResource();

				updateResourceCompilerFlags(resource);
				return true;
			}
		};
		try {
			rootDelta.accept(visitor);
		} catch (CoreException e) {
			//open error dialog with syncExec or print to plugin log file
		}
	}

	/**
	 * ���±����ı�ʶ
	 * @param resource
	 */
	private void updateResourceCompilerFlags(IResource resource){
		try {
			if(enableUpdateFlags(resource)){
				if(resource.isDerived() == false)
					resource.setDerived(true);

				if (resource instanceof IContainer) {
					IContainer container = (IContainer) resource;
					IResource[] members = container.members();
					for (IResource member : members) {
						updateResourceCompilerFlags(member);
					}
				}
			}
		} catch (CoreException e) {
			e.printStackTrace();
		}
	}

	private boolean enableUpdateFlags(IResource resource){
		IFolder binFolder = EclipseResourceManager.getOutputFolder(resource);

		//bin�µ���ԴҪ����
		if(null != binFolder && binFolder.exists()){
			if(binFolder.equals(resource) || binFolder.getFullPath().isPrefixOf(resource.getFullPath())){
				return true;
			}
		}

		//src�µ���Դ������
		IFolder srcFolder = EclipseResourceManager.getSourceFolder(resource);
		if(null != srcFolder && srcFolder.exists()){
			if(srcFolder.equals(resource) || srcFolder.getFullPath().isPrefixOf(resource.getFullPath())){
				return false;
			}
		}

		//debug�µ���ԴҪ����
		IFolder debugFolder = null;
		if(null != srcFolder){
			IContainer parentContainer = srcFolder.getParent();
			if (parentContainer.getType() == IResource.FOLDER) {
				IFolder parentFolder = (IFolder) parentContainer;

				debugFolder = parentFolder.getFolder(RuntimeConstant.DEBUG);
			}
		}
		if(null != debugFolder && debugFolder.exists()){
			if(debugFolder.equals(resource) || debugFolder.getFullPath().isPrefixOf(resource.getFullPath())){
				return true;
			}
		}

		return false;
	}
}
