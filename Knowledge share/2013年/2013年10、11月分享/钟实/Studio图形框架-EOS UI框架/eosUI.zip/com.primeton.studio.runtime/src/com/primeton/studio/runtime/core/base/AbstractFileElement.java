/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.base;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * �����ļ���Դ�Ľ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractFileElement.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/06/21 14:07:23  wanglei
 * Review:ȥ������Ҫ��import��
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public abstract class AbstractFileElement extends AbstractEosElement {

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param file
	 * @param parent
	 */
	public AbstractFileElement(IFileDelegate file, IEosElement parent) {
		super(file, parent);
	}

	/**
	 * @return �����ļ���Դ������ǿ��ת�͡�<BR>
	 */
	public IFileDelegate getFile() {
		return (IFileDelegate) this.getResource();
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getAdapter(Class adapter) {

		if (IFileDelegate.class == adapter) {
			return this.getResource();
		}

		return super.getAdapter(adapter);
	}
}
