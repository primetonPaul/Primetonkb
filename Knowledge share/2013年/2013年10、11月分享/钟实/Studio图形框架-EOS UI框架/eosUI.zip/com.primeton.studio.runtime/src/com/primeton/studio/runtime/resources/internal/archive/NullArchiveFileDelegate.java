/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.archive;

import java.io.InputStream;

import org.apache.commons.io.FilenameUtils;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * Ϊ�˷�ֹ����Ҫ��NPE������д������࣬�����������ⷵ��ֵΪnull�����⡣<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: NullArchiveFileDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/07/05 06:57:43  wanglei
 * �ύ��CVS��
 *
 */

public class NullArchiveFileDelegate extends ArchiveFileDelegate implements IFileDelegate {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param rootFile
	 * @param path
	 */
	protected NullArchiveFileDelegate(ArchiveRootFileDelegate rootFile, String path) {
		super(rootFile, path);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean exists() throws ResourceException {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getType() throws ResourceException {
		return FILE;
	}

	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		if (null != this.getPath()) {
			return this.getPath();
		}
		else {
			return super.toString();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void create(InputStream inputStream) {
		throw new UnsupportedOperationException("The operation of 'create' is not supported yet.");

	}

	/**
	 * {@inheritDoc}
	 */
	public InputStream getContents() throws ResourceException {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getExtension() {
		return FilenameUtils.getExtension(this.getName());
	}

	/**
	 * {@inheritDoc}
	 */
	public void setContents(InputStream inputStream) {
		throw new UnsupportedOperationException("The operation of 'setContents' is not supported yet.");
	}
}
