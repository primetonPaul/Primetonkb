/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.workbench.ui/src/com/primeton/studio/workbench/ui/IModelChangeListener.java,v
 * 1.1 2006/12/31 09:50:51 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 * 
 * ==============================================================================
 * 
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 * 
 * Created on 2006-12-31
 **********************************************************************************************************************/

package com.primeton.studio.runtime.model;

/**
 * ģ�͸ı�ļ����ߡ�<BR>
 * 
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 * 
 * $Log: IModelChangeListener.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/05 11:32:13  wanglei
 * �ύ��CVS
 *
 * 
 */

public interface IModelChangeListener {
	/**
	 * ģ�͸ı��֪ͨ��<BR>
	 * 
	 * @param event
	 */
	public void modelChanged(ModelChangeEvent event);
}
