/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/DefaultHtmlDocProvider.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-5-5
 *******************************************************************************/


package com.primeton.studio.runtime.model.internal;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.model.base.AbstractModelDocumentProvider;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultHtmlDocProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.5  2009/05/13 07:30:13  lvyuan
 * Update:�ع�EDOC�����ɷ�ʽ
 *
 * Revision 1.4  2009/05/13 02:49:30  lvyuan
 * Update:�˿�Ĵ����NameSpaceUtil���������NameSpaceUtil������JDT�Ķ��� ����������е�ECD�ڼ��ɱ����ʱ����Ҫ�޸Ľű������������������
 *
 * Revision 1.3  2009/05/13 01:03:06  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.2  2009/05/06 06:30:10  lvyuan
 * Update:�ع�EDOC���ɿ��
 * 
 */
public abstract class DefaultHtmlDocProvider extends AbstractModelDocumentProvider implements HtmlToolTipProvider{ 
	/**
	 * ��ȡelement����
	 * @param element
	 * @return
	 */
	public String getHtml(IEosElement element){
		// TODO Fix Me��������ͨ��ע��Adapter�ķ�ʽ
		return HtmlDocProvide.getHtmlDoc(element);
	}

	/**
	 * {@inheritDoc}
	 */
	public Map createDocument(IEosModel model) {
		IEosElement[] eosElements = model.getChildren();
		if (ArrayUtils.isEmpty(eosElements)) {
			return null;
		}
		IFileDelegate fileDelegate = (IFileDelegate) model.getResource();
		String path = fileDelegate.getSourceRelativePath();
		path = FilenameUtil.toPackageWithoutExtension(path);
		if(path == null || "".equals(path.trim())){ //$NON-NLS-1$
			return null;
		}
		return configDocMap(model);
	}
	
	/**
	 * @param model
	 * @return
	 */
	protected Map configDocMap(IEosElement model){
		Map map = new HashMap(10);
		String javaDoc = this.getHtml(model);
		if (javaDoc != null) {
			map.put(this.getKey(model), javaDoc);
		}
		Object[] methods = model.getChildrenOfType(getChildType()).toArray();
		if (!ArrayUtils.isEmpty(methods)) {
			for (int i = 0; i < methods.length; i++) {
				IEosElement method = (IEosElement) methods[i];
				javaDoc = this.getHtml(method);
				if (javaDoc != null) {
					map.put(this.getKey(method), javaDoc);
				}
			}
		}
		return map;
	}
	
	/**
	 * ���㸸�ӹ�ϵ��ʾ��<BR>
	 * 
	 * @return
	 */
	public abstract int getChildType();
}
