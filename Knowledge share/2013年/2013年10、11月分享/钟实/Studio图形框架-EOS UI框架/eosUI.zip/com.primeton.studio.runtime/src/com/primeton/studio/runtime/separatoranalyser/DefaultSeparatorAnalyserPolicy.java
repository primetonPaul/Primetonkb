/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/DefaultSeparatorAnalyserPolicy.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser;


/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultSeparatorAnalyserPolicy.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:45  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class DefaultSeparatorAnalyserPolicy implements ISeparatorAnalyserPolicy {
	private IComplexSeparatorAnalyser analyser;
	/**
	 * 
	 */
	public DefaultSeparatorAnalyserPolicy() {
		super();
	}
	/**
	 * 
	 * @param analyser
	 */
	public DefaultSeparatorAnalyserPolicy(IComplexSeparatorAnalyser analyser) {
		this();
		this.analyser = analyser;
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.ISeparatorAnalyserPolicy#getSeparatorAnalyzer(com.primeton.studio.runtime.helper.SeparatorModel)
	 */
	public IComplexSeparatorAnalyser getSeparatorAnalyzer(SeparatorModel model) {
		return this.analyser;
	}
	/**
	 * @return Returns the analyser.
	 */
	public IComplexSeparatorAnalyser getAnalyser() {
		return analyser;
	}
	/**
	 * @param analyser The analyser to set.
	 */
	public void setAnalyser(IComplexSeparatorAnalyser analyser) {
		this.analyser = analyser;
	}

}
