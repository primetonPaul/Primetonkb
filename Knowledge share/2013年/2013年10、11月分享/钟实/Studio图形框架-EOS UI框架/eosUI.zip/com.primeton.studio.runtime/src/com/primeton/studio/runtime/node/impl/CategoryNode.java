/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.node.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.OrderConstant;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.node.base.AbstractVirtualNode;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ��������ҵ��ؼ���ģ����Ϣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: CategoryNode.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2008/06/04 05:22:16  wanglei
 * Update:������Դ��ͼ��
 *
 * Revision 1.3  2008/05/29 10:06:27  wanglei
 * Update:������Դ��ͼ�Ľṹ��
 *
 * Revision 1.2  2008/05/29 05:13:53  wanglei
 * Update:��ȡ��������OrderConstant�С�
 *
 * Revision 1.1  2008/03/19 05:05:44  wanglei
 * Review:�������,��ģ�͵����ݴ�navigator����г�ȡ��runtime����С�
 *
 * Revision 1.6  2008/03/19 03:09:49  wanglei
 * Review:��ԭ��д��Nodeϵ�������е�IWorkbenchAdapter��ȡ����չ�㣬����ǿ������
 *
 * Revision 1.5  2008/01/10 07:50:02  wanglei
 * Review:ģ�͵�����,���µ���getParent���ƣ��Ա�֤ʵ��Link��
 *
 * Revision 1.4  2008/01/09 05:54:14  wanglei
 * Update:����������
 *
 * Revision 1.3  2007/06/30 13:11:03  wanglei
 * Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.2  2007/06/28 09:46:13  wanglei
 * Review:�������캯������֧�����ÿ⡣
 *
 * Revision 1.1  2007/05/24 08:29:41  wanglei
 * �ύ��CVS��
 *
 *
 */
public class CategoryNode extends AbstractVirtualNode {

	public static final String COMPOSITE_CATEGORY = "com.primeton.component.composite.category";

	private String category;

	private IContribution contribution;

	private static final Map orderMap = new HashMap();

	static {
		orderMap.put(RuntimeConstant.SERVICE, new Integer(OrderConstant.ORDER_CATEGORY_SERVICE));
		orderMap.put(RuntimeConstant.DATA, new Integer(OrderConstant.ORDER_CATEGORY_DATA));
		orderMap.put(RuntimeConstant.PROCESS, new Integer(OrderConstant.ORDER_CATEGORY_PROCESS));
		orderMap.put(RuntimeConstant.VIEW, new Integer(OrderConstant.ORDER_CATEGORY_VIEW));
		orderMap.put(RuntimeConstant.BIZLET, new Integer(OrderConstant.ORDER_CATEGORY_BIZLET));
	}

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param resource
	 * @param contribution
	 * @param category
	 */
	public CategoryNode(IResourceDelegate resource, IContribution contribution, String category) {
		super(resource);
		this.category = category;
		this.contribution = contribution;

		Integer order = (Integer) orderMap.get(category);
		if (null == order) {
			this.setOrder(OrderConstant.ORDER_CATEGORY);
		} else {
			this.setOrder(order.intValue());
		}

	}

	/**
	 * {@inheritDoc}
	 */
	public String getType() {
		return COMPOSITE_CATEGORY;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return this.category;
	}

	/**
	 * @return the contribution
	 */
	public IContribution getContribution() {
		return this.contribution;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + ((this.category == null) ? 0 : this.category.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {

		if (!super.equals(obj)) {
			return false;
		}
		final CategoryNode other = (CategoryNode) obj;
		boolean result = StringUtils.equals(this.category, other.category);
		return result;
	}

}
