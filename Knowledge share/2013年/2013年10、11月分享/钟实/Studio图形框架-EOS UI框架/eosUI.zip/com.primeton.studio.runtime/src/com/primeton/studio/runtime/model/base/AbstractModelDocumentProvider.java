/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.base;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.primeton.studio.core.util.LocaleUtil;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IDocument;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.model.IModelDocumentProvider;
import com.primeton.studio.runtime.model.IModelFactory;
import com.primeton.studio.runtime.model.internal.DefaultDocument;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.thoughtworks.xstream.XStream;

/**
 * IModelDocumentProvider�Ļ��࣬ʹ��XStream������ת����XML��ʽ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractModelDocumentProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.8  2009/10/12 07:22:47  hongsq
 * BUG:19932
 * �����������⡿����ʵ����ʾ���ƹ��ʻ�����
 *
 * Revision 1.7  2009/09/21 11:46:30  chenty
 * BUG��20447
 * �������е�XSDʹ����ʾ������ʾ����ȷ.
 *
 * Revision 1.6  2009/09/16 09:53:58  lvyuan
 * BugFix:fix bug 21420
 *
 * Revision 1.5  2009/06/17 06:54:25  chenty
 * update: fixbug 18901 ������������ʾ���Ʋ���ȷ by Chenty
 *
 * Revision 1.4  2009/06/15 07:25:05  lvyuan
 * BugFix:xstream��������Ĳ���
 *
 * Revision 1.3  2009/04/17 01:21:49  wanglei
 * Update:ʵ����createDocumentFile������
 *
 * Revision 1.2  2008/07/15 09:19:55  hongsq
 * Update:�ع��Զ����(jira����EOS-1654)
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/04/14 12:43:31  wanglei
 * Add:����getDocumentFile������
 *
 * Revision 1.2  2008/04/14 11:54:33  wanglei
 * Update:������Դ���ҷ�ʽ��
 *
 * Revision 1.1  2008/04/11 08:27:38  wanglei
 * Add:�ύ��CVS��
 *
 */

public abstract class AbstractModelDocumentProvider implements IModelDocumentProvider {

	protected static final XStream xstream = new XStream();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractModelDocumentProvider() {
		super();
	}

	/**
	 * �õ���ֵ��<BR>
	 *
	 * @param element
	 * @return
	 */
	public abstract String getKey(IEosElement element);

	/**
	 * {@inheritDoc}
	 */
	public IDocument getDocument(IEosElement element) {
		IResourceDelegate resource = element.getResource();

		if (resource.getType() != IResourceDelegate.FILE) {
			return null;
		}

		IFileDelegate fileDelegate = (IFileDelegate) resource;
		IFileDelegate docFile = RuntimeHelper.getDocumentFile(fileDelegate);

		if (ResourceHelper.isValidResource(docFile)) {

			InputStream inputStream = null;
			InputStreamReader inputStreamReader = null;
			try {
				inputStream = docFile.getContents();
				//by Chenty. ��ָ������,����������쳣.
				inputStreamReader = new InputStreamReader(inputStream,Charset.forName("UTF-8"));
				Map map = (Map) xstream.fromXML(inputStreamReader);

				String key = this.getKey(element);
				String content = (String) map.get(key);
				if (null == content) {
					content = matchDisplayName(key, map);
					if (null == content){
						content = getDefaultContent(element);
					}
				}
				
				return new DefaultDocument(content);

			} catch (Exception e) {
				return new DefaultDocument(element.getDescription());
			} finally {
				IOUtils.closeQuietly(inputStreamReader);
				IOUtils.closeQuietly(inputStream);
			}

		} else {
			return null;
		}
	}

	/**
	 * @param element
	 * @return
	 */
	protected String getDefaultContent(IEosElement element) {
		return element.getDescription();
	}

	/**
	 * ��ʱ���� add by gemchen
	 * ��map���ȡbizlet�ڵ�Ĺ��ʻ�����.
	 * ����:ServiceUtil [������ò�����]
	 * @param name
	 * @param map
	 * @return
	 */
	private String matchDisplayName(String name,Map map){
		Pattern pattern = Pattern.compile(name+"\\s\\[.*\\]");
		for (Object key : map.keySet()) {
			Matcher matcher = pattern.matcher(key.toString());
			boolean matchFound = matcher.find();
			if (matchFound) {
				return matcher.group(0);
			}
		}
		return null;
	}
	
	public IFileDelegate createDocumentFile(IEosModel model) {
		if (model == null) {
			return null;
		}

		IFileDelegate fileDelegate = (IFileDelegate) model.getResource();

		String fileName = FilenameUtils.getBaseName(fileDelegate.getName());
		String extension = this.getExtension(fileDelegate);
		if (StringUtils.isEmpty(extension)) {
			return null;
		}

		String docFileName = LocaleUtil.getResourceName((Locale) null, fileName,extension);
		IFileDelegate docFile = fileDelegate.getParent().getFile(docFileName);

		if (null == fileDelegate.getSourceFolder()) {
			return null;
		} else {
			docFile = ResourceHelper.getOutputFile(docFile, extension+"."+RuntimeConstant.EOS_DOCUMENT);
		}
		return docFile;
	}

	protected String getExtension(IFileDelegate fileDelegate) {
		IModelFactory modelFactory = RuntimeManager.getModelManager().getModelFactory(fileDelegate);
		if (null == modelFactory) {
			return null;
		}

		return modelFactory.getBinaryName();
	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate getDocumentFile(IEosModel model) {
		if (model == null) {
			return null;
		}
		IFileDelegate fileDelegate = (IFileDelegate) model.getResource();

		IFileDelegate docFile = doGetFile(fileDelegate, Locale.getDefault());
		if (ResourceHelper.isValidResource(docFile)) {
			return docFile;
		}

		return doGetFile(fileDelegate, null);
	}

	private IFileDelegate doGetFile(IFileDelegate fileDelegate, Locale locale) {
		String fileName = FilenameUtils.getBaseName(fileDelegate.getName());
		String docFileName = LocaleUtil.getResourceName(locale, fileName, fileDelegate.getExtension());
		IFileDelegate docFile = fileDelegate.getParent().getFile(docFileName);

		docFile = docFile.getParent().getFile(docFileName + "." + RuntimeConstant.EOS_DOCUMENT);
		return docFile;
	}
}
