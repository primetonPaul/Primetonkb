/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/project/FullBuildOrder.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-12-29
 *******************************************************************************/


package com.primeton.studio.runtime.project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;

import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseFolderDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseProjectDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceManager;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * ����˳��������
 * ˵��:�벻Ҫ����޸�,��Ӱ��ģ�͸��õ�������
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: FullBuildOrder.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/09/02 05:27:30  hongsq
 * Update:����ʱ�����������ڵ�ԴĿ¼
 *
 * Revision 1.1  2009/01/04 03:36:31  zhuxing
 * Update:EOS Studio�ڶ��������Ż�
 *
 */
public class FullBuildOrder {
	//�Ƚ���
	private static final Comparator<IFolder> CONTRIBUTION_COMPARATOR = new Comparator<IFolder>() {
		public int compare(IFolder folder1, IFolder folder2) {
			IContribution contribution1 = RuntimeManager.createContribution(new EclipseFolderDelegate(folder1));
			IContribution contribution2 = RuntimeManager.createContribution(new EclipseFolderDelegate(folder2));

			if (contribution1 == null || contribution2 == null)
				return 0;

			if (ContributionUtil.isContributionAReferenceContributionB(contribution1, contribution2))
				return -1;

			return 0;
		}
	};

	private IProject project;
	private Map<IFolder, Object> builtFolders = new HashMap<IFolder, Object>();

	public FullBuildOrder(IProject project) {
		this.project = project;
	}

	public IFolder[] getSourceFolders() {
		try {
			//�����ڵĲ���Ҫ���룬Ҳ�޷�����
			IFolder[] sourceFolders = EclipseResourceManager.getSourceFolders(this.project, true);

			//����
			Arrays.sort(sourceFolders, CONTRIBUTION_COMPARATOR);

			List list = Arrays.asList(sourceFolders);
			Collections.reverse(list);
			return (IFolder[])list.toArray(new IFolder[list.size()]);
		} catch (Exception e) {
			return new IFolder[0];
		}
	}

	/**
	 * �жϵ�ǰԴ���ļ����Ƿ��Ѿ��������
	 *
	 * @param sourceFolder
	 * @return
	 */
	public boolean hasBuilt(IFolder sourceFolder) {
		return this.builtFolders.containsKey(sourceFolder);
	}

	/**
	 * �趨�ض��ļ��б���״̬
	 *
	 * @param sourceFolder
	 */
	public void setBuilt(IFolder sourceFolder) {
		this.builtFolders.put(sourceFolder, null);
	}

	/**
	 * ��ȡ�ض�Դ��Ŀ¼������������Ӧ��Դ��Ŀ¼
	 *
	 * @param folder
	 * @return
	 */
	public IFolder[] getRequiredSourceFolders(IFolder folder) {
		IProjectDelegate projectDelegate = new EclipseProjectDelegate(folder.getProject());
		IContribution contribution = RuntimeManager.createContribution(new EclipseFolderDelegate(folder));
		if (contribution == null)
			return new IFolder[0];

		String[] requiredBundles = contribution.getRequiredBundles();
		IContribution[] contributions = RuntimeManager.findContributions(projectDelegate, requiredBundles, false);

		List<IFolder> requiredFolders = new ArrayList<IFolder>();
		for (int i = 0; i < contributions.length; i++) {
			ISourceFolderDelegate[] sourceFolderDelegates = ResourceHelper.getSourceFolders(contributions[i].getFolder());
			for (int j = 0; j < sourceFolderDelegates.length; j++) {
				requiredFolders.add((IFolder)sourceFolderDelegates[j].getAdapter(IFolder.class));
			}
		}

		IFolder[] folders = requiredFolders.toArray(new IFolder[requiredFolders.size()]);
		if (folders.length < 2)
			return folders;
		else {
			//����
			Arrays.sort(folders, CONTRIBUTION_COMPARATOR);
			return folders;
		}
	}
}
