/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/eclipse/EclipseResourceAdapterFactory.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-31
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.eclipse;

import java.io.File;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IAdapterFactory;

import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ���Խ�EclipseResourceDelegateת����Ҫ�����͡�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EclipseResourceAdapterFactory.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/04/18 08:39:04  wanglei
 * Update:��ɸ���Ĺ��ܡ�
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */


public class EclipseResourceAdapterFactory implements IAdapterFactory {

	private static final Class[] classes = new Class[] { File.class, IResource.class, IFolder.class, IContainer.class, IProject.class };

	/**
	 * Ĭ�Ϲ��캯��
	 */
	public EclipseResourceAdapterFactory() {
		super();

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.runtime.IAdapterFactory#getAdapter(java.lang.Object, java.lang.Class)
	 */
	public Object getAdapter(Object adaptableObject, Class adapterType) {

		if (adaptableObject instanceof IResourceDelegate) {
			IResourceDelegate delegate = (IResourceDelegate) adaptableObject;

			if (File.class == adapterType) {
				return delegate.getFile();
			}
			else {
				return delegate.getAdapter(adapterType);
			}
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.runtime.IAdapterFactory#getAdapterList()
	 */
	public Class[] getAdapterList() {
		return classes;
	}

}
