/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/internal/EntityFieldSeparatorPolicy.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.internal;

import com.primeton.studio.runtime.EntityConstant;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.separatoranalyser.SeparatorModel;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EntityFieldSeparatorPolicy.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:46  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.2  2008/05/23 01:36:29  yangmd
 * Update:������ʵ��������⴦��
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class EntityFieldSeparatorPolicy extends JavaFieldSeparatorPolicy{
	/**
	 * 
	 * @param project
	 * @param separator
	 */
	public EntityFieldSeparatorPolicy(IProjectDelegate project, String separator) {
		super(project,separator);
	}
	/* (non-Javadoc)
	 * @see com.primeton.studio.biz.core.other.JavaFieldSeparatorPolicy#filteField(com.primeton.studio.runtime.helper.SeparatorModel, com.primeton.studio.runtime.core.IField)
	 */
	@Override
	protected boolean filteField(SeparatorModel separatorModel, IField field) {
		IType type = field.getDeclaringType();
		boolean isJava = RuntimeConstant.JAVA.equals(field.getImplementationType());
		if(!isJava && type != null)isJava = RuntimeConstant.JAVA.equals(type.getImplementationType());
		if(isJava){
			return super.filteField(separatorModel, field);			
		} else {			
			String extension = field.getExtension(EntityConstant.PROPERTY_CODE_ASSIST);
			if(extension != null && !Boolean.valueOf(extension)){
				return false;
			} else {
				return true;
			}
		}
	}



}
