/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/project/EOSProjectServerValidator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Oct 21, 2010
 *******************************************************************************/


package com.primeton.studio.runtime.project;

import java.io.File;
import java.text.MessageFormat;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.RuntimeMessages;
import com.primeton.studio.runtime.RuntimePlugin;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseProjectDelegate;
import com.primeton.studio.runtime.web.WebAppLocationParserManager;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author guwei (mailto:guwei@primeton.com)
 */
public class EOSProjectServerValidator implements IProjectValidator {

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.project.IProjectValidator#isSupport(org.eclipse.core.resources.IProject)
	 */
	public boolean isSupport(IProject project) {
//		eos��Ŀ��Ҫͳһ��Ŀ���ͱ�ʶ
		if(RuntimeHelper.isEOSProject(new EclipseProjectDelegate(project))){
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.project.IProjectValidator#validate(com.primeton.studio.runtime.project.ProjectValidationResult)
	 */
	public boolean validate(ProjectValidationResult result) {
		IProject project = result.getProject();
		result.setType(RuntimeConstant.MARKER_PROJECT_WEBAPP);
		result.setPriority(IMarker.PRIORITY_HIGH);

		try {
			project.deleteMarkers(RuntimeConstant.MARKER_PROJECT_WEBAPP, false,
					IResource.DEPTH_ZERO);

			IEOSProject eosProject = RuntimePlugin.getEOSProject(project);

			if (eosProject.getServer() == null
					|| eosProject.getServer().trim().equals("")) { //$NON-NLS-1$
				String message = MessageFormat.format(
						RuntimeMessages.PROJECT_HAS_NOT_SET_WEB_SERVICE,
						project.getName());
				result.setMessage(message);
				result.setServerity(IMarker.SEVERITY_WARNING);
				return false;
			}

			String webAppName = eosProject.getApplication();
			if (StringUtils.isEmpty(webAppName)) {
				String message = MessageFormat.format(
						RuntimeMessages.PROJECT_HAS_NOT_SET_SERVICE, project
								.getName());
				result.setMessage(message);
				result.setServerity(IMarker.SEVERITY_WARNING);
				return false;
			}
//			���Ӧ�õ���Ч��
			IPath webAppLocation = WebAppLocationParserManager.getWebAppLocation(project);
			if (webAppLocation != null) {
				File webXmlFile = webAppLocation.append("/WEB-INF/web.xml").toFile(); //$NON-NLS-1$
				if (webXmlFile.exists()) {
					return true;
				} else {
					String message = MessageFormat.format(RuntimeMessages.THE_WEB_SERVICE_FOR_PROJECT_IS_ILLEGAL, project.getName(), webAppName);
					result.setMessage(message);
					result.setServerity(IMarker.SEVERITY_ERROR);
					return false;
				}
			} else {
				String message = MessageFormat.format(RuntimeMessages.THE_WEB_SERVICE_FOR_PROJECT_IS_NOT_EXIST, project.getName(), webAppName);
				result.setMessage(message);
				result.setServerity(IMarker.SEVERITY_ERROR);
				return false;
			}
		} catch (CoreException e) {
			ExceptionUtil.getInstance().logException(e);
			return false;
		}
	}

}

/*
 * �޸���ʷ
 * $Log: EOSProjectServerValidator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/10/21 08:47:07  guwei
 * JIRA: EOSP-324 ����Ŀ����֤��Ҫ�ṩ��չ��
 *
 */