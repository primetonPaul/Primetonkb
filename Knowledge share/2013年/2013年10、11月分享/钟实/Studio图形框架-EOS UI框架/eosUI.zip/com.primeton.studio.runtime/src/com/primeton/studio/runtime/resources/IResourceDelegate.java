/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/IResourceDelegate.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:53 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-25
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources;

import java.io.File;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.QualifiedName;

import com.primeton.studio.core.IDataContainer;
import com.primeton.studio.runtime.exception.ResourceException;

/**
 * ����ΪJDK��IO���Eclipse���ṩͳһ����Դ�����ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IResourceDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.12  2008/04/14 03:32:00  wanglei
 * Update:���ӶԳ־û����Ե�֧�֡�
 *
 * Revision 1.11  2008/02/18 07:54:32  wanglei
 * Update:ʵ����IDataContainer�ӿڡ�
 *
 * Revision 1.10  2007/11/01 06:45:11  wanglei
 * Review:������isArchive,isEditable,isBinary������
 *
 * Revision 1.9  2007/09/10 01:12:05  wanglei
 * Review:����ע�͡�
 *
 * Revision 1.8  2007/07/24 09:25:35  wanglei
 * Add:����NO_SOURCE_FOLDERS������
 *
 * Revision 1.7  2007/06/28 09:26:37  wanglei
 * Review:����getData��setData������
 *
 * Revision 1.6  2007/06/22 13:04:21  wanglei
 * Review:����Empty�����ʱ��Ӧ�ø���ȷһЩ��
 *
 * Revision 1.5  2007/05/30 08:58:22  wanglei
 * Refactor:��ΪIResourceDelegate��getSource�ع���getSourceFolder��
 *
 * Revision 1.4  2007/05/25 05:54:48  wanglei
 * Add:����һ���µĳ�����
 *
 * Revision 1.3  2007/04/17 09:56:22  wanglei
 * Refactor:��getFile���Ƶ�IResourceDelegate�С�
 *
 * Revision 1.2  2007/03/30 02:18:57  wanglei
 * Remove:ȥ����Ԫ���ݷ�����
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */
public interface IResourceDelegate extends IAdaptable, IDataContainer {

	public static final IResourceDelegate[] NO_RESOURCES = new IResourceDelegate[0];

	public static final IProjectDelegate[] NO_PROJECTS = new IProjectDelegate[0];

	public static final IFileDelegate[] NO_FILES = new IFileDelegate[0];

	public static final IFolderDelegate[] NO_FOLDERS = new IFolderDelegate[0];

	public static final ISourceFolderDelegate[] NO_SOURCE_FOLDERS = new ISourceFolderDelegate[0];

	public static final IOutputFolderDelegate[] NO_OUTPUT_FOLDERS = new IOutputFolderDelegate[0];

	/**
	 * Type constant (bit mask value 1) which identifies file resources.
	 *
	 * @see IResourceDelegate#getType()
	 * @see IFileDelegate
	 */
	public static final int FILE = 0x1;

	/**
	 * Type constant (bit mask value 2) which identifies folder resources.
	 *
	 * @see IResourceDelegate#getType()
	 * @see IFolderDelegate
	 */
	public static final int FOLDER = 0x2;

	/**
	 * Type constant (bit mask value 4) which identifies project resources.
	 *
	 * @see IResourceDelegate#getType()
	 * @see IProjectDelegate
	 */
	public static final int PROJECT = 0x4;

	/**
	 * Type constant (bit mask value 8) which identifies the root resource.
	 *
	 * @see IResourceDelegate#getType()
	 * @see IRootDelegate
	 */
	public static final int ROOT = 0x8;

	/**
	 * Returns the type of this resource. The returned value will be one of <code>FILE</code>, <code>FOLDER</code>,
	 * <code>PROJECT</code>, <code>ROOT</code>.
	 * <p>
	 * <ul>
	 * <li> All resources of type <code>FILE</code> implement <code>IFile</code>.</li>
	 * <li> All resources of type <code>FOLDER</code> implement <code>IFolder</code>.</li>
	 * <li> All resources of type <code>PROJECT</code> implement <code>IProject</code>.</li>
	 * <li> All resources of type <code>ROOT</code> implement <code>IWorkspaceRoot</code>.</li>
	 * </ul>
	 * </p>
	 * <p>
	 * This is a resource handle operation; the resource need not exist in the workspace.
	 * </p>
	 *
	 * the type of this resource
	 *
	 * @see #FILE
	 * @see #FOLDER
	 * @see #PROJECT
	 * @see #ROOT
	 *
	 * @throws ResourceException
	 */
	public int getType() throws ResourceException;

	/**
	 *
	 * @return ���ص�ǰ��Դ���ڵ���Ŀ��<BR>
	 *
	 * @throws ResourceException
	 */
	public IProjectDelegate getProject() throws ResourceException;

	/**
	 *
	 * @return ���ص�ǰ��Դ���ڵĸ�Ŀ¼��<BR>
	 *
	 * @throws ResourceException
	 */
	public IFolderDelegate getParent() throws ResourceException;

	/**
	 * @return �õ�Դ����Ŀ¼��<BR>
	 *         �п��ܷ��� <code>null</code>��<BR>
	 *         �������null���п�������ʵ���ļ������ڣ�Ҳ�п����Ǹ��ļ�����Դ����Ŀ¼�¡�<BR>
	 *
	 * @throws ResourceException
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException;

	/**
	 * ������Դ�Ƿ���ڡ�<BR>
	 *
	 * Return whether the resource exists or not.<BR>
	 *
	 * @throws ResourceException
	 *
	 * @return <BR>
	 */
	public boolean exists() throws ResourceException;

	/**
	 * �������ơ�<BR>
	 *
	 * Return the name.<BR>
	 *
	 * @return
	 *
	 * @throws ResourceException
	 */
	public String getName() throws ResourceException;

	/**
	 * ����ȫ·����<BR>
	 *
	 * Return the full path.<BR>
	 *
	 * @return
	 *
	 * @throws ResourceException
	 */
	public String getFullPath() throws ResourceException;

	/**
	 * @return �����������Ŀ�����·����<BR>
	 *
	 * @throws ResourceException
	 */
	public String getProjectRelativePath() throws ResourceException;

	/**
	 * @return ���������Դ����Ŀ¼�����·����<BR>
	 * @throws ResourceException
	 */
	public String getSourceRelativePath() throws ResourceException;

	/**
	 * ɾ������Դ��<BR>
	 *
	 * Delete the resource.<BR>
	 *
	 * @throws ResourceException
	 */
	public void delete() throws ResourceException;

	/**
	 * @return ���ظ�Ŀ¼��<BR>
	 *
	 * @throws ResourceException
	 */
	public IRootDelegate getRoot() throws ResourceException;

	/**
	 * ������Դ��<BR>
	 * ������ļ����ͣ����ǿհ��ļ���<BR>
	 *
	 * Create a empty resource.<BR>
	 *
	 */
	public void create();

	/**
	 * �õ���Դ����޸�ʱ�䡣<BR>
	 *
	 * Return the last time to be modified.<BR>
	 *
	 * @return
	 */
	public long getLastModified();

	/**
	 * ���ز���ϵͳ���ļ���<BR>
	 *
	 * Return the os file.<BR>
	 *
	 * @return
	 */
	public File getFile();

	/**
	 * �õ��ļ�Э�顣<BR>
	 *
	 * Return the file protocol.<BR>
	 *
	 * @return
	 */
	public String getProtocol();

	/**
	 * �����Ƿ���ѹ���ļ���<BR>
	 *
	 * @return
	 */
	public boolean isArchive();

	/**
	 * �����Ƿ���Ա༭��<BR>
	 *
	 * @return
	 */
	public boolean isEditable();

	/**
	 * �Ƿ��Ǳ������ļ���<BR>
	 *
	 * @return
	 */
	public boolean isBinary();

	/**
	 * Returns the value of the persistent property of this resource identified
	 * by the given key, or <code>null</code> if this resource has no such property.
	 *
	 * @param key the qualified name of the property
	 * @return the string value of the property,
	 *     or <code>null</code> if this resource has no such property
	 * @exception CoreException if this method fails. Reasons include:
	 * <ul>
	 * <li> This resource does not exist.</li>
	 * <li> This resource is not local.</li>
	 * <li> This resource is a project that is not open.</li>
	 * </ul>
	 * @see #setPersistentProperty(QualifiedName, String)
	 */
	public String getPersistentProperty(String key);

	/**
	 * Sets the value of the persistent property of this resource identified
	 * by the given key. If the supplied value is <code>null</code>,
	 * the persistent property is removed from this resource. The change
	 * is made immediately on disk.
	 * <p>
	 * Persistent properties are intended to be used by plug-ins to store
	 * resource-specific information that should be persisted across platform sessions.
	 * The value of a persistent property is a string that must be short -
	 * 2KB or less in length. Unlike session properties, persistent properties are
	 * stored on disk and maintained across workspace shutdown and restart.
	 * </p>
	 * <p>
	 * The qualifier part of the property name must be the unique identifier
	 * of the declaring plug-in (e.g. <code>"com.example.plugin"</code>).
	 * </p>
	 *
	 * @param key the qualified name of the property
	 * @param value the string value of the property,
	 *     or <code>null</code> if the property is to be removed
	 * @exception CoreException if this method fails. Reasons include:
	 * <ul>
	 * <li> This resource does not exist.</li>
	 * <li> This resource is not local.</li>
	 * <li> This resource is a project that is not open.</li>
	 * <li> Resource changes are disallowed during certain types of resource change
	 *       event notification. See <code>IResourceChangeEvent</code> for more details.</li>
	 * </ul>
	 * @see #getPersistentProperty(QualifiedName)
	 * @see #isLocal(int)
	 */
	public void setPersistentProperty(String key, String value);
}
