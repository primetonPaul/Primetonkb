/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/ImportContributionValidator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-10
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.RuntimeConstant;


/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ImportContributionValidator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 * 
 */
public class ImportContributionValidator{
	private IArchiveProvider provider;
	/**
	 * 
	 * @param provider
	 */
	public ImportContributionValidator(IArchiveProvider provider) {
		super();
		this.provider = provider;
	}
	/**
	 * 
	 * @param obj
	 * @return
	 */
	public boolean validate(Object element){
		List children = provider.getChildren(element);
		for (int i = 0; i < children.size(); i++) {
			Object temp = children.get(i);
			String label = provider.getLabel(temp);
			if(RuntimeConstant.EOS_FILE.equals(label)){
				InputStream inputStream = provider.getContents(temp);
				byte[] bytes;
				try {
					bytes = IOUtils.toByteArray(inputStream);
					inputStream = new ByteArrayInputStream(bytes);
					Properties properties = new Properties();
					properties.load(inputStream);
					String type = properties.getProperty(RuntimeConstant.COMPONENT_TYPE);
					return StringUtils.equals(RuntimeConstant.Contribution, type) ||   StringUtils.equals("com.primeton.component.composite", type);
				} catch (IOException e) {
				}
			}
		}
		return false;
	}
}
