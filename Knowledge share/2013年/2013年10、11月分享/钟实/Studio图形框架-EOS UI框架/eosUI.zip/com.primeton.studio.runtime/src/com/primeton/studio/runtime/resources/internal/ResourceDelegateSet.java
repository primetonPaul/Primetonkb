/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal;

import java.util.ArrayList;
import java.util.List;

import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegateSet;

/**
 * IResourceDelegateSet��ʵ����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ResourceDelegateSet.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/06/30 13:11:17  wanglei
 * Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.2  2007/06/21 14:01:01  wanglei
 * Review:����֧��IComposite��
 *
 * Revision 1.1  2007/06/13 01:48:21  wanglei
 * �ύ��CVS��
 *
 */

public class ResourceDelegateSet implements IResourceDelegateSet {

	private List files = new ArrayList();

	private List folders = new ArrayList();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public ResourceDelegateSet() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public Object clone() {
		ResourceDelegateSet set = new ResourceDelegateSet();
		set.files.addAll(this.files);
		set.folders.addAll(this.folders);
		return set;
	}

	/**
	 * ����һ���ļ���<BR>
	 *
	 * @param file
	 */
	public void addFile(IFileDelegate file) {
		if (null != file) {
			this.files.add(file);
		}
	}

	/**
	 * ����һ����Դ��<BR>
	 *
	 * @param resource
	 */
	public void addResource(IResourceDelegate resource) {
		if (null != resource) {
			if (IResourceDelegate.FILE == resource.getType()) {
				this.files.add(resource);
			}

			if (IResourceDelegate.FOLDER == resource.getType()) {
				this.folders.add(resource);
			}
		}
	}

	/**
	 * ����һ��Ŀ¼��
	 *
	 * @param folder
	 */
	public void addFolder(IFolderDelegate folder) {
		if (null != folder) {
			this.files.add(folder);
		}

	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate[] getFiles() {
		IFileDelegate[] results = new IFileDelegate[this.files.size()];
		this.files.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate[] getFolders() {
		IFolderDelegate[] results = new IFolderDelegate[this.files.size()];
		this.folders.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IResourceDelegate[] getAllResources() {
		List list = new ArrayList();
		list.addAll(this.folders);
		list.addAll(this.files);

		IResourceDelegate[] resources = new IResourceDelegate[list.size()];
		list.toArray(resources);
		return resources;
	}

	/**
	 * {@inheritDoc}
	 */
	public IResourceDelegateSet getMinSet() {

		IResourceDelegate[] resources = this.getAllResources();
		return ResourceHelper.computeMinSet(resources);
	}

	/**
	 * ɾ��һ���ļ�
	 *
	 * @param file
	 */
	public void removeFile(IFileDelegate file) {
		if (null != file) {
			this.files.remove(file);
		}
	}

	/**
	 * ɾ��һ��Ŀ¼��
	 *
	 * @param folder
	 */
	public void removeFolder(IFolderDelegate folder) {
		if (null != folder) {
			this.files.remove(folder);
		}

	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public boolean isEmpty() {
		return this.folders.isEmpty() && this.files.isEmpty();
	}

}
