/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/eclipse/EclipseFolderDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-29
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.eclipse;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * Eclipseƽ̨�ϵ�Ŀ¼ʵ�֡�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EclipseFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2007/06/22 13:04:21  wanglei
 * Review:����Empty�����ʱ��Ӧ�ø���ȷһЩ��
 *
 * Revision 1.7  2007/06/21 14:00:49  wanglei
 * Review:getFolderӦ�øĳ�getEclipseFolder��
 *
 * Revision 1.6  2007/06/06 12:17:50  wanglei
 * Refactor:��forceCreateFolder�����Ƶ�EclipseResourceManager�С�
 *
 * Revision 1.5  2007/05/25 05:55:13  wanglei
 * UnitTest:������getChildrenʱ��Ϊ���������ڶ����ֵĴ���
 *
 * Revision 1.4  2007/04/18 08:39:27  wanglei
 * Update:��ɸ���Ĺ��ܡ�
 *
 * Revision 1.3  2007/03/30 09:28:24  wanglei
 * Add:����isPrefixOf�����������ж�������Դ�Ƿ���ڸ��ӹ�ϵ��
 *
 * Revision 1.2  2007/03/30 02:19:24  wanglei
 * Remove:ȥ����Ԫ���ݷ�����
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public class EclipseFolderDelegate extends EclipseResourceDelegate implements IFolderDelegate {

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * @param folder
	 *            ��ʵ��EclipseĿ¼
	 */
	public EclipseFolderDelegate(IContainer folder) {
		super(folder);
	}

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * @param resource
	 *            ��ʵ��Eclipse��Դ
	 */
	protected EclipseFolderDelegate(IResource resource) {
		super(resource);

	}

	/**
	 *
	 * @return ����EclipseĿ¼��<BR>
	 */
	public IContainer getEclipseFolder() {
		return (IContainer) this.getResource();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getChildren()
	 */
	public IResourceDelegate[] getChildren() {
		try {
			if (this.exists()) {
				return EclipseResourceManager.getInstance().getChildren(this);
			}
			else {
				return NO_RESOURCES;
			}
		} catch (CoreException e) {
			throw new ResourceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getFile(java.lang.String)
	 */
	public IFileDelegate getFile(String path) {
		return EclipseResourceManager.getInstance().getFile(this, path);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getFolder(java.lang.String)
	 */
	public IFolderDelegate getFolder(String path) {
		return EclipseResourceManager.getInstance().getFolder(this, path);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#create()
	 */
	public void create() {
		try {
			IContainer container = this.getEclipseFolder();
			if (container instanceof IFolder) {
				EclipseResourceManager.forceCreateFolder((IFolder) container);
				return;
			}

			if (container instanceof IProject) {
				((IProject) container).create(null);
				return;
			}

		} catch (CoreException e) {
			throw new ResourceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceDelegate#getAdapter(java.lang.Class)
	 */
	public Object getAdapter(Class adapter) {
		if (IFolder.class == adapter || IContainer.class == adapter) {
			return this.getEclipseFolder();
		}

		return super.getAdapter(adapter);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isPrefixOf(IResourceDelegate resourceDelegate) {

		if (null == resourceDelegate) {
			return false;
		}
		Assert.isTrue((resourceDelegate instanceof EclipseResourceDelegate), "The resource must be eclipse resource");

		IResource resource = ((EclipseResourceDelegate) resourceDelegate).getResource();
		if (null == resource) {
			return false;
		}

		IPath path = resource.getFullPath();
		return this.getResource().getFullPath().isPrefixOf(path);
	}

}
