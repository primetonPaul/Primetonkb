/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.base;

import com.primeton.studio.core.base.AbstractDataContainer;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * IResourceDelegate�Ļ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractResourceDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/02/18 07:54:32  wanglei
 * Update:ʵ����IDataContainer�ӿڡ�
 *
 * Revision 1.2  2007/11/01 06:45:28  wanglei
 * Review:������isArchive,isEditable,isBinary������
 *
 * Revision 1.1  2007/06/28 09:33:11  wanglei
 * �ύ��CVS��
 *
 */

public abstract class AbstractResourceDelegate extends AbstractDataContainer implements IResourceDelegate {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractResourceDelegate() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isArchive() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isEditable() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isBinary() {
		return true;
	}
}
