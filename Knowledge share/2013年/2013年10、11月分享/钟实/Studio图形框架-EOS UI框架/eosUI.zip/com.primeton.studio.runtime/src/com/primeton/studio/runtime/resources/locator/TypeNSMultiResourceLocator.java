/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/TypeNSMultiResourceLocator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-8-19
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.primeton.studio.core.util.entry.StringMapEntry;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.index.IndexConstant;
import com.primeton.studio.runtime.index.model.DocumentItem;
import com.primeton.studio.runtime.index.query.IndexFinder;
import com.primeton.studio.runtime.index.query.QueryResult;
import com.primeton.studio.runtime.index.query.QueryStatement;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * ���Ӹ���TypeNameSpace�����ļ���ʵ��(��������ʽ���в���)��<BR>
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: TypeNSMultiResourceLocator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/10/16 01:19:14  chenxp
 * Update: �Ż�����
 *
 * Revision 1.2  2009/10/15 07:44:33  chenxp
 * Update:�Ż����������ٲ�ѯ������
 *
 * Revision 1.1  2009/08/20 07:47:03  hongsq
 * Update:�ṩһ��ӿ�֧�ֲ���һ���ļ������޸�xsd,wsdl��ع����������ƿռ��ظ�
 * 
 */
public class TypeNSMultiResourceLocator extends AbstractMultiResourceLocator {

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFiles(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFiles(IProjectDelegate project, String[] namespaces) {
		List<IFileDelegate> list = new ArrayList<IFileDelegate>();
		Map<String, List<String>> map = RuntimeHelper.analyserNamespace(namespaces);
		for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
			String NS = (String) iter.next();
			List<String> extentionList = map.get(NS);
			
			QueryStatement statement = new QueryStatement();
			statement.setExtensions(extentionList.toArray(new String[extentionList.size()]));
			statement.setNameSpace(new StringMapEntry(IndexConstant.TYPE_NAMESPACE, NS));
			QueryResult<DocumentItem> result = IndexFinder.getInstance().searchFiles(project, statement);
			for (int j = 0; j < result.size(); j++) {
				DocumentItem item = result.get(j);
				IFileDelegate file = item.getFile();
				if(null != file && !list.contains(file)){
					list.add(item.getFile());
				}
			}
		}
		return list.toArray(new IFileDelegate[list.size()]);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFiles(com.primeton.studio.runtime.core.IContribution, java.lang.String[], boolean)
	 */
	public IFileDelegate[] findFiles(IContribution contribution, String[] namespaces, boolean includeReference) {
		List<IFileDelegate> list = new ArrayList<IFileDelegate>();
		IContribution[] contributions = includeReference ? ContributionUtil.getAllRelatedContributions(new IContribution[] { contribution }) : new IContribution[] { contribution };
		Map<String, List<String>> map = RuntimeHelper.analyserNamespace(namespaces);
		for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
			String NS = (String) iter.next();
			List<String> extentionList = map.get(NS);
			
			QueryStatement statement = new QueryStatement();
			statement.setExtensions(extentionList.toArray(new String[extentionList.size()]));
			statement.setNameSpace(new StringMapEntry(IndexConstant.TYPE_NAMESPACE, NS));
			QueryResult<DocumentItem> result = IndexFinder.getInstance().searchFiles(contributions, statement);
			for (int j = 0; j < result.size(); j++) {
				DocumentItem item = result.get(j);
				IFileDelegate file = item.getFile();
				if(null != file && !list.contains(file)){
					list.add(item.getFile());
				}
			}
		}
		return list.toArray(new IFileDelegate[list.size()]);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInFolders(java.lang.String[], com.primeton.studio.runtime.resources.IFolderDelegate[])
	 */
	public IFileDelegate[] findFilesInFolders(String[] namespaces, IFolderDelegate[] folders) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInLibraries(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFilesInLibraries(IProjectDelegate project, String[] namespaces) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInSourceFolders(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFilesInSourceFolders(IProjectDelegate project, String[] namespaces) {
		// TODO Auto-generated method stub
		return null;
	}

}
