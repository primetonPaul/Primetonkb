/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/model/DocumentItem.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-5-27
 *******************************************************************************/

package com.primeton.studio.runtime.index.model;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;

import com.eos.system.utility.Assert;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.index.IndexConstant;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.internal.archive.ArchiveResourceDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseFileDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceDelegate;
import com.primeton.studio.runtime.resources.internal.java.JavaFileDelegate;

/**
 * ������ģ�ͣ���Ӧ��Lucene��Document���ݣ�Ҳ����˵�ܹ���DocumentItemת��һ��Lucene��Documenet��<BR>
 * ͬʱҲ�ܽ�Lucene��Documentת��һ��DocumentItem��<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DocumentItem.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/09/21 08:25:29  hongsq
 * Update:����ͬ����wsdl���ƿռ���ͬ�ı��������ɾ����һ��֮����һ��wsdl��Ҫ������֤��
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
public final class DocumentItem extends IndexItem {

	private IFileDelegate file;

	private IProjectDelegate project;

	//	private Set dependencies = new HashSet();

	private Set types = null;

	//	private Set fields = new HashSet();
	//
	//	private Set methods = new HashSet();

	/**
	 * �Ƿ�Ϊ�������ļ�
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#isBinary()
	 */
	private boolean binary;

	/**
	 * Ψһ��ʶ��ͨ��Ϊ����DocumentItem����ʱ��ʱ���
	 */
	private long identity;

	/**
	 * ȫ���������а�����ȫ������com.primeton.eos.Dict
	 */
	private String fullName;

	/**
	 * �����Դ�����·����
	 */
	private String sourceRelativePath;

	/**
	 * �ļ���ʱ���
	 */
	private long timestamp;

	/**
	 * ���������ͣ���biz֮�ࡣ<BR>
	 *
	 * @see com.primeton.studio.runtime.model.IModelFactory#getBinaryName()
	 *
	 */
	private String binaryType;

	/**
	 * ��չ����<BR>
	 */
	private String extension;

	/**
	 * ȫ·����<BR>
	 */
	private String path;

	/**
	 * �ļ���Э�顣<BR>
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#getProtocol()
	 */
	private String fileProtocol;

	/**
	 * Lucene�������ĵ�
	 *
	 */
	private Document document;
	
	/**
	 * ���ƿռ�
	 */
	private String namespace;

	/**
	 * ֻ�ṩ������������������<BR>
	 *
	 * @param name
	 * @param fileDelegate
	 * @return
	 */
	public static DocumentItem createDocument(String name, IFileDelegate fileDelegate) {
		return new DocumentItem(name, fileDelegate);
	}

	/**
	 * ֻ�ṩ������������������<BR>
	 *
	 * @param document
	 * @param project
	 * @return
	 */
	public static DocumentItem createDocument(Document document, IProjectDelegate project) {
		Assert.notNull(document, "the document can't be null.");
		String name = document.get(IndexConstant.NAME);
		DocumentItem docItem = new DocumentItem(name, project);

		docItem.document = document;

		docItem.fullName = document.get(IndexConstant.FULL_NAME);
		docItem.timestamp = Long.parseLong(document.get(IndexConstant.TIMESTAMP));
		docItem.fileProtocol = document.get(IndexConstant.FILE_PROTOCOL);
		docItem.binaryType = document.get(IndexConstant.BINARY_TYPE);
		docItem.extension = document.get(IndexConstant.EXTENSION);
		docItem.path = document.get(IndexConstant.PATH);
		docItem.sourceRelativePath = document.get(IndexConstant.SOURCE_PATH);
		docItem.binary = Boolean.parseBoolean(document.get(IndexConstant.BINARY_FILE));
		docItem.namespace = document.get(IndexConstant.NAMESPACE);

		return docItem;
	}

	/**
	 * �������ⲿ�����ö���<BR>
	 *
	 * @param name
	 * @param projectDelegate
	 */
	private DocumentItem(String name, IProjectDelegate projectDelegate) {
		super(null, name);

		Assert.notNull(ResourceHelper.isValidProject(projectDelegate), "the project isn't valid.");
		this.project = projectDelegate;
	}

	/**
	 * �������ⲿ�����ö���<BR>
	 *
	 * @param name
	 * @param fileDelegate
	 */
	private DocumentItem(String name, IFileDelegate fileDelegate) {
		super(null, name);

		Assert.notNull(ResourceHelper.isValidResource(fileDelegate), "the resource isn't valid.");
		this.file = fileDelegate;
		this.project = this.file.getProject();
		this.identity = System.nanoTime();
		this.binary = this.file.isBinary();
		this.fileProtocol = this.file.getProtocol();
		this.sourceRelativePath = fileDelegate.getSourceRelativePath();

	}

	/**
	 * {@inheritDoc}
	 */
	public DocumentItem getDocument() {
		return this;
	}

	/**
	 * @return Returns the binary.
	 */
	public boolean isBinary() {
		return binary;
	}

	/**
	 * @return Returns the sourceRelativePath.
	 */
	public String getSourceRelativePath() {
		return sourceRelativePath;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setDocument(DocumentItem document) {
		super.setDocument(this);
	}

	/**
	 * �õ���Ӧ���ļ���<BR>
	 *
	 * @return
	 */
	public IFileDelegate getFile() {

		if (null == this.file) {
			this.file = doGetFile();
		}

		return this.file;
	}

	/**
	 * ���ļ���Э�飬��Eclipse,archive��java�����ҡ�<BR>
	 *
	 * FIXME ���������ʵҪ�����ģ�����������Ӳ���롣<BR>
	 *
	 * @return
	 */
	private IFileDelegate doGetFile() {
		if (EclipseResourceDelegate.ECLIPSE.equals(this.fileProtocol)) {
			IFile file = ResourcesPlugin.getWorkspace().getRoot().getFile(new Path(this.path));
			return new EclipseFileDelegate(file);
		}

		if (RuntimeConstant.JAVA.equals(this.fileProtocol)) {
			File file = new File(this.getPath());
			return new JavaFileDelegate(file);
		}

		if (ArchiveResourceDelegate.ARCHIVE.equals(this.fileProtocol)) {
			IContribution[] contributions = RuntimeManager.getAllContributions4Libraries(this.project);

			for (int i = 0; i < contributions.length; i++) {
				IContribution contribution = contributions[i];
				IFileDelegate file = RuntimeManager.findFile(contribution, this.sourceRelativePath);
				if (ResourceHelper.isValidResource(file)) {
					return file;
				}
			}
		}

		return null;
	}

	/**
	 * @return Returns the binaryName.
	 */
	public String getBinaryType() {
		return binaryType;
	}

	/**
	 * @return Returns the extension.
	 */
	public String getExtension() {
		return extension;
	}

	/**
	 * @return Returns the fileProtocol.
	 */
	public String getFileProtocol() {
		return fileProtocol;
	}

	/**
	 * @return Returns the fullName.
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @return Returns the identity.
	 */
	public long getIdentity() {
		return identity;
	}

	/**
	 * @return Returns the path.
	 */
	public String getPath() {
		return path;
	}

	/**
	 * @return Returns the namespace.
	 */
	public String getNamespace() {
		return namespace;
	}
	
	/**
	 * @return Returns the project.
	 */
	public IProjectDelegate getProject() {
		return project;
	}

	/**
	 * @return Returns the timestamp.
	 */
	public long getTimestamp() {
		return timestamp;
	}

	//	/**
	//	 * ����������ϵ��<BR>
	//	 *
	//	 * @return
	//	 */
	//	public String[] getDependencies() {
	//		String[] results = new String[this.dependencies.size()];
	//		this.dependencies.toArray(results);
	//		return results;
	//	}
	//
	//	/**
	//	 * ����������ϵ��<BR>
	//	 * @param dependency
	//	 */
	//	public void addDependency(String dependency) {
	//		Assert.notNull(dependency, "the dependency can't be null.");
	//		this.dependencies.add(dependency);
	//	}
	//
	//	/**
	//	 * �Ƴ�������ϵ��<BR>
	//	 * @param dependency
	//	 */
	//	public void removeDependency(String dependency) {
	//		Assert.notNull(dependency, "the dependency can't be null.");
	//		this.dependencies.add(dependency);
	//	}

	private void checkTypes() {
		if (null == this.types) {
			this.types = new HashSet();
		}

		if (null != this.document) {
			Field[] namespacesFields = document.getFields(IndexConstant.TYPE_NAMESPACE);
			Field[] typeFields = document.getFields(IndexConstant.TYPE_NAME);

			for (int i = 0; i < namespacesFields.length; i++) {
				String namespace = namespacesFields[i].stringValue();
				String typeName = typeFields[i].stringValue();

				TypeItem typeItem = new TypeItem(this, typeName, namespace);
				this.types.add(typeItem);
			}
		}
	}

	/**
	 * �������͡�<BR>
	 *
	 * @return
	 */
	public TypeItem[] getTypes() {

		this.checkTypes();
		TypeItem[] results = new TypeItem[this.types.size()];
		this.types.toArray(results);
		return results;
	}

	/**
	 * ����һ�����͡�<BR>
	 *
	 * @param type
	 */
	public void addType(TypeItem type) {

		if (null == this.types) {
			this.types = new HashSet();
		}

		Assert.notNull(type, "the type can't be null.");
		this.types.add(type);
	}

	/**
	 * �Ƴ�һ�����͡�<BR>
	 *
	 * @param type
	 */
	public void removeType(TypeItem type) {
		if (null == this.types) {
			this.types = new HashSet();
		}
		Assert.notNull(type, "the type can't be null.");
		this.types.remove(type);
	}

	//	/**
	//	 * �����ֶΡ�<BR>
	//	 *
	//	 * @return
	//	 */
	//	public FieldItem[] getFields() {
	//		FieldItem[] results = new FieldItem[this.fields.size()];
	//		this.types.toArray(results);
	//		return results;
	//	}
	//
	//	/**
	//	 * ����һ���ֶΡ�<BR>
	//	 *
	//	 * @param field
	//	 */
	//	public void addField(FieldItem field) {
	//		Assert.notNull(field, "the field can't be null.");
	//		this.fields.add(field);
	//	}
	//
	//	/**
	//	 * �Ƴ�һ���ֶΡ�<BR>
	//	 *
	//	 * @param field
	//	 */
	//	public void removeField(FieldItem field) {
	//		Assert.notNull(field, "the field can't be null.");
	//		this.fields.remove(field);
	//	}
	//
	//	/**
	//	 * ���ط�����<BR>
	//	 *
	//	 * @return
	//	 */
	//	public MethodItem[] getMethods() {
	//		MethodItem[] results = new MethodItem[this.methods.size()];
	//		this.types.toArray(results);
	//		return results;
	//	}
	//
	//	/**
	//	 * ����һ��������<BR>
	//	 *
	//	 * @param field
	//	 */
	//	public void addMethod(MethodItem method) {
	//		Assert.notNull(method, "the method can't be null.");
	//		this.methods.add(method);
	//	}
	//
	//	/**
	//	 * ����һ��������<BR>
	//	 *
	//	 * @param field
	//	 */
	//	public void removeMethod(MethodItem method) {
	//		Assert.notNull(method, "the method can't be null.");
	//		this.methods.remove(method);
	//	}

}
