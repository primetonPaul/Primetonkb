/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/query/TypeQueryResult.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-6-5
 *******************************************************************************/

package com.primeton.studio.runtime.index.query;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;

import com.eos.system.utility.StringUtil;
import com.primeton.studio.runtime.index.IndexConstant;
import com.primeton.studio.runtime.index.model.DocumentItem;
import com.primeton.studio.runtime.index.model.TypeItem;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: TypeQueryResult.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/07/22 05:09:17  lvyuan
 * Update:�ع�����namespace��Ϊһ��StringEntry
 *
 * Revision 1.2  2009/07/21 09:51:19  lvyuan
 * Update:�ع��������ҽӿڣ��������ö���ؼ���
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
class TypeQueryResult<E> extends QueryResult<E> {

	private int visitedDocCount=0;

	/**
	 * @param projectDelegate
	 * @param query
	 * @param statement
	 */
	public TypeQueryResult(IProjectDelegate projectDelegate, Query query, QueryStatement statement) {
		super(projectDelegate, query, statement);
	}

	/**
	 * {@inheritDoc}
	 * @throws IOException
	 * @throws CorruptIndexException
	 */
	protected int computeSize(Hits hits) throws CorruptIndexException, IOException {

		int size = 0;
		String typeQueryName = (String) this.getStatement().getNameSpace().getValue();

		for (int i = 0; i < hits.length(); i++) {
			Document document = hits.doc(i);

			Field[] namespacesFields = document.getFields(IndexConstant.TYPE_NAMESPACE);
			Field[] typeFields = document.getFields(IndexConstant.TYPE_NAME);

			if (ArrayUtils.isEmpty(namespacesFields) || ArrayUtils.isEmpty(typeFields)) {
				continue;
			}

			for (int j = 0; j < namespacesFields.length; j++) {
				String namespace = namespacesFields[j].stringValue();
				String typeName = typeFields[j].stringValue();

				if (StringUtil.isWildcardMatch(typeName, typeQueryName, false) || StringUtil.isWildcardMatch(namespace, typeQueryName, false)) {
					size++;
				}
			}
		}

		return size;
	}

	/**
	 * {@inheritDoc}
	 */
	protected List<E> load(Hits hits, int startIndex, int endIndex) throws CorruptIndexException, IOException {

		List typeList = new ArrayList();

		endIndex = Math.min(this.size(), endIndex);

		for (int i = startIndex; i < endIndex; i++) {
			Document doc = hits.doc(visitedDocCount);
			visitedDocCount++;

			DocumentItem docItem = DocumentItem.createDocument(doc, this.getProject());
			addTypes(doc, docItem, (String) this.getStatement().getNameSpace().getValue(), typeList);

			if(typeList.size()>=(endIndex-startIndex)){
				return typeList;
			}
		}

		return typeList;
	}

	/**
	 * ����Typeģ�͡�<BR>
	 *
	 * @param document
	 * @param docItem
	 * @param typeQueryName
	 * @param typeList
	 */
	protected void addTypes(Document document, DocumentItem docItem, String typeQueryName, List<TypeItem> typeList) {

		Field[] namespacesFields = document.getFields(IndexConstant.TYPE_NAMESPACE);
		Field[] typeFields = document.getFields(IndexConstant.TYPE_NAME);

		if (ArrayUtils.isEmpty(namespacesFields) || ArrayUtils.isEmpty(typeFields)) {
			return;
		}

		for (int i = 0; i < namespacesFields.length; i++) {
			String namespace = namespacesFields[i].stringValue();
			String typeName = typeFields[i].stringValue();

			TypeItem typeItem = new TypeItem(docItem, typeName, namespace);
			docItem.addType(typeItem);

			if (null != typeList) {
				if (StringUtil.isWildcardMatch(typeName, typeQueryName, false) || StringUtil.isWildcardMatch(namespace, typeQueryName, false)) {
					typeList.add(typeItem);
				}
			}
		}
	}

}
