/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/internal/EntityFinder.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-8-14
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.internal;

import java.util.Collection;
import java.util.Iterator;

import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EntityFinder.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/09/10 07:10:12  zhuxing
 * Update:�޸��������ÿ��е���Դ��ȡģ��ʧ�ܵ����
 *
 * Revision 1.1  2008/08/15 07:50:18  zhuxing
 * Update:�޸Ĺ������з����ļ��Զ����ɺ�������ʾ������
 * 
 */
public class EntityFinder {
	
	private static final String[] TYPES = {RuntimeConstant.FILE_DATASETX,
		RuntimeConstant.FILE_DATASET,
		RuntimeConstant.FILE_XSDX,RuntimeConstant.FILE_XSD};
	/**
	 * ����Ҫ���캯��
	 *
	 */
	private EntityFinder() {
		//todonothing
	}
	/**
	 * 
	 * @param datasetName
	 * @param entityName
	 * @param contribution
	 * @return
	 */
	public static IType findEntity(String datasetName, String entityName, IContribution contribution){
		IProjectDelegate project = contribution.getResource().getProject();
		IFileDelegate file = null;
		for (int j = 0; j < TYPES.length; j++) {
			String string = TYPES[j];			
			file = ResourceHelper.findFile(project, contribution, datasetName, string);
			
			//modify by zhuxing:�õ���һ����Ч��eos model
			if (file != null) {
				IEosModel eosModel = RuntimeManager.createModel(file);
				if (eosModel != null)
					break ;
			}
		}
		if(file == null)
			return null;
		
		return getEntity(entityName,file);
	}
	

	/**
	 * 
	 * @param entityName
	 * @param file
	 * @return
	 */
	private static IType getEntity(String entityName, IFileDelegate file){
		if(file == null)return null;
		IEosModel eosModel = RuntimeManager.createModel(file);
		Collection collection = eosModel.getChildrenOfType(IEosElement.TYPE);
		if(collection == null || collection.size() < 1)
			return null;
		
		for (Iterator iter = collection.iterator(); iter.hasNext();) {
			IType element = (IType) iter.next();
			if(entityName.equals(element.getName())){
				return element;
			}
		}
		return null;
	}
}
