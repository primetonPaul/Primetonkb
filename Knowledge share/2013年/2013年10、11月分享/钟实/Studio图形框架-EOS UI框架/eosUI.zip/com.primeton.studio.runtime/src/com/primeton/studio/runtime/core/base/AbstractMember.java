/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.base;

import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IMember;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.core.internal.Type;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * IMember�Ļ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractMember.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/01/13 01:17:27  lvyuan
 * Bugfix:�޸������߼�����������ͬʱ��������ʾ����
 *
 * Revision 1.2  2008/08/04 07:44:38  yanfei
 * Update:ȥ��AbstractMenber���е�equalself�����������������ÿ�ʱ�����StackOverflow�����⡣
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.9  2008/05/30 06:16:50  chenxp
 * Update:����equalsSelf����
 *
 * Revision 1.8  2007/12/11 03:51:08  tenghao
 * Delete:  ȥ��isBinary
 *
 * Revision 1.7  2007/06/28 09:21:21  wanglei
 * Review:�������getModel��setModel�ᵽ�����С�
 *
 * Revision 1.6  2007/06/15 10:01:29  wanglei
 * Update:������Ĭ�Ϲ��캯����
 *
 * Revision 1.5  2007/06/15 09:43:40  wanglei
 * Update:�����˹��캯����
 *
 * Revision 1.4  2007/06/13 06:19:18  wanglei
 * Update:��setDeclaringType������
 *
 * Revision 1.3  2007/05/28 05:47:28  wanglei
 * Add:Ϊ����IEosElement����getModel������
 *
 * Revision 1.2  2007/04/27 10:06:50  wanglei
 * UnitTest:����ITypeΪnull
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public abstract class AbstractMember extends AbstractEosElement implements IMember {

	private IType declaringType;

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param resource
	 * @param type
	 */
	public AbstractMember(IResourceDelegate resource, IEosElement parent, IType type) {
		super(resource, parent);
		this.setDeclaringType(type);
	}

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param type
	 */
	public AbstractMember(IType type) {
		super(null, null);
		this.setDeclaringType(type);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param type
	 */
	public AbstractMember() {
		super(null, null);
	}

	/**
	 * @param type
	 */
	public void setDeclaringType(IType type) {
		this.declaringType = type;
	}

	/**
	 * {@inheritDoc}
	 */
	public IType getDeclaringType() {
		return this.declaringType;
	}

	/**
	 * @return ���ظ��׳�Ա������ǿ��ת�͡�<BR>
	 */
	public IMember getMember() {
		return (IMember) this.getParent();
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + ((this.declaringType == null) ? 0 : this.declaringType.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (!super.equals(obj)) {
			return false;
		}

		final AbstractMember other = (AbstractMember) obj;
		if (!ObjectUtils.equals(this.declaringType, other.declaringType)) {
			return false;
		}

		return true;
	}

	
	@Override
	public boolean equalsSelf(Object obj) {
		if(!super.equalsSelf(obj)){
			return false;
		}
		return ((AbstractEosElement)this.declaringType).equalsSelf(((AbstractMember)obj).declaringType);
	}
	/**
	 * {@inheritDoc}
	 */
	protected boolean checkParent() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkResource() {
		return false;
	}

}
