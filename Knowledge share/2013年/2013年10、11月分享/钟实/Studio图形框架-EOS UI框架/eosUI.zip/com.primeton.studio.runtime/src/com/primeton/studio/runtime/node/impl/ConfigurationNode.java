/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.node.impl;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;

import com.primeton.studio.runtime.OrderConstant;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.node.base.AbstractFolderNode;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseFolderDelegate;

/**
 *
 * ������Դ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ConfigurationNode.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/05/29 05:13:53  wanglei
 * Update:��ȡ��������OrderConstant�С�
 *
 * Revision 1.1  2008/03/19 05:05:44  wanglei
 * Review:�������,��ģ�͵����ݴ�navigator����г�ȡ��runtime����С�
 *
 * Revision 1.3  2008/03/19 03:09:49  wanglei
 * Review:��ԭ��д��Nodeϵ�������е�IWorkbenchAdapter��ȡ����չ�㣬����ǿ������
 *
 * Revision 1.2  2008/01/10 07:50:02  wanglei
 * Review:ģ�͵�����,���µ���getParent���ƣ��Ա�֤ʵ��Link��
 *
 * Revision 1.1  2007/08/28 08:16:55  wanglei
 * �ύ��CVS��
 *
 */

public class ConfigurationNode extends AbstractFolderNode {

	public static final String CONTRIBUTION_CONFIGURATION = "com.primeton.component.contribution.configuration";

	private IContribution contribution;

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param folder
	 * @param contribution
	 */
	public ConfigurationNode(IFolderDelegate folder, IContribution contribution) {
		super(folder);

		this.contribution = contribution;
		this.setOrder(OrderConstant.ORDER_CONFIGURATION);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getType() {
		return CONTRIBUTION_CONFIGURATION;
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getAdapter(Class adapter) {
		if (adapter == IResourceDelegate.class) {
			return this.getFolder();
		}

		if (adapter == IResource.class) {

			if (this.getFolder() instanceof EclipseFolderDelegate) {
				EclipseFolderDelegate folderDelegate = (EclipseFolderDelegate) this.getFolder();
				IContainer folder = folderDelegate.getEclipseFolder();
				//Path path = new Path(RuntimeConstant.META_INF);

				return folder;
			}
		}

		return super.getAdapter(adapter);
	}

	/**
	 * @return the contribution
	 */
	public IContribution getContribution() {
		return this.contribution;
	}

}
