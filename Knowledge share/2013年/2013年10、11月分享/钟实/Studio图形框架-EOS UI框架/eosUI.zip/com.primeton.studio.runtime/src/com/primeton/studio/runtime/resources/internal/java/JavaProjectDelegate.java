/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/java/JavaProjectDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-30
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.java;

import java.io.File;
import java.util.List;
import java.util.Vector;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * ����Java�ļ���Դʵ��IProjectDelegate�ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaProjectDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2008/03/03 08:43:38  yanfei
 * Updata:��ʼ��libraries, ��ֹ���ֿ�ָ�롣
 *
 * Revision 1.7  2007/08/23 03:11:07  wanglei
 * Review:��IEOSProject�е�getLibraries�ƶ���IProjectDelegate�С�
 *
 * Revision 1.6  2007/08/08 07:10:58  wanglei
 * Update:����ʵ�����еĹ��ܡ�
 *
 * Revision 1.5  2007/06/21 13:58:05  wanglei
 * Review:IProjectDelegateӦ��֧��isOpen�����ж�����Ч�ԡ�
 *
 * Revision 1.4  2007/05/08 09:03:03  wanglei
 * Refactor:��getSrcFolder��getSrcFolders���ĳ�getSourceFoder��getSourceFoders������
 *
 * Revision 1.3  2007/04/23 09:05:20  wanglei
 * Update:��ΪJavaResourceManager�ع��˼����������ƣ�����Ҫ���и��¡�
 *
 * Revision 1.2  2007/04/18 08:38:45  wanglei
 * Update:�����еķ������ö�ת����JavaResourceManager��������
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */
public class JavaProjectDelegate extends JavaFolderDelegate implements IProjectDelegate {

	List sourceFolders = new Vector();

	private ILibrary[] libraries = new ILibrary[0];

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param file
	 */
	public JavaProjectDelegate(File file) {
		super(file);

	}

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param fileName
	 */
	public JavaProjectDelegate(String fileName) {
		super(fileName);
	}

	/**
	 * Ϊ��ǰ��Ŀ����һ��Դ����Ŀ¼��<BR>
	 *
	 * @param sourceFolder
	 */
	public void addSourceFolder(JavaSourceFolderDelegate sourceFolder) {
		if (null != sourceFolder) {
			this.sourceFolders.add(sourceFolder);
		}
	}

	/**
	 * Ϊ��ǰ��Ŀɾ��һ��Դ����Ŀ¼��<BR>
	 *
	 * @param sourceFolder
	 */
	public void removeSourceFolder(JavaSourceFolderDelegate sourceFolder) {
		if (null != sourceFolder) {
			this.sourceFolders.remove(sourceFolder);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IProjectDelegate#getSourceFolders()
	 */
	public ISourceFolderDelegate[] getSourceFolders() {
		ISourceFolderDelegate[] results = new ISourceFolderDelegate[this.sourceFolders.size()];
		this.sourceFolders.toArray(results);
		return results;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.java.JavaFolderDelegate#getType()
	 */
	public int getType() throws ResourceException {
		return PROJECT;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public boolean isOpen() {
		return true;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return null;
	}

	/**
	 * @param libraries the libraries to set
	 */
	public final void setLibraries(ILibrary[] libraries) {
		this.libraries = libraries;
	}

	/**
	 * {@inheritDoc}
	 */
	public ILibrary[] getLibraries() {
		return this.libraries;
	}
}
