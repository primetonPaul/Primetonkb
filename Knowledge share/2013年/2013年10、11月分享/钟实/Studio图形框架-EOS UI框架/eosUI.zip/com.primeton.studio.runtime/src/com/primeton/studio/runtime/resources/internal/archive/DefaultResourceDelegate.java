/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/DefaultResourceDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-7-10
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.resources.internal.base.AbstractResourceDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultResourceDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.5  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 * Revision 1.4  2008/10/06 03:39:28  yangmd
 * Update:����hashcode�������һ����ڶ��󼶱𻺴�fullpath��
 *
 * Revision 1.3  2008/09/10 05:46:45  yanfei
 * Update:�޸�һ���������⣬���ļ������ļ�����ͬһ��Ŀ¼�£�����������ͬʱ������ֱȽϽ������ȷ��
 *
 * Revision 1.2  2008/07/13 14:05:22  yangmd
 * Update:�ع�
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 *
 */
public abstract class DefaultResourceDelegate extends AbstractResourceDelegate {

	/**
	 * archive
	 */
	public static final String ARCHIVE = "archive";

	private IFolderDelegate parent;
	private String name;
	private Map<String,String> persistent = new HashMap<String, String>();

	private Object model;
	private String fullPath = null;
	/**
	 *
	 * @param folderDelegate
	 * @param name
	 */
	public DefaultResourceDelegate(IFolderDelegate parent, String name) {
		this.parent = parent;
		this.name = name;
	}

	/**
	 * {@inheritDoc}
	 */
	public void create() {

	}

	/**
	 * {@inheritDoc}
	 */
	public void delete() throws ResourceException {

	}

	/**
	 * {@inheritDoc}
	 */
	public boolean exists() throws ResourceException {
		return true;
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean isBinary() {
		return false;
	}
	/**
	 * {@inheritDoc}
	 */
	public File getFile() {
		if(parent != null)return parent.getFile();
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getFullPath() throws ResourceException {
		if(parent != null){
			if(this.fullPath == null){
				IPath fullPath = new Path(this.parent.getFullPath()).append(new Path(this.name));
				this.fullPath =  fullPath.toString();
			}
			return this.fullPath;
		}
		return name;

	}

	/**
	 * {@inheritDoc}
	 */
	public long getLastModified() {
		if(this.getFile() != null){
			long time = this.getFile().lastModified();
			return time + this.getId();
		}
		return 0;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getName() throws ResourceException {
		return this.name;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getParent() throws ResourceException {
		return this.parent;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getPersistentProperty(String key) {
		return this.persistent.get(key);
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate getProject() throws ResourceException {
		if(parent != null){
			return this.parent.getProject();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProjectRelativePath() throws ResourceException {
		if(this.parent != null){
			IProjectDelegate project = this.getProject();
			if(project != null){
				IPath projectPath = new Path(project.getFullPath());
				IPath thisPath = new Path(this.getFullPath());
				if(projectPath.isPrefixOf(thisPath)){
					return StringUtils.substringAfter(thisPath.toString(), projectPath.toString());
				} else if(projectPath.equals(thisPath)){
					return Path.ROOT.toString();
				}
			}
		}
		return "";//���ؿ��ַ��������ⷢ����ָ���쳣��
	}

	/**
	 * {@inheritDoc}
	 */
	public IRootDelegate getRoot() throws ResourceException {
		if(parent != null){
			return this.parent.getRoot();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		if(parent != null){
			return this.parent.getSourceFolder();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getSourceRelativePath() throws ResourceException {
		if(this.getSourceFolder() != null){
			String sourcePath = this.getSourceFolder().getProjectRelativePath();
			String thisPath = this.getProjectRelativePath();
			String relativePath = StringUtils.substringAfterLast(thisPath, sourcePath);
			IPath path = new Path(relativePath);
			return path.toString();
		}
		return "";
	}

	/**
	 * {@inheritDoc}
	 */
	public void setPersistentProperty(String key, String value) {
		this.persistent.put(key, value);
	}

	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		return this.getTypeString() + this.getFullPath();
	}
	/**
	 *
	 * @return
	 */
	public String getTypeString(){
		int type = this.getType();
		switch (type) {
		case FILE:
			return "L";
		case FOLDER:
			return "F";
		case PROJECT:
			return "P";
		case ROOT:
			return "R";
		default:
			return "";
		}
	}

	/**
	 *
	 * @return
	 */
	private int getId() {
		String fullPath = this.getFullPath();
		if(fullPath != null)
		{
			return fullPath.hashCode();
		}
		return 0;
	}
	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		return this.getFullPath().hashCode();
	}
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final DefaultResourceDelegate other = (DefaultResourceDelegate) obj;
		return StringUtils.equals(this.getFullPath(), other.getFullPath()) && this.getType() == other.getType();
	}

	/**
	 * @return Returns the model.
	 */
	public Object getModel() {
		return model;
	}

	/**
	 * @param model The model to set.
	 */
	public void setModel(Object model) {
		this.model = model;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProtocol() {
		return ARCHIVE;
	}
}
