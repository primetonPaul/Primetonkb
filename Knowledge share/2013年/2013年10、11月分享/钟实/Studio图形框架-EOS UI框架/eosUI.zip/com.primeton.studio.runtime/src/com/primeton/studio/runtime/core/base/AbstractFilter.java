/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.base;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IFilter;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * IFilter�ĳ���ʵ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractFilter.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/01/09 05:40:06  wanglei
 * Add:�ύ��CVS��
 *
 */

public abstract class AbstractFilter implements IFilter {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractFilter() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean accept(IEosElement element) {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean accept(IEosElement parent, IResourceDelegate resource) {
		return true;
	}
}
