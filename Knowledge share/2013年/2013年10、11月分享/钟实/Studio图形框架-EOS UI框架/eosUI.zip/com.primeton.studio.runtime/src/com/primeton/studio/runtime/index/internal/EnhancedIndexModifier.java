/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.index.internal;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexModifier;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.LockObtainFailedException;

/**
 * ��ΪLucene�Դ���IndexModifier��֧��updateDocument��<BR>
 * �����ṩһ����ǿ��IndexModifier��֧���������<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EnhancedIndexModifier.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2007/10/15 08:58:06  wanglei
 * Review:������getWriter�п��ܳ���NPE��Bug��ͬʱ������getIndexReader������
 *
 * Revision 1.4  2007/06/30 13:20:39  wanglei
 * Review:��IndexWriter��autoCommit����
 *
 * Revision 1.3  2007/06/30 13:11:16  wanglei
 * Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.2  2007/06/29 13:25:23  wanglei
 * Update:����getIndexWriter��
 *
 * Revision 1.1  2007/06/13 06:36:14  wanglei
 * �ύ��CVS��
 *
 */

public class EnhancedIndexModifier extends IndexModifier {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param directory
	 * @param analyzer
	 * @param create
	 * @throws IOException
	 */
	public EnhancedIndexModifier(Directory directory, Analyzer analyzer, boolean create) throws IOException {
		super(directory, analyzer, create);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param file
	 * @param analyzer
	 * @param create
	 * @throws IOException
	 */
	public EnhancedIndexModifier(File file, Analyzer analyzer, boolean create) throws IOException {
		super(file, analyzer, create);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param dirName
	 * @param analyzer
	 * @param create
	 * @throws IOException
	 */
	public EnhancedIndexModifier(String dirName, Analyzer analyzer, boolean create) throws IOException {
		super(dirName, analyzer, create);
	}

	/**
	 * ʹ��IndexWriter��updateDocument��<BR>
	 * �����ܻ���߸����ĵ����ٶȡ�<BR>
	 *
	 * @param term
	 * @param doc
	 * @param docAnalyzer
	 * @throws IOException
	 */
	public void updateDocument(Term term, Document doc, Analyzer docAnalyzer) throws IOException {
		synchronized (this.directory) {
			assureOpen();
			createIndexWriter();
			if (docAnalyzer != null) {
				this.indexWriter.updateDocument(term, doc, docAnalyzer);
			}
			else {
				this.indexWriter.updateDocument(term, doc);
			}
		}
	}

	/**
	 * ʹ��IndexWriter��updateDocument��<BR>
	 * �����ܻ���߸����ĵ����ٶȡ�<BR>
	 *
	 * @param term
	 * @param doc
	 * @throws IOException
	 */
	public void updateDocument(Term term, Document doc) throws IOException {
		this.updateDocument(term, doc, null);
	}

	/**
	 * ����������Writer��<BR>
	 *
	 * @return
	 * @throws IOException
	 * @throws LockObtainFailedException
	 * @throws CorruptIndexException
	 */
	IndexWriter getIndexWriter() throws CorruptIndexException, LockObtainFailedException, IOException {
		super.createIndexWriter();
		return super.indexWriter;
	}

	/**
	 * ����������Reader��<BR>
	 *
	 * @return
	 * @throws IOException
	 * @throws CorruptIndexException
	 */
	IndexReader getIndexReader() throws CorruptIndexException, IOException {

		super.createIndexReader();
		return super.indexReader;
	}

	/**
	 * {@inheritDoc}
	 */
	protected void createIndexWriter() throws CorruptIndexException, LockObtainFailedException, IOException {
		if (super.indexWriter == null) {
			if (super.indexReader != null) {
				super.indexReader.close();
				super.indexReader = null;
			}
			super.indexWriter = new IndexWriter(super.directory, true, super.analyzer, false);
			super.indexWriter.setInfoStream(super.infoStream);
			super.indexWriter.setUseCompoundFile(super.useCompoundFile);
			super.indexWriter.setMaxBufferedDocs(super.maxBufferedDocs);
			super.indexWriter.setMaxFieldLength(super.maxFieldLength);
			super.indexWriter.setMergeFactor(super.mergeFactor);
		}
		//��IndexWriter��autoCommit����
	}

}
