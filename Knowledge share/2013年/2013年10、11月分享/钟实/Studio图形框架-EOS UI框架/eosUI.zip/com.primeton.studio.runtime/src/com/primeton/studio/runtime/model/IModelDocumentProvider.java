/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model;

import java.util.Map;

import com.primeton.studio.runtime.core.IDocument;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * �ĵ��ṩ�ߡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IModelDocumentProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/04/17 01:21:24  wanglei
 * Update:������createDocumentFile������
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/04/14 12:43:31  wanglei
 * Add:����getDocumentFile������
 *
 * Revision 1.2  2008/04/11 08:27:18  wanglei
 * Add:����createDocument������
 *
 * Revision 1.1  2008/04/09 11:35:18  wanglei
 * Add:�ύ��CVS��
 *
 */

public interface IModelDocumentProvider {

	/**
	 * �õ��ĵ���<BR>
	 *
	 * @param element
	 * @return
	 */
	public IDocument getDocument(IEosElement element);

	/**
	 * ����ģ���ĵ���<BR>
	 *
	 * @param model
	 * @return
	 */
	public Map createDocument(IEosModel model);

	/**
	 * �õ��ĵ��ġ�<BR>
	 *
	 * @param model
	 * @return
	 */
	public IFileDelegate getDocumentFile(IEosModel model);

	/**
	 * �����ĵ��ļ���<BR>
	 *
	 * @param model
	 * @return
	 */
	public IFileDelegate createDocumentFile(IEosModel model);
}
