/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal.filter;

import java.util.zip.ZipEntry;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.resources.internal.archive.ArchiveRootFileDelegate;
import com.primeton.studio.runtime.resources.internal.archive.IArchiveResourceFilter;

/**
 * ��������EOS6���е�classesĿ¼<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: BinaryCompositeArchiverResourceFilter.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/06/28 09:17:21  wanglei
 * �ύ��CVS��
 *
 */

public class BinaryCompositeArchiverResourceFilter implements IArchiveResourceFilter {

	private static final BinaryCompositeArchiverResourceFilter instance = new BinaryCompositeArchiverResourceFilter();

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private BinaryCompositeArchiverResourceFilter() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean accept(ArchiveRootFileDelegate rootFile, ZipEntry zipEntry) {
		return !zipEntry.getName().startsWith(RuntimeConstant.CLASSES);
	}

	/**
	 * @return the instance
	 */
	public static BinaryCompositeArchiverResourceFilter getInstance() {
		return instance;
	}

}
