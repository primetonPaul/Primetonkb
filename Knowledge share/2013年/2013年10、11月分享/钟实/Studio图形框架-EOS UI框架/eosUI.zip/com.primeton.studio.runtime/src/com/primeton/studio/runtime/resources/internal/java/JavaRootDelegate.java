/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/java/JavaRootDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-30
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.java;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;

/**
 * ����Java�ļ���Դʵ��IRootDelegate�ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaRootDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/08/08 07:10:58  wanglei
 * Update:����ʵ�����еĹ��ܡ�
 *
 * Revision 1.3  2007/07/12 07:22:19  wanglei
 * Add:����getEOSProjects������
 *
 * Revision 1.2  2007/04/18 08:38:45  wanglei
 * Update:�����еķ������ö�ת����JavaResourceManager��������
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public class JavaRootDelegate extends JavaFolderDelegate implements IRootDelegate {

	List projects = new Vector();

	Map projectMap = new HashMap();

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param file
	 */
	public JavaRootDelegate(File file) {
		super(file);
	}

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param fileName
	 */
	public JavaRootDelegate(String fileName) {
		super(fileName);
	}

	/**
	 * ����һ��EOS��Ŀ��<BR>
	 *
	 * @param project
	 */
	public void addProject(JavaProjectDelegate project) {
		if (null != project) {
			this.projects.add(project);
			this.projectMap.put(project.getName(), project);
		}
	}

	/**
	 * ɾ��һ��EOS��Ŀ��<BR>
	 *
	 * @param project
	 */
	public void removeProject(JavaProjectDelegate project) {
		if (null != project) {
			this.projects.remove(project);
			this.projectMap.remove(project.getName());
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IRootDelegate#getProject(java.lang.String)
	 */
	public IProjectDelegate getProject(String name) {
		return (IProjectDelegate) this.projectMap.get(name);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IRootDelegate#getProjects()
	 */
	public IProjectDelegate[] getProjects() {
		IProjectDelegate[] results = new IProjectDelegate[this.projects.size()];
		this.projects.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IProjectDelegate[] getEOSProjects() {
		return this.getProjects();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.java.JavaFolderDelegate#getType()
	 */
	public int getType() throws ResourceException {
		return ROOT;
	}
}
