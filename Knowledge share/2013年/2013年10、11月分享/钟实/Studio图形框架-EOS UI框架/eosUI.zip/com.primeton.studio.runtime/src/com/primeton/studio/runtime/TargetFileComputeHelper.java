/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/TargetFileComputeHelper.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved. 
 * 
 * Created on 2008-1-30
 *******************************************************************************/


package com.primeton.studio.runtime;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * ������ʱ����������ڷ�EOS��Դ�ļ����ڵ�Ŀ���ļ���<BR>
 * ��:JAVA��JSP�ȡ�<BR>
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: TargetFileComputeHelper.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/01/30 08:49:57  lvyuan
 * Update:����Ŀ���ļ�������
 * 
 */
public class TargetFileComputeHelper {
    
    /**
     * �õ�����ļ���������ļ�����Դ����Ŀ¼��,������IResourceDelegate[0];.
     *
     * @param file the file
     *
     * @return the output resources
     */
    public static IResourceDelegate[] getOutputResources(IFileDelegate file) {
        IResourceDelegate[] target = RuntimeHelper.getOutputResources(file);
        if(ArrayUtils.isEmpty(target)) {
            return getOutputResourcesNEos(file);
        }
        else {
            return target;
        }
    }
    
    /**
     * �õ�����ļ���������ļ�����Դ����Ŀ¼��,������IResourceDelegate[0];.
     *
     * @param file the file
     *
     * @return the output resources
     */
    public static IResourceDelegate[] getOutputResourcesNEos(IFileDelegate file) {
        IContribution contribution = RuntimeManager.createContribution(file);
        if(contribution != null) {
            IFolderDelegate contributionFolder = (IFolderDelegate) contribution.getResource();
            ISourceFolderDelegate sourceFolder = contributionFolder.getSourceFolder();
            // ��õ�ǰcontribution�����Ŀ¼��
            if (null != sourceFolder) {
                contributionFolder = sourceFolder.getOutputFolder();                
                IFolderDelegate parent = file.getParent();   
                if(parent != null) {
                    parent = contributionFolder.getFolder(parent.getSourceRelativePath());
                }
                IResourceDelegate[] allChilds = parent.getChildren();
                return collectionAllTargetFiles(allChilds, file);
            }
        }
       return new IResourceDelegate[0];
    }
    
    
    
    /**
     * �ӱ������ļ������л�ȡ��ӦԴ�ļ���Ŀ���ļ���<BR>
     * 
     * @param allChilds
     * @param file
     * @return
     */
    private static IResourceDelegate[] collectionAllTargetFiles(IResourceDelegate[] allChilds,IFileDelegate file) {
        List<IResourceDelegate> list = new ArrayList<IResourceDelegate>();
        for (int i = 0; i < allChilds.length; i++) {
            IResourceDelegate delegate = allChilds[i];
            if(condition(delegate, file)) {
                list.add(delegate);
            }
        }
        return list.toArray(new IResourceDelegate[0]);
    }
    
    /**
     * �ж�ĳһ�ļ��Ƿ�ΪԴ�ļ��ı����ļ���<BR>
     * 
     * @param allChilds
     * @param file
     * @return
     */
    private static boolean condition(IResourceDelegate someResource,IFileDelegate srcfile) {
        String ext = srcfile.getExtension();
        if(RuntimeConstant.JAVA.equals(ext)) {
            return javaJugde(someResource, srcfile);
        }
        else {
            return defaultJugde(someResource, srcfile);
        }
    }
    
    
    /**
     * �Ƚ��ļ��������Ƿ���ͬ��<BR>
     * 
     * @param someResource
     * @param srcfile
     * @return
     */
    private static boolean defaultJugde(IResourceDelegate someResource,IFileDelegate srcfile) {
        String desName = StringUtils.substringBeforeLast(someResource.getName(), ".");
        String srcName = StringUtils.substringBeforeLast(srcfile.getName(), ".");
        return desName.equals(srcName);
    }
    
    /**
     * �ж��ļ��Ƿ�ΪJAVA�ļ��ı����ļ���<BR>
     * 
     * @param someResource
     * @param srcfile
     * @return
     */
    private static boolean javaJugde(IResourceDelegate someResource,IFileDelegate srcfile) {
        if(someResource instanceof IFileDelegate) {
            IFileDelegate target = (IFileDelegate) someResource; 
            String ext = target.getExtension();
            if(RuntimeConstant.CLASS.equals(ext)) {
                String desName = StringUtils.substringBeforeLast(target.getName(), ".");
                String srcName = StringUtils.substringBeforeLast(srcfile.getName(), ".");
                return desName.equals(srcName) || desName.startsWith(srcName + "$");
            }
        }
        return false;
    }
}
