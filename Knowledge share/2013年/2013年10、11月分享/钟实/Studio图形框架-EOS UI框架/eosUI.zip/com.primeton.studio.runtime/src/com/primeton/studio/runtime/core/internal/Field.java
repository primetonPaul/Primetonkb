/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.core.base.AbstractMember;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ���ݽ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: Field.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2007/06/15 10:01:29  wanglei
 * Update:������Ĭ�Ϲ��캯����
 *
 * Revision 1.4  2007/06/15 09:43:40  wanglei
 * Update:�����˹��캯����
 *
 * Revision 1.3  2007/06/04 07:15:42  wanglei
 * Update:֧�ֱ�ʶ�š�
 *
 * Revision 1.2  2007/04/27 10:07:32  wanglei
 * UnitTest:��Ӧ�ü̳�IField�ӿڡ�
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public class Field extends AbstractMember implements IField {

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param resource
	 * @param parent
	 */
	public Field(IResourceDelegate resource, IEosElement parent, IType type) {
		super(resource, parent, type);
	}

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param type
	 */
	public Field(IType type) {
		super(type);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param type
	 */
	public Field() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public int getElementType() {
		return FIELD;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getMarkCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.getName() == null) ? 0 : this.getName().hashCode());

		return result;
	}

}
