/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/DefaultMethodDocumentProvider.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-5-5
 *******************************************************************************/


package com.primeton.studio.runtime.model.internal;

import org.apache.commons.lang.StringUtils;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IParameter;
import com.primeton.studio.runtime.core.internal.Method;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * ��EOSԪ������EDOC�ļ���<BR>
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultMethodDocumentProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/05/06 06:30:10  lvyuan
 * Update:�ع�EDOC���ɿ��
 *
 * Revision 1.1  2009/05/06 03:48:25  lvyuan
 * Update:��Ӧ������EOS��Դ�Ĺ��ʻ��ṩ֧�֣���ҵ���߼���������ԴҲ������edoc
 * 
 */
public abstract class DefaultMethodDocumentProvider extends DefaultHtmlDocProvider{

	/**
	 * 
	 */
	public DefaultMethodDocumentProvider() {
		super();
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.base.AbstractModelDocumentProvider#getKey(com.primeton.studio.runtime.core.IEosElement)
	 */
	@Override
	public String getKey(IEosElement element) {
		if (element instanceof Method) {//����������ǩ��
			StringBuffer key = new StringBuffer();
			Method method = (Method) element;

			IFileDelegate fileDelegate = (IFileDelegate) method.getResource();
			String path = fileDelegate.getSourceRelativePath();
			path = FilenameUtil.toPackageWithoutExtension(path);

			String methodName = method.getName();
			if(methodName.contains(".")){
				methodName = StringUtils.substringAfterLast(methodName, ".");
			}

			key.append(path + "." + methodName);
			key.append("(");
//			if(Boolean.toString(Boolean.TRUE).equals(method.getExtension(RuntimeConstant.DEFINED_METHOD))){
//			}
			IParameter[] parameters = method.getParameters();
			for (int i = 0; i < parameters.length; i++) {
				IParameter parameter = parameters[i];

				String type = parameter.getDeclaringType().getName();
				if(parameter.getDeclaringType().isArray() && !type.endsWith("[]")){
					type = type + "[]";
				}

				key.append(type);
				if(i < parameters.length - 1)
					key.append(", ");
			}

			key.append(")");

			return key.toString();
		}

		return element.getDisplayName();
	}
	
	@Override
	public int getChildType() {
		return IEosElement.METHOD;
	}
}
