/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/IArchiveProvider.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-11
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import java.io.InputStream;
import java.util.List;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IArchiveProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 * 
 */
public interface IArchiveProvider {
	/**
	 * 
	 * @param element
	 * @return
	 */
	public List getChildren(Object element);
	
	/**
	 * 
	 * @param element
	 * @return
	 */
	public InputStream getContents(Object element);
	/**
	 * 
	 * @param element
	 * @return
	 */
	public String getLabel(Object element);
	/**
	 * 
	 * @param element
	 * @return
	 */
	public String getFullPath(Object element);

	/**
	 * 
	 * @param element
	 * @return
	 */
	public boolean isFolder(Object element);
	/**
	 * 
	 * @param element
	 * @return
	 */
	public Object getParent(Object element);

	
	/**
	 * @return java.util.zip.ZipEntry
	 */
	public Object getRoot();
	
	/**
	 * 
	 * @return
	 */
	public boolean closeArchive();
	/**
	 * 
	 * @param level
	 */
	public void setStrip(int level);
	/**
	 * 
	 * @return
	 */
	public int getStrip();
}