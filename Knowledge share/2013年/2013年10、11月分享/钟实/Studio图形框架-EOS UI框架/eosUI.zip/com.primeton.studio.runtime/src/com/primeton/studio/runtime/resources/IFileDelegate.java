/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/IFileDelegate.java,v
 * 1.1 2007/03/05 11:32:14 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:53 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-25
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources;

import java.io.InputStream;

import com.primeton.studio.runtime.exception.ResourceException;

/**
 * �ļ���Դ�Ĵ����ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IFileDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/09/10 01:12:15  wanglei
 * Review:����ע�͡�
 *
 * Revision 1.3  2007/04/17 09:56:22  wanglei
 * Refactor:��getFile���Ƶ�IResourceDelegate�С�
 *
 * Revision 1.2  2007/03/23 02:34:36  wanglei
 * Add:������getFile���������ز���ϵͳ�ļ���
 * Revision 1.1 2007/03/05 11:32:14 wanglei �ύ��CVS
 *
 */

public interface IFileDelegate extends IResourceDelegate {

	/**
	 * ������չ����<BR>
	 *
	 * Return the extension.<BR>
	 *
	 * @return
	 *
	 */
	public String getExtension();

	/**
	 * �����ļ����ݡ�<BR>
	 *
	 * Set the file content.<BR>
	 *
	 * @param inputStream
	 */
	public void setContents(InputStream inputStream);

	/**
	 * �����ļ���Դ��<BR>
	 * ���������Ϊ <code>null</code>�����൱��create.<BR>
	 *
	 * Create a file with input stream.<BR>
	 * If the input stream is <code>null</code>,this method equals "create".<BR>
	 *
	 * @param inputStream
	 *
	 */
	public void create(InputStream inputStream);

	/**
	 * �����ļ����ݡ�<BR>
	 *
	 * Return the file contents.<BR>
	 *
	 * @param ResourceException
	 * @return
	 *
	 */
	public InputStream getContents() throws ResourceException;



}
