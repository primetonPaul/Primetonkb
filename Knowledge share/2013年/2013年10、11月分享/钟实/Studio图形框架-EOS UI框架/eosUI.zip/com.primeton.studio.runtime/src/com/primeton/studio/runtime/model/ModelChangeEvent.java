/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.workbench.ui/src/com/primeton/studio/workbench/ui/ModelChangeEvent.java,v
 * 1.1 2006/12/31 09:50:51 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2006-12-31
 **********************************************************************************************************************/

package com.primeton.studio.runtime.model;

/**
 * ģ�͸ı�֪ͨ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ModelChangeEvent.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/05/15 07:17:01  wanglei
 * Jira:����EOSP-246��
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/12/07 06:06:32  wanglei
 * Add:������UNKNOWN������
 *
 * Revision 1.3  2007/12/07 05:47:44  wanglei
 * Review:ʹ��delta���ƣ������Ǽ򵥵�ģ�͡�
 *
 * Revision 1.2  2007/05/31 10:16:59  wanglei
 * Add:Ϊ�¼����Ӹ�����Ϣ������Դ���ݣ��ı������ݣ��Լ��ı����Դ�ȡ�
 *
 * Revision 1.1  2007/03/05 11:32:13  wanglei
 * �ύ��CVS
 *
 *
 */
public class ModelChangeEvent {

	public static final int UNKNOWN = 0;

	public static final int ADD = 0x1;

	public static final int REMOVE = 0x2;

	public static final int UPDATE = 0x4;

	private int type;

	private Object source;

	private IResourceDelegateDelta resourceDelta;

	private int buildKind;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public ModelChangeEvent() {
		super();
	}

	/**
	 * ֱ�Ӵ��������<BR>
	 */
	public ModelChangeEvent(int type, Object source, IResourceDelegateDelta resourceDelta) {
		super();
		this.type = type;
		this.source = source;
	}

	/**
	 * @return Returns the source.
	 */
	public Object getSource() {
		return this.source;
	}

	/**
	 * @param source
	 *            The source to set.
	 */
	public void setSource(Object source) {
		this.source = source;
	}

	/**
	 * @return Returns the type.
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * @param type
	 *            The type to set.
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * @return Returns the buildKind.
	 */
	public int getBuildKind() {
		return buildKind;
	}

	/**
	 * @param buildKind The buildKind to set.
	 */
	public void setBuildKind(int buildKind) {
		this.buildKind = buildKind;
	}

	/**
	 * @return the resourceDelta
	 */
	public final IResourceDelegateDelta getResourceDelta() {
		return this.resourceDelta;
	}

	/**
	 * @param resourceDelta the resourceDelta to set
	 */
	public final void setResourceDelta(IResourceDelegateDelta resourceDelta) {
		this.resourceDelta = resourceDelta;
	}
}
