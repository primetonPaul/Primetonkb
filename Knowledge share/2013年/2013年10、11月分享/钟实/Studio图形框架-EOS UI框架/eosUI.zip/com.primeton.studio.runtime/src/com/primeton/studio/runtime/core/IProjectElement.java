/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core;

import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * EOS��ĿԪ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IProjectElement.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/01/07 02:05:29  wanglei
 * Add:����getLibraryContributions������
 *
 * Revision 1.1  2008/01/07 02:03:34  wanglei
 * Add:�ύ��CVS��
 *
 */

public interface IProjectElement extends IModule {

	/**
	 * �õ���Ŀ��Դ��<BR>
	 *
	 * @return
	 */
	public IProjectDelegate getProject();

	/**
	 * �õ����õ�Contribution��<BR>
	 *
	 * @return
	 */
	public IContribution[] getLibraryContributions();

}
