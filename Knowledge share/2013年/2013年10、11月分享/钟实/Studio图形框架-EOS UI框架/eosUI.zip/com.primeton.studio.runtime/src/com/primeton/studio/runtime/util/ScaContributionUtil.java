/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/util/ScaContributionUtil.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-8-6
 *******************************************************************************/

package com.primeton.studio.runtime.util;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.eos.system.utility.FilenameUtil;
import com.eos.system.utility.StringUtil;
import com.eos.system.utility.XmlUtil;
import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.exception.XmlUtilException;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseFileDelegate;

/**
 * �޸�sca-contribution.xml�ļ��Ĺ�����
 *
 * @author zhangzh (mailto:zhangzh@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ScaContributionUtil.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/07/16 05:56:00  hongsq
 * Update:�޸�scacontributionʱ�����Ƿ����ļ�顣
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.12  2008/04/17 12:43:52  wanglei
 * Review:�ر�û�йص�����
 *
 * Revision 1.11  2008/04/17 12:00:09  wanglei
 * Review:��ȥ���õķ�����
 *
 * Revision 1.10  2008/04/17 11:58:52  wanglei
 * Review:�ر�û�йص�����
 *
 * Revision 1.9  2008/04/14 07:33:12  wanglei
 * Update:��ȡͨ�÷�����ResourceHelper�С�
 *
 * Revision 1.8  2007/12/22 01:51:59  wanglei
 * Review:��CompositeUtil������ΪContributionUtil����SCA�����һ�¡�
 *
 * Revision 1.7  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.6  2007/12/19 01:00:55  chenxp
 * Update:ɾ������װ��ͼʱ����ns�Ķ���
 *
 * Revision 1.5  2007/12/04 09:32:50  chenxp
 * UnitTest:fix a bug.
 *
 * Revision 1.4  2007/10/08 07:56:19  zhangzh
 * Review:���ӷ���
 *
 * Revision 1.3  2007/09/19 05:52:42  zhangzh
 * UnitTest:�޸Ĳ���Composite�ļ�bug.
 *
 * Revision 1.2  2007/08/27 06:33:05  zhangzh
 * review:���ӹ��߷�����
 *
 * Revision 1.1  2007/08/17 08:58:53  zhangzh
 * updata:�ع�
 *
 * Revision 1.2  2007/08/06 03:11:14  zhangzh
 * add:�ع�
 *
 * Revision 1.1  2007/08/06 02:18:24  zhangzh
 * add:commit cvs
 *
 */
public class ScaContributionUtil {

	private static final String IMPORT = "import";

	public final static int FLAG_RMV = 1;

	public final static int FLAG_ADD = 0;

	private static final String NAMESPACE = "namespace";

	private static final String EXPORT = "export";

	private static final String CONTRIBUTION = "contribution";

	private static final String COMPOSITE = "composite";

	private static final String DEPLOYABLE = "deployable";

	/**
	 * ˽�й��췽��
	 *
	 */
	private ScaContributionUtil() {

	}

	private static String getXmlString(Document document, String childNode, String attributionName, String[] attributionValue, int flag) {
		Element contributionNode = getContributionNode(document);
		if (null != contributionNode) {
			if (flag == FLAG_ADD) {
				addChildNode(contributionNode, childNode, attributionName, attributionValue, document);
			}
			if (flag == FLAG_RMV) {
				removeChildNode(contributionNode, childNode, attributionName, attributionValue);
			}
			return XmlUtil.node2String(document, true, true);
		}
		else {
			document = XmlUtil.newDocument();
			contributionNode = document.createElement(CONTRIBUTION);
			document.appendChild(contributionNode);
			if (null != contributionNode) {
				if (flag == FLAG_ADD) {
					addChildNode(contributionNode, childNode, attributionName, attributionValue, document);
				}
				return XmlUtil.node2String(document, true, true);
			}
		}
		return null;
	}

	/**
	 * ����Dom������String��
	 * @param scaxml
	 * @param childNode �ӽڵ�����
	 * @param attributionName���ӽڵ�������
	 * @param attributionValue���ӽڵ�������
	 * @param flag�����ӽڵ��ɾ���ڵ㡡FLAG_RMV||FLAG_ADD
	 * @return
	 */
	private static String getXmlString(IFileDelegate scaxml, String childNode, String attributionName, String[] attributionValue, int flag) {
		if (null == scaxml) {
			throw new XmlUtilException("file is Null");
		}

		InputStream inputStream = null;
		try {
			inputStream = scaxml.getContents();
			Document document = XmlUtil.parseStream(inputStream);
			return getXmlString(document, childNode, attributionName, attributionValue, flag);
		} catch (XmlUtilException e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
		return null;
	}

	private static Element getContributionNode(Document document) {
		Element contributionNode = (Element) XmlUtil.findNode(document, CONTRIBUTION);
		return contributionNode;

	}

	/**
	 * ɾ��ָ��һ��namespace��Export�ڵ�.
	 * @param scaxml
	 * @param namespace
	 */
	public static void removeExportNode(IFileDelegate scaxml, String namespace) {
		String content = getXmlString(scaxml, EXPORT, NAMESPACE, new String[] {
			namespace
		}, FLAG_RMV);
		writeFile(scaxml, content);
	}

	/**
	 * ɾ��ָ��һ��namespace��import�ڵ�
	 * @param scaxml
	 * @param namespace
	 */
	public static void removeImportNode(IFileDelegate scaxml, String namespace) {
		String content = getXmlString(scaxml, IMPORT, NAMESPACE, new String[] {
			namespace
		}, FLAG_RMV);
		writeFile(scaxml, content);
	}

	/**
	 * ����ָ��namespace��import�ڵ�
	 * @param scaxml
	 * @param namespace
	 */
	public static void addImportNode(IFileDelegate scaxml, String[] namespace) {
		String content = getXmlString(scaxml, IMPORT, NAMESPACE, namespace, FLAG_ADD);
		writeFile(scaxml, content);
	}

	/**
	 * ɾ��ָ��һ��namespace��import�ڵ�
	 * @param scaxml
	 * @param namespace
	 */
	public static void removeImportNode(IFileDelegate scaxml, String[] namespace) {
		String content = getXmlString(scaxml, IMPORT, NAMESPACE, namespace, FLAG_RMV);
		writeFile(scaxml, content);
	}

	/**
	 * ����ָ��namespace��import�ڵ�
	 * @param scaxml
	 * @param namespace
	 */
	public static void addImportNode(IFileDelegate scaxml, String namespace) {
		String content = getXmlString(scaxml, IMPORT, NAMESPACE, new String[] {
			namespace
		}, FLAG_ADD);
		writeFile(scaxml, content);
	}

	/**
	 * ����ָ��namespace��Export�ڵ�.
	 * @param scaxml
	 * @param namespace
	 */
	public static void addExportNode(IFileDelegate scaxml, String namespace) {
		String content = getXmlString(scaxml, EXPORT, NAMESPACE, new String[] {
			namespace
		}, FLAG_ADD);
		writeFile(scaxml, content);
	}

	/**
	 * ɾ��ָ��path��Deployable�ڵ�
	 * @param scaxml
	 * @param compositePath
	 */
	public static void removeDeployableNode(IFileDelegate scaxml, String compositePath) {
		String content = getXmlString(scaxml, DEPLOYABLE, COMPOSITE, new String[] {
			compositePath
		}, FLAG_RMV);
		writeFile(scaxml, content);
	}

	/**
	 * ��Xml�ַ���д���ļ�sca_contribution.xml�ļ�.
	 * @param scafile
	 * @param content
	 */
	private static void writeFile(IFileDelegate scafile, String content) {

		try {
			if(ResourceHelper.checkFiles(new IFile[]{(IFile) scafile.getAdapter(IFile.class)}))
				ResourceHelper.write(scafile, content, IConstant.UTF8);
		} catch (UnsupportedEncodingException e) {
			//Nothing to do
		}
	}

	/**
	 *  �����ӽڵ�
	 * @param parentNode
	 * @param childNode
	 * @param attributionName
	 * @param attributionValue
	 * @param document
	 */
	private static void addChildNode(Element parentNode, String childNode, String attributionName, String[] attributionValue, Document document) {
		NodeList nodes = parentNode.getElementsByTagName(childNode);
		for (int i = 0; i < nodes.getLength(); i++) {
			Node node = nodes.item(i);
			String value = XmlUtil.getAttributeValue(node, attributionName);
			if (StringUtil.isIn(value, attributionValue, true)) {
				return;
			}
		}
		if (!ArrayUtils.isEmpty(attributionValue) && StringUtils.isNotEmpty(childNode)) {
			for (int i = 0; i < attributionValue.length; i++) {
				Element appendNode = document.createElement(childNode);
				XmlUtil.setAttribute(appendNode, attributionName, attributionValue[i]);
				if (null != appendNode) {
					parentNode.appendChild(appendNode);
				}
			}
		}
	}

	/**
	 * ɾ���ӽڵ�
	 * @param parentNode
	 * @param childNode
	 * @param attributionName
	 * @param attributionValue
	 */
	private static void removeChildNode(Element parentNode, String childNode, String attributionName, String[] attributionValue) {
		NodeList nodes = parentNode.getElementsByTagName(childNode);
		if (null != nodes) {
			Map allNSPrefix = new HashMap();
			Map nsToBeRemoved = new HashMap();
			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				String value = XmlUtil.getAttributeValue(node, attributionName);
				String path = StringUtils.substringAfterLast(value, ":");
				String localPart = StringUtils.substringBeforeLast(value, ":");
				if (allNSPrefix.get(localPart) == null) {
					allNSPrefix.put(localPart, new Integer(1));
				}
				else {
					Integer count = (Integer) allNSPrefix.get(localPart);
					allNSPrefix.put(localPart, new Integer(count.intValue() + 1));
				}

				if (StringUtil.isIn(path, attributionValue, true) && StringUtils.isNotEmpty(localPart)) {
					//removeNSDeclaration(parentNode, localPart);
					nsToBeRemoved.put(localPart, null);
					parentNode.removeChild(node);
				}
			}
			//�������ƿռ�ǰ׺�Ķ���
			Iterator removedNS = nsToBeRemoved.entrySet().iterator();
			while (removedNS.hasNext()) {
				Map.Entry entry = (Map.Entry) removedNS.next();
				Integer count = (Integer) allNSPrefix.get(entry.getKey());
				if (count.intValue() <= 1) {
					//����ns�Ķ���
					//removeNSDeclaration(parentNode, (String)entry.getKey());
				}
			}
		}
	}

	/**
	 * �õ����в���·��
	 *
	 * @param scaxml
	 * @return
	 */
	public static List getDeployCompositePaths(IFileDelegate scaxml) {
		if (null == scaxml) {
			throw new XmlUtilException("file doesn't exist!");
		}
		Document document = XmlUtil.parseStream(scaxml.getContents());
		Element contributionNode = (Element) XmlUtil.findNode(document, CONTRIBUTION);
		List compositeList = new ArrayList();
		if (null != contributionNode) {
			NodeList nodes = contributionNode.getChildNodes();
			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				if (node.getNodeName().equals(DEPLOYABLE)) {
					String compositePath = XmlUtil.getAttributeValue(node, COMPOSITE);

					if (null != compositePath) {
						compositeList.add(FilenameUtils.removeExtension(compositePath));
					}
				}
			}
			return compositeList;
		}
		return null;
	}

	/**
	 * �õ����е��������ƿռ�
	 * @param scaxml
	 * @return
	 */
	public static String[] getExportNS(IFileDelegate scaxml) {
		if (null == scaxml) {
			throw new XmlUtilException("file doesn't exist!");
		}

		InputStream inputStream = null;

		try {
			inputStream = scaxml.getContents();
			Document document = XmlUtil.parseStream(scaxml.getContents());
			Element contributionNode = (Element) XmlUtil.findNode(document, CONTRIBUTION);
			if (contributionNode == null) {
				return new String[0];
			}
			NodeList exportList = contributionNode.getElementsByTagName(EXPORT);
			List namespace = new ArrayList();
			for (int i = 0; i < exportList.getLength(); i++) {
				Node node = exportList.item(i);
				namespace.add(XmlUtil.getAttributeValue(node, NAMESPACE));

			}
			return (String[]) namespace.toArray(new String[namespace.size()]);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	/**
	 * �õ����в����CompsoiteFiles
	 *
	 * @param scaxml
	 * @return
	 */
	public static List getDeployableCompositeFiles(IFileDelegate scaxml) {
		List compositePath = getDeployCompositePaths(scaxml);
		List composite = new ArrayList();
		IResourceDelegate[] resourceDelegate = ResourceHelper.getAllResources(scaxml.getSourceFolder(), null, IResourceDelegate.FILE);
		for (int j = 0; j < resourceDelegate.length; j++) {
			IFileDelegate fileDelegate = (IFileDelegate) resourceDelegate[j];
			if ((compositePath.contains(FilenameUtil.toPackageWithoutExtension(fileDelegate.getSourceRelativePath())) && (fileDelegate.getExtension().equals(COMPOSITE)))) {
				composite.add(fileDelegate);
			}
		}
		return composite;
	}

	/**
	 * �ж�һ��Composite�ļ��Ƿ񵼳�
	 * @param scaxml
	 * @param namespace
	 * @return
	 */
	public static boolean isExport(IFileDelegate scaxml, String namespace) {
		if (!ResourceHelper.isValidResource(scaxml)) {
			throw new XmlUtilException("file doesn't exist!");
		}

		InputStream inputStream = null;

		try {
			inputStream = scaxml.getContents();
			Document document = XmlUtil.parseStream(scaxml.getContents());
			Element contributionNode = (Element) XmlUtil.findNode(document, CONTRIBUTION);
			if (contributionNode == null) {
				return false;
			}
			NodeList exportList = contributionNode.getElementsByTagName(EXPORT);
			for (int i = 0; i < exportList.getLength(); i++) {
				Node node = exportList.item(i);
				if (namespace.equals(XmlUtil.getAttributeValue(node, NAMESPACE))) {
					return true;
				}
			}
		} catch (Exception e) {
			//Nothing to do
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

		return false;
	}

	/**
	 * �ж�һ��Composite�ļ��Ƿ���
	 * @param scaxml
	 * @param namespace
	 * @return
	 */
	public static boolean isDeployable(IFileDelegate scaxml, String path) {
		if (null == scaxml) {
			throw new XmlUtilException("file doesn't exist!");
		}

		InputStream inputStream = null;

		try {
			inputStream = scaxml.getContents();
			Document document = XmlUtil.parseStream(inputStream);
			Element contributionNode = (Element) XmlUtil.findNode(document, CONTRIBUTION);
			if (contributionNode == null) {
				return false;
			}
			NodeList deployList = contributionNode.getElementsByTagName(DEPLOYABLE);
			for (int i = 0; i < deployList.getLength(); i++) {
				Node node = deployList.item(i);
				String deployablePath = StringUtils.substringAfterLast(XmlUtil.getAttributeValue(node, COMPOSITE), ":");
				if (path.equals(deployablePath)) {
					return true;
				}
			}

		} catch (Exception e) {
			// Nothing to do
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

		return false;

	}

	public static IFileDelegate getScaFileDelegate(IResource resource) {
		IFile scafile = ContributionUtil.getSCAContributionXmlFile(resource);
		return new EclipseFileDelegate(scafile);

	}

}
