/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/cache/impl/LRUMemCache.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2010-6-21
 *******************************************************************************/


package com.primeton.studio.runtime.cache.impl;

import org.apache.commons.collections.map.LRUMap;

import com.primeton.studio.runtime.cache.ICache;

/**
 * LRUMap���ݽṹ����洢
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: LRUMemCache.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/06/24 09:17:56  hongsq
 * Update:jira EOSP-286
 *
 */
public class LRUMemCache implements ICache{

	private Object cacheId;
	private LRUMap cache;

	/**
	 * LRUMap�洢����
	 * @param cacheId cache��Ψһ��ʶ
	 * @param maxSize ��󻺴�������
	 */
	public LRUMemCache(Object cacheId, int maxSize) {
		this.cacheId = cacheId;
		this.cache = new LRUMap(maxSize);
	}

	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.cache.ICache#clear()
	 */
	public void clear() {
		cache.clear();
	}

	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.cache.ICache#getCacheId()
	 */
	public Object getCacheId() {
		return cacheId;
	}

	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.cache.ICache#put(java.lang.Object, java.lang.Object)
	 */
	public void put(Object objId, Object objValue) {
		cache.put(objId, objValue);
	}

	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.cache.ICache#remove(java.lang.Object)
	 */
	public void remove(Object objId) {
		cache.remove(objId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.cache.ICache#size()
	 */
	public int size() {
		return cache.size();
	}

	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.cache.ICache#get(java.lang.Object)
	 */
	public Object get(Object objId) {
		return cache.get(objId);
	}

	public boolean contains(Object objId) {
		return this.cache.containsKey(objId);
	}
}
