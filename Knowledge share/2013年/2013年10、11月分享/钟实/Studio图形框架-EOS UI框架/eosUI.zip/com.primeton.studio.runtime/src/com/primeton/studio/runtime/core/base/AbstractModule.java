/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.base;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IModule;
import com.primeton.studio.runtime.core.internal.Contribution;
import com.primeton.studio.runtime.core.internal.Module;
import com.primeton.studio.runtime.exception.EosModelException;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;
import com.primeton.studio.runtime.validator.internal.ContributionValidator;
import com.primeton.studio.runtime.validator.internal.ModuleValidator;

/**
 * ģ��ĳ����࣬��ΪProject��Module���ƣ������ṩһ�����ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractModule.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/04/09 06:52:56  wanglei
 * Review:֧��FAT������
 *
 * Revision 1.5  2008/04/07 12:04:49  wanglei
 * Update:�̶�ֻʹ��NTFS֮�����Դʱ���,������Դ���ӻ���ɾ��ʱ���Ը��¸�Ŀ¼��ʱ�����
 *
 * Revision 1.4  2008/04/03 08:31:24  wanglei
 * UnitTest:����û����ȷ����ѭ���������ɶ��Contribution���ظ�������Bug��
 *
 * Revision 1.3  2008/01/23 08:12:11  wanglei
 * Review:��ΪModule�����Ŀ¼�ı�ʱ��Ҫˢ�µ�ǰModule�����к��ӣ����ܸ���ʱ������жϣ�������Ϊ������Ч��
 *
 * Revision 1.2  2008/01/09 01:19:07  wanglei
 * Review:�ع��ײ�ģ�ͣ���ԭ�д���Դ�������������getModelFactory������ȥ��
 *
 * Revision 1.1  2008/01/07 05:50:01  wanglei
 * Add:�ύ��CVS��
 *
 */

public abstract class AbstractModule extends AbstractContainerElement implements IModule {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param folder
	 * @param parent
	 */
	public AbstractModule(IFolderDelegate folder, IEosElement parent) {
		super(folder, parent);
	}

	/**
	 * {@inheritDoc}
	 */
	public IContribution[] getContributions() {
		Collection col = this.getChildrenOfType(CONTRIBUTION);
		IContribution[] results = new IContribution[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IModule[] getModules() {
		Collection col = this.getChildrenOfType(MODULE);
		IModule[] results = new IModule[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	protected IResourceDelegate[] getChildrenResources() {
		IFolderDelegate rootFolder = this.getFolder();

		IFolderDelegate[] folders = ResourceHelper.getFolders(rootFolder, (String[]) null);
		List list = new ArrayList(5);
		List modules = new ArrayList(5);

		for (int i = 0; i < folders.length; i++) {
			IFolderDelegate folder = folders[i];

			if (ModuleValidator.INSTANCE.validate(folder, null, null)) {
				modules.add(folder);
				list.add(folder);
				continue;
			}
			//��.eos�ļ���ʶΪmodule��Ŀ¼ת��Module�������б�
		}

		ISourceFolderDelegate[] sourceFolders = ResourceHelper.getSourceFolders(rootFolder);
		for (int i = 0; i < sourceFolders.length; i++) {
			ISourceFolderDelegate sourceFolder = sourceFolders[i];

			if (modules.size() == 0) {
				if (ContributionValidator.INSTANCE.validate(sourceFolder, null, null)) {
					list.add(sourceFolder);
				}
			}
			else {

				boolean founded = false;

				for (int j = 0; j < modules.size(); j++) {
					IFolderDelegate moduleFolder = (IFolderDelegate) modules.get(j);

					if (moduleFolder.isPrefixOf(sourceFolder)) {
						founded = true;
						break;
					}
				}

				if (!founded) {
					if (ContributionValidator.INSTANCE.validate(sourceFolder, null, null)) {
						list.add(sourceFolder);
					}
					//��.eos�ļ���ʶΪcontribution��Ŀ¼ת��contribution�������б�
				}
			}
		}

		IResourceDelegate[] results = new IResourceDelegate[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	protected IEosElement loadChild(IResourceDelegate childResource) {

		if (childResource.getType() != IResourceDelegate.FOLDER) {
			return null;
		}

		if (childResource instanceof ISourceFolderDelegate) {
			if (ContributionValidator.INSTANCE.validate(childResource, null, null)) {
				return new Contribution((ISourceFolderDelegate) childResource, this);
			}
		}

		IFolderDelegate folder = (IFolderDelegate) childResource;
		if (ModuleValidator.INSTANCE.validate(folder, null, null)) {
			IModule module = new Module(folder, this);
			return module;
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosElement[] doLoadChildren(IEosElement[] oldChildren) throws EosModelException {

		IFolderDelegate rootFolder = this.getFolder();

		IFolderDelegate[] folders = ResourceHelper.getFolders(rootFolder, (String[]) null);
		List list = new ArrayList(5);
		List modules = new ArrayList(5);

		for (int i = 0; i < folders.length; i++) {
			IFolderDelegate folder = folders[i];

			if (ModuleValidator.INSTANCE.validate(folder, null, null)) {
				IModule module = new Module(folder, this);
				list.add(module);
				modules.add(folder);
				continue;
			}
			//��.eos�ļ���ʶΪmodule��Ŀ¼ת��Module�������б�
		}

		ISourceFolderDelegate[] sourceFolders = ResourceHelper.getSourceFolders(rootFolder);
		for (int i = 0; i < sourceFolders.length; i++) {
			ISourceFolderDelegate sourceFolder = sourceFolders[i];

			if (modules.size() == 0) {
				if (ContributionValidator.INSTANCE.validate(sourceFolder, null, null)) {
					IContribution contribution = new Contribution(sourceFolder, this);
					list.add(contribution);
				}

			}
			else {

				boolean founded = false;

				for (int j = 0; j < modules.size(); j++) {
					IFolderDelegate moduleFolder = (IFolderDelegate) modules.get(j);

					if (moduleFolder.isPrefixOf(sourceFolder)) {
						founded = true;
						break;
					}
				}

				if (!founded) {
					if (ContributionValidator.INSTANCE.validate(sourceFolder, null, null)) {
						IContribution contribution = new Contribution(sourceFolder, this);
						list.add(contribution);
					}
					//��.eos�ļ���ʶΪcontribution��Ŀ¼ת��contribution�������б�
				}
			}
		}

		IEosElement[] results = new IEosElement[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isBinary() {
		return false;
	}
}
