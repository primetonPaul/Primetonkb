/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/eclipse/EclipseFileDelegate.java,v
 * 1.1 2007/03/05 11:32:14 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-29
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.eclipse;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * Eclipse�ļ���Դ�ķ�װ
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EclipseFileDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/07/15 06:50:51  wanglei
 * Update:֧����û���ļ����ڵ�����£��´����ļ���
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2007/09/10 01:12:36  wanglei
 * Review:����equals��hashCode������
 *
 * Revision 1.7  2007/09/06 06:41:21  wanglei
 * Remove:getFile�Ѿ���EclipseResourceDelegateʵ���ˡ�
 *
 * Revision 1.6  2007/08/28 08:10:47  wanglei
 * UnitTest:���������ļ�ʱ�Ĵ���
 *
 * Revision 1.5  2007/08/27 08:47:54  wanglei
 * UnitTest:���������ļ�ʱ��Ϊ�ϼ�Ŀ¼�����ڶ�������Bug��
 *
 * Revision 1.4  2007/04/24 05:28:22  wanglei
 * UnitTest:������getAdapter�з���File����IFile��Bug��
 *
 * Revision 1.3  2007/03/30 02:19:24  wanglei
 * Remove:ȥ����Ԫ���ݷ�����
 *
 * Revision 1.2  2007/03/23 02:34:36  wanglei
 * Add:������getFile���������ز���ϵͳ�ļ���
 * Revision 1.1 2007/03/05 11:32:14 wanglei �ύ��CVS
 *
 */

public class EclipseFileDelegate extends EclipseResourceDelegate implements IFileDelegate {

	/**
	 * ֱ�Ӵ���Eclipse��Դ�Թ������<BR>
	 */
	public EclipseFileDelegate(IFile file) {
		super(file);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#getContents()
	 */
	public InputStream getContents() {
		try {
			return this.getEclipseFile().getContents(true);
		} catch (CoreException e) {
			throw new ResourceException(e);
		}
	}

	/**
	 *
	 * @return ����Eclipse�ļ���
	 */
	public IFile getEclipseFile() {
		return (IFile) this.getResource();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#getExtension()
	 */
	public String getExtension() {
		return this.getEclipseFile().getFileExtension();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#create(java.io.InputStream)
	 */
	public void create(InputStream inputStream) {
		try {

			IFile file = this.getEclipseFile();
			IContainer container = file.getParent();
			if (container.getType() == IResource.FOLDER) {
				EclipseResourceManager.forceCreateFolder((IFolder) container);
			}

			this.getEclipseFile().create(inputStream, true, null);

		} catch (CoreException e) {
			throw new ResourceException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#setContents(java.io.InputStream)
	 */
	public void setContents(InputStream inputStream) {
		try {

			if (this.getEclipseFile().exists()) {
				this.getEclipseFile().setContents(inputStream, true, true, null);
			} else {
				this.create(inputStream);
			}
		} catch (CoreException e) {
			throw new ResourceException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#create()
	 */
	public void create() {
		this.create(new ByteArrayInputStream(new byte[0]));
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceDelegate#getAdapter(java.lang.Class)
	 */
	public Object getAdapter(Class adapter) {
		if (IFile.class == adapter) {
			return this.getEclipseFile();
		}

		return super.getAdapter(adapter);
	}

}
