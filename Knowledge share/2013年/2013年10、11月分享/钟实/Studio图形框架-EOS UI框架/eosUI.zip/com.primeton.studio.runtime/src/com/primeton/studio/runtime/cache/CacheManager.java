/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/cache/CacheManager.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2010-6-21
 *******************************************************************************/


package com.primeton.studio.runtime.cache;

import com.primeton.platform.Kernel;


/**
 * Cache������
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: CacheManager.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/06/24 09:17:56  hongsq
 * Update:jira EOSP-286
 *
 */
public final class CacheManager {
	private static final CacheManager INSTANCE = new CacheManager();

	private final Object rootCacheId = new Object();

	private ICache rootCache = null;

	private ICacheFactory cacheFactory;
	/**
	 * ����Ψһ��ʵ��
	 * @return
	 */
	public static CacheManager getInstance(){
		return INSTANCE;
	}

	/**
	 *
	 */
	private CacheManager() {
		super();

//		User can use his ICacheFactory instead of SimpleCacheFactory.
		this.cacheFactory = (ICacheFactory) Kernel.getServiceManager().findService(ICacheFactory.class, null, null, null);
		if(this.cacheFactory == null){
			this.cacheFactory = new SimpleCacheFactory();
		}
	}

	/**
	 *
	 * ��ȡһ��Cacheʵ��
	 * @param cacheId cacheΨһ��ʶ
	 * @param createNew <li><code>true</code>���û���ҵ�ָ����Cache����һ���µ�Cache</li>
	 * 					<li><code>false</code>���û���ҵ�ָ����Cache�ͷ���null</li>
	 * @return
	 */
	public ICache getCache(Object cacheId, boolean createNew){
		checkRootCache();
		synchronized (rootCache) {
			Object cache = rootCache.get(cacheId);
			if(cache == null && createNew){
				cache = this.cacheFactory.createCache(cacheId);
				rootCache.put(cacheId, cache);
			}
			return (ICache) cache;
		}
	}

	/**
	 *
	 */
	private synchronized void checkRootCache() {
		if(rootCache == null){
			rootCache = this.cacheFactory.createCache(rootCacheId);
		}
	}
}
