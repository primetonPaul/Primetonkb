/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/SeparatorModel.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: SeparatorModel.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:45  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class SeparatorModel {
	
	private SeparatorModel backSeparatorModel;
	private Object thisModel;
	/**
	 * 
	 * @param backSeparatorModel
	 * @param thisModel
	 */
	public SeparatorModel(SeparatorModel backSeparatorModel,Object thisModel) {
		this.backSeparatorModel = backSeparatorModel;
		this.thisModel = thisModel;
	}
	/**
	 * @return Returns the backSeparatorModel.
	 */
	public SeparatorModel getBackSeparatorModel() {
		return backSeparatorModel;
	}
	/**
	 * @param backSeparatorModel The backSeparatorModel to set.
	 */
	public void setBackSeparatorModel(SeparatorModel backSeparatorModel) {
		this.backSeparatorModel = backSeparatorModel;
	}
	/**
	 * @return Returns the thisModel.
	 */
	public Object getThisModel() {
		return thisModel;
	}
	/**
	 * @param thisModel The thisModel to set.
	 */
	public void setThisModel(Object thisModel) {
		this.thisModel = thisModel;
	}
}
