/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/util/MethodParamHelper.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-2-22
 *******************************************************************************/


package com.primeton.studio.runtime.util;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import xjavadoc.XClass;
import xjavadoc.XExecutableMember;
import xjavadoc.XParameter;

import com.eos.system.utility.ClassUtil;
import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.util.GenericUtil;
import com.sun.org.apache.bcel.internal.Constants;
import com.sun.org.apache.bcel.internal.Repository;
import com.sun.org.apache.bcel.internal.classfile.ClassParser;
import com.sun.org.apache.bcel.internal.classfile.LocalVariable;
import com.sun.org.apache.bcel.internal.classfile.LocalVariableTable;
import com.sun.org.apache.bcel.internal.classfile.Utility;
import com.sun.org.apache.bcel.internal.generic.Type;

/**
 * ������������������
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: MethodParamHelper.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/04/16 07:51:43  chenxp
 * BUG: 25754
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2008/04/22 11:28:12  yangmd
 * Update:�޸��ڲ�������⡣
 *
 * Revision 1.4  2008/02/28 09:34:45  yangmd
 * Update:ȥ�����Դ���
 *
 * Revision 1.3  2008/02/26 08:43:30  yangmd
 * Update:�޸Ĳ��ܼ������bug
 *
 * Revision 1.2  2008/02/26 08:17:07  yangmd
 * Update:�޸Ĳ��ܼ������bug
 *
 * Revision 1.1  2008/02/22 09:27:04  yangmd
 * Add:�ṩ�������������İ�����
 * 
 */
public class MethodParamHelper {
	
	
	public static final Param[] EMPTY_PARAM = new Param[0];

	/**
	 * ���캯��˽��
	 */
	private MethodParamHelper() {
		//doNothing
	}

	/**
	 * �ж�����Method�Ƿ����
	 * 
	 * @param javaMethod
	 * @param bcelMethod
	 * @return
	 */
	public static boolean methodEquals(Method javaMethod, com.sun.org.apache.bcel.internal.classfile.Method bcelMethod){
		if(javaMethod.getName().equals(bcelMethod.getName())){

			Class<?>[] paramClazzs = javaMethod.getParameterTypes();

			Class<?> returnClazz = javaMethod.getReturnType();
			
			Type[] paramTypes = new Type[paramClazzs.length];
			
			for (int i = 0; i < paramClazzs.length; i++) {
				String tempSig = paramClazzs[i].getCanonicalName();
				String sigName = Utility.getSignature(tempSig);
				paramTypes[i] = Type.getType(sigName);
			}
			
			String sigName = Utility.getSignature(returnClazz.getCanonicalName());
			
			Type returnType = Type.getType(sigName);
			
			String javaMethodSig = Type.getMethodSignature(returnType, paramTypes);
			
			String bcelMethodSig = bcelMethod.getSignature();
			bcelMethodSig = bcelMethodSig.replace('$', '/');
			if(javaMethodSig.equals(bcelMethodSig)){
				return true;
			}
		}
		return false;
	}
	
	public static boolean methodEquals(Constructor javaMethod, com.sun.org.apache.bcel.internal.classfile.Method bcelMethod){
		if(Constants.CONSTRUCTOR_NAME.equals(bcelMethod.getName())){	
			Class<?>[] paramClazzs = javaMethod.getParameterTypes();
			
			Type[] paramTypes = new Type[paramClazzs.length];
			
			for (int i = 0; i < paramClazzs.length; i++) {
				String tempSig = paramClazzs[i].getCanonicalName();
				String sigName = Utility.getSignature(tempSig);
				paramTypes[i] = Type.getType(sigName);
			}
			
			String javaMethodSig = Type.getMethodSignature(Type.VOID, paramTypes);
			
			String bcelMethodSig = bcelMethod.getSignature();
			
			if(javaMethodSig.equals(bcelMethodSig)){
				return true;
			}
		}
		return false;
	}
	/**
	 * ��ȡ�����б�
	 * @param jdkMethod
	 * @return
	 */
	public static Param[] getParams(Constructor jdkMethod){
		Class declaringClazz = jdkMethod.getDeclaringClass();
		String name = declaringClazz.getCanonicalName();
		com.sun.org.apache.bcel.internal.classfile.JavaClass javaClass = Repository.lookupClass(
				name);
		name = name.replace('/', '.');
		if(javaClass == null){
			name = name.replace('/', '.');
			InputStream is = null;
			try {
				is = declaringClazz.getResourceAsStream(declaringClazz.getSimpleName()+".class");
				ClassParser classParser = new ClassParser(is,name);
				javaClass = classParser.parse();
				Repository.addClass(javaClass);
			} catch (IOException e) {
				//should not happen
			} finally {
				if(is != null){
					IOUtils.closeQuietly(is);
				}
			}
		}
		com.sun.org.apache.bcel.internal.classfile.Method[] methods = javaClass.getMethods();
		
		for (int i = 0; i < methods.length; i++) {
			com.sun.org.apache.bcel.internal.classfile.Method tempMethod = methods[i];
			if(methodEquals(jdkMethod, tempMethod)){
				return getParams(tempMethod,jdkMethod);
			}
		}
		return EMPTY_PARAM;
	}
	/**
	 * ��ȡ�����б�
	 * @param jdkMethod
	 * @return
	 */
	public static Param[] getParams(Method jdkMethod){
		Class declaringClazz = jdkMethod.getDeclaringClass();
		String name = declaringClazz.getCanonicalName();
		com.sun.org.apache.bcel.internal.classfile.JavaClass javaClass = Repository.lookupClass(
				name);
		if(javaClass == null){
			name = name.replace('/', '.');
			InputStream is = null;
			try {
				is = declaringClazz.getResourceAsStream(declaringClazz.getSimpleName() + ".class");
				ClassParser classParser = new ClassParser(is,name);
				javaClass = classParser.parse();
				Repository.addClass(javaClass);
			} catch (IOException e) {
				//should not happen
			} finally {
				if(is != null){
					IOUtils.closeQuietly(is);
				}
			}
		}
		com.sun.org.apache.bcel.internal.classfile.Method[] methods = javaClass.getMethods();
		
		for (int i = 0; i < methods.length; i++) {
			com.sun.org.apache.bcel.internal.classfile.Method tempMethod = methods[i];
			if(methodEquals(jdkMethod, tempMethod)){
				return getParams(tempMethod,jdkMethod);
			}
		}
		return EMPTY_PARAM;
	}
	
	/**
	 * ͨ��XClassԴ��;����ȡ��������.
	 * @param jdkMethod
	 * @param xClazz
	 * @return
	 */
	public static Param[] getParams(Method method, XClass xClazz){
		//add by yangmd 2010-04-15 ���Ӵ˷�������Դ���л�ȡ��Ӧ�ķ�������ȡ�����������.
		List methods = xClazz.getMethods(true);
		XExecutableMember xmethod = null;
		
		String signature = getNameWithSignature(method);
		
		for (Iterator iter = methods.iterator(); iter.hasNext();) {
			XExecutableMember xmethodtemp = (XExecutableMember) iter.next();
			
			if(StringUtils.equals(xmethodtemp.getName(), method.getName())){
				String xSignature = xmethodtemp.getNameWithSignature(false);
				if(StringUtils.equals(xSignature, signature)){
					xmethod = xmethodtemp;
					break;
				}
			}
		}
		if(xmethod == null){
			return getParams(method);
		} else {
			Class[] paramterTypes = method.getParameterTypes();
			Param[] params = new Param[paramterTypes.length];
			int count = 0;
			for( Iterator i = xmethod.getParameters().iterator(); i.hasNext();  )
			{
				XParameter parameter = (XParameter) i.next();
				String name = parameter.getName();
				
				params[count] = new Param(name, paramterTypes[count]);
				++count;
			}
			return params;
		}
	}
	
	/**
	 * ����jdk method�ķ���ǩ�������صĴ˷���ǩ��Ӧ�ú�{@link XMethod#getNameWithSignature(false)}����ֵһ�¡�
	 * @param method
	 * @return
	 */
	private static String getNameWithSignature(Method method){
		String name = method.getName();
		StringBuilder sb = new StringBuilder(name);
		Class[] params = method.getParameterTypes();
		sb.append('(');
		for (int i = 0; i < params.length; i++) {
			
			Class temp = params[i];
			if(i != 0 && temp != null){
				sb.append(',');
			}
			sb.append(temp.getCanonicalName());
		}
		sb.append(')');
		return sb.toString();
	}
	/**
	 * ������һ��������Ӧ���������ݡ�<BR>
	 *
	 * @param genericType
	 * @param componentType
	 */
	private static void refactor(Class refactorClass, java.lang.reflect.Type genericType, com.primeton.studio.runtime.core.internal.Type refactorType) {

		if (null == refactorClass) {
			refactorType.setName("void");
			return;
		}

		String name;
		//System.err.println("genericType  "+genericType.getClass());

		if (!(genericType instanceof Class)) {
			name = GenericUtil.getName(refactorClass, genericType);
			//����з���
			//���ù�����ȡ��ȫ����<BR>
		}
		else {
			Class componentClass = refactorClass;
			name = ClassUtil.getQualifiedName(componentClass);

			//System.err.println("componentClass:  "+ componentClass + "  name: " + name);
		}

		refactorType.setName(name);

		com.primeton.studio.runtime.core.internal.Type parentType = refactorType;

		while (name.endsWith(IConstant.CLASS_ARRAY)) {
			com.primeton.studio.runtime.core.internal.Type componentType = new com.primeton.studio.runtime.core.internal.Type(parentType.getResource(), parentType);
			name = StringUtils.substringBeforeLast(name, IConstant.CLASS_ARRAY);
			componentType.setName(name);

			parentType = componentType;
		}
	}
	
	/**
	 * 
	 * @param bcelMethod
	 * @param jdkMethod
	 * @return
	 */
	private static Param[] getParams(com.sun.org.apache.bcel.internal.classfile.Method bcelMethod, Method jdkMethod){
		Class[] paramTypes = jdkMethod.getParameterTypes();
		Param[] params = getParams(bcelMethod, paramTypes);
		return params;
	}
	/**
	 * 
	 * @param bcelMethod
	 * @param jdkMethod
	 * @return
	 */
	private static Param[] getParams(com.sun.org.apache.bcel.internal.classfile.Method bcelMethod, Constructor jdkMethod){
		Class[] paramTypes = jdkMethod.getParameterTypes();
		Param[] params = getParams(bcelMethod, paramTypes);
		return params;
	}

	/**
	 * @param bcelMethod
	 * @param paramTypes
	 * @return
	 */
	private static Param[] getParams(com.sun.org.apache.bcel.internal.classfile.Method bcelMethod, Class[] paramTypes) {
		int paramLen = paramTypes.length;
		if(paramLen < 1){
			return EMPTY_PARAM;
		}
		Param[] params = new Param[paramLen];
		String access = Utility.accessToString(bcelMethod.getAccessFlags());
		LocalVariableTable vars = bcelMethod.getLocalVariableTable();
		int var_index = (access.indexOf("static") >= 0)? 0 : 1;
		if(vars == null){//bcel��bug����varsΪnull
			vars = new LocalVariableTable(-1,0,null,null);
		}
		for (int j = 0; j < paramLen; j++) {
			LocalVariable varable = vars.getLocalVariable(var_index);
			if(varable != null){
				String name = varable.getName();
				params[j] = new Param(name,paramTypes[j]);
			} else {
				params[j] = new Param("arg" + j,paramTypes[j]);
			}
			++ var_index; 
		}
		return params;
	}
	public static class Param {
		String name;
		Class paramType;
		/**
		 * 
		 * @param name
		 * @param paramType
		 */
		public Param(String name, Class paramType) {
			this.name = name;
			this.paramType = paramType;
		}
		/**
		 *	���ز�������
		 * @return Returns the name.
		 */
		public String getName() {
			return name;
		}
		/**
		 *  ���ò�������
		 *  
		 * @param name The name to set.
		 */
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * ���ز�������
		 * @return Returns the paramType.
		 */
		public Class getParamType() {
			return paramType;
		}
		/**
		 * ���ò�������
		 * @param paramType The paramType to set.
		 */
		public void setParamType(Class paramType) {
			this.paramType = paramType;
		}
	}
//	public static void main(String[] args) {
//		Method[] methods = Test.class.getMethods();
//		Constructor[] constructors = Test.class.getConstructors();
//		for (int i = 0; i < constructors.length; i++) {
//			Param[] pas = getParams(constructors[i]);
//			System.out.print(constructors[i].getName() + "(");
//			for (int j = 0; j < pas.length; j++) {
//				System.out.print(constructors[i].getParameterTypes()[j].getCanonicalName());
//				System.out.print(" " + pas[j].getName() + ", ");
//			}
//			System.out.print(") ");
//			System.out.println();
//		}
//		for (int i = 0; i < methods.length; i++) {
//			Param[] pas = getParams(methods[i]);
//			System.out.print(methods[i].getName()+ "(");
//			for (int j = 0; j < pas.length; j++) {
//				
//				System.out.print(methods[i].getParameterTypes()[j].getCanonicalName());
//				System.out.print(" " + pas[j].getName() + ", ");
//			}
//			System.out.print(") ");
//			System.out.println();
//		}
//	}
}

//class Test <T extends List>{
//	public Test(String a){}
//	public Test(){}
//	public void getAA(String...strings){}
//	public void getAA(Test[]strings){}
//	public void getAA(Test strings){}
//	public List<List<Object>> getList(){return null;}
//	public void setT(T a){}
//	public T getT(Map<Map<String,Object>,List<String>> map){return null;}
//	
//}
