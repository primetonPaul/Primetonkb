/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.adapter;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.runtime.IAdapterFactory;

import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.internal.Contribution;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.archive.ArchiveResourceDelegate;

/**
 * ��ѹ�����е���ԴAdapte��IContribution��ʵ�֡�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ArchiveContributionAdapterFactory.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/07/18 05:08:08  yujl
 * update:ɾ����Ч����
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/11/29 07:50:32  lvyuan
 * UnitTest:�޸Ĺ������EOSģ���ļ��ò���contribution������
 *
 * Revision 1.1  2007/11/29 06:15:44  wanglei
 * Add:�ύ��CVS��
 *
 */

public class ArchiveContributionAdapterFactory implements IAdapterFactory {

    private static final Class[] CLASSES = new Class[] { IContribution.class, Contribution.class };

    /**
     * Ĭ�Ϲ��캯����<BR>
     *
     * The default constructor.<BR>
     *
     */
    public ArchiveContributionAdapterFactory() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    public Object getAdapter(Object adaptableObject, Class adapterType) {

        if ((adaptableObject instanceof ArchiveResourceDelegate)
                && (IContribution.class == adapterType || Contribution.class == adapterType)) {
            ArchiveResourceDelegate resourceDelegate = (ArchiveResourceDelegate) adaptableObject;
            IProjectDelegate project = resourceDelegate.getProject();

            ILibrary[] libraries = project.getLibraries();
            //��Ϊѹ��������Ϊ���ÿ���ڵģ�����Ҫͨ�����ÿ�����������ϵ����

            if (!ArrayUtils.isEmpty(libraries)) {
                for (int i = 0; i < libraries.length; i++) {
                    ILibrary library = libraries[i];
                    IContribution[] contributions = library.getContributions();

                    if (!ArrayUtils.isEmpty(contributions)) {
                        for (int j = 0; j < contributions.length; j++) {
                            IContribution contribution = contributions[j];
                            IResourceDelegate root = contribution.getResource();

                            if (root == resourceDelegate.getArchiveFile()) {
                                return contribution;
                            }
                            //˫���ж�
                            //��Ϊ��ЩContribution������ͨ����Ŀ�����ⲿ�ļ��������
                            //������ѹ����
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * {@inheritDoc}
     */
    public Class[] getAdapterList() {
        return CLASSES;
    }
}
