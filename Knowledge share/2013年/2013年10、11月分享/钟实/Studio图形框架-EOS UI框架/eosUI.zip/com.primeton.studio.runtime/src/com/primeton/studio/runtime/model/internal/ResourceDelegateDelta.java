/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.internal;

import com.primeton.studio.runtime.model.IResourceDelegateDelta;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * IResourceDelegateDelta��Ĭ��ʵ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ResourceDelegateDelta.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/12/07 05:47:07  wanglei
 * Add:�ύ��CVS��
 *
 */

public class ResourceDelegateDelta implements IResourceDelegateDelta {

	private IResourceDelegate resourceDelegate;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public ResourceDelegateDelta(IResourceDelegate resourceDelegate) {
		this.resourceDelegate = resourceDelegate;
	}

	/**
	 * {@inheritDoc}
	 */
	public IResourceDelegate getResource() {
		return this.resourceDelegate;
	}
}
