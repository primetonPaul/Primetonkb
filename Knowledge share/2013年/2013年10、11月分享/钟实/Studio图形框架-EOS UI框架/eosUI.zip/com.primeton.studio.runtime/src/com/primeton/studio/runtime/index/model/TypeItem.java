/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/model/TypeItem.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-5-27
 *******************************************************************************/


package com.primeton.studio.runtime.index.model;

import com.eos.system.utility.Assert;

/**
 * ���͵ı�־�ӿڡ�<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: TypeItem.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
public final class TypeItem  extends IndexItem{

	private String namespace;

	/**
	 * ���캯��
	 *
	 * @param document
	 * @param name
	 * @param namespace
	 */
	public TypeItem(DocumentItem document, String name,String namespace) {
		super(document, name);
		Assert.notNull(namespace, "the namespace can't be null.");
		this.namespace = namespace;
	}

	/**
	 * �õ������ռ䡣<BR>
	 *
	 * @return
	 */
	public String getNameSpace() {
		return this.namespace;
	}
}
