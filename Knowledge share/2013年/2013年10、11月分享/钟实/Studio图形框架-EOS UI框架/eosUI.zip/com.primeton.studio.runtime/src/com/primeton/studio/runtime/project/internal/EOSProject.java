/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.runtime/src/com/primeton/studio/workbench/core/internal/EOSProject.java,v
 * 1.1 2006/12/31 09:50:02 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:53 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2006-12-14
 **********************************************************************************************************************/

package com.primeton.studio.runtime.project.internal;

import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;

import com.primeton.studio.core.base.AbstractAdaptableObject;
import com.primeton.studio.runtime.EOSProjectInfoChangeListenerManager;
import com.primeton.studio.runtime.ResourceHelper;
import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.metadata.IMetadata;
import com.primeton.studio.runtime.metadata.internal.FolderMetadata;
import com.primeton.studio.runtime.project.EOSProjectNature;
import com.primeton.studio.runtime.project.IEOSProject;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseFolderDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseProjectDelegate;

/**
 * EOS��Ŀ��ʵ�֡�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 *
 * $Log: EOSProject.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/03/05 08:52:30  lvyuan
 * BugFix:17650
 *
 * Revision 1.2  2008/08/27 03:08:21  yanfei
 * Update:���ӿ�ָ���жϡ�
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.15  2008/06/23 05:47:54  zhuxing
 * Update:�޸�.project�ļ���ͬ��������
 *
 * Revision 1.14  2008/04/30 02:38:53  yanfei
 * Update:IProject.setDescription����FORCE����������ļ���ͬ��������
 *
 * Revision 1.13  2008/04/21 11:58:31  yanfei
 * Update:
 * 1.��Ŀ�ļ��ı�ʱ������������������������project�ı��롣
 * 2.ֻ�е���Ŀ����ֵ�����ʱ���Ÿı�project�ļ���
 *
 * Revision 1.12  2008/04/09 06:06:47  yanfei
 * STBUG:6089 �½���Ŀ��Ĭ�ϡ��Զ�����ѡ�С�
 *
 * Revision 1.11  2008/04/02 09:49:34  lvyuan
 * UnitTest:�޸�ѡ��server��jsp�ļ����ܲ��������
 *
 * Revision 1.10  2008/03/31 09:57:29  wanglei
 * Update:��������Ϣ��.project���Ƶ�.eos�ļ��С�
 *
 * Revision 1.9  2007/12/22 08:07:22  wanglei
 * Review:���ڵ�EOS��Ŀ����Ҫһ��WEB��Ŀ������ȥ��get/setWebProject����������Ҫ֧���Զ���������������get/setAutoDeploy������
 *
 * Revision 1.8  2007/11/29 03:26:51  wanglei
 * Review:����hashCode��equals������
 *
 * Revision 1.7  2007/08/23 03:11:07  wanglei
 * Review:��IEOSProject�е�getLibraries�ƶ���IProjectDelegate�С�
 *
 * Revision 1.6  2007/08/09 06:58:39  wanglei
 * Update:��ΪILibrary�ĵ����������ʵ��ĵ�����
 *
 * Revision 1.5  2007/07/12 07:21:50  wanglei
 * Add:������getAdapter������
 *
 * Revision 1.4  2007/07/02 13:00:44  wanglei
 * Add:����getApplication������
 *
 * Revision 1.3  2007/06/28 09:26:04  wanglei
 * Review:��Ҫ��Library���л��档
 *
 * Revision 1.2  2007/04/23 09:02:22  wanglei
 * Update:�ϲ�Library��LibraryRepository
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 *
 */
public final class EOSProject extends AbstractAdaptableObject implements IEOSProject {
	private IProject project;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 */
	public EOSProject() {
		super();
	}

	/**
	 * ֱ�Ӵ���IProject������EOS��Ŀ��<BR>
	 */
	public EOSProject(IProject project) {
		super();
		this.setProject(project);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSResource#getEOSProject()
	 */
	public IEOSProject getEOSProject() {
		return this;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#getDatabase()
	 */
	public String getDatabase() throws CoreException {
		return getDatabase(this.project);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#getServer()
	 */
	public String getServer() throws CoreException {
		return getServer(this.project);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#setDatabase(java.lang.String)
	 */
	public void setDatabase(String database) throws CoreException {
		setDatabase(this.project, database);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#setServer(java.lang.String)
	 */
	public void setServer(String server) throws CoreException {
		boolean isSame = StringUtils.equals(server, this.getServer());
		
		setServer(this.project, server);
		
		if(!isSame){
			EOSProjectInfoChangeListenerManager.getInstance().fireProjectInfoChange(this, RuntimeConstant.SERVER);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#getApplication()
	 */
	public String getApplication() throws CoreException {
		return getApplication(this.project);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#getProject()
	 */
	public IProject getProject() {
		return this.project;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#setApplication(java.lang.String)
	 */
	public void setApplication(String application) throws CoreException {
		boolean isSame = StringUtils.equals(application, this.getApplication());
		
		setApplication(this.project, application);
		
		if(!isSame){
			EOSProjectInfoChangeListenerManager.getInstance().fireProjectInfoChange(this, RuntimeConstant.SERVER);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.IEOSProject#setProject(org.eclipse.core.resources.IProject)
	 */
	public void setProject(IProject project) {
		this.project = project;
	}

	/**
	 * ����ĳ����Ŀ��ĳ������������Ϣ������.project�ļ���builder�Ĳ�������С�
	 *
	 * @param project
	 * @return
	 * @throws CoreException
	 * @throws CoreException
	 */
	private static String getProjectParameter(IProject project, String key) throws CoreException {
		if (null == project) {
			return null;
		}

		IProjectDescription description = project.getDescription();

		if (!EOSProjectNature.isEOSProject(description)) {
			return null;
		}
		// ����EOS��Ŀ��ֱ�ӷ��� null��

		ICommand[] commands = project.getDescription().getBuildSpec();
		if (null == commands) {
			return null;
		}
		else {
			for (int i = 0; i < commands.length; i++) {
				ICommand command = commands[i];
				if (RuntimeConstant.BUILDER_ID.equals(command.getBuilderName())) {
					return (String) command.getArguments().get(key);
				}
			}
		}

		return null;

	}

	/**
	 * ����ĳ����Ŀ�Ĳ���������Ϣ������.project�ļ���builder�Ĳ�������С�
	 *
	 * @param project
	 *            ָ������Ŀ
	 * @param key
	 * @param value
	 * @throws CoreException
	 */
	private static void setProjectParameter(IProject project, String key, String value) throws CoreException {
		Assert.isNotNull(project, "The target can't be null");

		IFile projectFile = project.getFile(RuntimeConstant.PROJECT_FILE);
		if(null != projectFile && projectFile.exists()){
			if(ResourceHelper.checkFiles(new IFile[]{projectFile}) == false)
				return;//û�м��ֱ�ӷ���
		}

		IProjectDescription description = project.getDescription();

		if (!EOSProjectNature.isEOSProject(description)) {
			return;
		}

		ICommand[] commands = project.getDescription().getBuildSpec();
		if (null != commands) {
			for (int i = 0; i < commands.length; i++) {
				ICommand command = commands[i];
				if (RuntimeConstant.BUILDER_ID.equals(command.getBuilderName())) {
					Map map = command.getArguments();

					String oldValue=(String) map.get(key);
					if(!StringUtils.equals(value, oldValue))
					{
						map.put(key, value);
						command.setArguments(map);

						description.setBuildSpec(commands);

						//modify by zhuxing:ɾ��ǿ�Ʊ���ķ�ʽ���������ļ���ͬ��
						project.setDescription(description, null);
					}
					//ֻ�в��ȵ�ʱ�򣬲���Ҫ����
				}
			}
		}
	}

	/**
	 *
	 *
	 * @param project
	 * @return ���ص�ǰ��Ŀ�󶨵����ݿ⡣<BR>
	 * @throws CoreException
	 */
	public static String getDatabase(IProject project) throws CoreException {
		return getProjectParameter(project, RuntimeConstant.DATABASE);
	}

	/**
	 * �趨��ǰ��Ŀ�󶨵����ݿ⡣<BR>
	 *
	 * @param project
	 * @param database
	 * @throws CoreException
	 */
	public static void setDatabase(IProject project, String database) throws CoreException {
		setProjectParameter(project, RuntimeConstant.DATABASE, database);
	}

	/**
	 * {@inheritDoc}
	 * @throws CoreException
	 */
	public boolean isAutoDeploy() throws CoreException {
		EclipseProjectDelegate projectDelegate = new EclipseProjectDelegate(this.project);
		IMetadata metadata = FolderMetadata.newInstance(projectDelegate, false);

		if (null == metadata) {
			return true;
		}
		else {
			String autoDeploy = metadata.getString(RuntimeConstant.AUTO_DEPLOY)==null ? "true" : metadata.getString(RuntimeConstant.AUTO_DEPLOY);
			return Boolean.valueOf(autoDeploy);
		}
	}

	/**
	 * {@inheritDoc}
	 * @throws CoreException
	 */
	public void setAutoDeploy(boolean autoDeploy) throws CoreException {
		EclipseProjectDelegate projectDelegate = new EclipseProjectDelegate(this.project);
		IMetadata metadata = FolderMetadata.newInstance(projectDelegate, false);

		if (null != metadata) {
			metadata.setString(RuntimeConstant.AUTO_DEPLOY, Boolean.toString(autoDeploy));
		}
	}

	/**
	 *
	 *
	 * @param project
	 * @return ���ص�ǰ��Ŀ�󶨵����ݿ⡣<BR>
	 * @throws CoreException
	 */
	public static String getServer(IProject project) throws CoreException {
		return getProjectParameter(project, RuntimeConstant.SERVER);
	}

	/**
	 * �趨��ǰ��Ŀ�󶨵����ݿ⡣<BR>
	 *
	 * @param project
	 * @param server
	 * @throws CoreException
	 */
	public static void setServer(IProject project, String server) throws CoreException {
		setProjectParameter(project, RuntimeConstant.SERVER, server);
	}

	/**
	 *
	 *
	 * @param project
	 * @return ���ص�ǰ��Ŀ�Ĳ���Ŀ¼��<BR>
	 * @throws CoreException
	 */
	public static String getApplication(IProject project) throws CoreException {
		return getProjectParameter(project, RuntimeConstant.APPLICATION);
	}

	/**
	 * �趨��ǰ��Ŀ�Ĳ���Ŀ¼��<BR>
	 *
	 * @param project
	 * @param deployPath
	 * @throws CoreException
	 */
	public static void setApplication(IProject project, String deployPath) throws CoreException {
		setProjectParameter(project, RuntimeConstant.APPLICATION, deployPath);
	}

	/**
	 * ����Ԫ���ݡ�<BR>
	 *
	 * @return
	 */
	public IMetadata getMetadata() {
		IFolderDelegate folder = new EclipseFolderDelegate(this.project);
		FolderMetadata metadata = FolderMetadata.newInstance(folder, true);

		return metadata;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.project == null) ? 0 : this.project.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final EOSProject other = (EOSProject) obj;
		return ObjectUtils.equals(this.project, other.project);
	}

	/**
	 * {@inheritDoc}
	 */

	public Object getAdapter(Class adapter) {
		if (IResource.class == adapter) {
			return this.project;
		}

		if (IProject.class == adapter) {
			return this.project;
		}

		return super.getAdapter(adapter);
	}
}
