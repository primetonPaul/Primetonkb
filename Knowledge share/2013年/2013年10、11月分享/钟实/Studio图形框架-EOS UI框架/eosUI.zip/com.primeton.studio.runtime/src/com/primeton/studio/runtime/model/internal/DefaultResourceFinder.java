/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.internal;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.runtime.Assert;

import com.eos.system.utility.FilenameUtil;
import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.model.IResourceFinder;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * TODO ��дע��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: DefaultResourceFinder.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2008/03/28 02:02:29  lvyuan
 * Update:���Ӷ�������Ŀ��contribution���������ļ�
 *
 * Revision 1.7  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.6  2007/11/28 09:26:13  wanglei
 * Review:RuntimeManager�еĲ��ַ����Ƶ�RuntimeHelper�У�Ҳ��һЩ��������������
 *
 * Revision 1.5  2007/11/02 01:06:47  hongsq
 * Update:�޸�ArrayUtils.add����ʱ�����Ͳ�ƥ������⣨78�У�
 *
 * Revision 1.4  2007/11/01 08:07:39  wanglei
 * UnitTest:�޸���ǰContribution�����ÿ�Contributionͬ��ʱ�������õ��ļ��޷��ҵ���Bug��
 *
 * Revision 1.3  2007/07/20 02:53:08  wanglei
 * Review:�����ɷ�����NPE�쳣�������˴�����
 *
 * Revision 1.2  2007/06/30 13:11:17  wanglei
 * Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.1  2007/06/06 10:36:36  wanglei
 * �ύ��CVS��
 *
 */

public class DefaultResourceFinder implements IResourceFinder {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public DefaultResourceFinder() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate findFile(IProjectDelegate project, IContribution contribution, String path, String type) {
		Assert.isNotNull(project, "The project can't be null");
		Assert.isNotNull(contribution, "The composite can't be null");
		Assert.isNotNull(path, "The path can't be null");

		String filePath = FilenameUtil.toPathInUnixStyle(path);
		if (null != type) {
			filePath = filePath + "." + type;
		}

		IFileDelegate file = RuntimeManager.findFile(contribution, filePath);
		if (null != file && file.exists()) {
			return file;
		}
		//����ָ���Ĺ���Ŀ¼���ң��ҵ���ֱ�ӷ���

		String[] nameSpaces=contribution.getRequiredBundles();
		nameSpaces=(String[]) ArrayUtils.add(nameSpaces, contribution.getName());

		IContribution[] contributions = RuntimeManager.findContributions(project, contribution.getRequiredBundles());

		if (!ArrayUtils.isEmpty(contributions)) {
			for (int i = 0; i < contributions.length; i++) {
				IContribution bundleContribution = contributions[i];
				file = RuntimeManager.findFile(bundleContribution, filePath);
				if (null != file && file.exists()) {
					return file;
				}
			}
			//�����ǰ�Ĺ���Ŀ¼��û�У��ʹӵ�ǰ�����������õĹ����в���
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate findFolder(IProjectDelegate project, IContribution contribution, String path) {
		Assert.isNotNull(project, "The project can't be null");
		Assert.isNotNull(contribution, "The composite can't be null");
		Assert.isNotNull(path, "The path can't be null");

		String folderPath = FilenameUtil.toPathInUnixStyle(path);

		IFolderDelegate folder = RuntimeManager.findFolder(contribution, folderPath);
		if (null != folder && folder.exists()) {
			return folder;
		}
		//����ָ���Ĺ���Ŀ¼���ң��ҵ���ֱ�ӷ���

		IContribution[] composites = RuntimeManager.findContributions(project, contribution.getRequiredBundles());
		for (int i = 0; i < composites.length; i++) {
			IContribution bundleContribution = composites[i];
			folder = RuntimeManager.findFolder(bundleContribution, folderPath);
			if (null != folder && folder.exists()) {
				return folder;
			}
		}
		//�����ǰ�Ĺ���Ŀ¼��û�У��ʹӵ�ǰ�����������õĹ����в���

		return null;
	}

    /* (non-Javadoc)
     * @see com.primeton.studio.runtime.model.IResourceFinder#findFile(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String, java.lang.String)
     */
    public IFileDelegate findFile(IProjectDelegate project, String path, String type) {
        Assert.isNotNull(project, "The project can't be null");
        Assert.isNotNull(path, "The path can't be null");
        IContribution[] contributions = RuntimeManager.getAllContributions(project);
        for (int i = 0; i < contributions.length; i++) {
            IContribution contribution = contributions[i];
            IFileDelegate fileDelegate = this.findFile(project, contribution, path, type);
            if(fileDelegate != null && fileDelegate.exists()) {
                return fileDelegate;
            }
        }
        return null;
    }

    /* (non-Javadoc)
     * @see com.primeton.studio.runtime.model.IResourceFinder#findFolder(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String)
     */
    public IFolderDelegate findFolder(IProjectDelegate project, String path) {
        Assert.isNotNull(project, "The project can't be null");
        Assert.isNotNull(path, "The path can't be null");
        IContribution[] contributions = RuntimeManager.getAllContributions(project);
        for (int i = 0; i < contributions.length; i++) {
            IContribution contribution = contributions[i];
            IFolderDelegate folderDelegate = this.findFolder(project, contribution, path);
            if(folderDelegate != null && folderDelegate.exists()) {
                return folderDelegate;
            }
        }
        return null;
    }
}
