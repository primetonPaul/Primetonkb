/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.archive;

import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;
import com.primeton.studio.runtime.resources.internal.base.AbstractResourceDelegate;

/**
 * IResourceDelegate��ѹ���ļ��ϵĻ��ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractArchiveResourceDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/04/22 11:56:40  yanfei
 * Update:getpersitenProperty����û��ʵ��ʱ�����׳��쳣������null.
 *
 * Revision 1.5  2008/04/14 03:32:00  wanglei
 * Update:���ӶԳ־û����Ե�֧�֡�
 *
 * Revision 1.4  2007/11/01 06:45:28  wanglei
 * Review:������isArchive,isEditable,isBinary������
 *
 * Revision 1.3  2007/06/28 09:28:36  wanglei
 * Review:��getData��setData�����Ƶ������С�
 *
 * Revision 1.2  2007/06/28 09:27:54  wanglei
 * Review:����getData��setData������
 *
 * Revision 1.1  2007/06/26 07:53:56  wanglei
 * �ύ��CVS��
 *
 */
public abstract class AbstractArchiveResourceDelegate extends AbstractResourceDelegate implements IResourceDelegate {

	/**
	 * archive
	 */
	public static final String ARCHIVE = "archive";

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractArchiveResourceDelegate() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public void create() {
		throw new UnsupportedOperationException("create operation is not support for a compressed file.");

	}

	/**
	 * {@inheritDoc}
	 */
	public void delete() throws ResourceException {
		throw new UnsupportedOperationException("delete operation is not support for a compressed file.");

	}

	/**
	 * {@inheritDoc}
	 */
	public boolean exists() throws ResourceException {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public IRootDelegate getRoot() throws ResourceException {
		return RuntimeManager.getRoot();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getProtocol() {
		return ARCHIVE;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isArchive() {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isEditable() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isBinary() {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getPersistentProperty(String key) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setPersistentProperty(String key, String value) {
		throw new UnsupportedOperationException("This operation is not valid for archive resource.");
	}


}
