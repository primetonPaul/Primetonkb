/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.validator.internal;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.validator.base.ComponentValidator;

/**
 * ������֤һ��Ŀ¼�Ƿ���ģ��Ŀ¼��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ModuleValidator.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/04/27 01:04:00  wanglei
 * �ύ��CVS��
 *
 */

public class ModuleValidator extends ComponentValidator {

	public static final ModuleValidator INSTANCE=new ModuleValidator();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public ModuleValidator() {
		super();
	}

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param message
	 */
	public ModuleValidator(String message) {
		super(message);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getComponentType() {
		return RuntimeConstant.MODULE;
	}
}
