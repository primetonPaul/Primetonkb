/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.java;

import com.primeton.studio.core.INamingElement;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IType;

/**
 * Annotation��Bridge�ӿ�<BR>
 * ����ͬʱʹ��JDT��Ĭ�ϵ�Class��<BR>
 * �μ�Bridgeģʽ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IAnnotationType.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/10/31 08:31:09  wanglei
 * Add:�ύ��CVS��
 *
 */

public interface IAnnotationType extends INamingElement {

	public static final IAnnotationType[] NUL_TYPES = new IAnnotationType[0];

	/**
	 *
	 * @return �����������ڵ��ࡣ<BR>
	 */
	public IType getDeclaringType();

	/**
	 *
	 * @return
	 */
	public IEosElement getDeclaringElement();

	/**
	 * �õ�Annotation�������������ԡ�<BR>
	 *
	 * @return
	 */
	public IAnnotationProperty[] getProperties();

}
