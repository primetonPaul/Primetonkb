/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/query/DocumentQueryResult.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-6-5
 *******************************************************************************/

package com.primeton.studio.runtime.index.query;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;

import com.primeton.studio.runtime.index.model.DocumentItem;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DocumentQueryResult.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/07/22 05:09:17  lvyuan
 * Update:�ع�����namespace��Ϊһ��StringEntry
 *
 * Revision 1.2  2009/07/21 09:51:19  lvyuan
 * Update:�ع��������ҽӿڣ��������ö���ؼ���
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
class DocumentQueryResult<E> extends TypeQueryResult<E> {

	/**
	 * @param projectDelegate
	 * @param query
	 * @param statement
	 */
	public DocumentQueryResult(IProjectDelegate projectDelegate, Query query, QueryStatement statement) {
		super(projectDelegate, query, statement);
	}

	/**
	 * {@inheritDoc}
	 */
	protected int computeSize(Hits hits) {
		return hits.length();
	}

	/**
	 * {@inheritDoc}
	 */
	protected List<E> load(Hits hits, int startIndex, int endIndex) throws CorruptIndexException, IOException {

		List docList = new ArrayList();

		endIndex = Math.min(hits.length(), endIndex);

		for (int i = startIndex; i < endIndex; i++) {
			Document doc = hits.doc(i);
			DocumentItem docItem = DocumentItem.createDocument(doc, this.getProject());
			addTypes(doc, docItem, (String) this.getStatement().getNameSpace().getValue(), null);

			docList.add(docItem);
		}

		return docList;
	}

}
