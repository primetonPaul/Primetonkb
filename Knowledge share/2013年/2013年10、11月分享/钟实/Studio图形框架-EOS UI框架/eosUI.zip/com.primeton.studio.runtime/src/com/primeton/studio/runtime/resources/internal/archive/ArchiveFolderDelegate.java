/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.resources.internal.archive;

import java.util.Collection;
import java.util.HashSet;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ������ʾѹ������һ��Ŀ¼��㵽�ļ���Դ��ӳ�䡣<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ArchiveFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/06/28 09:29:57  wanglei
 * UnitTest:ԭ����ȡ��������Bug��
 *
 * Revision 1.1  2007/06/26 07:53:56  wanglei
 * �ύ��CVS��
 *
 */

public class ArchiveFolderDelegate extends ArchiveResourceDelegate implements IFolderDelegate {

	private Collection children = new HashSet();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param rootFile
	 * @param path
	 */
	public ArchiveFolderDelegate(ArchiveRootFileDelegate rootFile, String path) {
		super(rootFile, path);

		String name = StringUtils.substringBeforeLast(path, "/");
		this.setName(FilenameUtils.getName(name));
	}

	/**
	 * {@inheritDoc}
	 */
	public int getType() throws ResourceException {
		return IResourceDelegate.FOLDER;
	}

	/**
	 * {@inheritDoc}
	 */
	public IResourceDelegate[] getChildren() {
		IResourceDelegate[] delegates = new IResourceDelegate[this.children.size()];
		this.children.toArray(delegates);
		return delegates;
	}

	/**
	 * {@inheritDoc}
	 */
	public IFileDelegate getFile(String path) {
		return this.getArchiveFile().getFile(this, path);
	}

	/**
	 * {@inheritDoc}
	 */
	public IFolderDelegate getFolder(String path) {
		return this.getArchiveFile().getFolder(this, path);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isPrefixOf(IResourceDelegate resourceDelegate) {
		return this.getArchiveFile().isPrefixOf(this, resourceDelegate);
	}

	/**
	 * ����һ������Դ��<BR>
	 *
	 * @param resourceDelegate
	 */
	public void addChild(IResourceDelegate resourceDelegate) {
		this.children.add(resourceDelegate);
	}

	/**
	 * ��ȥһ������Դ��<BR>
	 *
	 * @param resourceDelegate
	 */
	public void removeChild(IResourceDelegate resourceDelegate) {
		this.children.remove(resourceDelegate);
	}
}
