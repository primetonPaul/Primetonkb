/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/AbstractSeparatorAnalyser.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.core.IType;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: AbstractSeparatorAnalyser.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/10/29 10:27:37  liu-jun
 * Bug:13984 ��javabean�е�List������ʾ����ȷ commit by yangmd
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:45  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public abstract class AbstractSeparatorAnalyser implements
		IComplexSeparatorAnalyser {
	

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.IComplexSeparatorAnalyser#computeLastResult(com.primeton.studio.runtime.helper.ComplexSeparatorContext, com.primeton.studio.runtime.helper.ISeparatorAnalyserPolicy)
	 */
	public Object computeLastResult(ComplexSeparatorContext context, ISeparatorAnalyserPolicy policy) {
		
		Object rootElement = context.getElement();
		
		ISeparatorPolicy separatorPolicy = context.getSeparatorPolicy();
		SeparatorModel separatormodel = new SeparatorModel(null,rootElement);
		String separator = separatorPolicy.getSeparator(separatormodel);
		
		String childName = context.getChildrenContents();
		if(childName == null || "".equals(childName)){
			return rootElement;
		}
		if(onlyOneChild(separator,childName)){
			return doGetOneChild(context,rootElement, separatorPolicy, separatormodel, childName);
		} else {
			String tempOneChild = StringUtils.substringBefore(childName, separator);
			String afterChildren = StringUtils.substringAfter(childName, separator);
			Object element = doGetOneChild(context,rootElement, separatorPolicy, separatormodel, tempOneChild);
			if(element == null)return null;
			separatormodel = new SeparatorModel(separatormodel,element);
			IComplexSeparatorAnalyser separatorAnalyser = policy.getSeparatorAnalyzer(separatormodel);
			context.setElement(element);
			context.setParentContent(tempOneChild);
			context.setChildrenContents(afterChildren);
			return separatorAnalyser.computeLastResult(context, policy);
		}
	
	}
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.IComplexSeparatorAnalyser#getAssertResult(int, com.primeton.studio.runtime.helper.ComplexSeparatorContext, com.primeton.studio.runtime.helper.ISeparatorAnalyserPolicy)
	 */
	public SeparateAssertResult getAssertResult(int rootIndex, 
			ComplexSeparatorContext context, ISeparatorAnalyserPolicy policy) {
		Object rootElement = context.getElement();
		
		ISeparatorPolicy separatorPolicy = context.getSeparatorPolicy();
		SeparatorModel separatormodel = new SeparatorModel(null,rootElement);
		String separator = separatorPolicy.getSeparator(separatormodel);
		
		String childName = context.getChildrenContents();
		if(childName == null || "".equals(childName)){
			return new SeparateAssertResult(rootIndex,null,rootElement);
		}
		if(onlyOneChild(separator,childName)){
			rootElement = doGetOneChild(context,rootElement, separatorPolicy, separatormodel, childName);
			if(rootElement == null)return new SeparateAssertResult(rootIndex,null,rootElement);
			return new SeparateAssertResult(rootIndex+1, separator,rootElement);
		} else {
			String tempOneChild = StringUtils.substringBefore(childName, separator);
			String afterChildren = StringUtils.substringAfter(childName, separator);
			Object element = doGetOneChild(context, rootElement, separatorPolicy, separatormodel, tempOneChild);
			if(element == null)return new SeparateAssertResult(rootIndex,null,rootElement);
			separatormodel = new SeparatorModel(separatormodel, element);
			IComplexSeparatorAnalyser separatorAnalyser = policy.getSeparatorAnalyzer(separatormodel);
			context.setElement(element);
			context.setParentContent(tempOneChild);
			context.setChildrenContents(afterChildren);
			return separatorAnalyser.getAssertResult(rootIndex+1, context, policy);
		}
	}
	
	/**
	 * 
	 * @param element
	 * @param separatorPolicy
	 * @param separatormodel
	 * @param childName
	 * @return
	 */
	protected abstract Object doGetOneChild(ComplexSeparatorContext context,Object element, 
			ISeparatorPolicy separatorPolicy, SeparatorModel separatormodel, String childName);
	/**
	 * 
	 * @param separator
	 * @param childrenContent
	 * @return
	 */
	protected boolean onlyOneChild(String separator, String childrenContent){
		if(separator == null || "".equals(separator) 
				|| childrenContent.indexOf(separator) == -1){
			return true;
		}
		return false;
	}
	/**
	 * 
	 * @param type
	 * @return
	 */
	protected int arrayCount(IType type){
		int count = 0;
		IType tempType = type.getComponentType();
		while(tempType != null){
			++count;
			tempType = tempType.getComponentType();
		}
		if(count == 0){//��Щ���������δ����type��componentType,�������ƿ��ܴ洢���Ƿ��������Ϣ��
			String typeName = type.getName();
			while(typeName.indexOf("[]") > 0){
				++count;
				typeName = StringUtils.substringBeforeLast(typeName, "[]");
			}
		}
		return count;
	}
	/**
	 * 
	 * @param fieldName
	 * @return
	 */
	protected int arrayCount(String fieldName){
		char[] chars = fieldName.toCharArray();
		int count = 0;
		for (int i = 0; i < chars.length; i++) {
			char c = chars[i];
			if(c == '['){
				++count; 
			}
		}
		return count;
	}
}
