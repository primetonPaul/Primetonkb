/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/EosMultiResourceLocatorDirector.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-8-20
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * ��Դ��λ����������һ����Դ
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EosMultiResourceLocatorDirector.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/08/20 07:47:03  hongsq
 * Update:�ṩһ��ӿ�֧�ֲ���һ���ļ������޸�xsd,wsdl��ع����������ƿռ��ظ�
 * 
 */
public final class EosMultiResourceLocatorDirector {
	private static EosMultiResourceLocatorDirector INSTANCE = new EosMultiResourceLocatorDirector();
	/**�������е�locator,����ͨ����չ�����ķ�ʽ*/
	private Map<Class,IEosMultiResourceLocator> locator = new LinkedHashMap<Class,IEosMultiResourceLocator>();
	
	private EosMultiResourceLocatorDirector(){
		locator.put(IndexMultiResourceLocator.class,new IndexMultiResourceLocator());
		locator.put(DefaultMultiResourceLocator.class,new DefaultMultiResourceLocator());
		locator.put(TypeNSMultiResourceLocator.class,new TypeNSMultiResourceLocator());
	}
	
	/**��������*/
	private IEosMultiResourceLocator defaultResourceLocator = new IEosMultiResourceLocator(){

		public IFileDelegate[] findFiles(IProjectDelegate project, String[] namespaces) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEosMultiResourceLocator locatorElement = (IEosMultiResourceLocator) iter.next();
				IFileDelegate[] files = locatorElement.findFiles(project, namespaces);
				
				//ֻҪ��һ����λ����Ч�Ͳ��ڼ���
				if(files.length > 0)
					return files;
			}
			return new IFileDelegate[0];
		}

		public IFileDelegate[] findFiles(IContribution contribution, String[] namespaces, boolean includeReference) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEosMultiResourceLocator locatorElement = (IEosMultiResourceLocator) iter.next();
				IFileDelegate[] files = locatorElement.findFiles(contribution, namespaces, includeReference);
				
				//ֻҪ��һ����λ����Ч�Ͳ��ڼ���
				if(files.length > 0)
					return files;
			}
			return new IFileDelegate[0];
		}

		public IFileDelegate[] findFilesInFolders(String[] namespaces, IFolderDelegate[] folders) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEosMultiResourceLocator locatorElement = (IEosMultiResourceLocator) iter.next();
				IFileDelegate[] files = locatorElement.findFilesInFolders(namespaces, folders);
				
				//ֻҪ��һ����λ����Ч�Ͳ��ڼ���
				if(files.length > 0)
					return files;
			}
			return new IFileDelegate[0];
		}

		public IFileDelegate[] findFilesInLibraries(IProjectDelegate project, String[] namespaces) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEosMultiResourceLocator locatorElement = (IEosMultiResourceLocator) iter.next();
				IFileDelegate[] files = locatorElement.findFilesInLibraries(project, namespaces);
				
				//ֻҪ��һ����λ����Ч�Ͳ��ڼ���
				if(files.length > 0)
					return files;
			}
			return new IFileDelegate[0];
		}

		public IFileDelegate[] findFilesInSourceFolders(IProjectDelegate project, String[] namespaces) {
			for (Iterator iter = INSTANCE.locator.values().iterator(); iter.hasNext();) {
				IEosMultiResourceLocator locatorElement = (IEosMultiResourceLocator) iter.next();
				IFileDelegate[] files = locatorElement.findFilesInSourceFolders(project, namespaces);
				
				//ֻҪ��һ����λ����Ч�Ͳ��ڼ���
				if(files.length > 0)
					return files;
			}
			return new IFileDelegate[0];
		}
		
	};
	
	/**
	 * @return Ψһ��ʵ����<BR>
	 */
	public static EosMultiResourceLocatorDirector getInstance(){
		return INSTANCE;
	}
	
	/**
	 * @return Returns the defaultResourceLocator.
	 */
	public IEosMultiResourceLocator getResourceLocator() {
		return defaultResourceLocator;
	}
	
	/**
	 * @return Returns the defaultResourceLocator.
	 */
	public IEosMultiResourceLocator getResourceLocator(Class className) {
		if(locator.get(className) != null){
			return locator.get(className);
		}
		return defaultResourceLocator;
	}
}
