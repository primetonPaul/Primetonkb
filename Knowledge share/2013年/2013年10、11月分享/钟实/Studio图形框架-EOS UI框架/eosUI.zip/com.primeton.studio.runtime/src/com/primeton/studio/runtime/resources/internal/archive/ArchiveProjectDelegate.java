/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/ArchiveProjectDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-10
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import java.util.HashSet;
import java.util.Set;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.library.ILibrary;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.resources.IRootDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ArchiveProjectDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 * 
 */
public class ArchiveProjectDelegate extends DefaultFolderDelegate implements
		IProjectDelegate {
	private Set<ISourceFolderDelegate> sourceFolders = new HashSet<ISourceFolderDelegate>();
	/**
	 * 
	 * @param rootFile
	 * @param path
	 */
	public ArchiveProjectDelegate(ArchiveRootDelegate rootFile, String path) {
		super(rootFile, path);
	}

	

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IProjectDelegate#getLibraries()
	 */
	public ILibrary[] getLibraries() {
		return new ILibrary[0];
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.ArchiveResourceDelegate#getProject()
	 */
	@Override
	public IProjectDelegate getProject() throws ResourceException {
		return this;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.internal.archive.AbstractArchiveResourceDelegate#getRoot()
	 */
	@Override
	public IRootDelegate getRoot() throws ResourceException {
		return (IRootDelegate) this.getParent();
	}
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IProjectDelegate#getSourceFolders()
	 */
	public ISourceFolderDelegate[] getSourceFolders() {
		return sourceFolders.toArray(new ISourceFolderDelegate[0]);
	}
	
	/**
	 * Ϊ��ǰ��Ŀ����һ��Դ����Ŀ¼��<BR>
	 *
	 * @param sourceFolder
	 */
	public void addSourceFolder(ISourceFolderDelegate sourceFolder) {
		if (null != sourceFolder) {
			this.sourceFolders.add(sourceFolder);
		}
	}

	/**
	 * Ϊ��ǰ��Ŀɾ��һ��Դ����Ŀ¼��<BR>
	 *
	 * @param sourceFolder
	 */
	public void removeSourceFolder(ISourceFolderDelegate sourceFolder) {
		if (null != sourceFolder) {
			this.sourceFolders.remove(sourceFolder);
		}
	}
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IProjectDelegate#isOpen()
	 */
	public boolean isOpen() {
		return true;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.internal.java.JavaFolderDelegate#getType()
	 */
	public int getType() throws ResourceException {
		return PROJECT;
	}

}
