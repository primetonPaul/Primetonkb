/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/core/internal/ReferenceCollector.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2007-12-26
 *******************************************************************************/


package com.primeton.studio.runtime.core.internal;

import java.util.HashMap;
import java.util.Map;

import com.primeton.studio.runtime.core.IImportReference;

/**
 * import reference�ռ���
 * ˵�������Զ��ϲ��ظ���import reference��reference name��Ϊ�ؼ��֣�
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ReferenceCollector.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/12/02 06:43:33  zhuxing
 * New:�������벿�ֵ������������ؼ������߼�����װ
 *
 * Revision 1.1  2008/07/04 12:01:01  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/12/27 01:24:33  zhuxing
 * update:jsp��������ʵ�ִ����ύ
 * 
 */
public class ReferenceCollector {
	/**
	 * reference instance map��keyΪreference name
	 */
	private Map<String, IImportReference> references = new HashMap<String, IImportReference>();
	
	public ReferenceCollector() {}
	
	/**
	 * ����һ��referenceʵ����reference name��ͬ��ʵ���ᱻ�ϲ�
	 * 
	 * @param references
	 */
	public void addReferences(IImportReference[] references) {
		if (references == null)
			return ;
		
		for (int i = 0; i < references.length; i++) {
			this.addReference(references[i]);
		}
	}
	
	/**
	 * ����referenceʵ����reference name��ͬ��ʵ���ᱻ�ϲ�
	 * 
	 * @param reference
	 */
	public void addReference(IImportReference reference) {
		//param check
		if (reference == null || reference.getName() == null)
			return ;
		
		String referenceName = reference.getName();
		ImportReference existingReference = (ImportReference)this.references.get(referenceName);
		if (existingReference != null) {
			String[] referenceContents = reference.getReferenceContents();
			ImportReferenceHelper.mergeReferenceContents(existingReference, referenceContents);
		}
		else {
			this.references.put(referenceName, reference);
		}
	}
	
	/**
	 * ��ȡcollector�е�����referenceʵ��
	 * 
	 * @return
	 */
	public IImportReference[] getReferences() {
		return this.references.values().toArray(new IImportReference[this.references.values().size()]);
	}
	
}
