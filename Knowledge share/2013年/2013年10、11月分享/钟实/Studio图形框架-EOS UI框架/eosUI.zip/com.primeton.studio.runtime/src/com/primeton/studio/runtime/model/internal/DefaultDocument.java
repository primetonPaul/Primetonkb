/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.internal;

import com.primeton.studio.core.base.AbstractAdaptableObject;
import com.primeton.studio.runtime.core.IDocument;

/**
 * IDocument��Ĭ��ʵ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: DefaultDocument.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/09 12:11:38  wanglei
 * Add:�ύ��CVS��
 *
 */

public class DefaultDocument extends AbstractAdaptableObject implements IDocument {

	private String content;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param content
	 */
	public DefaultDocument(String content) {
		super();
		this.content = content;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getContent() {
		return this.content;
	}

}
