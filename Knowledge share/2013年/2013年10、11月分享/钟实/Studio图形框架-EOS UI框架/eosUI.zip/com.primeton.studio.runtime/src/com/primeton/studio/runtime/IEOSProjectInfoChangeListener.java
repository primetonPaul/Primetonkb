/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/IEOSProjectInfoChangeListener.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved. 
 * 
 * Created on 2008-4-2
 *******************************************************************************/


package com.primeton.studio.runtime;

import com.primeton.studio.runtime.project.internal.EOSProject;

/**
 * TODO�˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IEOSProjectInfoChangeListener.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:24  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/02 09:26:47  lvyuan
 * Add:����һ�������Ľӿ�
 * 
 */
public interface IEOSProjectInfoChangeListener {
    
    /**
     * ����������Ŀ������Ϣ�ĸı䡣<BR>
     * 
     * @param project
     * @param changeType
     */
    public void fireProjectInfoChange(EOSProject project,String changeType);
}
