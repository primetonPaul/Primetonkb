/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core;

/**
 * �̳й�ϵ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ISuperTypeReference.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/07/23 09:19:02  wanglei
 * Add:���ӳ����ͷ�����
 *
 * Revision 1.1  2007/04/27 01:05:13  wanglei
 * �ύ��CVS��
 *
 */

public interface ISuperTypeReference extends IReference {
	//Marker Interface

	public static final int INTERFACE_SUPER_TYPE = 1 << 2;

	public static final int IMPLEMENTATION_SUPER_TYPE = 2 << 2;

	/**
	 * ������Ӧ�����͡�<BR>
	 *
	 * {@link #INTERFACE_SUPER_TYPE}
	 * {@link #IMPLEMENTATION_SUPER_TYPE}
	 *
	 * @return
	 */
	public int getSuperType();
}
