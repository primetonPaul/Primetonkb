/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/archive/DefaultFolderDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-10
 *******************************************************************************/


package com.primeton.studio.runtime.resources.internal.archive;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DefaultFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/07/13 14:05:22  yangmd
 * Update:�ع�
 *
 * Revision 1.1  2008/07/12 05:08:12  yangmd
 * Add:�ύ��cvs
 * 
 */
public class DefaultFolderDelegate extends DefaultResourceDelegate implements IFolderDelegate{
	protected Set<IResourceDelegate> children = new HashSet<IResourceDelegate>();
	private ISourceFolderDelegate sourceFolder;
	/**
	 * @param parent
	 * @param path
	 */
	public DefaultFolderDelegate(IFolderDelegate parent,String path) {
		super(parent, path);
		if(parent instanceof ISourceFolderDelegate){
			this.sourceFolder = (ISourceFolderDelegate) parent;
		}
	}
	/**
	 * 
	 * @param sourceFolder
	 * @param parent
	 * @param path
	 */
	public DefaultFolderDelegate(ISourceFolderDelegate sourceFolder,IFolderDelegate parent,String path) {
		this(parent, path);
		this.sourceFolder = sourceFolder;
	}
	/*
	 * (non-Javadoc)
	 * @see org.eclipse.core.runtime.PlatformObject#getAdapter(java.lang.Class)
	 */
	@Override
	public Object getAdapter(Class adapter) {
		return super.getAdapter(adapter);
	}
	@Override
	public ISourceFolderDelegate getSourceFolder() throws ResourceException {
		return this.sourceFolder;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getChildren()
	 */
	public IResourceDelegate[] getChildren() {
		return children.toArray(new IResourceDelegate[0]);
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getFile(java.lang.String)
	 */
	public IFileDelegate getFile(String path) {
		if (StringUtils.isEmpty(path)) {
			return null;
		}
		Path temp = new Path(path);
		int count = temp.segmentCount();
		String name = "";
		IResourceDelegate[] children = this.getChildren();
		IFileDelegate file = null;
		for (int i = 0; i < count && children.length > 0; i++) {
			name = temp.segment(i);
			for (int j = 0; j < children.length; j++) {
				IResourceDelegate delegate = children[j];
				if(delegate instanceof IFolderDelegate){
					if(name.equals(delegate.getName())){
						IFolderDelegate folder = (IFolderDelegate) delegate;
						children = folder.getChildren();
						break;
					}
				} else if( i == count-1 && name.equals(delegate.getName())){
					file = (IFileDelegate) delegate;
				}
			}
		}
		return file;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#getFolder(java.lang.String)
	 */
	public IFolderDelegate getFolder(String path) {
		if (StringUtils.isEmpty(path)) {
			return null;
		}
		if(path.equals("..")){
			return this.getParent();
		}
		if(path.equals("/")){
			return this;
		}
		Path temp = new Path(path);
		int count = temp.segmentCount();
		String name = "";
		IResourceDelegate[] children = this.getChildren();
		IFolderDelegate folder = null;
		for (int i = 0; i < count && children.length > 0; i++) {
			name = temp.segment(i);
			for (int j = 0; j < children.length; j++) {
				IResourceDelegate delegate = children[j];
				if(delegate instanceof IFolderDelegate){
					if(name.equals(delegate.getName())){
						folder = (IFolderDelegate) delegate;
						children = folder.getChildren();
						break;
					}
				}
			}
		}
		return folder;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IFolderDelegate#isPrefixOf(com.primeton.studio.runtime.resources.IResourceDelegate)
	 */
	public boolean isPrefixOf(IResourceDelegate resourceDelegate) {
		IPath resoucePath = new Path(resourceDelegate.getFullPath());
		IPath thisPath = new Path(this.getFullPath());
		if(thisPath.isPrefixOf(resoucePath)){
			return true;
		}
		return false;
	}
	/**
	 * 
	 * @param resource
	 */
	public void addChild(IResourceDelegate resource){
		this.children.add(resource);
	}
	/**
	 * 
	 * @param resource
	 */
	public void removeChild(IResourceDelegate resource){
		this.children.remove(resource);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#getType()
	 */
	public int getType() throws ResourceException {
		return FOLDER;
	}
	/**
	 * @param sourceFolder The sourceFolder to set.
	 */
	public void setSourceFolder(ISourceFolderDelegate sourceFolder) {
		this.sourceFolder = sourceFolder;
	}
}
