/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.node.base;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.JavaCore;

import com.primeton.studio.runtime.metadata.IMetadata;
import com.primeton.studio.runtime.metadata.internal.FileMetadata;
import com.primeton.studio.runtime.metadata.internal.FolderMetadata;
import com.primeton.studio.runtime.model.IResourceNode;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IResourceDelegate;
import com.primeton.studio.runtime.resources.internal.eclipse.EclipseResourceDelegate;

/**
 * ��Դ��㣬����һ����Դ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractResourceNode.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/04/08 05:36:12  wanglei
 * Update:ʵ��getMetadata������
 *
 * Revision 1.1  2008/03/19 05:05:44  wanglei
 * Review:�������,��ģ�͵����ݴ�navigator����г�ȡ��runtime����С�
 *
 * Revision 1.9  2008/03/19 03:09:50  wanglei
 * Review:��ԭ��д��Nodeϵ�������е�IWorkbenchAdapter��ȡ����չ�㣬����ǿ������
 *
 * Revision 1.8  2008/01/24 10:46:47  hongsq
 * Update;��ԭΪԭ�����룬ȥ�����ӵ�����Adapter
 *
 * Revision 1.7  2008/01/23 10:55:03  hongsq
 * Update:��IResourceNode�ṩIcontributorResourceAdapter��IcontributorResourceAdapter2������
 *
 * Revision 1.6  2008/01/09 06:54:23  wanglei
 * Update:�Ż���hashCode������
 *
 * Revision 1.5  2007/09/11 03:24:35  wanglei
 * Review:֧�ֶ�IJavaElementԪ�ص�Adapter��
 *
 * Revision 1.4  2007/05/08 09:09:37  wanglei
 * Refactor:�̳���AbstractNode
 *
 * Revision 1.3  2007/04/24 06:53:33  wanglei
 * ֧��getResource������
 *
 * Revision 1.2  2007/04/05 01:24:09  wanglei
 * Add:���Ӷ�Metadata��֧�֡�
 *
 * Revision 1.1  2007/03/30 09:34:43  wanglei
 * �ύ��CVS��
 *
 */

public abstract class AbstractResourceNode extends AbstractNode implements IResourceNode {

	private IResourceDelegate resource;

	/**
	 * ֱ�Ӵ�����Դ�����캯����<BR>
	 *
	 * @param resource ��ֵ����Ϊ��
	 */
	public AbstractResourceNode(IResourceDelegate resource) {
		super();

		this.setResource(resource);
		Assert.isNotNull(this.resource, "The resource should not be null.");
	}

	/**
	 * ������Դ
	 * @param resource
	 */
	protected void setResource(IResourceDelegate resource) {
		this.resource = resource;
	}

	/**
	 * @return the resource
	 */
	public IResourceDelegate getResource() {
		return this.resource;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.INode#getModel()
	 */
	public Object getModel() {
		return this.resource;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.model.INode#isVirtual()
	 */
	public boolean isVirtual() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getAdapter(Class adapter) {

		if (IJavaElement.class == adapter) {
			EclipseResourceDelegate resourceDelegate = (EclipseResourceDelegate) this.getResource();
			IResource eclipseResource = resourceDelegate.getResource();
			return JavaCore.create(eclipseResource);
		}

		if (IResourceDelegate.class == adapter) {
			return this.getResource();
		}

		if (IResource.class.isAssignableFrom(adapter)) {
			return this.getResource().getAdapter(adapter);
		}

		return super.getAdapter(adapter);
	}

	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		return this.resource.getName();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getName() {
		return this.getResource().getName();
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {

		Object model = this.getModel();
		String type = this.getType();

		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((model == null) ? 0 : model.hashCode());
		result = PRIME * result + ((this.resource == null) ? 0 : this.resource.hashCode());
		result = PRIME * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		final AbstractResourceNode other = (AbstractResourceNode) obj;

		if (!ObjectUtils.equals(this.resource, other.resource)) {
			return false;
		}

		Object model = this.getModel();
		Object otherModel = other.getModel();

		if (!ObjectUtils.equals(model, otherModel)) {
			return false;
		}

		String type = this.getType();
		String otherType = other.getType();
		return StringUtils.equals(type, otherType);
	}

	/**
	 * {@inheritDoc}
	 */
	public IMetadata getMetadata() {

		IResourceDelegate currentResource=this.getResource();
		if(null==currentResource)
		{
			return null;
		}

		if(currentResource.getType()==IResourceDelegate.FILE)
		{
			return FileMetadata.newInstance((IFileDelegate)currentResource,false);
		}

		if(currentResource.getType()==IResourceDelegate.FOLDER)
		{
			return FolderMetadata.newInstance((IFolderDelegate)currentResource,false);
		}

		return null;

	}
}
