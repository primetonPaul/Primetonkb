/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal.filter;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IPackage;
import com.primeton.studio.runtime.core.base.AbstractFilter;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ���˰������Package<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ConfigurationFilter.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/01/11 05:21:36  tenghao
 * Update: ������webcontentĿ¼
 *
 * Revision 1.2  2008/01/10 09:53:02  wanglei
 * Update:����webcontentĿ¼��
 *
 * Revision 1.1  2008/01/09 05:46:30  wanglei
 * Add:�ύ��CVS��
 *
 */

public class ConfigurationFilter extends AbstractFilter {

	public static final ConfigurationFilter instance = new ConfigurationFilter();

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private ConfigurationFilter() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean accept(IEosElement parent, IResourceDelegate resource) {

		if (null == resource) {
			return false;
		}

		if (resource.getType() == IResourceDelegate.FILE) {
			return true;
		}

		if (parent instanceof IPackage) {
			IPackage pkg = (IPackage) parent;
			if (pkg.getParent().equals(pkg.getPackageRoot())) {
//				return (!RuntimeConstant.META_INF.equalsIgnoreCase(resource.getName())) && (!RuntimeConstant.WEB_CONTENT.equalsIgnoreCase(resource.getName()));
				return (!RuntimeConstant.META_INF.equalsIgnoreCase(resource.getName()));//������webcontentĿ¼
			}
		}

		return super.accept(parent, resource);
	}

}
