/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.exception;


/**
 * EOSģ���쳣<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EosModelException.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/04/24 02:48:45  wanglei
 * �ύ��CVS��
 *
 */
public class EosModelException extends RuntimeException {
	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public EosModelException() {
		super();

	}

	/**
	 * @param message
	 * @param cause
	 */
	public EosModelException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 */
	public EosModelException(String message) {
		super(message);

	}

	/**
	 * @param cause
	 */
	public EosModelException(Throwable cause) {
		super(cause);

	}
}
