/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/project/EosProjectMarkHelper.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-6-5
 *******************************************************************************/


package com.primeton.studio.runtime.project;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;

/**
 * 
 * ��Ǵ�����Ϣ
 *
 * @author yujl (mailto:yujl@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EosProjectMarkHelper.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/06/06 02:13:38  yujl
 * Fix BUG:8533[ʾ����Ŀ]�½�helloworld��ʾ����Ŀ����뱨��,��ʾwebӦ��eos-default�Ƿ�
 *
 */
public class EosProjectMarkHelper {

	/**
	 * �����࣬˽�л�������
	 *
	 */
	private EosProjectMarkHelper(){}
	
	/**
	 * ��Ǵ�����Ϣ
	 * @param project
	 * @param message
	 */
	public static void markError(IProject project,String message,String type,int priority,int severity) {
		IMarker mark;
		try {
			mark = project.createMarker(type);
			mark.setAttribute(IMarker.MESSAGE, message);
			mark.setAttribute(IMarker.PRIORITY, priority);
			mark.setAttribute(IMarker.SEVERITY, severity);
		} catch (CoreException e) {
			// Nothing to do
		}
	}
}
