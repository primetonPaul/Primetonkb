/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/event/StudioEventManager.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2004 Primeton Technologies, Ltd.
 * All rights reserved. 
 * 
 * Created on 2004-7-30
 *******************************************************************************/


package com.primeton.studio.runtime.event;

import java.util.Hashtable;
import java.util.Vector;

import com.primeton.studio.core.log.StudioTraceManager;
import com.primeton.studio.core.log.TraceLogger;
import com.primeton.studio.runtime.RuntimePlugin;

/**
 * �¼�������
 * @author jiaoly (mailto:jiaoly@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: StudioEventManager.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/05/12 07:52:10  jiaoly
 * Add���� 5 �汾Ǩ���¼�����ģ��
 *
 * Revision 1.2  2006/12/27 08:36:52  caiwei
 * fix bug
 *
 * Revision 1.1  2005/04/07 01:15:02  yanfei
 * Create 5.1 Project
 *
 * Revision 1.4  2005/03/10 04:16:50  jiaoly
 * listener��ִ������������쳣, Ҳ��֪ͨ������listener
 *
 * Revision 1.3  2004/09/16 08:39:48  jiaoly
 * *** empty log message ***
 *
 * Revision 1.2  2004/09/13 10:12:31  jiaoly
 * *** empty log message ***
 *
 * Revision 1.1  2004/07/30 06:50:47  jiaoly
 * �½� �¼����� ģ��
 * 
 */
public class StudioEventManager {
     
	private static TraceLogger logger = StudioTraceManager.registerTraceLogger(RuntimePlugin.PLUGIN_ID, StudioEventManager.class.getName());
    private Hashtable listeners = new Hashtable();
    private static StudioEventManager studioEventManager = new StudioEventManager();
    /**
     * 
     */
    private StudioEventManager() {
        super();
    }
    
    public static StudioEventManager theOne(){
        return studioEventManager;
    }
    
    /**
     * Ϊ eventID ָ�����͵��¼�ע�������
     * @param eventID
     * @param listener
     * @return
     */
    public static int registerListener(String eventID, StudioListener listener){
        int size = StudioEventManager.theOne().registe(eventID, listener);
        if(logger.isDebugEnabled()){
            String str = "StudioEventManager.registerListener eventID : [" + eventID + "]";
            str = str + StudioEventManager.theOne().getListeners().get(eventID);
            logger.debug(str);
        }        
        return size;
    }

    /**
     * Ϊ eventID ָ�����͵��¼�������������, ɾ��ָ���ļ�����
     * @param eventID
     * @param listener
     * @return
     */
    public static int removeListener(String eventID, StudioListener listener){
        int size = StudioEventManager.theOne().remove(eventID, listener);
        if(logger.isDebugEnabled()){
            String str = "StudioEventManager.removeListener eventID : [" + eventID + "]";
            str = str + StudioEventManager.theOne().getListeners().get(eventID);
            logger.debug(str);
        }                
        return size;
    }

    /**
     * �õ�ָ�� eventID �����м������б�
     * @param eventID
     * @return
     */
    public static Vector allListeners(String eventID){
        StudioEventManager manager = StudioEventManager.theOne();
        Vector vector = (Vector)manager.listeners.get(eventID);
        return vector;
    }
    
    /**
     * �����¼�, eventID Ϊ�¼�����
     * @param eventID
     * @param event
     */
    public static void fire(String eventID, StudioEvent event){
        if(logger.isDebugEnabled()){
            String str = "StudioEventManager.fire eventID : [" + eventID + "]" + event.getParams();
            logger.debug(str);
        }
        event.setEventID(eventID);
        StudioEventManager.theOne().fireEvent(event);
    }

    /**
     * �����¼�, �¼�����Ϊ event.getName()
     * @param event
     */
    public static void fire(StudioEvent event){
        if(logger.isDebugEnabled()){
            String str = "StudioEventManager.fire event : [" + event.getParams() + "]";
            logger.debug(str);
        }
        StudioEventManager.theOne().fireEvent(event);
    }
    
    private synchronized int registe(String id, StudioListener listener){
        Vector vector = (Vector)this.listeners.get(id);
        if(id == null){
            return 0;
        }
        
        if(vector == null){
            vector = new Vector();
            this.listeners.put(id, vector);
        }
        vector.add(listener);
        return vector.size();
    }

    private synchronized int remove(String id, StudioListener listener){
        Vector vector = (Vector)this.listeners.get(id);
        if(vector == null){
            return 0;
        }
        vector.remove(listener);
        return vector.size();
    }

    private synchronized void fireEvent(StudioEvent event){
        String id = event.getEventID();
        if(id == null){
            logger.warn("The event name == null : [" + event + "]");
            return ;
        }
        Vector vector = (Vector)this.listeners.get(id);
        if(vector == null){
            return ;
        }
        
        Vector cloneVector = (Vector)vector.clone();
        for(int i = 0; i < cloneVector.size(); i++){
            StudioListener listener = (StudioListener)cloneVector.get(i);
            try{
                listener.execute(event);
            }catch(Throwable e){
            	logger.error("Execute listener error " + listener.getClass() , e);
            }
        }
    }
    
    public Hashtable getListeners() {
        return listeners;
    }
}
