/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core;

/**
 * �������鳣��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: IEosElementConstant.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/12/23 08:57:52  wanglei
 * Review:���������֡�
 *
 * Revision 1.1  2007/12/23 02:36:59  wanglei
 * Add:�ύ��CVS��
 *
 */

public interface IEosElementConstant {

	public static final IEosElement[] NO_CHILDREN = new IEosElement[] {};

	public static final IModule[] EMPTY_MODULES = new IModule[0];

	public static final IContribution[] EMPTY_CONTRIBUTIONS = new IContribution[0];

	public static final IPackageRoot[] EMPTY_PACKAGE_ROOTS = new IPackageRoot[0];

	public static final IPackage[] EMPTY_PACKAGES = new IPackage[0];

	public static final IEosModel[] EMPTY_MODELS = new IEosModel[0];

	public static final IType[] EMPTY_TYPES = new IType[0];

	public static final IMethod[] EMPTY_METHODS = new IMethod[0];

	public static final IField[] EMPTY_FIELDS = new IField[0];

	public static final IParameter[] EMPTY_PARAMETERS = new IParameter[0];

	public static final IResult[] EMPTY_RESULTS = new IResult[0];

	public static final IImportReference[] EMPTY_IMPORT_REFERENCES = new IImportReference[0];

	public static final ISuperTypeReference[] EMPTY_SUPER_TYPE_REFERENCES = new ISuperTypeReference[0];

}
