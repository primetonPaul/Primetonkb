/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/helper/SeparatorAnalyserHelper.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.helper;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.core.internal.Type;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.separatoranalyser.ComplexSeparatorContext;
import com.primeton.studio.runtime.separatoranalyser.DefaultSeparatorAnalyserPolicy;
import com.primeton.studio.runtime.separatoranalyser.IComplexSeparatorAnalyser;
import com.primeton.studio.runtime.separatoranalyser.ISeparatorAnalyserPolicy;
import com.primeton.studio.runtime.separatoranalyser.ISeparatorPolicy;
import com.primeton.studio.runtime.separatoranalyser.SeparateAssertResult;
import com.primeton.studio.runtime.separatoranalyser.internal.EntityFieldSeparatorPolicy;
import com.primeton.studio.runtime.separatoranalyser.internal.EntityFinder;
import com.primeton.studio.runtime.separatoranalyser.internal.EntitySeparatorAnalyserPolicy;
import com.primeton.studio.runtime.separatoranalyser.internal.JavaFieldSeparatorPolicy;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: SeparatorAnalyserHelper.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.5  2008/10/29 10:27:37  liu-jun
 * Bug:13984 ��javabean�е�List������ʾ����ȷ commit by yangmd
 *
 * Revision 1.4  2008/08/15 07:50:18  zhuxing
 * Update:�޸Ĺ������з����ļ��Զ����ɺ�������ʾ������
 *
 * Revision 1.3  2008/07/09 10:50:45  yangmd
 * Update:�ع���
 *
 * Revision 1.2  2008/07/08 13:23:15  yangmd
 * Update:��������������
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/05/23 06:02:11  yangmd
 * Update:�ع�separatorAnalyser����дע��
 *
 * Revision 1.2  2008/05/23 05:31:22  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/23 05:24:46  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class SeparatorAnalyserHelper {
	
	/**
	 * 
	 */
	private SeparatorAnalyserHelper() {
		//todo nothing;
	}
	
	/**
	 * ����xpath·�������һ��������ģ�ͣ�ģ���ǣ�field�� �����δ�ܽ��������ָ�����ʱ���ֹͣ�ˣ����᷵��null
	 * @param rootType {@link ISeparatorAnalyserConstant#JAVA}
	 * 					{@link ISeparatorAnalyserConstant#ENTITY}
	 * @param fullXpath ����ȫ�������ӽڵ�ĸ�ʽ
	 * 					�������£�
	 * 					��entity���Ϳ�ʼ:	com.primeton.Dataset.Entity1/field1/entity/...
	 * 					��java���Ϳ�ʼ: com.priemeton.eos.JavaType/field1/field1child/.... 
	 * @param contribution
	 * @return
	 */
	public static Object computeLastResult(String rootType, String fullXpath,IContribution contribution){
		return getResult(rootType, fullXpath, contribution, false);
	}
	
	/**
	 * add by zhuxing:��ʱ��֧��project�ӿ�
	 * 
	 * @param rootType
	 * @param fullXpath
	 * @param projectDelegate
	 * @return
	 */
	public static Object computeLastResult(String rootType, String fullXpath, IProjectDelegate projectDelegate){
		return getResult(rootType, fullXpath, projectDelegate, false);
	}
	
	/**
	 * ����xpath·�������������ȷ������ģ�ͣ�field��������ֵ��Ϊnull
	 * @param rootType {@link ISeparatorAnalyserConstant#JAVA}
	 * 					{@link ISeparatorAnalyserConstant#ENTITY}
	 * @param fullXpath ����ȫ�������ӽڵ�ĸ�ʽ
	 * 					�������£�
	 * 					��entity���Ϳ�ʼ:	com.primeton.Dataset.Entity1/field1/entity/...
	 * 					��java���Ϳ�ʼ: com.priemeton.eos.JavaType/field1/field1child/.... 
	 * @param contribution
	 * @return
	 */
	public static SeparateAssertResult getAssertResult(String rootType, String fullXpath,IContribution contribution){
		return (SeparateAssertResult) getResult(rootType, fullXpath, contribution, true);
	}
	
	/**
	 * add by zhuxing:��ʱ�ع��ӿڣ�֧���ڷ�contribution�ڲ�������ʹ�ø���ʾ
	 * 
	 * @param rootType
	 * @param fullXpath
	 * @param prjDelegate
	 * @return
	 */
	public static SeparateAssertResult getAssertResult(String rootType, String fullXpath, IProjectDelegate prjDelegate) {
		return (SeparateAssertResult) getResult(rootType, fullXpath, prjDelegate, true);
	}
	
	/**
	 * ����xpath·�������������ȷ������ģ�ͣ�field��������ֵ��Ϊnull
	 * @param fullXpath ����ȫ�������ӽڵ�ĸ�ʽ
	 * 					�������£�
	 * 					��entity���Ϳ�ʼ:	com.primeton.Dataset.Entity1/field1/entity/...
	 * 					��java���Ϳ�ʼ: com.priemeton.eos.JavaType/field1/field1child/.... 
	 * @param contribution
	 * @param fieldType JavaFieldSeparatorPolicy#ALL
	 * 					 JavaFieldSeparatorPolicy#GET
	 * 					 JavaFieldSeparatorPolicy#NONE
	 * 					 JavaFieldSeparatorPolicy#ONLY_ONE
	 *  				 JavaFieldSeparatorPolicy#SET
	 * @return
	 */
	public static Object computeLastJavaResult(String fullXpath,IContribution contribution,short fieldType){
		IProjectDelegate projectDelegate = contribution.getResource().getProject();
		JavaFieldSeparatorPolicy separatorPolicy = new JavaFieldSeparatorPolicy(projectDelegate,"/");
		separatorPolicy.setPojoMehod(fieldType);
		return getResult(ISeparatorAnalyserConstant.JAVA, fullXpath, new IContribution[] {contribution}, separatorPolicy, false);
	}
	
	/**
	 * ����xpath·�������������ȷ������ģ�ͣ�field��������ֵ��Ϊnull
	 * @param fullXpath ����ȫ�������ӽڵ�ĸ�ʽ
	 * 					�������£�
	 * 					��entity���Ϳ�ʼ:	com.primeton.Dataset.Entity1/field1/entity/...
	 * 					��java���Ϳ�ʼ: com.priemeton.eos.JavaType/field1/field1child/.... 
	 * @param contribution
	 * @param fieldType JavaFieldSeparatorPolicy#ALL
	 * 					 JavaFieldSeparatorPolicy#GET
	 * 					 JavaFieldSeparatorPolicy#NONE
	 * 					 JavaFieldSeparatorPolicy#ONLY_ONE
	 *  				 JavaFieldSeparatorPolicy#SET
	 * @return
	 */
	public static SeparateAssertResult getJavaAssertResult(String fullXpath, IContribution contribution,short fieldType){
		IProjectDelegate projectDelegate = contribution.getResource().getProject();
		JavaFieldSeparatorPolicy separatorPolicy = new JavaFieldSeparatorPolicy(projectDelegate,"/");
		separatorPolicy.setPojoMehod(fieldType);
		return (SeparateAssertResult) getResult(ISeparatorAnalyserConstant.JAVA, fullXpath, new IContribution[] {contribution}, separatorPolicy, true);
	}
	
	/**
	 * 
	 * @param rootType
	 * @param fullXpath 
	 * @param contribution
	 * @param useAssert
	 * @return
	 */
	private static Object getResult(String rootType, String fullXpath,IContribution contribution,boolean useAssert){
		IProjectDelegate projectDelegate = contribution.getResource().getProject();
		if(ISeparatorAnalyserConstant.JAVA.equals(rootType)){
			ISeparatorPolicy separatorPolicy = new JavaFieldSeparatorPolicy(projectDelegate,"/");
			return getResult(rootType, fullXpath, new IContribution[] {contribution}, separatorPolicy, useAssert);
		} else if(ISeparatorAnalyserConstant.ENTITY.equals(rootType)){
			ISeparatorPolicy separatorPolicy = new EntityFieldSeparatorPolicy(projectDelegate,"/");
			return getResult(rootType, fullXpath, new IContribution[] {contribution}, separatorPolicy, useAssert);
		}
		return null;
	}
	
	private static Object getResult(String rootType, String fullXpath, IProjectDelegate prjDelegate,boolean useAssert){
		IContribution[] contributions = RuntimeManager.getAllContributions(prjDelegate);
		if(ISeparatorAnalyserConstant.JAVA.equals(rootType)){
			ISeparatorPolicy separatorPolicy = new JavaFieldSeparatorPolicy(prjDelegate,"/");
			return getResult(rootType, fullXpath, contributions, separatorPolicy, useAssert);
		}
		else if (ISeparatorAnalyserConstant.ENTITY.equals(rootType)) {
			ISeparatorPolicy separatorPolicy = new EntityFieldSeparatorPolicy(prjDelegate,"/");
			return getResult(rootType, fullXpath, contributions, separatorPolicy, useAssert);
		}
		return null;
	}
	
	/**
	 * 
	 * @param rootType
	 * @param fullXpath
	 * @param contribution
	 * @param separatorPolicy
	 * @param useAssert
	 * @return
	 */
	private static Object getResult(String rootType, String fullXpath, IContribution[] contributions, ISeparatorPolicy separatorPolicy,boolean useAssert){
		fullXpath = formatXpath(fullXpath);
		String rootTypeName = StringUtils.substringBefore(fullXpath,"/");
		String childrenContents = StringUtils.substringAfter(fullXpath,"/");
		if(ISeparatorAnalyserConstant.JAVA.equals(rootType)){
			Type type = new Type();
			type.setName(rootTypeName);
			IProjectDelegate projectDelegate = contributions[0].getResource().getProject();
			IComplexSeparatorAnalyser analyser = SeparatorAnalyserFactory.Instance.createJavaFieldSeAnalyser(projectDelegate);
			ComplexSeparatorContext separatorContext = new ComplexSeparatorContext(
					separatorPolicy,type,rootTypeName,childrenContents);
			ISeparatorAnalyserPolicy policy = new DefaultSeparatorAnalyserPolicy(analyser);
			if(useAssert){				
				return analyser.getAssertResult(0,separatorContext, policy);
			} else {
				return analyser.computeLastResult(separatorContext, policy);
			}
		} else if(ISeparatorAnalyserConstant.ENTITY.equals(rootType)){
			IProjectDelegate projectDelegate = contributions[0].getResource().getProject();
			IComplexSeparatorAnalyser javaAnalyser = SeparatorAnalyserFactory.Instance.createJavaFieldSeAnalyser(projectDelegate);
			IComplexSeparatorAnalyser entityAnalyser = SeparatorAnalyserFactory.Instance.createEntityFieldSeAnalyser(contributions);
			
			String datasetName = StringUtils.substringBeforeLast(rootTypeName, ".");
			String firstChild = StringUtils.substringAfterLast(rootTypeName, ".");
			IType tempType = null;
			for (int i = 0; i < contributions.length; i++) {
				IContribution contribution = contributions[i];
				tempType = EntityFinder.findEntity(datasetName, firstChild, contribution);
				if(tempType != null){
					break;
				}
			}
			if(tempType == null)return null;
			ComplexSeparatorContext separatorContext = new ComplexSeparatorContext(
					separatorPolicy,tempType,rootType, childrenContents);
			ISeparatorAnalyserPolicy policy = new EntitySeparatorAnalyserPolicy(javaAnalyser,entityAnalyser);
			
			if(useAssert){
				return entityAnalyser.getAssertResult(0,separatorContext, policy);
			} else {
				return entityAnalyser.computeLastResult(separatorContext, policy);
			}
		}
		return null;
	
	}

	
	/**
	 * 
	 * @param xpath
	 * @return
	 */
	private static String formatXpath(String xpath){
		if(xpath.startsWith("/")){
			xpath = StringUtils.substringAfter(xpath, "/");
		}
		if(xpath.endsWith("/")){
			xpath = StringUtils.substringBeforeLast(xpath, "/");
		}
		return xpath;
	}
	
	
}
