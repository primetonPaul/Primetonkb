/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/IOutputFolderDelegate.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:53 $
 * 
 * ==============================================================================
 * 
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 * 
 * Created on 2007-1-25
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources;

/**
 * ���������Ŀ¼��<BR>
 * 
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 * 
 * $Log: IOutputFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public interface IOutputFolderDelegate extends IFolderDelegate {

}
