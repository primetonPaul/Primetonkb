/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/project/IJavaBuilder.java,v 1.1 2012/01/12 02:06:42 guwei Exp $
 * $Revision: 1.1 $
 * $Date: 2012/01/12 02:06:42 $
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2011-9-19
 *******************************************************************************/


package com.primeton.studio.runtime.project;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.runtime.IProgressMonitor;

/**
 * ��ʶ�ӿڣ���ͬ�汾��ͬʵ��
 *
 * @author guwei (mailto:guwei@primeton.com)
 */
public interface IJavaBuilder {
	
	public void build(IFolder folder, boolean supportNoneJavaResources, IProgressMonitor monitor);
	
}

/*
 * �޸���ʷ
 * $Log: IJavaBuilder.java,v $
 * Revision 1.1  2012/01/12 02:06:42  guwei
 * Update: �汾�������޸ģ�֧��eclipse3.6
 * 
 */