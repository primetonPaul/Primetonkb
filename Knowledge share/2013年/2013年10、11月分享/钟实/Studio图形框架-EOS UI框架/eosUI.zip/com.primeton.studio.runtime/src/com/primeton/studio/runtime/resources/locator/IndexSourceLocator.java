/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/IndexSourceLocator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-7-20
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;
import com.primeton.studio.runtime.util.ContributionUtil;

/**
 * ͨ�������������ƿռ䣬�����ļ�·�����ٲ�����Դ��<BR>
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IndexSourceLocator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/07/20 10:38:50  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 * 
 */
public class IndexSourceLocator implements IEOSResourceLocator {
	
	public IndexSourceLocator(){}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFile(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate findFile(IProjectDelegate project, String[] namespaces) {
		return new ProjectLookupParticipant(project).findFile(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFile(com.primeton.studio.runtime.core.IContribution, java.lang.String[], boolean)
	 */
	public IFileDelegate findFile(IContribution contribution,String[] namespaces, boolean includeReference) {
		IContribution[] contributions = includeReference ? ContributionUtil.getAllRelatedContributions(new IContribution[] { contribution }) : new IContribution[] { contribution };
		return new ContributionLookupParticipant(contributions).findFile(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInLibraries(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate findFileInLibraries(IProjectDelegate project,String[] namespaces) {
		return new ProjectLibrariesLookupParticipant(project).findFile(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInSourceFolders(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate findFileInSourceFolders(IProjectDelegate project,String[] namespaces) {
		IContribution[] allContributions = RuntimeManager.getAllContributions(project, false);
		return new ContributionLookupParticipant(allContributions).findFile(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEOSResourceLocator#findFileInFolders(java.lang.String[], com.primeton.studio.runtime.resources.IFolderDelegate[])
	 */
	public IFileDelegate findFileInFolders(String[] namespaces, IFolderDelegate[] folders) {
		return new FolderLookupParticipant(folders).findFile(namespaces);
	}
}
