/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/java/JavaSourceFolderDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-30
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.java;

import java.io.File;

import com.primeton.studio.runtime.resources.IOutputFolderDelegate;
import com.primeton.studio.runtime.resources.ISourceFolderDelegate;

/**
 * ����Java�ļ���Դʵ��ISourceFolderDelegate�ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaSourceFolderDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/08/08 07:10:58  wanglei
 * Update:����ʵ�����еĹ��ܡ�
 *
 * Revision 1.2  2007/04/18 08:38:45  wanglei
 * Update:�����еķ������ö�ת����JavaResourceManager��������
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public class JavaSourceFolderDelegate extends JavaFolderDelegate implements ISourceFolderDelegate {

	private JavaOutputFolderDelegate outputFolder;

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param file
	 * @param outputFolder
	 */
	public JavaSourceFolderDelegate(File file,File outputFolder) {
		super(file);
		this.outputFolder=new JavaOutputFolderDelegate(outputFolder);
	}

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param fileName
	 * @param outputFolderName
	 */
	public JavaSourceFolderDelegate(String fileName,String outputFolderName) {
		super(fileName);
		this.outputFolder=new JavaOutputFolderDelegate(outputFolderName);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.ISourceFolderDelegate#getOutputFolder()
	 */
	public IOutputFolderDelegate getOutputFolder() {
		return this.outputFolder;
	}
}
