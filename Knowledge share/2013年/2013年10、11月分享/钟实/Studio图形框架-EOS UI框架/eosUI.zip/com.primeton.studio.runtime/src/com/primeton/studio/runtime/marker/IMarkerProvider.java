/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/marker/IMarkerProvider.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-9-20
 *******************************************************************************/


package com.primeton.studio.runtime.marker;

import org.eclipse.core.resources.IMarker;

/**
 * IMarker���ṩ��
 *
 * @author Chenxp (mailto:chenxp@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IMarkerProvider.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/09/20 07:01:08  chenxp
 * Add:�ύ��ʼ���뵽cvs.
 *
 */
public interface IMarkerProvider {

	public IMarker getMarker();

}
