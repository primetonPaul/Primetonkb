/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/base/AbstractModelFactory.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-2-7
 **********************************************************************************************************************/

package com.primeton.studio.runtime.model.base;

import org.apache.commons.io.FilenameUtils;
import org.eclipse.core.runtime.IProgressMonitor;

import com.eos.system.utility.StringUtil;
import com.primeton.studio.core.base.AbstractAdaptableObject;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.model.IModelCompiler;
import com.primeton.studio.runtime.model.IModelDocumentProvider;
import com.primeton.studio.runtime.model.IModelFactory;
import com.primeton.studio.runtime.model.IModelParser;
import com.primeton.studio.runtime.model.IModelValidator;
import com.primeton.studio.runtime.model.ISignature;
import com.primeton.studio.runtime.model.internal.InternalSignature;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * IModelFactory�Ļ��ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractModelFactory.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.4  2010/04/14 10:17:42  wanglei
 * Jira:����EOSP-197��
 *
 * Revision 1.3  2009/05/04 01:43:31  wanglei
 * Review:���µ���APIǩ��������ISignature�ӿڡ�
 *
 * Revision 1.2  2009/04/21 09:51:53  wanglei
 * Review:ʹ��ģ��ǩ���ķ�ʽ���ӿ�ģ�͵��������롣
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.19  2008/04/09 11:56:03  wanglei
 * Update:ʵ��getDocumentProvider������
 *
 * Revision 1.18  2008/03/03 07:00:05  hongsq
 * Update:����һ��validateFileName�ķ���,��ָ֤�����ļ��Ƿ��Ǹ�ModelFactory�ܱ�������͵��ļ�,�������ֱ�ӷ���true
 *
 * Revision 1.17  2007/12/17 05:29:46  wanglei
 * Add:����getPossibleNames������
 *
 * Revision 1.16  2007/11/29 03:39:23  wanglei
 * Review:�ֽ�ԭ����ResourceHelper�ķ�����RuntimeHelper��ModelHelper�С�
 *
 * Revision 1.15  2007/11/29 02:56:52  wanglei
 * Review:��Ϊ�ع������Ѿ�������ȡ����������ȥ�ع���ص����ݡ�
 *
 * Revision 1.14  2007/11/26 06:45:08  chenxp
 * UnitTest:��getValidator������һ���ǿ��ж�
 *
 * Revision 1.13  2007/09/26 06:21:05  wanglei
 * Add:����getBinaryName������
 *
 * Revision 1.12  2007/06/30 13:11:17  wanglei
 * Review:CompositeӦ���޸ĳ�Contribution��
 *
 * Revision 1.11  2007/06/28 09:24:04  wanglei
 * Add:����һ��supportBinary�������ж��Ƿ�֧�ֶ��������ÿ⡣
 *
 * Revision 1.10  2007/06/27 01:34:45  wanglei
 * Review:Ӧ�����Ӻ�Binary�йص����ݡ�
 *
 * Revision 1.9  2007/06/21 14:10:02  wanglei
 * Review:���ֽӿ��Ѿ�ɾ����Ӧ���е�����
 *
 * Revision 1.8  2007/06/16 03:12:14  wanglei
 * Add:����getVersion��֧�ְ汾��
 *
 * Revision 1.7  2007/06/11 08:22:20  wanglei
 * Add:������supportIndex������������ж��Ƿ�ģ���Ƿ�֧��������
 *
 * Revision 1.6  2007/06/04 11:54:53  wanglei
 * Add:ʵ��getDisplayName��isVirtual������
 *
 * Revision 1.5  2007/06/04 08:17:19  wanglei
 * Update:�������ù�ϵʹ��IReferenceAnalyser��
 *
 * Revision 1.4  2007/04/10 10:49:13  wanglei
 * Refactor:���ӶԽ�������֧�֡�
 *
 * Revision 1.3  2007/04/10 10:30:39  wanglei
 * Refactor:���ӶԽ�������֧�֡�
 *
 * Revision 1.2  2007/03/30 09:29:58  wanglei
 * Add:����getExtensionNames������
 *
 * Revision 1.1  2007/03/05 11:32:13  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractModelFactory extends AbstractAdaptableObject implements IModelFactory {

	private int priority = 0;

	/**
	 * Ĭ�Ϲ��캯��
	 */
	public AbstractModelFactory() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public final int getPriority() {
		return this.priority;
	}

	/**
	 * {@inheritDoc}
	 */
	public final void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * {@inheritDoc}
	 */
	public final Object clone() {
		return this;
	}

	/**
	 * {@inheritDoc}
	 */
	public final IModelCompiler getCompiler(IFileDelegate fileDelegate, IProgressMonitor progressMonitor) {
		if (!validateFileName(fileDelegate)) {
			return null;
		}
		Object model = RuntimeHelper.parse(fileDelegate, progressMonitor);
		return this.getCompiler(model, progressMonitor);
	}

	/**
	 * {@inheritDoc}
	 */
	public final IModelValidator getValidator(IFileDelegate fileDelegate, IProgressMonitor progressMonitor) {
		if (!validateFileName(fileDelegate)) {
			return null;
		}

		Object model = RuntimeHelper.parse(fileDelegate, progressMonitor);
		if (model == null)
			return null;
		return this.getValidator(model, progressMonitor);
	}

	/**
	 * �ж�Ҫ������ļ��Ƿ��ܴ���
	 * @param fileDelegate
	 * @return
	 */
	protected boolean validateFileName(IFileDelegate fileDelegate) {
		//����������ظ÷���,���˴������˵��ļ�
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public final boolean supportSearch() {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public final boolean supportTemplate() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean supportIndex(IFileDelegate fileDelegate, IProgressMonitor progressMonitor) {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public String[] getExtensionNames() {
		return new String[] {
			"*." + this.getName()
		};
	}

	/**
	 * {@inheritDoc}
	 */
	public String getDisplayName(IFileDelegate file) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getBinaryDisplayName(IFileDelegate file) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isVirtual() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getVersion() {
		return "6.0";
	}

	/**
	 * {@inheritDoc}
	 */
	public String[] getBinaryExtensionNames() {
		return new String[] {
			"*." + this.getBinaryName()
		};
	}

	/**
	 * {@inheritDoc}
	 */
	public String getBinaryName() {
		return this.getName();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean supportBinary() {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getBinaryName(IFileDelegate file) {
		return this.getBinaryName();
	}

	/**
	 * {@inheritDoc}
	 */
	public String[] getPossibleNames(String fileName) {

		String name = FilenameUtils.removeExtension(fileName);
		return new String[] {
			name + "." + this.getName(),
			name + "." + this.getBinaryName()
		};
	}

	/**
	 * {@inheritDoc}
	 */
	public ISignature createSignature(IFileDelegate fileDelegate, IProgressMonitor monitor) {
		IModelParser modelParser=this.getModelParser(fileDelegate, monitor);

		if(null==modelParser)
		{
			return null;
		}

		Object model=modelParser.parse(fileDelegate, monitor);
		return this.createSignature(model,monitor);
	}

	/**
	 * {@inheritDoc}
	 */
	public ISignature createSignature(Object model, IProgressMonitor monitor) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public ISignature createSignature(String signatureString, IProgressMonitor monitor) {
		return new InternalSignature(signatureString);
	}

	/**
	 * {@inheritDoc}
	 */
	public IModelDocumentProvider getDocumentProvider(IFileDelegate file, IProgressMonitor progressMonitor) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isAcceptable(IFileDelegate file) {
		return StringUtil.isWildcardMatchOne(file.getName(), this.getExtensionNames(), false);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean supportIdenticalExtension() {
		return true;
	}


}
