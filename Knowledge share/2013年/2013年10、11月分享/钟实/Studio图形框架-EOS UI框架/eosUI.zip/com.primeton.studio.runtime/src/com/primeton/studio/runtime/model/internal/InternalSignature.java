/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/InternalSignature.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-4-27
 *******************************************************************************/


package com.primeton.studio.runtime.model.internal;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.Assert;

import com.primeton.studio.runtime.model.ISignature;

/**
 * ISignature��Ĭ��ʵ��
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: InternalSignature.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/05/04 05:22:34  wanglei
 * Review:�ڹ��캯�����Ѿ��Ա���signature������null�жϣ����������ٽ��д�����
 *
 * Revision 1.2  2009/05/04 01:43:31  wanglei
 * Review:���µ���APIǩ��������ISignature�ӿڡ�
 *
 */
public class InternalSignature implements ISignature {

	private String signature;

	/**
	 *
	 */
	public InternalSignature(String signature) {
		Assert.isNotNull(signature, "the signature can't be null.");
		this.signature=signature;
	}

	/**
	 * {@inheritDoc}
	 */
	public String[] findDifferences(ISignature singnature) {

		if(null==singnature){
			return new String[]{this.signature};
		}

		if(StringUtils.equals(this.signature, singnature.getSignatureString()))		{
			return null;
		}
		else {
			return new String[]{this.signature};
		}

	}

	/**
	 * {@inheritDoc}
	 */
	public String getSignatureString() {
		return this.signature;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + signature.hashCode();
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		final InternalSignature other = (InternalSignature) obj;
		return (StringUtils.equals(this.signature, other.getSignatureString()))		;
	}
}
