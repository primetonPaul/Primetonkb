/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.internal.java;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.core.base.AbstractNamingElement;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.model.java.IAnnotationProperty;
import com.primeton.studio.runtime.model.java.IAnnotationType;

/**
 * IAnnotationType��Ĭ��ʵ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AnnotationType.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/12/06 07:58:37  chenxp
 * Update:����setDeclaringElement����
 *
 * Revision 1.1  2007/10/31 08:31:09  wanglei
 * Add:�ύ��CVS��
 *
 */

public class AnnotationType extends AbstractNamingElement implements IAnnotationType {

	private IType type;

	private IEosElement element;

	private List propertyList = new ArrayList(5);

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AnnotationType() {
		super();
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param displayName
	 * @param name
	 */
	public AnnotationType(String displayName, String name) {
		super(displayName, name);
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosElement getDeclaringElement() {
		return this.element;
	}

	/**
	 * ����Annotation��������Ԫ��
	 *
	 * @param element
	 */
	public void setDeclaringElement(IEosElement element) {
		this.element = element;
	}

	/**
	 * {@inheritDoc}
	 */
	public IType getDeclaringType() {
		return this.type;
	}

	/**
	 * {@inheritDoc}
	 */
	public IAnnotationProperty[] getProperties() {
		IAnnotationProperty[] properties = new IAnnotationProperty[this.propertyList.size()];
		this.propertyList.toArray(properties);
		return properties;
	}

	/**
	 * ����һ��Annotation���ԡ�<BR>
	 *
	 * @param property
	 */
	public void addProperty(IAnnotationProperty property) {
		this.propertyList.add(property);
	}

	/**
	 * ɾ��һ��Annotation���ԡ�<BR>
	 *
	 * @param property
	 */
	public void removeProperty(IAnnotationProperty property) {
		this.propertyList.remove(property);
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + ((this.element == null) ? 0 : this.element.hashCode());
		result = PRIME * result + ((this.propertyList == null) ? 0 : this.propertyList.hashCode());
		result = PRIME * result + ((this.type == null) ? 0 : this.type.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		final AnnotationType other = (AnnotationType) obj;
		if (!ObjectUtils.equals(this.element, other.element)) {
			return false;
		}

		if (!ObjectUtils.equals(this.type, other.type)) {
			return false;
		}

		return ObjectUtils.equals(this.propertyList, other.propertyList);
	}
}
