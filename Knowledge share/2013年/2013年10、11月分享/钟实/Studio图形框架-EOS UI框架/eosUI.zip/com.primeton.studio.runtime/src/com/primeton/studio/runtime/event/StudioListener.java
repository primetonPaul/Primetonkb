/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/event/StudioListener.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2004 Primeton Technologies, Ltd.
 * All rights reserved. 
 * 
 * Created on 2004-7-30
 *******************************************************************************/


package com.primeton.studio.runtime.event;

/**
 * @author jiaoly (mailto:jiaoly@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: StudioListener.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/05/12 07:52:10  jiaoly
 * Add���� 5 �汾Ǩ���¼�����ģ��
 *
 * Revision 1.1  2005/04/07 01:15:02  yanfei
 * Create 5.1 Project
 *
 * Revision 1.1  2004/07/30 06:50:47  jiaoly
 * �½� �¼����� ģ��
 * 
 */
public interface StudioListener {
    public String execute(StudioEvent event);
}
