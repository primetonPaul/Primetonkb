/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/internal/EntityFieldSeparatorAnalyser.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-5-22
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.internal;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.separatoranalyser.AbstractSeparatorAnalyser;
import com.primeton.studio.runtime.separatoranalyser.ComplexSeparatorContext;
import com.primeton.studio.runtime.separatoranalyser.ISeparatorPolicy;
import com.primeton.studio.runtime.separatoranalyser.SeparatorModel;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author ������ (mailto:yangmd@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EntityFieldSeparatorAnalyser.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.3  2008/10/29 10:27:37  liu-jun
 * Bug:13984 ��javabean�е�List������ʾ����ȷ commit by yangmd
 *
 * Revision 1.2  2008/08/15 07:50:18  zhuxing
 * Update:�޸Ĺ������з����ļ��Զ����ɺ�������ʾ������
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/23 05:24:46  yangmd
 * Update:�ع�separatorAnalyser
 *
 * Revision 1.1  2008/05/22 12:57:48  yangmd
 * Update:��������xpath�����ǲ�������xpath��ʵ���Ͽ������κηָ������е�Ԫ�ָ���������Ԫ��ܡ�
 * 
 */
public class EntityFieldSeparatorAnalyser extends AbstractSeparatorAnalyser {
	private IContribution[] contributions;
	
	/**
	 * 
	 * @param contribution
	 */
	public EntityFieldSeparatorAnalyser(IContribution[] contributions) {
		this.contributions = contributions;
	}
	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.runtime.helper.AbstractSeparatorAnalyser#doGetOneChild(java.lang.Object, com.primeton.studio.runtime.helper.ISeparatorPolicy, com.primeton.studio.runtime.helper.SeparatorModel, java.lang.String)
	 */
	protected Object doGetOneChild(ComplexSeparatorContext context, Object rootElement, ISeparatorPolicy separatorPolicy, SeparatorModel separatormodel, String childName) {
		IType type = null;
		if(rootElement instanceof IField){
			type = ((IField)rootElement).getDeclaringType();
			type = getEntityType(childName, type);
		} else if(rootElement instanceof IType){
			type = (IType)rootElement;
		}
		if(type == null)return null;
		IField[] fields = type.getFields();
		childName = StringUtils.substringBefore(childName, "[");
		IField field = null;
		for (int i = 0; i < fields.length; i++) {
			IField temp = fields[i];
			if(childName.equals(temp.getName())){
				field = temp;
			}
		}
		if(field == null)return null;
		SeparatorModel sepaModel = new SeparatorModel(separatormodel,field);
		if(separatorPolicy.accept(sepaModel)){
			return field;
		}
		return null;
	}
	/**
	 * 
	 * @param childName
	 * @param type
	 * @return
	 */
	private IType getEntityType(String childName, IType type){
		String typeName = type.getName();
		int typeArrayCount = this.arrayCount(type);
		int strArrayCount = this.arrayCount(childName);
		if(typeArrayCount < 1 || typeArrayCount == strArrayCount){
			typeName = StringUtils.substringBefore(typeName, "[");
			typeName = StringUtils.substringBefore(typeName, "<");
			
			String datasetName = StringUtils.substringBeforeLast(typeName, ".");
			datasetName = datasetName.replace('.', '/');
			String entityName = StringUtils.substringAfterLast(typeName, ".");
			return getEntity(entityName,datasetName);
		}
		return null;
	}
	/**
	 * 
	 * @param entityName
	 * @param datesetName
	 * @return
	 */
	private IType getEntity(String entityName, String datesetName){
		for (int i = 0; i < contributions.length; i++) {
			IContribution contribution = contributions[i];
			IType type = EntityFinder.findEntity(datesetName, entityName, contribution);
			if(type != null){
				return type;
			}
		}
		return null;
	}
}
