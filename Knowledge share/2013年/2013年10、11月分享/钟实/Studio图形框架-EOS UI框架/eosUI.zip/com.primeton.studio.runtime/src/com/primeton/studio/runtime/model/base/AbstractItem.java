/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/base/AbstractItem.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 * 
 * ==============================================================================
 * 
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 * 
 * Created on 2007-2-8
 **********************************************************************************************************************/

package com.primeton.studio.runtime.model.base;

/**
 * TODO �˴���д class ��Ϣ
 * 
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 * 
 * $Log: AbstractItem.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/05 11:32:13  wanglei
 * �ύ��CVS
 *
 */

// TODO ������δ���
public abstract class AbstractItem {
	private String value;

	private String type;

	/**
	 * Ĭ�Ϲ��캯��
	 */
	public AbstractItem() {
		super();

	}

	/**
	 * Ĭ�Ϲ��캯��
	 */
	public AbstractItem(String value, String type) {
		super();
		this.value = value;
		this.type = type;
	}

	/**
	 * @return Returns the value.
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * @param value
	 *            The value to set.
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * @param type
	 *            The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}

}
