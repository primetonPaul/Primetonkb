/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/locator/IndexMultiResourceLocator.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-8-19
 *******************************************************************************/


package com.primeton.studio.runtime.resources.locator;

import com.primeton.studio.runtime.RuntimeManager;
import com.primeton.studio.runtime.core.IContribution;
import com.primeton.studio.runtime.index.query.IndexFinder;
import com.primeton.studio.runtime.resources.IFileDelegate;
import com.primeton.studio.runtime.resources.IFolderDelegate;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * ������������
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IndexMultiResourceLocator.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/10/21 08:45:44  chenxp
 * Update: �Ż�studio����
 *
 * Revision 1.1  2009/08/20 07:47:03  hongsq
 * Update:�ṩһ��ӿ�֧�ֲ���һ���ļ������޸�xsd,wsdl��ع����������ƿռ��ظ�
 * 
 */
public class IndexMultiResourceLocator extends AbstractMultiResourceLocator {

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFiles(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFiles(IProjectDelegate project, String[] namespaces) {
		return new ProjectLookupParticipant(project).findFiles(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFiles(com.primeton.studio.runtime.core.IContribution, java.lang.String[], boolean)
	 */
	public IFileDelegate[] findFiles(IContribution contribution, String[] namespaces, boolean includeReference) {
		IContribution[] contributions = includeReference ? IndexFinder.getInstance().getAllRelatedContributions(new IContribution[] { contribution }) : new IContribution[] { contribution };
		return new ContributionLookupParticipant(contributions).findFiles(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInFolders(java.lang.String[], com.primeton.studio.runtime.resources.IFolderDelegate[])
	 */
	public IFileDelegate[] findFilesInFolders(String[] namespaces, IFolderDelegate[] folders) {
		return new FolderLookupParticipant(folders).findFiles(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInLibraries(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFilesInLibraries(IProjectDelegate project, String[] namespaces) {
		return new ProjectLibrariesLookupParticipant(project).findFiles(namespaces);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.resources.locator.IEosMultiResourceLocator#findFilesInSourceFolders(com.primeton.studio.runtime.resources.IProjectDelegate, java.lang.String[])
	 */
	public IFileDelegate[] findFilesInSourceFolders(IProjectDelegate project, String[] namespaces) {
		IContribution[] allContributions = RuntimeManager.getAllContributions(project, false);
		return new ContributionLookupParticipant(allContributions).findFiles(namespaces);
	}
	
}
