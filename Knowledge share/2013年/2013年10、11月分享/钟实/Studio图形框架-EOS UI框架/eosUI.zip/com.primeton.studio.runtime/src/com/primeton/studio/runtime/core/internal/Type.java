/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.core.internal;

import java.util.Collection;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IImportReference;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.ISuperTypeReference;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.core.base.AbstractEosElement;
import com.primeton.studio.runtime.resources.IResourceDelegate;

/**
 * ��������<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: Type.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/09/11 07:03:03  chenxp
 * Update:����equalsSelf�������������ƿռ�ıȽ�
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.10  2008/01/02 09:43:23  chenxp
 * Update:����checkChildrenEquals����
 *
 * Revision 1.9  2007/09/17 05:13:19  wanglei
 * Add:����isVariable��������ʾ���Ϳɶ�̬������
 *
 * Revision 1.8  2007/08/14 08:40:26  wanglei
 * Remove:ȥ��getTypeName������
 *
 * Revision 1.7  2007/08/09 05:49:31  wanglei
 * Add:��������ͷ��͵�֧�֡�
 *
 * Revision 1.6  2007/06/28 09:20:22  wanglei
 * Review:��getModel��setModel�ᵽ�����С�
 *
 * Revision 1.5  2007/06/16 03:10:00  wanglei
 * Add:����(get/set)TypeName
 *
 * Revision 1.4  2007/06/16 01:23:04  wanglei
 * UnitTest:������鸸������Դ��Bug.
 *
 * Revision 1.3  2007/06/15 09:56:40  wanglei
 * Update:�����˹��캯����
 *
 * Revision 1.2  2007/04/27 10:11:49  wanglei
 * UnitTest:����������IEosElement��
 *
 * Revision 1.1  2007/04/27 01:08:07  wanglei
 * �ύ��CVS��
 *
 */

public class Type extends AbstractEosElement implements IType {

	private IType componentType;

	private boolean variable;

	/**
	 * �̳и���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param resource
	 * @param parent
	 */
	public Type(IResourceDelegate resource, IEosElement parent) {
		super(resource, parent);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param type
	 */
	public Type() {
		super(null, null);
	}

	/**
	 * {@inheritDoc}
	 */
	public IField[] getFields() {
		Collection col = this.getChildrenOfType(FIELD);
		IField[] results = new IField[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IMethod[] getMethods() {
		Collection col = this.getChildrenOfType(METHOD);
		IMethod[] results = new IMethod[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getElementType() {
		return TYPE;
	}

	/**
	 * {@inheritDoc}
	 */
	public IImportReference[] getImports() {
		Collection col = this.getChildrenOfType(IMPORT);
		IImportReference[] results = new IImportReference[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public ISuperTypeReference[] getSuperTypes() {
		Collection col = this.getChildrenOfType(SUPER_TYPE);
		ISuperTypeReference[] results = new ISuperTypeReference[col.size()];
		col.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkParent() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkResource() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public IType getComponentType() {
		return this.componentType;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isArray() {
		return null != this.componentType;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isGeneric() {
		return StringUtils.contains(this.getName(), "<");
	}

	/**
	 * @param componentType the componentType to set
	 */
	public final void setComponentType(IType componentType) {
		this.componentType = componentType;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isVariable() {
		return this.variable;
	}

	/**
	 * �����Ƿ���Զ�̬������<BR>
	 *
	 * @param variable the variable to set
	 */
	public final void setVariable(boolean variable) {
		this.variable = variable;
	}

	/**
	 * {@inheritDoc}
	 */
	protected boolean checkChildrenEquals() {
		return true;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.runtime.core.base.AbstractEosElement#equalsSelf(java.lang.Object)
	 */
	@Override
	public boolean equalsSelf(Object aObj) {
		if(super.equalsSelf(aObj)) {
			if(this.getNamespace()!=null && !this.getNamespace().equals(((IEosElement)aObj).getNamespace()))
				return false;
			else
				return true;
		} else {
			return false;
		}
	}
	
	
}
