/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime;

import org.eclipse.osgi.util.NLS;

/**
 * Runtime����Ĺ��ʻ���Ϣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: RuntimeMessages.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.7  2010/05/24 08:35:44  wanglei
 * Jira:����EOSP-259��
 *
 * Revision 1.6  2010/05/21 06:13:56  wanglei
 * Jira:����EOSP-205��ȥ��EOS������
 *
 * Revision 1.5  2010/05/21 06:09:36  wanglei
 * Jira:����EOSP-205��ȥ��EOS������
 *
 * Revision 1.4  2009/08/31 03:43:15  hongsq
 * Update:���ӳ���
 *
 * Revision 1.3  2009/05/13 01:03:06  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.2  2009/05/07 12:55:48  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/05/05 09:27:21  yangmd
 * Update:�޸�������ȷ����javadoc��bug
 *
 * Revision 1.1  2008/01/22 02:36:15  wanglei
 * Add:�ύ��CVS��
 *
 */

public class RuntimeMessages extends NLS {

	static {
		NLS.initializeMessages(RuntimeMessages.class.getName(), RuntimeMessages.class);
	}

	public static String BETWEEN_CONTRIBUTION;

	public static String CHECK_REFERENCE_LIBRARY;

	public static String CIRCLE_REFERENCE_EXIST;

	public static String COMPILE;

	public static String DefaultHtmlDocProvider_Description;

	public static String DefaultHtmlDocProvider_DisplayName;

	public static String DefaultHtmlDocProvider_Name;

	public static String DefaultHtmlDocProvider_NameSpace;

	public static String DefaultHtmlDocProvider_Parameter;

	public static String DefaultHtmlDocProvider_Retvalue;

	public static String DefaultHtmlDocProvider_Type;

	public static String DEPENDENCE_CONTRIBUTION_IS_NOT_EXIST;

	public static String FUNDATION_NAME_ILLEGAL;

	public static String FUNDATION_NAME_NOT_EXIST;

	public static String FUNDATION_NAME_PARSER_WRONG;

	public static String HAS_EXISTED_NAME_SPACE_FILE;

	public static String MODEL_PARSE_EXCEPTION;

	/**///##########javadoc start
	public static String JAVADOC_PARAM;

	public static String JAVADOC_RETURN;

	public static String JAVADOC_THROWS;

	public static String JAVADOC_AUTHOR;

	public static String JAVADOC_SEE;

	public static String JAVADOC_SINCE;
	/**///##########javadoc end

	public static String PROJECT_HAS_NOT_SET_SERVICE;

	public static String PROJECT_HAS_NOT_SET_WEB_SERVICE;

	public static String PROJECT_VALIDATE_WRONG;

	public static String THE_WEB_SERVICE_FOR_PROJECT_IS_ILLEGAL;

	public static String THE_WEB_SERVICE_FOR_PROJECT_IS_NOT_EXIST;

	public static String TIME_FOR_COMPILE;

	public static String UNZIP_FILE;

	public static String UNZIPING;

	public static String ContributionMustUpdate;
	public static String NotSupportXsdx;

	public static String EOS;

	public static String EOS_HOME;
}
