/***********************************************************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/resources/internal/java/JavaFileDelegate.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $ $Revision: 1.1 $ $Date: 2011/06/01 02:40:52 $
 *
 * ==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd. All rights reserved.
 *
 * Created on 2007-1-30
 **********************************************************************************************************************/

package com.primeton.studio.runtime.resources.internal.java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;

import com.primeton.studio.runtime.exception.ResourceException;
import com.primeton.studio.runtime.metadata.internal.FileMetadata;
import com.primeton.studio.runtime.metadata.internal.FolderMetadata;
import com.primeton.studio.runtime.resources.IFileDelegate;

/**
 * ����Java�ļ���Դʵ��IFileDelegate�ӿڡ�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: JavaFileDelegate.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/04/14 03:32:00  wanglei
 * Update:���ӶԳ־û����Ե�֧�֡�
 *
 * Revision 1.6  2007/12/19 01:18:30  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.5  2007/08/08 07:09:55  wanglei
 * Update:����ʵ�����еĹ��ܡ�
 *
 * Revision 1.4  2007/04/18 08:38:45  wanglei
 * Update:�����еķ������ö�ת����JavaResourceManager��������
 *
 * Revision 1.3  2007/03/30 02:19:24  wanglei
 * Remove:ȥ����Ԫ���ݷ�����
 *
 * Revision 1.2  2007/03/23 02:34:36  wanglei
 * Add:������getFile���������ز���ϵͳ�ļ���
 *
 * Revision 1.1  2007/03/05 11:32:14  wanglei
 * �ύ��CVS
 *
 */

public class JavaFileDelegate extends JavaResourceDelegate implements IFileDelegate {

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param file
	 */
	public JavaFileDelegate(File file) {
		super(file);

	}

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * @param fileName
	 */
	public JavaFileDelegate(String fileName) {
		super(fileName);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#create(java.io.InputStream)
	 */
	public void create(InputStream inputStream) {
		this.create();

		OutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(this.getFile());
			IOUtils.copy(inputStream, outputStream);
		} catch (Exception e) {
			throw new ResourceException(e);
		} finally {
			IOUtils.closeQuietly(outputStream);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#getContents()
	 */
	public InputStream getContents() {
		try {
			return new FileInputStream(this.getFile());
		} catch (FileNotFoundException e) {
			throw new ResourceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#getExtension()
	 */
	public String getExtension() {
		return FilenameUtils.getExtension(this.getFile().getName());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IFileDelegate#setContents(java.io.InputStream)
	 */
	public void setContents(InputStream inputStream) {
		FileOutputStream outStream = null;
		try {
			outStream = new FileOutputStream(this.getFile());
			IOUtils.copy(inputStream, outStream);
		} catch (IOException e) {
			throw new ResourceException(e);
		} finally {
			IOUtils.closeQuietly(outStream);
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#create()
	 */
	public void create() {
		try {

			File file = this.getFile();
			File parentFile = file.getParentFile();
			if (!parentFile.exists()) {
				parentFile.mkdirs();
			}

			file.createNewFile();
		} catch (IOException e) {
			throw new ResourceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#delete()
	 */
	public void delete() throws ResourceException {
		this.getFile().delete();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.runtime.resources.IResourceDelegate#getType()
	 */
	public int getType() throws ResourceException {
		return FILE;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getPersistentProperty(String key) {
		FileMetadata fileMetadata = FileMetadata.newInstance(this, false);
		if (null == fileMetadata) {
			return null;
		}
		else {
			return fileMetadata.getString(key);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void setPersistentProperty(String key, String value) {
		FileMetadata fileMetadata = FileMetadata.newInstance(this, true);
		if (null != fileMetadata) {
			fileMetadata.setString(key, value);
		}
	}
}
