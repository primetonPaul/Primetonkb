/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/separatoranalyser/internal/JavaAnalyserFieldsFinder.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-8
 *******************************************************************************/


package com.primeton.studio.runtime.separatoranalyser.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.RuntimeConstant;
import com.primeton.studio.runtime.RuntimeHelper;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.IParameter;
import com.primeton.studio.runtime.core.IResult;
import com.primeton.studio.runtime.core.ISuperTypeReference;
import com.primeton.studio.runtime.core.IType;
import com.primeton.studio.runtime.core.internal.Field;
import com.primeton.studio.runtime.model.IJavaAnalyser;
import com.primeton.studio.runtime.resources.IProjectDelegate;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: JavaAnalyserFieldsFinder.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.4  2008/09/11 05:49:55  yanfei
 * JIRA EOS-3128 :
 * ��ҳ�����ж������ϴ��ļ����󣬵���ֻ��ͨ������java���������ص�������Ϣ����
 *
 * Revision 1.3  2008/09/09 09:25:08  yanfei
 * Update:�޸�����java���ж�Boolean�ֶεĴ�����ʾ���⣬�����java���д���һ��Boolean��
 * �͵��ֶΣ�������get��set����������û����ʾ������
 * ԭ�����ڶ�Boolean���͵ĵ�get��get��������is��ͷ���д�����Ӧ��ֻ��boolean��
 * �������Ĵ������������������⡣
 *
 * Revision 1.2  2008/09/03 09:29:36  yanfei
 * bug 12624 ����:[�Զ���ʾ]��javabean��������public��ʱ���Զ���ʾ������������
 *
 * Revision 1.1  2008/07/09 10:50:45  yangmd
 * Update:�ع���
 * 
 */
public class JavaAnalyserFieldsFinder {
	
	private static final List<String> primitiveType = new ArrayList<String>();
	
	private static final String PREFIX_GET = "get";
	
	private static final String PREFIX_SET = "set";
	
	private static final String PREFIX_IS = "is";
	
	private static final String[] UPLOADFILE_FIELDS = {
		"name",
		"clientPath",
		"clientFileName",
		"fileName", 
		"filePath",
		"contentType",
		"size",
		"bytes"
	};
	static{
		
		primitiveType.add(byte.class.getName());
		primitiveType.add(int.class.getName());
		primitiveType.add(short.class.getName());
		primitiveType.add(char.class.getName());
		primitiveType.add(long.class.getName());
		primitiveType.add(float.class.getName());
		primitiveType.add(double.class.getName());
		primitiveType.add(boolean.class.getName());
		primitiveType.add(void.class.getName());
		
		
		primitiveType.add(Integer.class.getName());
		primitiveType.add(Byte.class.getName());
		primitiveType.add(Short.class.getName());
		primitiveType.add(Character.class.getName());
		primitiveType.add(Long.class.getName());
		primitiveType.add(Float.class.getName());
		primitiveType.add(Double.class.getName());
		primitiveType.add(Boolean.class.getName());
		primitiveType.add(Void.class.getName());
	}
	/**
	 * 
	 */
	private JavaAnalyserFieldsFinder() {
		super();
	}
	/**
	 * 
	 * @param project
	 * @param className
	 * @param fieldType JavaFieldSeparatorPolicy#ALL
	 * 					 JavaFieldSeparatorPolicy#GET
	 * 					 JavaFieldSeparatorPolicy#NONE
	 * 					 JavaFieldSeparatorPolicy#ONLY_ONE
	 *  				 JavaFieldSeparatorPolicy#SET
	 * @return
	 */
	public static IField[] getField(IProjectDelegate project,String className,short fieldType){
		IJavaAnalyser javaAnalyser = RuntimeHelper.createJavaAnalyser(project, className);
		if(javaAnalyser == null)return new IField[0];

		IField[] allField = getAllField(project,javaAnalyser);
		allField = filterField(allField, javaAnalyser.getMethods(null),fieldType);
		List<IField> fields = new ArrayList<IField>(Arrays.asList(allField));
		//�Խӿ����ͽ��в²����ֶ� , JIRA EOS-3128 
		if(javaAnalyser.isInterface()
				&& "com.primeton.ext.access.http.IUploadFile".equals(className)){			
			IField[] guestFields = guestMethodFields(javaAnalyser, fieldType);
			List<String> uploadFields = Arrays.asList(UPLOADFILE_FIELDS);
			for (int i = 0; i < guestFields.length; i++) {
				IField field = guestFields[i];
				if(uploadFields.contains(field.getName()))
					addField(field, fields);
			}
		}
		return fields.toArray(new IField[fields.size()]);
	}
	/**
	 * 
	 * @param javaAnalyser
	 * @param fieldType
	 * @return
	 */
	private static IField[] guestMethodFields(IJavaAnalyser javaAnalyser, short fieldType){
		IMethod[] tempMethods = javaAnalyser.getMethods(null);
		List<IField> fields = new ArrayList<IField>();
		for (int i = 0; i < tempMethods.length; i++) {
			IMethod method = tempMethods[i];
			IField field = null;
			switch (fieldType) {
			case JavaFieldSeparatorPolicy.GET:
				field = newField(method, true);
				addField(field, fields);
				break;
			case JavaFieldSeparatorPolicy.SET:
				field = newField(method, false);
				addField(field, fields);
				break;
			case JavaFieldSeparatorPolicy.ALL:
				field = newField(method, true);
				if(field != null){
					field = newField(method, false);
					addField(field, fields);
				}
				break;
			case JavaFieldSeparatorPolicy.ONLY_ONE:
				field = newField(method, true);
				if(field == null){					
					field = newField(method, false);
				}
				addField(field, fields);
				break;
			default:
				break;
			}
		}
		return fields.toArray(new IField[fields.size()]);
	}
	/**
	 * 
	 * @param method
	 * @param isGet
	 * @return
	 */
	private static IField newField(IMethod method, boolean isGet) {
		String methodName = method.getName();
		if(methodName == null)return null;
		IParameter[] parameters = method.getParameters();
		if(isGet){
			if(parameters != null && parameters.length > 0)return null;
			IResult[] results = method.getResults();
			boolean isBooleanReturn = false;
			if(results != null && results.length > 0){
				String declaringType = results[0].getDeclaringType().getName();
				if("getClass".equals(methodName))return null;
				isBooleanReturn = boolean.class.getName().equals(declaringType);
			}
			if(results == null || results.length < 1){
				return null;
			}
			IType declaringType = results[0].getDeclaringType();
			if(methodName.startsWith(PREFIX_GET)){
				return newField(method, declaringType, PREFIX_GET);
			} else if(isBooleanReturn && methodName.startsWith(PREFIX_IS)){
				return newField(method, declaringType, PREFIX_IS);
			}
		} else {
			if(methodName.startsWith(PREFIX_SET)){
				if(parameters != null && parameters.length == 1){
					IType paramType = parameters[0].getDeclaringType();
					return newField(method, paramType, PREFIX_SET);
				}
			}
		}
		return null;
	}
	/**
	 * 
	 * @param method
	 * @param declaringType
	 * @param prefix
	 * @return
	 */
	private static IField newField(IMethod method, IType declaringType, String prefix) {
		Field field = new Field(method.getResource(),method.getParent(), declaringType);
		String name = StringUtils.substringAfter(method.getName(), prefix);
		if(name.length() > 0){
			name = name.substring(0, 1).toLowerCase() + name.substring(1);
		}
		field.setName(name);
		field.setDeclaringType(declaringType);
		field.setModifier(IEosElement.PRIVATE_MODIFIER);
		field.setImplementationType(RuntimeConstant.JAVA);
		return field;
	}
	/**
	 * 
	 * @param field
	 * @param list
	 * @return
	 */
	private static boolean addField(IField field, List<IField> list) {
		if(field == null || list == null)return false;
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			IField element = (IField) iter.next();
			if(field.getName().equals(element.getName())){
				return false;//�Ѿ�������ͬ���Ƶ�Field��ֱ�ӷ��أ������ظ�
			}
		}
		list.add(field);
		return true;
	}
	
	/**
	 * 
	 * @param className
	 * @return
	 */
	public static boolean isPrimitive(String className){
		if(primitiveType.contains(className)){
			return true;
		} else {			
			return false;
		}
	}
	/**
	 * 
	 * @param fields
	 * @param methods
	 * @param fieldType
	 * @return
	 */
	private static IField[] filterField(IField[] fields, IMethod[] methods, short fieldType){
		List<IField> filterFields = new ArrayList<IField>();
		for (int i = 0; i < fields.length; i++) {
			IField field = fields[i];
			String fieldName = field.getName();
			String lastName = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1, fieldName.length());
			lastName = lastName.trim();
			String getMethodName = PREFIX_GET + lastName;
			String name = field.getDeclaringType().getName();
			if(boolean.class.getName().equals(name)){
				getMethodName = PREFIX_IS+lastName;
			}
			String setMethodName = PREFIX_SET + lastName;
			boolean pass = false;
			if (IEosElement.PUBLIC_MODIFIER == field.getModifier()) {
				pass = true;
			} else {
				switch (fieldType) {
				case JavaFieldSeparatorPolicy.GET:
					pass = hasMethod(methods, getMethodName);
					break;
				case JavaFieldSeparatorPolicy.SET:
					pass = hasMethod(methods, setMethodName);
					break;
				case JavaFieldSeparatorPolicy.ALL:
					pass = hasMethod(methods, getMethodName)
							&& hasMethod(methods, setMethodName);
					break;
				case JavaFieldSeparatorPolicy.ONLY_ONE:
					pass = hasMethod(methods, getMethodName)
							|| hasMethod(methods, setMethodName);
					break;
				default:
					pass = true;
					break;
				}
			}
			if(pass){
				filterFields.add(field);
			}
		}
		return filterFields.toArray(new IField[filterFields.size()]);
	}
	/**
	 * 
	 * @param methods
	 * @param methodName
	 * @return
	 */
	private static boolean hasMethod(IMethod[] methods, String methodName){
		for (int i = 0; i < methods.length; i++) {
			IMethod method = methods[i];
			if(method.getName().equals(methodName)){
				return true;
			}
		}
		return false;
	}
	/**
	 * 
	 * @param project
	 * @param javaAnalyser
	 * @return
	 */
	private static IField[] getAllField(IProjectDelegate project,IJavaAnalyser javaAnalyser){
		List<IField> allFields = new ArrayList<IField>(); 
		if(javaAnalyser == null)return new IField[0];
		IField[] fields = javaAnalyser.getFields(null);
		addField(allFields, fields);
		
		fields = javaAnalyser.getDeclaredFields(null);
		addField(allFields, fields);
		
		ISuperTypeReference[] superTypes = javaAnalyser.getSuperTypeReferences(null);
		for (int i = 0; i < superTypes.length; i++) {
			String superName = superTypes[i].getName();
			javaAnalyser = RuntimeHelper.createJavaAnalyser(project, superName);
			if(javaAnalyser != null){
				fields = javaAnalyser.getDeclaredFields(null);
				addField(allFields, fields);
			}
		}
		return allFields.toArray(new IField[allFields.size()]);
	}
	
	/**
	 * 
	 * @param collection
	 * @param fields
	 */
	private static void addField(Collection<IField> collection, IField[] fields){
		List<String> fieldNames = new ArrayList<String>();
		for (Iterator iter = collection.iterator(); iter.hasNext();) {
			IField element = (IField) iter.next();
			fieldNames.add(element.getName());
		}
		for (int i = 0; i < fields.length; i++) {
			if(!fieldNames.contains(fields[i].getName())){
				collection.add(fields[i]);
			}
		}
	}
}
