/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/index/model/IndexItem.java,v 1.1 2011/06/01 02:40:53 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:53 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-5-27
 *******************************************************************************/

package com.primeton.studio.runtime.index.model;

import java.util.HashSet;
import java.util.Set;

import com.eos.system.utility.Assert;

/**
 * ��������Ļ���Ԫ�ء�<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IndexItem.java,v $
 * Revision 1.1  2011/06/01 02:40:53  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/07/21 05:45:57  lvyuan
 * Add:�����������ƿռ���Ҳ��ֵĴ���
 *
 */
abstract class IndexItem {

	private String name;

	private Set references = new HashSet();

	private float rating;

	private DocumentItem document;

	/**
	 * ���캯����<BR>
	 * �����ռ�һ�����������ɸ��ġ�<BR>
	 * @param document
	 * @param namespace
	 */
	IndexItem(DocumentItem document, String name) {
		super();

		Assert.notNull(name, "the name can't be null.");
		this.name = name;

		this.setDocument(document);
	}


	/**
	 * @param document The document to set.
	 */
	public void setDocument(DocumentItem document) {
		Assert.notNull(document, "the document can't be null.");
		this.document = document;
	}

	/**
	 * @return Returns the document.
	 */
	public DocumentItem getDocument() {
		return document;
	}

	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * �����������͵������ռ䡣<BR>
	 *
	 * @return
	 */
	public String[] getReferences() {
		String[] results = new String[this.references.size()];
		this.references.toArray(results);
		return results;
	}

	/**
	 * ����һ�����ù�ϵ��<BR>
	 *
	 * @param reference
	 */
	public void addReference(String reference) {
		Assert.notNull(reference, "the reference can't be null.");
		this.references.add(reference);
	}

	/**
	 * �Ƴ�һ�����ù�ϵ��<BR>
	 *
	 * @param reference
	 */
	public void removeReference(String reference) {
		Assert.notNull(reference, "the reference can't be null.");
		this.references.remove(reference);
	}

	/**
	 * �õ����֡�<BR>
	 *
	 * @return
	 */
	public float getRating() {
		return this.rating;
	}

	/**
	 * �������֡�<BR>
	 * ����ԭ�������֡�<BR>
	 *
	 * @return
	 */
	public float setRating(float newRating) {
		float oldRating = this.rating;
		this.rating = newRating;
		return oldRating;
	}
}
