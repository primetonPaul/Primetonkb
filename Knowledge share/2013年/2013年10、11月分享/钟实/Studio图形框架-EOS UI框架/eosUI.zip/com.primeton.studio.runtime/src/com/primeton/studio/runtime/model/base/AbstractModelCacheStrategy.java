/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.runtime.model.base;

import org.eclipse.core.runtime.Assert;

import com.primeton.studio.runtime.core.IEosModel;
import com.primeton.studio.runtime.model.IModelCacheStrategy;

/**
 * IModelCacheStrategy�Ļ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractModelCacheStrategy.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:57:25  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/01/09 01:19:07  wanglei
 * Review:�ع��ײ�ģ�ͣ���ԭ�д���Դ�������������getModelFactory������ȥ��
 *
 */

public abstract class AbstractModelCacheStrategy implements IModelCacheStrategy {

	private IEosModel model;

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param model
	 *
	 */
	public AbstractModelCacheStrategy(IEosModel model) {
		this.model = model;
		Assert.isNotNull(model, "The model should not be null.");
	}

	/**
	 * {@inheritDoc}
	 */
	public IEosModel getModel() {
		return this.model;
	}
}
