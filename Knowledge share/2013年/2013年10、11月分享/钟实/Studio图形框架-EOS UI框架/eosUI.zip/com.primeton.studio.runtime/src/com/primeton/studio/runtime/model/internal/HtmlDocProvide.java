/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.runtime/src/com/primeton/studio/runtime/model/internal/HtmlDocProvide.java,v 1.1 2011/06/01 02:40:52 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:40:52 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-5-13
 *******************************************************************************/


package com.primeton.studio.runtime.model.internal;

import java.text.MessageFormat;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.runtime.RuntimeMessages;
import com.primeton.studio.runtime.core.IEosElement;
import com.primeton.studio.runtime.core.IField;
import com.primeton.studio.runtime.core.IMethod;
import com.primeton.studio.runtime.core.IParameter;
import com.primeton.studio.runtime.core.IResult;
import com.primeton.studio.runtime.core.IType;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yourname (mailto:yourname@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: HtmlDocProvide.java,v $
 * Revision 1.1  2011/06/01 02:40:52  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:41  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/05/13 07:30:13  lvyuan
 * Update:�ع�EDOC�����ɷ�ʽ
 * 
 */
public class HtmlDocProvide {
	
	private HtmlDocProvide(){}
	
	public static String getHtmlDoc(IEosElement element){
		StringBuffer buffer = new StringBuffer();
		buffer.append("<html>"); //$NON-NLS-1$
		buffer.append(RuntimeMessages.DefaultHtmlDocProvider_Name);
		buffer.append(element.getName());
		if(element.getResource().getFullPath().endsWith(".wsdl")){ //$NON-NLS-1$
			buffer.append(RuntimeMessages.DefaultHtmlDocProvider_NameSpace);
			buffer.append(element.getExtension("namespace")); //$NON-NLS-1$
		}else{
			buffer.append(RuntimeMessages.DefaultHtmlDocProvider_DisplayName);
			buffer.append(element.getDisplayName());

			if(!(element instanceof IField)){
				buffer.append(RuntimeMessages.DefaultHtmlDocProvider_NameSpace);
				buffer.append(DOCNameSpaceUtil.getNameSpace4EOSElement(element));
			}
			if(element instanceof IField){
				IType declaringType = ((IField)element).getDeclaringType();
				if(declaringType != null){
					buffer.append(RuntimeMessages.DefaultHtmlDocProvider_Type);
					String name = declaringType.getName();
					buffer.append(name);
				}
			}
			if(element instanceof IMethod){
				setMethodDescription((IMethod) element, buffer);
			}

			String description = element.getDescription();
			if(StringUtils.isNotBlank(description)){
				buffer.append(RuntimeMessages.DefaultHtmlDocProvider_Description);
				description = description.replaceAll("\n", "<br>"); //$NON-NLS-1$ //$NON-NLS-2$
				description = description.replaceAll("\r", ""); //$NON-NLS-1$ //$NON-NLS-2$
				buffer.append(description);
			}
		}
		buffer.append("</html>"); //$NON-NLS-1$
		return buffer.toString();
	}
	
	
	/**
	 * ��ȡ�߼���������Ϣ
	 * @param object
	 */
	private static void setMethodDescription(IMethod method, StringBuffer buffer) {
		if(method != null){
			IParameter[] parameters = method.getParameters();
			if(parameters != null && parameters.length > 0){
				buffer.append(RuntimeMessages.DefaultHtmlDocProvider_Parameter);
				buffer.append(getParametersDescription(parameters));
			}
			IResult[] results = method.getResults();
			if(results != null && results.length > 0){
				if(!(buffer.toString().endsWith("</dt>")|| buffer.toString().endsWith("</dd>"))){ //$NON-NLS-1$ //$NON-NLS-2$
					buffer.append("<dl>"); //$NON-NLS-1$
				}
				buffer.append(RuntimeMessages.DefaultHtmlDocProvider_Retvalue);
				buffer.append(getParametersDescription(results));
			}
			if(buffer.toString().endsWith("</dt>")){ //$NON-NLS-1$
				buffer.append("</dl>"); //$NON-NLS-1$
			}

		}
	}

	/**
	 * ��ȡ�������߷���ֵ������Ϣ
	 * @param list
	 * @return
	 */
	private static StringBuffer getParametersDescription(IField[] fields){
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < fields.length; i++) {
			String name = fields[i].getName();

			if(name == null){
				continue;
			}

			if(name.indexOf(".") != -1){ //$NON-NLS-1$
				name = "out" + i; //$NON-NLS-1$
			}

			IType declaringType = fields[i].getDeclaringType();
			String dType = declaringType == null ? "" : declaringType.getName(); //$NON-NLS-1$
			String desc = fields[i].getDescription();
			desc = desc == null ? "" : desc; //$NON-NLS-1$
			if(!StringUtils.equals(dType, "void")){ //$NON-NLS-1$
				buffer.append(MessageFormat.format("<dd><b>{0}({1}):</b>{2}</dd>", name,dType,desc)); //$NON-NLS-1$
			}else{
				buffer.append("<dd><b>void</b></dd>"); //$NON-NLS-1$
			}
		}
		return buffer;
	}
	
}
