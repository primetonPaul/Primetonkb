/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */
package com.primeton.studio.swt.util;

import java.util.HashSet;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;


/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * SWT�����һЩ����������<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The hlper class for swt table. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * @author Lei.Wang
 * @version $Revision: 1.1 $Date: 2011/06/01 01:23:06 $
 */
public final class TableUtil
{
	/**
	 * �������ʵ��<BR>
	 * 
	 * The object instance is not needed.<BR>
	 */
	private TableUtil()
	{
		super();
	}

	/**
	 * ����ָ����������TableViewer<BR>
	 * 
	 * Build a TableViewer by the parameters.<BR>
	 * 
	 * @param r_Composite
	 *            the parent control for the table
	 * @param r_Style
	 *            the style for the table
	 * @param r_ColumnTexts
	 *            the titles for the table header.
	 */
	public static TableViewer buildTableViewer(Composite r_Composite, int r_Style, String[] r_ColumnTitles)
	{
		String[] t_Properties = new String[r_ColumnTitles.length];

		for (int i = 0; i < t_Properties.length; i++)
		{
			t_Properties[i] = Integer.toString(i);
		}

		return buildTableViewer(r_Composite, r_Style, r_ColumnTitles, t_Properties);
	}

	/**
	 * 
	 * ����ָ����������TableViewer<BR>
	 * 
	 * Build a TableViewer by the parameters.<BR>
	 * 
	 * @param r_Composite
	 *            the parent control for the table
	 * @param r_Style
	 *            the style for the table
	 * @param r_ColumnTexts
	 *            the titles for the table header.
	 * @param r_Properties
	 *            the properties for the table columns.
	 */
	public static TableViewer buildTableViewer(Composite r_Composite, int r_Style, String[] r_ColumnTitles, String[] r_Properties)
	{
		TableViewer t_TableViewer = new TableViewer(r_Composite, r_Style);
		t_TableViewer.setColumnProperties(r_Properties);

		for (int i = 0; i < r_ColumnTitles.length; i++)
		{
			TableColumn t_Column = new TableColumn(t_TableViewer.getTable(), SWT.FLAT);
			t_Column.setMoveable(false);
			t_Column.setText(r_ColumnTitles[i]);
			t_Column.setData(r_Properties[i]);
		}

		for (int i = 0; i < r_ColumnTitles.length; i++)
		{
			TableColumn t_Column = t_TableViewer.getTable().getColumn(i);
			t_Column.pack();
		}

		t_TableViewer.getTable().setHeaderVisible(true);
		t_TableViewer.getTable().setLinesVisible(true);

		return t_TableViewer;
	}

	/**
	 * ����ʵ����Ҫ����������еĴ�С<BR>
	 * 
	 * Resize the width of the columns automaticlly.<BR>
	 * 
	 * @param r_Table
	 *            the target table to be resized.
	 */
	public static void doAutoSize(Table r_Table)
	{
		TableColumn[] t_Columns = r_Table.getColumns();
		for (int i = 0; i < t_Columns.length; i++)
		{
			t_Columns[i].pack();
		}
	}

	/**
	 * ����ָ�����ڱ����ϵ�������<BR>
	 * 
	 * Compute the column for the x location.<BR>
	 * 
	 * @param r_Table
	 * @param r_X
	 */
	public static int computeColumn(Table r_Table, int r_X)
	{
		int t_X = 0;

		for (int i = 0; i < r_Table.getColumnCount(); i++)
		{
			TableColumn t_Column = r_Table.getColumn(i);
			t_X = t_X + t_Column.getWidth();
			if (t_X >= r_X)
			{
				return i;
			}
		}

		return 0;
	}

	
}
