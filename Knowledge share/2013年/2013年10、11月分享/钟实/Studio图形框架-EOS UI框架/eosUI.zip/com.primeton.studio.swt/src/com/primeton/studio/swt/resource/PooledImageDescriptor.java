/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.swt.resource;

import java.util.Hashtable;

import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;

import com.primeton.studio.swt.SwtMessages;

/**
 * �ܹ��������е�ͼƬ��<BR>
 * ����ʹ�ñ�ImageRegistry������һЩ��
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: PooledImageDescriptor.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/05/06 10:47:47  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.3  2007/05/11 06:12:42  wanglei
 * UnitTest:������loadIcon������Դй©��Bug��
 *
 * Revision 1.2  2007/05/10 05:22:02  wanglei
 * Add:������hashCode��equals��������֤ʹ��Hashtable��HashMap����������⡣
 *
 * Revision 1.1  2007/04/23 01:04:00  wanglei
 * Add:����һ��֧�ֻ����ͼƬ�ࡣ
 *
 */

public class PooledImageDescriptor extends ImageDescriptor {

	private Image image;

	private ImageDescriptor imageDescriptor;

	private static final Hashtable descriptorPools = new Hashtable();

	private static final Hashtable imagePools = new Hashtable();

	/**
	 * ����ָ��ImageDescriptor�Ļ���ʵ����<BR>
	 *
	 * Return the pooled instance for the specified ImageDescriptor.<BR>
	 *
	 * @param r_ImageDescriptor
	 * @return
	 */
	public static PooledImageDescriptor getImageDescriptor(ImageDescriptor r_ImageDescriptor) {
		if (null == r_ImageDescriptor) {
			return null;
		}

		ImageDescriptor t_RealImageDescriptor = r_ImageDescriptor;
		while (t_RealImageDescriptor instanceof PooledImageDescriptor) {
			t_RealImageDescriptor = ((PooledImageDescriptor) t_RealImageDescriptor).imageDescriptor;
		}

		Object t_Object = descriptorPools.get(t_RealImageDescriptor);
		if (null != t_Object) {
			return (PooledImageDescriptor) t_Object;
		}
		else {
			PooledImageDescriptor t_ImageDescriptor = new PooledImageDescriptor(t_RealImageDescriptor);
			descriptorPools.put(t_RealImageDescriptor, t_ImageDescriptor);
			return t_ImageDescriptor;
		}
	}

	/**
	 * ����ָ��Image�Ļ���ʵ����<BR>
	 *
	 * Return the pooled instance for the specified Image.<BR>
	 *
	 * @param r_Image
	 * @return
	 */
	public static PooledImageDescriptor getImageDescriptor(Image r_Image) {
		if (null == r_Image) {
			return null;
		}

		Object t_Object = imagePools.get(r_Image);
		if (null != t_Object) {
			return (PooledImageDescriptor) t_Object;
		}
		else {
			ImageDescriptor t_ImageDescriptor = ImageDescriptor.createFromImage(r_Image);
			PooledImageDescriptor t_PooledImageDescriptor = new PooledImageDescriptor(t_ImageDescriptor);
			t_PooledImageDescriptor.image = r_Image;
			imagePools.put(r_Image, t_PooledImageDescriptor);
			return t_PooledImageDescriptor;
		}
	}

	/**
	 * ���캯����<BR>
	 *
	 * The  constructor.<BR>
	 *
	 * @param r_ImageDescriptor
	 */
	private PooledImageDescriptor(ImageDescriptor r_ImageDescriptor) {
		super();
		this.imageDescriptor = r_ImageDescriptor;
		Assert.isNotNull(r_ImageDescriptor, SwtMessages.IMAGE_DESCRIPTOR_CAN_NOT_BE_NULL);
	}

	/**
	 * {@inheritDoc}
	 */
	public Image createImage(boolean r_ReturnMissingImageOnError, Device r_Device) {

		if ((null != this.image) && (!this.image.isDisposed())) {
			return this.image;
		}
		//�����ȸ������е�ͼƬ

		this.image = super.createImage(r_ReturnMissingImageOnError, r_Device);
		return this.image;
	}

	/**
	 * {@inheritDoc}
	 */
	public ImageData getImageData() {
		return this.imageDescriptor.getImageData();
		//���image��Ϊ�գ��Ͳ�������������
		//���image��disposed���ͻ�������������
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.imageDescriptor == null) ? 0 : this.imageDescriptor.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final PooledImageDescriptor other = (PooledImageDescriptor) obj;
		return other.imageDescriptor.equals(this.imageDescriptor);
	}

	/**
	 * @return the imageDescriptor
	 */
	public ImageDescriptor getImageDescriptor() {
		return this.imageDescriptor;
	}

}
