/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */
package com.primeton.studio.swt.resource;

import java.awt.Point;

import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.RGB;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �ṩһЩ���õĹ��ܣ�������Swing��SWT��ת��һЩ����������<BR>
 * ��Rectangle,Point,Dimension��һЩ���ݼ��ת��<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Provide some convert functions for swing and swt<BR>
 * Just like the convertion of Rectangle,Point,Dimension<BR>
 * Swt and swing have different definition<BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 13:12:53
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: ResourceConvertUtil.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */

public final class ResourceConvertUtil
{
	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 * 
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private ResourceConvertUtil()
	{
		super();
	}

	/**
	 * ��Swt�е�Rectangleת����Swing��Rectangle��<BR>
	 * 
	 * Convert the Rectangle of swt to the Rectangle of swing<BR>
	 * 
	 * @param r_Rectangle
	 *            the source rectangle to be converted.
	 */
	public static java.awt.Rectangle convert(org.eclipse.draw2d.geometry.Rectangle r_Rectangle)
	{
		java.awt.Rectangle t_Rectangle = new java.awt.Rectangle();

		t_Rectangle.x = r_Rectangle.x;
		t_Rectangle.y = r_Rectangle.y;
		t_Rectangle.width = r_Rectangle.width;
		t_Rectangle.height = r_Rectangle.height;

		return t_Rectangle;
	}

	/**
	 * ��Swing�е�Rectangleת����Swt��Rectangle��<BR>
	 * 
	 * Convert the Rectangle of Swing to the Rectangle of Swt<BR>
	 * 
	 * @param r_Rectangle
	 *            the source rectangle to be converted.
	 */
	public static org.eclipse.draw2d.geometry.Rectangle convert(java.awt.Rectangle r_Rectangle)
	{
		org.eclipse.draw2d.geometry.Rectangle t_Rectangle = new org.eclipse.draw2d.geometry.Rectangle();

		t_Rectangle.x = r_Rectangle.x;
		t_Rectangle.y = r_Rectangle.y;
		t_Rectangle.width = r_Rectangle.width;
		t_Rectangle.height = r_Rectangle.height;

		return t_Rectangle;
	}

	/**
	 * ��Swing�е�Rectangleת����Swt��Rectangle��<BR>
	 * 
	 * Convert the Rectangle of Swing to the Rectangle of Swt<BR>
	 * 
	 * @param r_Location
	 *            the source point to be converted.
	 * 
	 */
	public static Point convert(org.eclipse.draw2d.geometry.Point r_Location)
	{
		Point t_Location = new Point();

		t_Location.x = r_Location.x;
		t_Location.y = r_Location.y;

		return t_Location;
	}

	/**
	 * ��Swing�е�Rectangleת����Swt��Rectangle��<BR>
	 * Convert the Rectangle of Swing to the Rectangle of Swt<BR>
	 * 
	 * @param r_Location
	 *            the source point to be converted.
	 */
	public static org.eclipse.draw2d.geometry.Point convert(Point r_Location)
	{
		org.eclipse.draw2d.geometry.Point t_Location = new org.eclipse.draw2d.geometry.Point();

		t_Location.x = r_Location.x;
		t_Location.y = r_Location.y;

		return t_Location;
	}

	/**
	 * ��Swt������Ϣת��ϵͳ���ж����������Ϣ<BR>
	 * 
	 * Convert the swt font data to the pre defined font infomation<BR>
	 * 
	 * @param r_FontData
	 * 
	 */
	public static FontInfo convertFont(FontData r_FontData)
	{
		if (null == r_FontData)
		{
			return null;
		}

		FontInfo t_FontInfo = new FontInfo();

		t_FontInfo.setHeight(r_FontData.getHeight());
		t_FontInfo.setLocale(r_FontData.getLocale());
		t_FontInfo.setName(r_FontData.getName());
		t_FontInfo.setStyle(r_FontData.getStyle());

		return t_FontInfo;
	}

	/**
	 * ��ϵͳ���ж����������Ϣת��Swt������Ϣ<BR>
	 * 
	 * Convert the pre defined font infomation to the swt font data<BR>
	 * 
	 * @param r_FontInfo
	 *            the source font to be converted.
	 */

	public static FontData convertFont(FontInfo r_FontInfo)
	{
		if (null == r_FontInfo)
		{
			return null;
		}

		FontData t_FontData = new FontData();

		t_FontData.setHeight(r_FontInfo.getHeight());
		t_FontData.setLocale(r_FontInfo.getLocale());
		t_FontData.setName(r_FontInfo.getName());
		t_FontData.setStyle(r_FontInfo.getStyle());

		return t_FontData;
	}

	/**
	 * ����һ��Swt��������Ϣ<BR>
	 * 
	 * Clone the swt font<BR>
	 * 
	 * @param r_FontData
	 *            the source font to be converted.
	 */
	public static FontData cloneFont(FontData r_FontData)
	{
		if (null == r_FontData)
		{
			return null;
		}

		FontData t_FontData = new FontData();

		t_FontData.setHeight(r_FontData.getHeight());
		t_FontData.setLocale(r_FontData.getLocale());
		t_FontData.setName(r_FontData.getName());
		t_FontData.setStyle(r_FontData.getStyle());

		return t_FontData;
	}

	/**
	 * ����һ��Swt����ɫ��Ϣ<BR>
	 * 
	 * Clone the swt color<BR>
	 * 
	 * @param r_RGB
	 *            the source color to be cloned..
	 */
	public static RGB cloneColor(RGB r_RGB)
	{
		if (null == r_RGB)
		{
			return null;
		}

		return new RGB(r_RGB.red, r_RGB.green, r_RGB.blue);
	}

	/**
	 * ��Swt��ɫ��Ϣת��ϵͳ���ж������ɫ��Ϣ<BR>
	 * 
	 * Convert the swt color data to the pre defined color infomation<BR>
	 * 
	 * @param r_ColorInfo
	 *            the source color to be converted.
	 */
	public static RGB convertColor(ColorInfo r_ColorInfo)
	{
		if (null == r_ColorInfo)
		{
			return null;
		}

		return new RGB(r_ColorInfo.getRed(), r_ColorInfo.getGreen(), r_ColorInfo.getBlue());
	}

	/**
	 * ��ϵͳ���ж������ɫ��Ϣת��Swt��ɫ��Ϣ<BR>
	 * Convert the pre defined color infomation to the swt color data<BR>
	 * 
	 * @param r_RGB
	 *            the source color to be converted.
	 */
	public static ColorInfo convertColor(RGB r_RGB)
	{
		if (null == r_RGB)
		{
			return null;
		}

		ColorInfo t_ColorInfo = new ColorInfo();

		t_ColorInfo.setRed(r_RGB.red);
		t_ColorInfo.setGreen(r_RGB.green);
		t_ColorInfo.setBlue(r_RGB.blue);

		return t_ColorInfo;
	}

	/**
	 * ��Java�е�Insetsת��Eclipse��Insets��<BR>
	 * 
	 * Convert the insets in java to the insets in eclipse.<BR>
	 * 
	 * @param r_Insets
	 *            the source insets to be converted.
	 * 
	 */
	public static org.eclipse.draw2d.geometry.Insets convertInsets(java.awt.Insets r_Insets)
	{
		org.eclipse.draw2d.geometry.Insets t_Insets = new org.eclipse.draw2d.geometry.Insets();

		t_Insets.top = r_Insets.top;
		t_Insets.bottom = r_Insets.bottom;
		t_Insets.left = r_Insets.left;
		t_Insets.right = r_Insets.right;

		return t_Insets;
	}

	/**
	 * ��Eclipse�е�Insetsת��Java��Insets��<BR>
	 * 
	 * Convert the insets in eclipse to the insets in Java.<BR>
	 * 
	 * @param r_Insets
	 *            the source insets to be converted.
	 */
	public static java.awt.Insets convertInsets(org.eclipse.draw2d.geometry.Insets r_Insets)
	{
		return new java.awt.Insets(r_Insets.top, r_Insets.left, r_Insets.bottom, r_Insets.right);
	}
}
