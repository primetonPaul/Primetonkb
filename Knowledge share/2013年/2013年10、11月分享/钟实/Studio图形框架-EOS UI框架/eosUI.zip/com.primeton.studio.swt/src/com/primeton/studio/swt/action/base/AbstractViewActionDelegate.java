/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.swt.action.base;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * IViewActionDelegate�ĳ�����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractViewActionDelegate.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2007/04/02 08:58:16  wanglei
 * �ύ��CVS��
 *
 */

public abstract class AbstractViewActionDelegate implements IViewActionDelegate {

	private IStructuredSelection selection;

	private IViewPart view;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractViewActionDelegate() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public void init(IViewPart r_View) {
		this.view = r_View;
	}

	/**
	 * {@inheritDoc}
	 */
	public void selectionChanged(IAction r_Action, ISelection r_Selection) {
		this.selection = (IStructuredSelection) r_Selection;
	}

	/**
	 * @return the selection
	 */
	public IStructuredSelection getSelection() {
		return this.selection;
	}

	/**
	 * @return the view
	 */
	public IViewPart getView() {
		return this.view;
	}

}
