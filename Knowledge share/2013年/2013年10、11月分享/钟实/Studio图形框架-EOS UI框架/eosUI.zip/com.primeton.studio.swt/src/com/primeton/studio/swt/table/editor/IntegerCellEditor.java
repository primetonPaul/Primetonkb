/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.swt.table.editor;

import java.text.MessageFormat;

import org.eclipse.jface.util.Assert;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Spinner;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����ڱ����б༭���֡�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * This editor is used to input a integer in a table. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-9-16 ����01:44:57
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: IntegerCellEditor.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:49:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.4  2007/03/05 06:06:35  wanglei
 * �ύ��CVS
 *
 */
public final class IntegerCellEditor extends CellEditor
{
	private Spinner spinner;

	private ModifyListener modifyListener;

	/**
	 * �̳��Ը����Ĭ�Ϲ��캯����<BR>
	 * 
	 * The derived default constructor.<BR>
	 */
	public IntegerCellEditor()
	{
		super();
	}

	/**
	 * �̳��Ը����Ĭ�Ϲ��캯����<BR>
	 * 
	 * The derived default constructor.<BR>
	 * 
	 * @param r_Parent
	 * @param r_Style
	 */
	public IntegerCellEditor(Composite r_Parent, int r_Style)
	{
		super(r_Parent, r_Style);
	}

	/**
	 * �̳��Ը����Ĭ�Ϲ��캯����<BR>
	 * 
	 * The derived default constructor.<BR>
	 * 
	 * @param r_Parent
	 */
	public IntegerCellEditor(Composite r_Parent)
	{
		super(r_Parent);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.CellEditor#createControl(org.eclipse.swt.widgets.Composite)
	 */
	protected Control createControl(Composite r_Parent)
	{
		this.spinner = new Spinner(r_Parent, SWT.NONE);

		this.spinner.addSelectionListener(new SelectionAdapter()
		{
			public void widgetDefaultSelected(SelectionEvent e)
			{
				handleDefaultSelection(e);
			}
		});
		this.spinner.addKeyListener(new KeyAdapter()
		{
			// hook key pressed - see PR 14201
			public void keyPressed(KeyEvent e)
			{
				keyReleaseOccured(e);

				// as a result of processing the above call, clients may have
				// disposed this cell editor
				if ((getControl() == null) || getControl().isDisposed())
				{
					return;
				}
			}
		});
		this.spinner.addTraverseListener(new TraverseListener()
		{
			public void keyTraversed(TraverseEvent e)
			{
				if (e.detail == SWT.TRAVERSE_ESCAPE || e.detail == SWT.TRAVERSE_RETURN)
				{
					e.doit = false;
				}
			}
		});

		this.spinner.addFocusListener(new FocusAdapter()
		{
			public void focusLost(FocusEvent e)
			{
				IntegerCellEditor.this.focusLost();
			}
		});
		this.spinner.setFont(r_Parent.getFont());
		this.spinner.setBackground(r_Parent.getBackground());
		this.spinner.setSelection(0);
		this.spinner.addModifyListener(getModifyListener());

		return this.spinner;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.CellEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		return new Integer(this.spinner.getSelection());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.CellEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value)
	{
		Assert.isTrue(this.spinner != null && (r_Value instanceof Integer));
		this.spinner.removeModifyListener(getModifyListener());
		this.spinner.setSelection(((Integer) r_Value).intValue());
		this.spinner.addModifyListener(getModifyListener());

	}

	/**
	 * Handles a default selection event from the text control by applying the editor value and deactivating this cell
	 * editor.
	 * 
	 * @param event
	 *            the selection event
	 * 
	 * @since 3.0
	 */
	protected void handleDefaultSelection(SelectionEvent event)
	{
		// same with enter-key handling code in keyReleaseOccured(e);
		fireApplyEditorValue();
		deactivate();
	}

	/**
	 * Return the modify listener.
	 */
	private ModifyListener getModifyListener()
	{
		if (this.modifyListener == null)
		{
			this.modifyListener = new ModifyListener()
			{
				public void modifyText(ModifyEvent e)
				{
					editOccured(e);
				}
			};
		}
		return this.modifyListener;
	}

	/**
	 * Processes a modify event that occurred in this text cell editor. This framework method performs validation and
	 * sets the error message accordingly, and then reports a change via <code>fireEditorValueChanged</code>.
	 * Subclasses should call this method at appropriate times. Subclasses may extend or reimplement.
	 * 
	 * @param e
	 *            the SWT modify event
	 */
	protected void editOccured(ModifyEvent e)
	{
		int t_OldValue = this.spinner.getSelection();

		Object t_NewValue = new Integer(t_OldValue);
		boolean t_OldValidState = isValueValid();
		boolean t_NewValidState = isCorrect(t_NewValue);
		if (t_NewValue == null && t_NewValidState)
		{
			Assert.isTrue(false, "Validator isn't limiting the cell editor's type range");//$NON-NLS-1$
		}
		if (!t_NewValidState)
		{
			// try to insert the current value into the error message.
			setErrorMessage(MessageFormat.format(getErrorMessage(), new Object[] { new Integer(t_OldValue) }));
		}
		valueChanged(t_OldValidState, t_NewValidState);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.CellEditor#doSetFocus()
	 */
	protected void doSetFocus()
	{
		this.spinner.setFocus();
	}
}
