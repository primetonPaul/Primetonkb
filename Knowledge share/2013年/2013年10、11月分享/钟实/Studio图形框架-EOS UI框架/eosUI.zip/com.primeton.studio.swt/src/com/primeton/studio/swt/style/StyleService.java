/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */
package com.primeton.studio.swt.style;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.custom.StyledText;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.swt.style.impl.DefaultStyle;
import com.primeton.studio.swt.style.impl.DefaultStyleProvider;
import com.primeton.studio.swt.style.impl.WordGroup;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ������ɫ��ʽ<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The tool to manage the color style. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * @author Lei.Wang
 * @version $Revision: 1.1 $Date: 2011/06/01 01:23:06 $
 */
public final class StyleService
{
	private static Map styles = new HashMap();

	private static final String ExtensionID = "com.primeton.studio.ui.style";

	private static final String Word = "word";

	private static final String Pattern = "pattern";

	private static final String Color = "color";

	static
	{
		load();
	}

	/**
	 * ����չ������UI�����Դ��<BR>
	 * 
	 * Load the actions from the extension point.<BR>
	 * 
	 */
	private static void load()
	{
		IExtensionRegistry t_ExtensionRegistry = Platform.getExtensionRegistry();
		IExtensionPoint t_ExtensionPoint = t_ExtensionRegistry.getExtensionPoint(ExtensionID);

		IExtension[] t_Extensions = t_ExtensionPoint.getExtensions();

		for (int i = 0; i < t_Extensions.length; i++)
		{
			IExtension t_Extension = t_Extensions[i];
			IConfigurationElement[] t_ConfigurationElements = t_Extension.getConfigurationElements();

			for (int j = 0; j < t_ConfigurationElements.length; j++)
			{
				IConfigurationElement t_StyleElements = t_ConfigurationElements[j];
				doLoadStyle(t_StyleElements);

				// t_ConfigurationElement

			}
		}
		// ����չ������Action��
	}

	/**
	 * ����չ��������ȡ����Ӧ����ʽ��Ϣ��<BR>
	 * 
	 * Get the style from the configuration of plugin.<BR>
	 * 
	 * @param r_ConfigurationElement
	 *            the configuration content defined in the extension-point.
	 */
	private static void doLoadStyle(IConfigurationElement r_ConfigurationElement)
	{
		String t_Name = r_ConfigurationElement.getAttribute(IConstant.NAME);
		String t_ColorName = r_ConfigurationElement.getAttribute(Color);
		String t_Pattern = r_ConfigurationElement.getAttribute(Pattern);
		boolean t_AccurateMatch = Boolean.valueOf(r_ConfigurationElement.getAttribute(DefaultStyle.AccurateMatch)).booleanValue();

		DefaultStyle t_Style = new DefaultStyle();
		t_Style.setName(t_Name);
		t_Style.setColorName(t_ColorName);
		t_Style.setAccurateMatch(t_AccurateMatch);

		if (null != t_Pattern)
		{
			t_Style.setPattern(t_Pattern);
		}

		IConfigurationElement[] t_ColorElements = r_ConfigurationElement.getChildren();
		for (int i = 0; i < t_ColorElements.length; i++)
		{
			WordGroup t_WordGroup = doLoadKeyWords(t_ColorElements[i]);
			t_Style.doAddWord(t_WordGroup);
		}

		register(t_Style);
	}

	/**
	 * ����չ��������ȡ����Ӧ�Ĺؼ�����ϡ�<BR>
	 * 
	 * Get the group of key word from the configuration of plugin.<BR>
	 * 
	 * @param r_ConfigurationElement
	 *            the configuration content defined in the extension-point.
	 */
	private static WordGroup doLoadKeyWords(IConfigurationElement r_ConfigurationElement)
	{
		WordGroup t_Group = new WordGroup();

		String t_ColorName = r_ConfigurationElement.getAttribute(Color);
		boolean t_CaseSensitive = Boolean.valueOf(r_ConfigurationElement.getAttribute(WordGroup.CaseSensitive)).booleanValue();

		t_Group.setColorName(t_ColorName);
		t_Group.setCaseSensitive(t_CaseSensitive);

		IConfigurationElement[] t_ColorElements = r_ConfigurationElement.getChildren();
		for (int i = 0; i < t_ColorElements.length; i++)
		{
			t_Group.doAddWord(t_ColorElements[i].getAttribute(Word));
		}

		return t_Group;
	}

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 * 
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private StyleService()
	{
		super();
	}

	/**
	 * ����ָ�����Ƶ���ɫ��ʽ<BR>
	 * 
	 * Return the color style for the name<BR>
	 * 
	 * @param r_StyleName
	 *            the specified name for get styles.
	 */
	public static IStyle[] getStyle(String r_StyleName)
	{
		Set t_StyleSet = (Set) styles.get(r_StyleName);
		IStyle[] t_Styles = new IStyle[t_StyleSet.size()];
		t_StyleSet.toArray(t_Styles);

		return t_Styles;
	}

	/**
	 * ������ʽ������Ϊָ����StyledText������Ӧ����ʽ��<BR>
	 * 
	 * Set the styles for the StyledText by the specified name.<BR>
	 * 
	 * @param r_Text
	 *            the specified StyledText
	 * @param r_StyleName
	 *            the specified name for styles.
	 */
	public static void updateStyleListener(StyledText r_Text, String r_StyleName)
	{
		DefaultStyleProvider t_Provider = new DefaultStyleProvider();
		IStyle[] t_Styles = getStyle(r_StyleName);

		if (t_Styles.length > 0)
		{
			for (int i = 0; i < t_Styles.length; i++)
			{
				IStyle t_Style = t_Styles[i];
				t_Provider.doAddStyle(t_Style);
			}

			r_Text.addLineStyleListener(t_Provider.createStyleListener());
		}
	}

	/**
	 * ע��һ��ָ����������ʽ<BR>
	 * 
	 * Register a style.<BR>
	 * 
	 * @param r_Style
	 *            the style to register.
	 */
	public static void register(IStyle r_Style)
	{
		Set t_StyleSet = (Set) styles.get(r_Style.getName());
		if (null == t_StyleSet)
		{
			t_StyleSet = new HashSet();
			styles.put(r_Style.getName(), t_StyleSet);
		}

		t_StyleSet.add(r_Style);
	}

	/**
	 * ȡ��ע��һ��ָ����������ʽ<BR>
	 * 
	 * Unregister a style.<BR>
	 * 
	 * @param r_Style
	 *            the style to remove.
	 */
	public static void unRegister(IStyle r_Style)
	{
		Set t_StyleSet = (Set) styles.get(r_Style.getName());
		if (null != t_StyleSet)
		{
			t_StyleSet.remove(r_Style);
		}
	}
}
