/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.swt.resource;

import java.util.Arrays;

import org.eclipse.jface.resource.CompositeImageDescriptor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Point;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �ϳ�ͼƬ<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Composite image. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-4-8 ����07:13:28
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: DecoratorOverlayIcon.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/08 11:09:07  wanglei
 * Add:�ύ��CVS��
 *
 */

public class DecoratorOverlayIcon extends CompositeImageDescriptor {

	/**
	 * Position <code>TOP_LEFT</code>. Value <code>0</code>
	 */
	public static final int TOP_LEFT = 0;

	/**
	 * Position <code>TOP_RIGHT</code>. Value <code>1</code>
	 */
	public static final int TOP_RIGHT = 1;

	/**
	 * Position <code>BOTTOM_LEFT</code>. Value <code>2</code>
	 */
	public static final int BOTTOM_LEFT = 2;

	/**
	 * Position <code>BOTTOM_RIGHT</code>. Value <code>3</code>
	 */
	public static final int BOTTOM_RIGHT = 3;

	/**
	 * Position <code>UNDERLAY</code>. Value <code>4</code>
	 */
	public static final int UNDERLAY = 4;

	// the base image
	private Image base;

	// the overlay images
	private ImageDescriptor[] overlays;

	// the size
	private Point size;

	/**
	 * OverlayIcon constructor.
	 *
	 * @param r_BaseImage
	 *            the base image
	 * @param r_OverlaysArray
	 *            the overlay images
	 * @param r_Size
	 *            the size
	 */
	public DecoratorOverlayIcon(Image r_BaseImage, ImageDescriptor[] r_OverlaysArray, Point r_Size) {
		this.base = r_BaseImage;
		this.overlays = r_OverlaysArray;
		this.size = r_Size;
	}

	/**
	 * Draw the overlays for the reciever.
	 */
	protected void drawOverlays(ImageDescriptor[] t_OverlaysArray) {

		for (int i = 0; i < this.overlays.length; i++) {
			ImageDescriptor t_Overlay = t_OverlaysArray[i];
			if (t_Overlay == null) {
				continue;
			}
			ImageData t_OverlayData = t_Overlay.getImageData();
			// Use the missing descriptor if it is not there.
			if (t_OverlayData == null) {
				t_OverlayData = ImageDescriptor.getMissingImageDescriptor().getImageData();
			}
			switch (i) {
				case TOP_LEFT:
					drawImage(t_OverlayData, 0, 0);
					break;
				case TOP_RIGHT:
					drawImage(t_OverlayData, this.size.x - t_OverlayData.width, 0);
					break;
				case BOTTOM_LEFT:
					drawImage(t_OverlayData, 0, this.size.y - t_OverlayData.height);
					break;
				case BOTTOM_RIGHT:
					drawImage(t_OverlayData, this.size.x - t_OverlayData.width, this.size.y - t_OverlayData.height);
					break;
			}
		}
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public boolean equals(Object r_Object) {
		if (!(r_Object instanceof DecoratorOverlayIcon)) {
			return false;
		}
		DecoratorOverlayIcon t_Other = (DecoratorOverlayIcon) r_Object;
		return this.base.equals(t_Other.base) && Arrays.equals(this.overlays, t_Other.overlays);
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public int hashCode() {
		int t_HashCode = this.base.hashCode();
		for (int i = 0; i < this.overlays.length; i++) {
			if (this.overlays[i] != null) {
				t_HashCode ^= this.overlays[i].hashCode();
			}
		}
		return t_HashCode;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	protected void drawCompositeImage(int r_Width, int r_Height) {
		if (this.overlays.length > UNDERLAY) {
			ImageDescriptor t_Underlay = this.overlays[UNDERLAY];
			if (t_Underlay != null) {
				drawImage(t_Underlay.getImageData(), 0, 0);
			}
		}

		drawImage(this.base.getImageData(), 0, 0);
		drawOverlays(this.overlays);
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	protected Point getSize() {
		return this.size;
	}
}
