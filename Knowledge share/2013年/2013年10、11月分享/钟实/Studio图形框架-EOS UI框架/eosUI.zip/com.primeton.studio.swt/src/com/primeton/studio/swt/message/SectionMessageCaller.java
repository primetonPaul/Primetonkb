/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.swt.message;

import java.util.Properties;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.forms.widgets.Section;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.util.PropertiesUtil;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��Section����ʾ��Ϣ<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Show message in Section. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2007-3-2 ����08:17:35
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: SectionMessageCaller.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2008/02/15 07:17:18  wanglei
 * Review:��IMessageCaller��UI���඼�Ƶ�com.primeton.studio.ui.swt.messages����
 *
 * Revision 1.1  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public class SectionMessageCaller implements IMessageCaller
{
	private Label label;

	private boolean error = false;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 * 
	 * @param r_Section
	 */
	public SectionMessageCaller(Section r_Section)
	{
		this.label = new Label(r_Section, SWT.NONE);

		this.label.setText("");
		r_Section.setTextClient(this.label);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMessageCaller#clear()
	 */
	public void clear()
	{
		this.error = false;
		this.label.setText("");
		this.label.setForeground(ColorConstants.black);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMessageCaller#error(java.lang.String, java.util.Properties)
	 */
	public void error(String r_Message, Properties r_Properties)
	{
		if (null != r_Message)
		{
			this.error = true;
			this.label.setForeground(ColorConstants.red);
			this.label.setText(r_Message + PropertiesUtil.toString(r_Properties));
		}
		else
		{
			this.clear();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMessageCaller#hasError()
	 */
	public boolean hasError()
	{
		return this.error;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMessageCaller#info(java.lang.String, java.util.Properties)
	 */
	public void info(String r_Message, Properties r_Properties)
	{
		if (null != r_Message)
		{
			this.error = true;
			this.label.setForeground(ColorConstants.black);
			this.label.setText(r_Message + PropertiesUtil.toString(r_Properties));
		}
		else
		{
			this.clear();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMessageCaller#warn(java.lang.String, java.util.Properties)
	 */
	public void warn(String r_Message, Properties r_Properties)
	{
		if (null != r_Message)
		{
			this.error = false;
			this.label.setForeground(ColorConstants.yellow);
			this.label.setText(r_Message + PropertiesUtil.toString(r_Properties));
		}
		else
		{
			this.clear();
		}
	}

}
