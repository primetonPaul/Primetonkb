/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.swt/src/com/primeton/studio/swt/message/InfoControlMessageCaller.java,v 1.1 2011/06/01 01:23:06 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:23:06 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-5-13
 *******************************************************************************/


package com.primeton.studio.swt.message;

import java.util.Properties;

import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.resource.JFaceColors;
import org.eclipse.jface.text.DefaultInformationControl;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.swt.SwtMessages;
import com.primeton.studio.swt.html.HTMLTextPresenter;

/**
 * ��װ������Ϣ��ʾ����ͼԪ�����Ӳ���֧�֣�����ʾ�û�ԭ��ĳ�����ʹ�ã�
 * @author caijing (mailto:caijing@primeton.com)
 */
/*
 *
 * $Log: InfoControlMessageCaller.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/12/21 07:09:57  wanglei
 * Update:Ϊ�˼���Eclipse3.2���ϰ汾����Html��һЩ�������Eclipse�и��Ƶ�com.primeton.studio.swt����С�
 *
 * Revision 1.2  2009/05/06 10:47:47  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.5  2007/06/22 09:51:21  caijing
 * update:���¼�����ʾ��Ŀ���
 *
 * Revision 1.4  2007/05/22 05:54:17  lvyuan
 * Update:�������ߵ���ʾ��ϢΪ��ʱ�򲻵�����ʾ
 *
 * Revision 1.3  2007/05/14 06:50:21  caijing
 * Add�����Ӷ���
 *
 * Revision 1.2  2007/05/13 13:00:04  caijing
 * update:fix������Ϣ����Ϊnull�� nullpointer
 *
 * Revision 1.1  2007/05/13 12:51:27  caijing
 * update:��װ������Ϣ��ʾ����ͼԪ�����Ӳ���֧�֣�����ʾ�û�ԭ��ĳ�����ʹ�ã�
 *
 */
public class InfoControlMessageCaller implements IMessageCaller {
	private Shell shell;
	private int x,y = 0;


	public InfoControlMessageCaller(Shell shell,int x, int y) {
		super();
		Assert.isNotNull(shell, SwtMessages.SHELL_CAN_NOT_BE_NULL);
		Assert.isTrue(x>=0 && y >=0 , SwtMessages.X_Y_CAN_NOT_BE_NEGATIVE);
		this.shell = shell;
		x = x;
		y = y;
	}


	public void clear() {

	}

	public void error(String r_Message, Properties r_Properties) {
        if("".equals(r_Message) || null == r_Message) return; //$NON-NLS-1$

		HTMLTextPresenter presenter = new HTMLTextPresenter(true);

		final DefaultInformationControl infoControl = new DefaultInformationControl(shell,SWT.None,presenter,null);
        infoControl.setSizeConstraints(Integer.MAX_VALUE, Integer.MAX_VALUE);
        infoControl.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                infoControl.dispose();
            }
        });
        infoControl.setInformation(r_Message);

        Display display= shell.getDisplay();
        org.eclipse.swt.graphics.Rectangle displayBounds = display.getBounds();
        //ȱʡλ���м�
         x = x == 0 ?displayBounds.width/2:x;
         y = y == 0 ?displayBounds.height/2:y;

        org.eclipse.swt.graphics.Point p= shell.toDisplay(new org.eclipse.swt.graphics.Point(x,y));



        infoControl.setLocation(p);
        infoControl.setForegroundColor(JFaceColors.getErrorText(display));
        //fix nullpointer
        //���¼�����ʾ��Ŀ���
        int width =r_Message == null ? 40: r_Message.getBytes().length * (13/2)+2;
        infoControl.setSize(width,20);
        infoControl.setVisible(true);
        infoControl.setFocus();

	}

	public boolean hasError() {
		return false;
	}

	public void info(String r_Message, Properties r_Properties) {
		// TODO Auto-generated method stub

	}

	public void warn(String r_Message, Properties r_Properties) {
		// TODO Auto-generated method stub

	}

}

