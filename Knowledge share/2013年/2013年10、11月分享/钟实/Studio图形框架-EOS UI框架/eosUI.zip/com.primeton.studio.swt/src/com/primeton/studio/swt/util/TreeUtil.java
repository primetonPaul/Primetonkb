/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.swt.util;

import java.util.ArrayList;
import java.util.LinkedList;

import org.eclipse.jface.util.Assert;
import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * SWT���Ĺ����ࡣ <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The util class for swt tree. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * @author Lei.Wang
 * @version $Revision: 1.1 $Date: 2011/06/01 01:23:06 $
 */
public final class TreeUtil {

	/**
	 * Present the node' state is not checked.<BR>
	 */
	private static final int UnChecked = 0;

	/**
	 * Present the node' state is checked partly.<BR>
	 */
	private static final int Grayed = 1;

	/**
	 * Present the node' state is checked.<BR>
	 */
	private static final int Checked = 2;

	/**
	 * �������ʵ��<BR>
	 *
	 * The object instance is not needed.<BR>
	 */
	private TreeUtil() {
		super();
	}

	/**
	 * ����ָ����������TreeViewer<BR>
	 *
	 * Build a TreeViewer by the parameters.<BR>
	 *
	 * @param r_Composite
	 *            the parent control for the tree
	 * @param r_Style
	 *            the style for the tree
	 * @param r_ColumnTexts
	 *            the titles for the tree header.
	 */
	public static TreeViewer buildTreeViewer(Composite r_Composite, int r_Style, String[] r_ColumnTexts) {
		TreeViewer t_TreeViewer = new TreeViewer(r_Composite, r_Style);

		String[] t_Properties = new String[r_ColumnTexts.length];

		for (int i = 0; i < t_Properties.length; i++) {
			t_Properties[i] = Integer.toString(i);
		}
		t_TreeViewer.setColumnProperties(t_Properties);

		for (int i = 0; i < r_ColumnTexts.length; i++) {
			TreeColumn t_Column = new TreeColumn(t_TreeViewer.getTree(), SWT.FLAT);
			t_Column.setText(r_ColumnTexts[i]);
		}

		for (int i = 0; i < r_ColumnTexts.length; i++) {
			TreeColumn t_Column = t_TreeViewer.getTree().getColumn(i);
			t_Column.pack();
		}

		t_TreeViewer.getTree().setHeaderVisible(true);
		t_TreeViewer.getTree().setLinesVisible(true);

		return t_TreeViewer;
	}

	/**
	 * ��ָ����������µ��ӽ��ȫ����չ��.<BR>
	 *
	 * Expand the specified node.<BR>
	 *
	 * @param r_TreeViewer
	 *            the swt tree viewer.
	 * @param r_TreeItem
	 *            the target tree item which all the children nodes will be expaned.
	 */
	public static void expand(TreeViewer r_TreeViewer, TreeItem r_TreeItem) {
		r_TreeViewer.expandToLevel(r_TreeItem.getData(), AbstractTreeViewer.ALL_LEVELS);
	}

	/**
	 * ��ѡ����������չ��<BR>
	 *
	 * Expand the selected tree node.<BR>
	 *
	 * @param r_TreeViewer
	 *            the swt tree viewer.
	 */
	public static void expand(TreeViewer r_TreeViewer) {
		if (r_TreeViewer.getTree().getSelectionCount() != 1) {
			return;
		}

		TreeItem t_TreeItem = r_TreeViewer.getTree().getSelection()[0];
		expand(r_TreeViewer, t_TreeItem);
	}

	/**
	 * ����ĳһ������Լ��Ƿ�ѡ�У������е��ӽ�㶼�ᱻ������ͬ��״̬��<BR>
	 *
	 * Set the specified node checked or not.All the children nodes will be setted to the same state.<BR>
	 *
	 * @param r_TreeViewer
	 *            the swt tree viewer.
	 * @param r_Checked
	 *            the state to set all the nodes.
	 */
	public static void setState(TreeViewer r_TreeViewer, boolean r_Checked) {
		TreeItem[] t_TreeItems = r_TreeViewer.getTree().getItems();

		for (int i = 0; i < t_TreeItems.length; i++) {
			TreeItem t_Item = t_TreeItems[i];
			setState(t_Item, r_Checked);
		}
	}

	/**
	 * ����ĳһ������Լ��Ƿ�ѡ�У������е��ӽ�㶼�ᱻ������ͬ��״̬��<BR>
	 *
	 * Set the specified node checked or not.All the children nodes will be setted to the same state.<BR>
	 *
	 * @param r_TreeItem
	 *            the node and all the children nodes will be set to be the specified state.
	 * @param r_Checked
	 *            the state to set all the nodes.
	 */
	public static void setState(TreeItem r_TreeItem, boolean r_Checked) {
		r_TreeItem.setChecked(r_Checked);

		if (r_TreeItem.getItemCount() > 0) {
			TreeItem[] t_TreeItems = r_TreeItem.getItems();

			for (int i = 0; i < t_TreeItems.length; i++) {
				TreeItem t_Item = t_TreeItems[i];
				setState(t_Item, r_Checked);
			}
		}
	}

	/**
	 * ��ָ����������µ��ӽ��ȫ������.<BR>
	 *
	 * Collapse the specified node.<BR>
	 *
	 * @param r_TreeViewer
	 *            the swt tree viewer.
	 */
	public static void collapse(TreeViewer r_TreeViewer) {
		if (r_TreeViewer.getTree().getSelectionCount() != 1) {
			return;
		}

		TreeItem t_TreeItem = r_TreeViewer.getTree().getSelection()[0];
		collapse(r_TreeViewer, t_TreeItem);
	}

	/**
	 * ��ѡ������������<BR>
	 *
	 * Collapse the selected tree node.<BR>
	 *
	 * @param r_TreeViewer
	 *            the swt tree viewer.
	 */
	public static void collapse(TreeViewer r_TreeViewer, TreeItem r_TreeItem) {
		r_TreeViewer.collapseToLevel(r_TreeItem.getData(), AbstractTreeViewer.ALL_LEVELS);
	}

	/**
	 * ���������д�С<BR>
	 *
	 * Resize the width of the tree.<BR>
	 *
	 * @param r_TreeViewer
	 *            the swt tree viewer.
	 */
	public static void doAutoSize(TreeViewer r_TreeViewer) {
		r_TreeViewer.expandAll();

		TreeColumn[] t_Columns = r_TreeViewer.getTree().getColumns();
		for (int i = 0; i < t_Columns.length; i++) {
			t_Columns[i].pack();
		}
	}

	/**
	 * ��ָ�����ϲ��Ҵ��������ж���Ľ��<BR>
	 *
	 * Find the node which present the object in the parameter.<BR>
	 *
	 * @param r_Tree
	 *            the swt tree.
	 * @param r_Object
	 *            the specified object for being found.
	 */
	public static TreeItem find(Tree r_Tree, final Object r_Object) {
		TreeItem[] t_TreeItems = r_Tree.getItems();
		for (int i = 0; i < t_TreeItems.length; i++) {
			TreeItem t_TreeItem = find(t_TreeItems[i], r_Object);
			if (null != t_TreeItem) {
				return t_TreeItem;
			}
		}

		return null;
	}

	/**
	 * ��ָ������²��Ҵ��������ж���Ľ��<BR>
	 *
	 * Find the node which present the object in the parameter.<BR>
	 *
	 * @param r_TreeItem
	 * @param r_Object
	 * @return
	 */
	private static TreeItem find(TreeItem r_TreeItem, final Object r_Object) {
		if (r_Object == r_TreeItem.getData()) {
			return r_TreeItem;
		}

		TreeItem[] t_TreeItems = r_TreeItem.getItems();
		for (int i = 0; i < t_TreeItems.length; i++) {
			TreeItem t_TreeItem = find(t_TreeItems[i], r_Object);
			if (null != t_TreeItem) {
				return t_TreeItem;
			}
		}

		return null;
	}

	/**
	 * ����һ��֧��ѡ�������������н���״̬��֧��ѡ�У���ѡ�У�����ѡ������״̬��<BR>
	 *
	 * Update the state of a tree which is a checkbox tree.<BR>
	 * The state can be one the following 3 states:checked,unchecked and grayed.<BR>
	 *
	 * @param r_Tree
	 *            the swt tree.
	 */
	public static void updateTreeState(Tree r_Tree) {
		if ((r_Tree.getStyle() & SWT.CHECK) == 0) {
			return;
		}

		TreeItem[] t_TreeItems = r_Tree.getItems();
		for (int i = 0; i < t_TreeItems.length; i++) {
			TreeItem t_Item = t_TreeItems[i];

			t_Item.setGrayed(false);
			updateTreeItemState(t_Item);
		}
	}

	/**
	 * �ݹ�ĸ���ÿһ������״̬��ÿһ������״̬�������ӽ�������<BR>
	 *
	 * Update every node recursively.<BR>
	 * The state of every node will resulted from the children node.<BR>
	 *
	 * @param r_TreeItem
	 *            the tree item which checked state will be updated.
	 * @return Return the result state.
	 */
	private static void updateTreeItemState(TreeItem r_TreeItem) {
		TreeItem[] t_TreeItems = r_TreeItem.getItems();
		if (0 != t_TreeItems.length) {
			for (int i = 0; i < t_TreeItems.length; i++) {
				TreeItem t_TreeItem = t_TreeItems[i];
				updateTreeItemState(t_TreeItem);
			}

			int t_State = getTreeItemState(r_TreeItem);
			updateTreeItemState(r_TreeItem, t_State);
		}
	}

	/**
	 * ֻ�����ӽ���״̬�������µ�ǰ���͵�ǰ���ĸ�����㣬�������ӽ��<BR>
	 *
	 * Refresh the node and the parent nodes .The chldren nodes will not be updated.<BR>
	 *
	 * @param r_TreeItem
	 *            the tree item which checked state will be updated.
	 */
	public static void refreshTreeItemState(TreeItem r_TreeItem) {
		TreeItem[] t_TreeItems = r_TreeItem.getItems();
		if (0 != t_TreeItems.length) {
			int t_State = getTreeItemState(r_TreeItem);
			updateTreeItemState(r_TreeItem, t_State);
		}

		if (null != r_TreeItem.getParentItem()) {
			refreshTreeItemState(r_TreeItem.getParentItem());
		}
	}

	/**
	 * �ݹ�Ĳ�ѯÿһ������״̬��ÿһ������״̬�������ӽ�������<BR>
	 *
	 * Retrieve every node recursively.<BR>
	 * The state of every node will resulted from the children node.<BR>
	 *
	 * @param r_TreeItem
	 *            this tree node will be checked the state.
	 * @see #Checked
	 * @see #UnChecked
	 * @see #Grayed
	 *
	 * @return Return the result state.
	 */
	private static int getTreeItemState(TreeItem r_TreeItem) {
		TreeItem[] t_TreeItems = r_TreeItem.getItems();
		if (0 == t_TreeItems.length) {
			if (r_TreeItem.getChecked()) {
				return Checked;
			}
			else {
				return UnChecked;
			}
		}
		// If a node without children.The state is result from itself.

		int t_Count = 0;

		for (int i = 0; i < t_TreeItems.length; i++) {
			TreeItem t_Item = t_TreeItems[i];

			int t_State = getTreeItemState(t_Item);

			if (t_State == Checked) {
				t_Count = t_Count + 2;
			}

			if (t_State == Grayed) {
				t_Count++;
			}
		}
		// If the child node is checked .Do a count.
		// If the child node is grayed .Do a double count.

		if (t_Count == (t_TreeItems.length * 2)) {
			return Checked;
			// If the count equals to the double length of the child nodes.
			// That means every child node is checked.
		}
		else {
			if (t_Count == 0) {
				return UnChecked;
				// If the count equals to 0.
				// That means every child node is unchecked.
			}
			else {
				return Grayed;
				// The last condition is grayed.
			}
		}
	}

	/**
	 * ����ָ����״̬���½���״̬��<BR>
	 *
	 * Update the state for the specified tree node.
	 *
	 * @param r_TreeItem
	 *            this tree node will be set to the specified state.
	 *
	 * @param r_State
	 *            the state to be set.
	 */
	private static void updateTreeItemState(TreeItem r_TreeItem, int r_State) {
		r_TreeItem.setGrayed(false);

		switch (r_State) {
			case Checked:
				r_TreeItem.setChecked(true);
				return;

			case UnChecked:
				r_TreeItem.setChecked(false);
				return;

			case Grayed:
				r_TreeItem.setChecked(true);
				r_TreeItem.setGrayed(true);
				return;

		}
	}

	/**
	 * ����ָ���������ϵ�������<BR>
	 *
	 * Compute the column for the x location.<BR>
	 *
	 * @param r_Table
	 * @param r_X
	 */
	public static int computeColumn(Tree r_Tree, int r_X) {
		int t_X = 0;

		for (int i = 0; i < r_Tree.getColumnCount(); i++) {
			TreeColumn t_Column = r_Tree.getColumn(i);
			t_X = t_X + t_Column.getWidth();
			if (t_X >= r_X) {
				return i;
			}
		}

		return 0;
	}

	/**
	 * ��������ѡ������ݡ�<BR>
	 *
	 * Return the selection of the tree.<BR>
	 *
	 * @param r_Tree
	 * @return
	 */
	public static IStructuredSelection getSelection(Tree r_Tree) {
		TreeItem[] items = r_Tree.getSelection();
		ArrayList list = new ArrayList(items.length);
		for (int i = 0; i < items.length; i++) {
			TreeItem item = items[i];
			if (item.getData() != null) {
				list.add(getTreePathFromItem(item));
			}
		}
		return new TreeSelection((TreePath[]) list.toArray(new TreePath[list.size()]));
	}

	/**
	 * Returns the tree path for the given item.
	 *
	 */
	protected static TreePath getTreePathFromItem(TreeItem item) {
		LinkedList segments = new LinkedList();
		while (item != null) {
			Object segment = item.getData();
			Assert.isNotNull(segment);
			segments.addFirst(segment);
			item = item.getParentItem();
		}
		return new TreePath(segments.toArray());
	}
}
