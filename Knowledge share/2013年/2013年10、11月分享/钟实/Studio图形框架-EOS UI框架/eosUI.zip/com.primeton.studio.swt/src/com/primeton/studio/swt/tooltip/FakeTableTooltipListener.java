/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.swt.tooltip;

import org.eclipse.core.runtime.Assert;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.swt.SwtMessages;
import com.primeton.studio.swt.util.SwtResourceUtil;
import com.primeton.studio.swt.util.TableUtil;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��������ģ��Tableʱʹ�õ�Shell���Ӷ��ں��ʵ�ʱ��ر����ģ�µ�Shell.<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The listener to handle the shell to fake the tooltip of a swt table.<BR>
 * It can close the shell to fake table tooltip. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-20 ����10:53:47
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: FakeTableTooltipListener.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/05/06 10:47:47  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:49:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2008/02/20 08:38:40  wanglei
 * Update:�ƶ���tooltip������
 *
 * Revision 1.2  2007/12/12 05:15:18  wanglei
 * Review:֧��Table������������TableBuilder��
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public final class FakeTableTooltipListener implements Listener
{
	private static final String TableItemTooltip = "_TableItemTooltip"; //$NON-NLS-1$

	private ITooltipProvider tooltipProvider;

	private Table table;

	private Shell tooltipShell = null;

	private Label label = null;

	// Implement a "fake" tooltip
	private final Listener labelListener;

	/**
	 * ����Ҫģ��Tooltip�ı������������<BR>
	 *
	 * Pass the table for fake tooltip to construct a new object.<BR>
	 *
	 * @param r_TableBuilder
	 */
	private FakeTableTooltipListener(Table r_Table,ITooltipProvider r_TooltipProvider)
	{
		super();
		this.tooltipProvider = r_TooltipProvider;
		this.table = r_Table;
		this.table.setToolTipText(null);
		// close the default the tooltip for table.

		this.labelListener = new Listener()
		{
			public void handleEvent(Event r_Event)
			{
				Label t_Label = (Label) r_Event.widget;
				Shell t_Shell = t_Label.getShell();
				switch (r_Event.type)
				{
					case SWT.MouseDown:
					{
						Event t_Event = new Event();
						t_Event.item = (TableItem) t_Label.getData(TableItemTooltip);
						Table t_Table = FakeTableTooltipListener.this.table;
						// Assuming table is single select, set the selection as if
						// the mouse down event went through to the table
						t_Table.setSelection(new TableItem[] { (TableItem) t_Event.item });
						t_Table.notifyListeners(SWT.Selection, t_Event);
						t_Shell.dispose();
						t_Table.setFocus();
						break;
					}

					case SWT.MouseExit:
					{
						t_Shell.dispose();
						break;
					}
				}
			}
		};
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.widgets.Listener#handleEvent(org.eclipse.swt.widgets.Event)
	 */
	public void handleEvent(Event r_Event)
	{
		switch (r_Event.type)
		{
			case SWT.MouseMove:
			{
				if (this.tooltipShell == null)
				{
					break;
				}
				mouseMove();
				break;
			}
			case SWT.MouseHover:
			{
				mouseHover(r_Event);
			}
		}
	}

	/**
	 * ������������¼���<BR>
	 *
	 * Handle the event of mouse hover.<BR>
	 *
	 * @param r_Event
	 */
	private void mouseHover(Event r_Event)
	{
		TableItem t_TableItem = this.table.getItem(new Point(r_Event.x, r_Event.y));

		if (t_TableItem != null)
		{
			if (this.tooltipShell != null && !this.tooltipShell.isDisposed())
			{
				this.tooltipShell.dispose();
			}

			int t_ColumnIndex = TableUtil.computeColumn(this.table, r_Event.x);

			Tooltip t_Tooltip = this.tooltipProvider.getTooltip(t_TableItem.getData(), t_ColumnIndex);
			if (null == t_Tooltip)
			{
				return;
			}

			this.tooltipShell = new Shell(this.table.getShell(), SWT.ON_TOP | SWT.NO_FOCUS | SWT.TOOL);
			this.tooltipShell.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_INFO_BACKGROUND));
			FillLayout t_Layout = new FillLayout();
			t_Layout.marginWidth = 2;
			this.tooltipShell.setLayout(t_Layout);
			updateTooltip(t_TableItem, t_Tooltip);

			Point t_Size = this.tooltipShell.computeSize(SWT.DEFAULT, SWT.DEFAULT);
			Rectangle r_Bounds = t_TableItem.getBounds(0);
			Point t_Point = this.table.toDisplay(r_Bounds.x, r_Bounds.y);
			this.tooltipShell.setBounds(t_Point.x + r_Event.x, t_Point.y, t_Size.x, t_Size.y);
			this.tooltipShell.setVisible(true);
		}
	}

	/**
	 * @param r_TableItem
	 * @param r_Tooltip
	 */
	private void updateTooltip(TableItem r_TableItem, Tooltip r_Tooltip)
	{
		this.label = new Label(this.tooltipShell, SWT.NONE);

		if (r_Tooltip.getLevel() == IConstant.ERROR)
		{
			this.label.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_RED));
		}
		else
		{
			this.label.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_INFO_FOREGROUND));
		}

		this.label.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_INFO_BACKGROUND));

		this.label.setData(TableItemTooltip, r_TableItem);
		this.label.setText(r_Tooltip.getContent());
		this.label.addListener(SWT.MouseExit, this.labelListener);
		this.label.addListener(SWT.MouseDown, this.labelListener);
	}

	/**
	 * ��������ƶ��¼���<BR>
	 *
	 * Handle the event of mouse move.<BR>
	 */
	private void mouseMove()
	{
		this.tooltipShell.dispose();
		this.tooltipShell = null;
		this.label = null;
	}

	/**
	 * Ϊָ���������Ӷ�Ӧ�Ĺ�����ʾ���ݡ�<BR>
	 *
	 * Add tool tip to the specified table.<BR>
	 *
	 * @param r_Table
	 * @param r_TooltipProvider
	 */
	public static void addTooltipListener(Table r_Table,ITooltipProvider r_TooltipProvider)
	{
		Assert.isTrue(SwtResourceUtil.isValid(r_Table), SwtMessages.TREE_NULL);
		Assert.isNotNull(r_TooltipProvider, SwtMessages.TOOL_TIP_CAN_NOT_BE_NULL);

		FakeTableTooltipListener t_Listener = new FakeTableTooltipListener(r_Table,r_TooltipProvider);
		r_Table.addListener(SWT.Dispose, t_Listener);
		r_Table.addListener(SWT.KeyDown, t_Listener);
		r_Table.addListener(SWT.MouseMove, t_Listener);
		r_Table.addListener(SWT.MouseHover, t_Listener);

	}
}
