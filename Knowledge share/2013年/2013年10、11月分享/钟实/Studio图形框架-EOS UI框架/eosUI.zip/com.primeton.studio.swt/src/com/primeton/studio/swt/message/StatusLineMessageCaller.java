/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.swt/src/com/primeton/studio/swt/message/StatusLineMessageCaller.java,v 1.1 2011/06/01 01:23:06 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:23:06 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved. 
 * 
 * Created on 2007-4-27
 *******************************************************************************/


package com.primeton.studio.swt.message;

import java.util.Properties;

import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.ui.IEditorPart;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.swt.SwtMessages;

/**
 * TODO�˴���д class ��Ϣ
 *
 * @author lvyuan (mailto:lvyuan@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: StatusLineMessageCaller.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/05/06 10:47:47  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2007/04/27 03:36:27  lvyuan
 * Update:����
 * 
 */
public class StatusLineMessageCaller implements IMessageCaller {
    
    private IEditorPart editorPart;
    
    /**
     * 
     */
    public StatusLineMessageCaller(IEditorPart editorPart) {
        super();
        Assert.isNotNull(editorPart, SwtMessages.RESOURCE_CAN_NOT_BE_NULL);
        this.editorPart = editorPart;
    }
    
    
    /* (non-Javadoc)
     * @see com.primeton.studio.core.IMessageCaller#clear()
     */
    public void clear() {
        IStatusLineManager status = editorPart.getEditorSite().getActionBars().getStatusLineManager();
        status.setErrorMessage(null);
    }

    /* (non-Javadoc)
     * @see com.primeton.studio.core.IMessageCaller#error(java.lang.String, java.util.Properties)
     */
    public void error(String r_Message, Properties r_Properties) {
        IStatusLineManager status = editorPart.getEditorSite().getActionBars().getStatusLineManager();
        status.setErrorMessage(r_Message);
    }

    /* (non-Javadoc)
     * @see com.primeton.studio.core.IMessageCaller#hasError()
     */
    public boolean hasError() {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see com.primeton.studio.core.IMessageCaller#info(java.lang.String, java.util.Properties)
     */
    public void info(String r_Message, Properties r_Properties) {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see com.primeton.studio.core.IMessageCaller#warn(java.lang.String, java.util.Properties)
     */
    public void warn(String r_Message, Properties r_Properties) {
        // TODO Auto-generated method stub
        
    }

}
