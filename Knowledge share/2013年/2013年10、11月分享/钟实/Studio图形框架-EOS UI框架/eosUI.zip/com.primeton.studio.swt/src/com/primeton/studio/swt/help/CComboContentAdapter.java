/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.swt.help;

import org.eclipse.jface.fieldassist.IControlContentAdapter;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ģ��ComboContentAdapter��֧��CCombo<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Like ComboContentAdapter,it can support CCombo. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2007-2-27 ����04:09:54
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: CComboContentAdapter.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:49:22  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public class CComboContentAdapter implements IControlContentAdapter
{

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 * 
	 */
	public CComboContentAdapter()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.dialogs.taskassistance.IControlContentAdapter#getControlContents(org.eclipse.swt.widgets.Control)
	 */
	public String getControlContents(Control r_Control)
	{
		return ((CCombo) r_Control).getText();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.fieldassist.IControlContentAdapter#setControlContents(org.eclipse.swt.widgets.Control,
	 *      java.lang.String, int)
	 */
	public void setControlContents(Control r_Control, String r_Text, int r_CursorPosition)
	{
		((CCombo) r_Control).setText(r_Text);
		((CCombo) r_Control).setSelection(new Point(r_CursorPosition, r_CursorPosition));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.fieldassist.IControlContentAdapter#insertControlContents(org.eclipse.swt.widgets.Control,
	 *      java.lang.String, int)
	 */
	public void insertControlContents(Control r_Control, String r_Text, int r_CursorPosition)
	{
		CCombo t_Combo = (CCombo) r_Control;
		String t_Content = t_Combo.getText();
		Point t_Selection = t_Combo.getSelection();
		StringBuffer t_StringBuffer = new StringBuffer();
		t_StringBuffer.append(t_Content.substring(0, t_Selection.x));
		t_StringBuffer.append(r_Text);
		if (t_Selection.y < t_Content.length())
		{
			t_StringBuffer.append(t_Content.substring(t_Selection.y, t_Content.length()));
		}
		t_Combo.setText(t_StringBuffer.toString());
		t_Selection.x = t_Selection.x + r_CursorPosition;
		t_Selection.y = t_Selection.x;
		t_Combo.setSelection(t_Selection);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.fieldassist.IControlContentAdapter#getCursorPosition(org.eclipse.swt.widgets.Control)
	 */
	public int getCursorPosition(Control r_Control)
	{
		return ((CCombo) r_Control).getSelection().x;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.fieldassist.IControlContentAdapter#getInsertionBounds(org.eclipse.swt.widgets.Control)
	 */
	public Rectangle getInsertionBounds(Control r_Control)
	{
		CCombo t_Combo = (CCombo) r_Control;
		int t_Position = t_Combo.getSelection().y;
		String t_Content = t_Combo.getText();
		GC t_GC = new GC(t_Combo);
		t_GC.setFont(t_Combo.getFont());
		Point t_Extent = t_GC.textExtent(t_Content.substring(0, Math.min(t_Position, t_Content.length())));
		t_GC.dispose();
		return new Rectangle(t_Combo.getClientArea().x + t_Extent.x, t_Combo.getClientArea().y, 1, t_Combo.getClientArea().height);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.fieldassist.IControlContentAdapter#setCursorPosition(org.eclipse.swt.widgets.Control, int)
	 */
	public void setCursorPosition(Control r_Control, int r_Index)
	{
		((CCombo) r_Control).setSelection(new Point(r_Index, r_Index));
	}
}
