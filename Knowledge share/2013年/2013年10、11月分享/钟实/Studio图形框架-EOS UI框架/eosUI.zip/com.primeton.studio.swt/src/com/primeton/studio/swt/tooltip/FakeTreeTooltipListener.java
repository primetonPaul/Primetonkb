/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.swt.tooltip;

import org.eclipse.core.runtime.Assert;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.swt.SwtMessages;
import com.primeton.studio.swt.util.SwtResourceUtil;
import com.primeton.studio.swt.util.TreeUtil;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��������ģ��Tableʱʹ�õ�Shell���Ӷ��ں��ʵ�ʱ��ر����ģ�µ�Shell.<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The listener to handle the shell to fake the tooltip of a swt tree.<BR>
 * It can close the shell to fake tree tooltip. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-20 ����10:53:47
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: FakeTreeTooltipListener.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/05/06 10:47:47  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:49:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2008/02/20 08:38:40  wanglei
 * Update:�ƶ���tooltip������
 *
 * Revision 1.3  2007/12/29 03:25:27  chenxp
 * Update:����tooltip����ʾλ��
 *
 * Revision 1.2  2007/12/12 05:15:33  wanglei
 * Review:֧��Tree����������TreeBuilder��
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public final class FakeTreeTooltipListener implements Listener
{
	private static final String TreeItemTooltip = "_TreeItemTooltip"; //$NON-NLS-1$

	private Tree tree;

	private ITooltipProvider tooltipProvider;

	private Shell tooltipShell = null;

	private Label label = null;

	// Implement a "fake" tooltip
	private final Listener labelListener;

	/**
	 * ����Ҫģ��Tooltip�������������<BR>
	 *
	 * Pass the tree for fake tooltip to construct a new object.<BR>
	 *
	 * @param r_Tree
	 * @param r_TooltipProvider
	 */
	private FakeTreeTooltipListener(Tree r_Tree,ITooltipProvider r_TooltipProvider)
	{
		super();
		this.tree = r_Tree;
		this.tooltipProvider=r_TooltipProvider;
		this.tree.setToolTipText(null);
		// close the default the tooltip for tree.

		this.labelListener = new Listener()
		{
			public void handleEvent(Event r_Event)
			{
				Label t_Label = (Label) r_Event.widget;
				Shell t_Shell = t_Label.getShell();
				switch (r_Event.type)
				{
					case SWT.MouseDown:
					{
						Event t_Event = new Event();
						t_Event.item = (TableItem) t_Label.getData(TreeItemTooltip);
						Tree t_Tree = FakeTreeTooltipListener.this.tree;
						// Assuming tree is single select, set the selection as if
						// the mouse down event went through to the tree
						t_Tree.setSelection(new TreeItem[] { (TreeItem) t_Event.item });
						t_Tree.notifyListeners(SWT.Selection, t_Event);
						t_Shell.dispose();
						t_Tree.setFocus();
						break;
					}

					case SWT.MouseExit:
					{
						t_Shell.dispose();
						break;
					}

				}
			}
		};
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.widgets.Listener#handleEvent(org.eclipse.swt.widgets.Event)
	 */
	public void handleEvent(Event r_Event)
	{
		switch (r_Event.type)
		{
			case SWT.MouseMove:
			{
				if (this.tooltipShell == null)
				{
					break;
				}
				mouseMove();
				break;
			}
			case SWT.MouseHover:
			{
				mouseHover(r_Event);
			}
		}
	}

	/**
	 * ������������¼���<BR>
	 *
	 * Handle the event of mouse hover.<BR>
	 *
	 * @param r_Event
	 */
	private void mouseHover(Event r_Event)
	{
		TreeItem t_TreeItem = this.tree.getItem(new Point(r_Event.x, r_Event.y));

		if (t_TreeItem != null)
		{
			if (this.tooltipShell != null && !this.tooltipShell.isDisposed())
			{
				this.tooltipShell.dispose();
			}

			int t_ColumnIndex = TreeUtil.computeColumn(this.tree, r_Event.x);

			Tooltip t_Tooltip = this.tooltipProvider.getTooltip(t_TreeItem.getData(), t_ColumnIndex);
			if (null == t_Tooltip)
			{
				return;
			}

			this.tooltipShell = new Shell(this.tree.getShell(), SWT.ON_TOP | SWT.NO_FOCUS | SWT.TOOL);
			this.tooltipShell.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_INFO_BACKGROUND));
			FillLayout t_Layout = new FillLayout();
			t_Layout.marginWidth = 2;
			this.tooltipShell.setLayout(t_Layout);
			updateTooltip(t_TreeItem, t_Tooltip);

			Point t_Size = this.tooltipShell.computeSize(SWT.DEFAULT, SWT.DEFAULT);

			Point t_Point = this.tree.toDisplay(r_Event.x, r_Event.y);
			this.tooltipShell.setBounds(t_Point.x, t_Point.y+20, t_Size.x, t_Size.y);
			this.tooltipShell.setVisible(true);
		}
	}

	/**
	 * @param r_TreeItem
	 * @param r_Tooltip
	 */
	private void updateTooltip(TreeItem r_TreeItem, Tooltip r_Tooltip)
	{
		this.label = new Label(this.tooltipShell, SWT.NONE);

		if (r_Tooltip.getLevel() == IConstant.ERROR)
		{
			this.label.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_RED));
		}
		else
		{
			this.label.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_INFO_FOREGROUND));
		}

		this.label.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_INFO_BACKGROUND));

		this.label.setData(TreeItemTooltip, r_TreeItem);
		this.label.setText(r_Tooltip.getContent());
		this.label.addListener(SWT.MouseExit, this.labelListener);
		this.label.addListener(SWT.MouseDown, this.labelListener);
	}

	/**
	 * ��������ƶ��¼���<BR>
	 *
	 * Handle the event of mouse move.<BR>
	 */
	private void mouseMove()
	{
		this.tooltipShell.dispose();
		this.tooltipShell = null;
		this.label = null;
	}

	/**
	 * Ϊָ�������Ӷ�Ӧ�Ĺ�����ʾ���ݡ�<BR>
	 *
	 * Add tool tip to the specified tree.<BR>
	 *
	 * @param r_Tree
	 * @param r_TooltipProvider
	 */
	public static void addTooltipListener(Tree r_Tree,ITooltipProvider r_TooltipProvider)
	{
		Assert.isTrue(SwtResourceUtil.isValid(r_Tree), SwtMessages.TREE_NULL);
		Assert.isNotNull(r_TooltipProvider, SwtMessages.TOOL_TIP_CAN_NOT_BE_NULL);

		FakeTreeTooltipListener t_Listener = new FakeTreeTooltipListener(r_Tree,r_TooltipProvider);
		r_Tree.addListener(SWT.Dispose, t_Listener);
		r_Tree.addListener(SWT.KeyDown, t_Listener);
		r_Tree.addListener(SWT.MouseMove, t_Listener);
		r_Tree.addListener(SWT.MouseHover, t_Listener);
	}
}
