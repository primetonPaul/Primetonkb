/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.swt/src/com/primeton/studio/swt/util/AutoResizeTableLayout.java,v 1.1 2011/06/01 01:23:06 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:23:06 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2007-6-25
 *******************************************************************************/

package com.primeton.studio.swt.util;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLayoutData;
import org.eclipse.jface.viewers.ColumnPixelData;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * �Զ�����Table�Ĵ�С
 *
 * @author caiwei (mailto:caiwei@primeton.com)
 */
/*
 * $Log: AutoResizeTableLayout.java,v $
 * Revision 1.1  2011/06/01 01:23:06  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:31  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:49:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:03:22  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2008/01/11 05:53:26  caiwei
 * Update:�ƶ�������studio.ui
 *
 * Revision 1.3  2007/10/08 09:05:35  caiwei
 * review:����todo
 *
 * Revision 1.2  2007/10/08 08:55:26  caiwei
 * review:����todo��javadoc�ͱ������������ù��ܵ�
 *
 * Revision 1.1  2007/06/28 12:02:52  caiwei
 * add:�������Bizlet������
 * 
 */
public class AutoResizeTableLayout extends TableLayout implements
		ControlListener {
	private final Table table;

	private List columns = new ArrayList();

	private boolean autosizing = false;

	public AutoResizeTableLayout(Table table) {
		this.table = table;
		table.addControlListener(this);
	}

	public void addColumnData(ColumnLayoutData data) {
		columns.add(data);
		super.addColumnData(data);
	}

	public void controlMoved(ControlEvent e) {
	}

	public void controlResized(ControlEvent e) {
		if (autosizing)
			return;
		autosizing = true;
		try {
			autoSizeColumns();
		} finally {
			autosizing = false;
		}
	}

	private void autoSizeColumns() {
		int width = table.getClientArea().width;

		// XXX: Layout is being called with an invalid value
		// the first time it is being called on Linux.
		// This method resets the layout to null,
		// so we run it only when the value is OK.
		if (width <= 1)
			return;

		TableColumn[] tableColumns = table.getColumns();
		int size = Math.min(columns.size(), tableColumns.length);
		int[] widths = new int[size];
		int fixedWidth = 0;
		int numberOfWeightColumns = 0;
		int totalWeight = 0;

		// First calculate space occupied by fixed columns.
		for (int i = 0; i < size; i++) {
			ColumnLayoutData col = (ColumnLayoutData) columns.get(i);
			if (col instanceof ColumnPixelData) {
				int pixels = ((ColumnPixelData) col).width;
				widths[i] = pixels;
				fixedWidth += pixels;
			} else if (col instanceof ColumnWeightData) {
				ColumnWeightData cw = (ColumnWeightData) col;
				numberOfWeightColumns++;
				int weight = cw.weight;
				totalWeight += weight;
			} else {
				throw new IllegalStateException("Unknown column layout data");
			}
		}
		// Do we have columns that have a weight?
		if (numberOfWeightColumns > 0) {
			// Now, distribute the rest
			// to the columns with weight.
			int rest = width - fixedWidth;
			int totalDistributed = 0;
			for (int i = 0; i < size; i++) {
				ColumnLayoutData col = (ColumnLayoutData) columns.get(i);
				if (col instanceof ColumnWeightData) {
					ColumnWeightData cw = (ColumnWeightData) col;
					int weight = cw.weight;
					int pixels = totalWeight == 0 ? 0 : weight * rest
							/ totalWeight;
					if (pixels < cw.minimumWidth)
						pixels = cw.minimumWidth;
					totalDistributed += pixels;
					widths[i] = pixels;
				}
			}

			// Distribute any remaining pixels
			// to columns with weight.
			int diff = rest - totalDistributed;
			for (int i = 0; diff > 0; i++) {
				if (i == size)
					i = 0;
				ColumnLayoutData col = (ColumnLayoutData) columns.get(i);
				if (col instanceof ColumnWeightData) {
					++widths[i];
					--diff;
				}
			}
		}

		for (int i = 0; i < size; i++) {
			if (tableColumns[i].getWidth() != widths[i])
				tableColumns[i].setWidth(widths[i]);
		}
	}
	
	/**
	 * Ϊһ��������Layout
	 * @param table
	 * @param weightDatas
	 */
	public static void buildNewLayoutForTable(Table table, int[] weightDatas) {
		AutoResizeTableLayout layout = new AutoResizeTableLayout(table);

		for (int i : weightDatas) {
			layout.addColumnData(new ColumnWeightData(i));
		}

		table.setLayout(layout);

	}
}
