/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.swt/src/com/primeton/studio/swt/SwtMessages.java,v 1.2 2011/06/02 07:11:02 yujie Exp $
 * $Revision: 1.2 $
 * $Date: 2011/06/02 07:11:02 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-5-6
 *******************************************************************************/

package com.primeton.studio.swt;

import org.eclipse.osgi.util.NLS;

public class SwtMessages extends NLS {
	private static final String BUNDLE_NAME = "com.primeton.studio.swt.swtMmessages"; //$NON-NLS-1$

	public static String IMAGE_DESCRIPTOR_CAN_NOT_BE_NULL;

	public static String RESOURCE_CAN_NOT_BE_NULL;

	public static String SHELL_CAN_NOT_BE_NULL;

	public static String TOOL_TIP_CAN_NOT_BE_NULL;

	public static String TREE_NULL;

	public static String X_Y_CAN_NOT_BE_NEGATIVE;
	
	/**
	 * �����ǳ�JDT�е�JavaUIMessages�еĳ���
	 */
	public static String JavaAnnotationHover_multipleMarkersAtThisLine;
	
	public static String HTMLTextPresenter_ellipsis;
	
	public static String HTML2TextReader_listItemPrefix;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, SwtMessages.class);
	}

	private SwtMessages() {
	}
}
