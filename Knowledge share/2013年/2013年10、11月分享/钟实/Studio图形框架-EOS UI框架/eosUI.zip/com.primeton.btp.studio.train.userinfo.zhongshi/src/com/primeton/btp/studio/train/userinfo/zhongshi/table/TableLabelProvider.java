/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��21��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.table;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

import com.primeton.btp.studio.train.userinfo.zhongshi.model.Hobby;
import com.primeton.btp.studio.train.userinfo.zhongshi.model.Person;
import com.primeton.btp.studio.train.userinfo.zhongshi.model.Sex;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class TableLabelProvider implements ITableLabelProvider {

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#addListener(org.eclipse.jface.viewers.ILabelProviderListener)
	 */
	@Override
	public void addListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#dispose()
	 */
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#isLabelProperty(java.lang.Object, java.lang.String)
	 */
	@Override
	public boolean isLabelProperty(Object element, String property) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#removeListener(org.eclipse.jface.viewers.ILabelProviderListener)
	 */
	@Override
	public void removeListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnImage(java.lang.Object, int)
	 */
	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnText(java.lang.Object, int)
	 */
	@Override
	public String getColumnText(Object element, int columnIndex) {
		//����ת����element���������е�һ��
		Person person = (Person)element;
		switch (columnIndex) {
		case PersonTableWindow.NAME:
			return person.getName();
		case PersonTableWindow.AGE:
			return person.getAge()+"";
		case PersonTableWindow.SEX:
			if(Sex.MAlE.equals(person.getSex())){
				return "��";
			}
			return "Ů";
		case PersonTableWindow.HOBBY:
			String hobbys = "";
			for(Hobby hobby:person.getHobbys()){
				hobbys = hobby.toString()+" ";
			}
			return hobbys;
		case PersonTableWindow.INFO:
			return person.getInfo();
		}
		return "";
	}
}

/*
 * �޸���ʷ
 * $Log$ 
 */