/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.manager;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

import com.primeton.btp.studio.train.userinfo.zhongshi.model.Person;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 * Person��Ϣ�ļ�����
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class PersonFileManager {
	
	public static List<Person> load(String filePath){
		List<Person> persons = new ArrayList<Person>();
		String xmls;
		try {
			xmls = FileUtils.readFileToString(new File(filePath));
			XStream xStream=new XStream(new DomDriver());
			xStream.alias("persons",List.class);
			persons = (List<Person>) xStream.fromXML(xmls);
		} catch (IOException e) {
		}
		return persons;
	} 
	
	public static void save(List<Person> persons,String filePath) throws IOException{
		XStream xStream=new XStream(new DomDriver());
		xStream.alias("persons",List.class);
		String strxml=xStream.toXML(persons);
		FileUtils.writeStringToFile(new File(filePath), strxml);
	}

}

/*
 * �޸���ʷ
 * $Log$ 
 */