/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013-10-23
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.ui;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.primeton.btp.studio.train.userinfo.zhongshi.model.Hobby;
import com.primeton.btp.studio.train.userinfo.zhongshi.model.Person;
import com.primeton.btp.studio.train.userinfo.zhongshi.model.Sex;
import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.core.impl.validator.NotEmptyValidator;
import com.primeton.studio.core.model.IDataProvider;
import com.primeton.studio.core.model.impl.MapProvider;
import com.primeton.studio.core.util.entry.MapEntry;
import com.primeton.studio.ui.editor.ObjectEditor;
import com.primeton.studio.ui.editor.swt.impl.CheckBoxPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.ComboPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.RadioGroupPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.StringPropertyEditor;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutBuilder;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;
import com.primeton.studio.ui.swt.dialog.ControlFactoryDialog;
import com.primeton.studio.ui.swt.factory.base.AbstractObjectEditorCreatorFactory;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class PersonControlFactory  extends AbstractObjectEditorCreatorFactory{

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.swt.factory.base.AbstractObjectEditorCreatorFactory#createObjectEditor()
	 */
	@Override
	public ObjectEditor createObjectEditor() {
		// TODO Auto-generated method stub
		final ObjectEditor objectEditor = new ObjectEditor();
		objectEditor.setTitle("�����û���Ϣ");
		objectEditor.setWindowTitle("�����û���Ϣ");
		
		//��������
		GridLayoutBuilder gridLayoutBuilder = new GridLayoutBuilder();
		gridLayoutBuilder.setColumnCount(4);
		gridLayoutBuilder.setGridColumnEqual(false);
		objectEditor.setLayoutBuilder(gridLayoutBuilder);
		
		
		//����
		StringPropertyEditor name = new StringPropertyEditor();
		name.setLabel("����:");
		name.setPropertyName("name");
		name.doAddValidator(new NotEmptyValidator("�û���������Ϊ��"));
		
		GridLayoutDataBuilder nameLayoutData = new GridLayoutDataBuilder();
		nameLayoutData.setHorizontalFill(true);
		nameLayoutData.setHorizontalSpan(3);
//		gridLayoutData.setLabelHorizontalAlignment(SWT.LEFT);
		name.setLayoutDataBuilder(nameLayoutData);

		objectEditor.doAddPropertyEditor(name);
		
		
		//�ڶ��в���
		GridLayoutDataBuilder simpleLayoutData = new GridLayoutDataBuilder();
		simpleLayoutData.setHorizontalFill(true);
		simpleLayoutData.setHorizontalSpan(1);
		
		
		//����
		StringPropertyEditor age = new StringPropertyEditor();
		age.setLabel("����:");
		age.setLayoutDataBuilder(simpleLayoutData);
		age.setPropertyName("age");
		age.doAddValidator(new NotEmptyValidator("�û����䲻��Ϊ��"));
		objectEditor.doAddPropertyEditor(age);
		
		//�Ա�
		RadioGroupPropertyEditor sex = new RadioGroupPropertyEditor();
		sex.setLabel("�Ա�:");

		List<MapEntry> sexList = new ArrayList<MapEntry>();			
		MapEntry sexMap = new MapEntry();
		sexMap.setKey("��");
		sexMap.setValue(Sex.MAlE);
		sexList.add(sexMap);
		
		sexMap = new MapEntry();
		sexMap.setKey("Ů");
		sexMap.setValue(Sex.FEMALE);
		sexList.add(sexMap);
		
		IDataProvider sexProvider = new MapProvider(sexList);
		
		sex.setDataProvider(sexProvider);
		sex.setHorizontalAlign(true);
		sex.setLayoutDataBuilder(simpleLayoutData);
		sex.setPropertyName("sex");
		objectEditor.doAddPropertyEditor(sex);
		
		//ʡ��
		ComboPropertyEditor province = new ComboPropertyEditor();
		province.setLabel("ʡ��:");
		province.setLayoutDataBuilder(simpleLayoutData);
		province.setPropertyName("province");
		objectEditor.doAddPropertyEditor(province);
		
		List<MapEntry> proviceList = new ArrayList<MapEntry>();	
		
		MapEntry provinceMap = new MapEntry();
		provinceMap.setKey("����");
		provinceMap.setValue("BJ");
		proviceList.add(provinceMap);
		
		provinceMap = new MapEntry();		
		provinceMap.setKey("�㶫ʡ");
		provinceMap.setValue("GD");
		proviceList.add(provinceMap);
		
		provinceMap = new MapEntry();
		provinceMap.setKey("�Ϻ�");
		provinceMap.setValue("SH");
		proviceList.add(provinceMap);
		
		IDataProvider provinceProvider = new MapProvider(proviceList);
		province.setDataProvider(provinceProvider);
		province.doAddValueChangeListener(new IValueChangeListener(){

			@Override
			public void valueChange(ValueChangeEvent event) {
				// TODO Auto-generated method stub
				List<MapEntry> cityList = new ArrayList<MapEntry>();
				ComboPropertyEditor city = (ComboPropertyEditor)objectEditor.getPropertyEditor("city");
				MapProvider cityProvider = new MapProvider(cityList);
				if(city==null){
					return;
				}
				if("BJ".equals(event.getNewValue())){
					
					MapEntry cityMap = new MapEntry();
					cityMap.setKey("������");
					cityMap.setValue("GZ");
					cityList.add(cityMap);
					
					cityMap = new MapEntry();
					cityMap.setKey("������");
					cityMap.setValue("FS");
					cityList.add(cityMap);					
				}else if("GD".equals(event.getNewValue())){
							
					MapEntry cityMap = new MapEntry();
					cityMap.setKey("������");
					cityMap.setValue("GZ");
					cityList.add(cityMap);
					
					cityMap = new MapEntry();
					cityMap.setKey("��ɽ��");
					cityMap.setValue("FS");
					cityList.add(cityMap);					
				}else if("SH".equals(event.getNewValue())){
					MapEntry cityMap = new MapEntry();
					cityMap.setKey("��̲");
					cityMap.setValue("WT");
					cityList.add(cityMap);
					
					cityMap = new MapEntry();
					cityMap.setKey("����");
					cityMap.setValue("MN");
					cityList.add(cityMap);	
				}
				city.setDataProvider(cityProvider);
				city.refresh();
				city.getCombo().select(0);
			}
			
		});
		
		//����
		ComboPropertyEditor city = new ComboPropertyEditor();
		city.setLabel("����:");
		city.setPropertyName("city");
		city.setLayoutDataBuilder(simpleLayoutData);
		objectEditor.doAddPropertyEditor(city);
		

		
		//���
		StringPropertyEditor infoEditor = new StringPropertyEditor();
		infoEditor.setLabel("���:");
		infoEditor.setMulti(true);
		infoEditor.setPropertyName("info");
		
		GridLayoutDataBuilder infoLayoutData = new GridLayoutDataBuilder();
		infoLayoutData.setHorizontalFill(true);
		infoLayoutData.setHorizontalSpan(3);
		infoLayoutData.setPreferredHeight(80);
		infoLayoutData.setLabelVerticalAlignment(SWT.TOP);
		infoEditor.setLayoutDataBuilder(infoLayoutData);
		
		objectEditor.doAddPropertyEditor(infoEditor);
		
		//����checkbox
//		Hobby[] values = Hobby.values();
//		for(int i =0 ;i<values.length;i++){
//			CheckBoxPropertyEditor hobbyEditor = new CheckBoxPropertyEditor();
//			hobbyEditor.setLabel(values[i].toString());
//			hobbyEditor.setPropertyName("hobbys");
//			objectEditor.doAddPropertyEditor(hobbyEditor);
//		}
		
		return objectEditor;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PersonControlFactory controlFactory = new PersonControlFactory();
		controlFactory.setValue(new Person());
		Shell shell = new Shell(new Display());
		ControlFactoryDialog dialog = new ControlFactoryDialog(shell, controlFactory);
		dialog.getUIDescription().setWindowTitle("�û���Ϣ�༭");
		dialog.getUIDescription().setTitle("�༭�û���Ϣ");
		if(dialog.open()==Window.OK){
			Person person = (Person) controlFactory.getValue();
			System.out.println(person.getName());
		}
		
	}
}

/*
 * �޸���ʷ
 * $Log$ 
 */