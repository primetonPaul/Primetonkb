/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��20��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.table;

import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.Item;

import com.primeton.btp.studio.train.userinfo.zhongshi.model.Person;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class TableCellModifier implements ICellModifier{
	
	private TableViewer table;
	
	/**
	 * 
	 */
	public TableCellModifier(TableViewer table) {
		this.table = table;
	}
	
	//�������Ϊ��һ�У����ò����޸�
	public boolean canModify(Object element, String property) {
		if ( property.equals(PersonTableWindow.COLUMN_NAME[2])||property.equals(PersonTableWindow.COLUMN_NAME[3]))
			return false;
		return true;
	}
	//�����ڱ༭״̬ʱ����ʾ��ֵ
	public Object getValue(Object element, String property) {
		Person p = (Person) element;
		if ( property.equals(PersonTableWindow.COLUMN_NAME[0]))
			return p.getName();
		else if ( property.equals(PersonTableWindow.COLUMN_NAME[1]))
			return p.getAge()+"";
		else if ( property.equals(PersonTableWindow.COLUMN_NAME[4]))
			return p.getInfo();
		return null;
	}
	//���޸ĺ����ø�������
	public void modify(Object element, String property, Object value) {
		if (element instanceof Item) 
			element = ((Item) element).getData();
		Person p = (Person) element;
		if ( property.equals(PersonTableWindow.COLUMN_NAME[0]))
			p.setName( (String)value );
		else if ( property.equals(PersonTableWindow.COLUMN_NAME[1])) {
			int parseInt = p.getAge();
			try {
				parseInt = Integer.parseInt((String)value);
			} catch (NumberFormatException e) {
			}
			p.setAge( parseInt);
		} else if ( property.equals(PersonTableWindow.COLUMN_NAME[4]))
			p.setInfo( (String)value );
		//ˢ�±���
		table.refresh();
	}
	
}

/*
 * �޸���ʷ
 * $Log$ 
 */