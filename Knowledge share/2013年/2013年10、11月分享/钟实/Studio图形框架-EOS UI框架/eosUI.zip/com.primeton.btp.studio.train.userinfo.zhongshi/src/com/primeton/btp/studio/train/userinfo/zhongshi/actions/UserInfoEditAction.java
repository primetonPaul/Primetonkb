/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

import com.primeton.btp.studio.train.userinfo.zhongshi.Activator;
import com.primeton.btp.studio.train.userinfo.zhongshi.table.PersonTableWindow;

/**
 * �û���Ϣ�༭�˵�
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class UserInfoEditAction implements IWorkbenchWindowActionDelegate {

	private IWorkbenchWindow window;
	@Override
	public void run(IAction action) {
		String filePath = Activator.getDefault().getStateLocation()+"/person.xml";
//		try {
//			Person person = null;
//			if(persons.size()>0){
//				person = persons.get(0);
//			}
//			UserInfoDialog dialog = new UserInfoDialog(person);
//			person = dialog.open();
//			if(persons.size()>0){
//				persons.set(0, person);
//			}else{
//				persons.add(person);
//			}
//		
//		} catch (IOException e) {
//			MessageDialog.openError(window.getShell(), "����", "�ļ���дʧ��");
//		}
//		
		Shell shell = new Shell(Display.getDefault());
		PersonTableWindow tableWindow = new PersonTableWindow(shell, filePath);
		tableWindow.open();
		
//		PersonControlFactory controlFactory = new PersonControlFactory();
//		controlFactory.setValue(new Person());
//		Shell shell = new Shell(Display.getDefault());
//		ControlFactoryDialog dialog = new ControlFactoryDialog(shell, controlFactory);
//		dialog.open();
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		this.window = null;
	}

	@Override
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

}

/*
 * �޸���ʷ
 * $Log$ 
 */