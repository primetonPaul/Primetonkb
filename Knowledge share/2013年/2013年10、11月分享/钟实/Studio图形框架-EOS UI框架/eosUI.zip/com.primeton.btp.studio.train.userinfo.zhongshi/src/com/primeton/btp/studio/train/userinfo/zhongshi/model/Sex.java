/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��15��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.model;

/**
 * �Ա�ö����
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public enum Sex {
	
	MAlE,//����
	FEMALE;//Ů��
}

/*
 * �޸���ʷ
 * $Log$ 
 */