/*******************************************************************************
 * $Header$
 * $Revision$
 * $Date$
 *
 *==============================================================================
 *
 * Copyright (c) 2005-2015 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2013��10��16��
 *******************************************************************************/


package com.primeton.btp.studio.train.userinfo.zhongshi.dialog;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.btp.studio.train.userinfo.zhongshi.model.Hobby;
import com.primeton.btp.studio.train.userinfo.zhongshi.model.Person;
import com.primeton.btp.studio.train.userinfo.zhongshi.model.Sex;

/**
 * �û���Ϣ�༭��.
 *
 * @author zhongshi (mailto:zhongshi@primeton.com)
 */
public class UserInfoDialog {
	
	private Person person = new Person();
	
	private Label nameLabel;
	private Text nameText;
	private Label ageLabel;
	private Text ageText;
	private Label sexLabel;
	private Button maleRadio;
	private Button femaleRadio;
	private Label hobbyLabel;
	private Label infoLabel;
	private Text infoText;
	private Button saveButton;
	
	List<Button> hobbyChecks;
	
	
	
	/**
	 * 
	 */
	public UserInfoDialog(Person person) {
		if(person != null){
			this.person = person;
		}
	}

	public Person open(){
		Display display= Display.getDefault();
		final Shell shell = new Shell(display);
		shell.setSize(600,360);
		shell.setText("�û���Ϣ");
		shell.setLayout(new GridLayout(5, true));
		
		//������Ϣ�༭
		doCreateNameEditor(shell);
		//������Ϣ�༭
		doCreateAgeEditor(shell);
		//�Ա���Ϣ
		doCreateSexEditor(shell);
		//������Ϣ
		doCreateHobbyEditor(shell);
		//�����Ϣ
		doCreateInfoEditor(shell);
		//���水ť
		doCreateSaveButton(shell);
		//���ݳ�ʼ��
		initDate();
		
		//��Shell����
		shell.open();
		while(!shell.isDisposed()){
			if(!display.readAndDispatch()){
				display.sleep();
			}
		}
		return person;
	}

	/**
	 * 
	 */
	private void initDate() {
		if(person.getName() != null){
			nameText.setText(person.getName());
		}

		maleRadio.setSelection(true);
		if(Sex.FEMALE.equals(person.getSex())){
			femaleRadio.setSelection(true);
		}
		if(person.getHobbys()!=null){
			List<Hobby>hobbies = new ArrayList<Hobby>();
			for(Hobby hobby:person.getHobbys()){
				hobbies.add(hobby);
			}	
			for(int i=0 ;i<Hobby.values().length;i++){
				if(hobbies.contains(Hobby.values()[i])){
					hobbyChecks.get(i).setSelection(true);
				}
			}
		}
		if(person.getInfo()!=null){
			infoText.setText(person.getInfo());
		}
		
	}

	private void doCreateSaveButton(final Shell shell) {
		saveButton = new Button(shell,SWT.NONE);
		saveButton.setText("���");
		GridData saveData = new GridData(GridData.FILL_HORIZONTAL);
		saveData.horizontalSpan = 1;
		saveButton.setLayoutData(saveData);
		saveButton.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseUp(MouseEvent e) {
				
			}
			@Override
			public void mouseDown(MouseEvent e) {
				String name = nameText.getText();
				String age = ageText.getText();
				if(name.length() == 0||age.length() == 0){
					MessageDialog.openInformation(shell, "��ʾ", "���ֺ����䲻��Ϊ��.");
					return;
				}
				person.setName(name);
				person.setAge(Integer.parseInt(age));
				person.setSex(getSex());
				person.setHobbys(getHobbys());
				person.setInfo(infoText.getText());
				shell.dispose();
			}

			@Override
			public void mouseDoubleClick(MouseEvent e) {
				
			}
		});
	}

	private Hobby[] getHobbys() {
		List<Hobby> hobbies = new ArrayList<Hobby>();
		for(int i=0;i<hobbyChecks.size();i++){
			if(hobbyChecks.get(i).getSelection()){
				hobbies.add(Hobby.values()[i]);
			}
		}
		return hobbies.toArray(new Hobby[hobbies.size()]);
	}
	
	private Sex getSex() {
		if(femaleRadio.getSelection()){
			return Sex.FEMALE;
		}
		return Sex.MAlE;
	}
	
	private void doCreateInfoEditor(final Shell shell) {
		infoLabel = new Label(shell, SWT.NONE);
		infoLabel.setText("���:");
		infoLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		infoText = new Text(shell, SWT.MULTI | SWT.V_SCROLL | SWT.WRAP | SWT.BORDER);
		GridData infoData = new GridData(GridData.FILL_HORIZONTAL);
		infoData.horizontalSpan = 4;
		infoText.setLayoutData(infoData);
		
		//spaceLabel
		Label spaceLabel = new Label(shell, SWT.NONE);
		GridData spaceData = new GridData(GridData.FILL_HORIZONTAL);
		spaceData.horizontalSpan = 2;
		spaceLabel.setLayoutData(spaceData);
	}

	private void doCreateHobbyEditor(final Shell shell) {
		hobbyLabel = new Label(shell, SWT.NONE);
		hobbyLabel.setText("����:");
		hobbyLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		Group hobbyGroup = new Group(shell, SWT.NONE); 
		hobbyGroup.setLayout(new GridLayout(4, true));
		GridData hobbyData = new GridData(GridData.FILL_HORIZONTAL);
		hobbyData.horizontalSpan = 4;
		hobbyGroup.setLayoutData(hobbyData);
		Hobby[] values = Hobby.values();
		hobbyChecks = new ArrayList<Button>();
		for(int i = 0;i<values.length;i++){
			Hobby h = values[i];
			Button hobbyButton = new Button(hobbyGroup,SWT.CHECK);
			hobbyButton.setText(h.toString());
			GridData hobbyRadioData = new GridData(GridData.FILL_HORIZONTAL);
			hobbyRadioData.horizontalSpan = 1;
			hobbyButton.setLayoutData(hobbyRadioData);
			hobbyChecks.add(hobbyButton);
		}
	}

	private void doCreateSexEditor(final Shell shell) {
		sexLabel = new Label(shell, SWT.NONE);
		sexLabel.setText("�Ա�:");
		sexLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		maleRadio = new Button(shell,SWT.RADIO);
		maleRadio.setText("��");
		maleRadio.setSelection(true);
		GridData maleData = new GridData(GridData.FILL_HORIZONTAL);
		maleData.horizontalSpan = 1;
		maleRadio.setLayoutData(maleData);
		femaleRadio = new Button(shell,SWT.RADIO);
		femaleRadio.setText("Ů");
		GridData femaleData = new GridData(GridData.FILL_HORIZONTAL);
		femaleData.horizontalSpan = 1;
		femaleRadio.setLayoutData(femaleData);
		//spaceLabel
		Label spaceLabel = new Label(shell, SWT.NONE);
		GridData spaceData = new GridData(GridData.FILL_HORIZONTAL);
		spaceData.horizontalSpan = 2;
		spaceLabel.setLayoutData(spaceData);
	}

	private void doCreateAgeEditor(final Shell shell) {
		ageLabel = new Label(shell, SWT.NONE);
		ageLabel.setText("����:");
		ageLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		ageText = new Text(shell, SWT.BORDER);
		if(person.getAge() > 0){
			ageText.setText(String.valueOf(person.getAge()));
		}else{
			ageText.setText("0");
		}
		GridData ageData = new GridData(GridData.FILL_HORIZONTAL);
		ageData.horizontalSpan = 4;
		ageText.setLayoutData(ageData);
		ageText.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent vEvent) {
				vEvent.doit = false; // don't allow anything but numbers
				if (Character.isDigit(vEvent.character) || vEvent.character == '\b') {
					vEvent.doit = true;
				}
			}
		});
	}

	private void doCreateNameEditor(final Shell shell) {
		nameLabel = new Label(shell, SWT.NONE);
		nameLabel.setText("����:");
		nameLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		nameText = new Text(shell, SWT.BORDER);
		GridData nameData = new GridData(GridData.FILL_HORIZONTAL);
		nameData.horizontalSpan = 4;
		nameText.setLayoutData(nameData);
	}
	
}

/*
 * �޸���ʷ
 * $Log$ 
 */