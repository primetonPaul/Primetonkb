/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.base;

import java.util.List;

import com.primeton.studio.core.CoreMessages;
import com.primeton.studio.core.IObjectTranslator;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.impl.PropertyIntrospector;
import com.primeton.studio.core.tree.ITreeNode;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ���ڴ���JavaBean��IObjectTranslator����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The base class to handle java bean. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2007-3-1 ����05:56:50
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: AbstractPropertyTranslator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/12/13 05:20:30  yuhl
 * Update:���ʻ�
 *
 * Revision 1.1  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractPropertyTranslator implements IObjectTranslator
{
	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 * 
	 */
	public AbstractPropertyTranslator()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IObjectTranslator#getIntrospector()
	 */
	public Introspector getIntrospector()
	{
		return new PropertyIntrospector();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IObjectTranslator#fromProperties(java.lang.String, java.lang.Object,
	 *      java.lang.Object)
	 */
	public void fromProperties(String r_Type, Object r_Moel, Object r_Value)
	{
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IObjectTranslator#fromTable(java.lang.String, java.lang.Object, java.util.List)
	 */
	public void fromTable(String r_Type, Object r_Moel, List r_Values)
	{
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IObjectTranslator#fromTree(java.lang.String, java.lang.Object,
	 *      com.primeton.studio.core.tree.ITreeNode)
	 */
	public void fromTree(String r_Type, Object r_Moel, ITreeNode r_Node)
	{
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IObjectTranslator#toProperties(java.lang.String, java.lang.Object)
	 */
	public Object toProperties(String r_Type, Object r_Moel)
	{
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IObjectTranslator#toTable(java.lang.String, java.lang.Object)
	 */
	public List toTable(String r_Type, Object r_Moel)
	{
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IObjectTranslator#toTree(java.lang.String, java.lang.Object)
	 */
	public ITreeNode toTree(String r_Type, Object r_Moel)
	{
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

}
