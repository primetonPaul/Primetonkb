/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/platform/service/IServiceManager.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-12-21
 *******************************************************************************/


package com.primeton.platform.service;

import java.util.Map;

import com.primeton.platform.service.spi.IServiceProvider;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IServiceManager.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 */
public interface IServiceManager extends IServiceProvider{

	/**
	 * ����һ����������á�<BR>
	 *
	 * Create a service reference.<BR>
	 *
	 * @param serviceProvider
	 * @param serviceDeclaration
	 * @param serviceImplementation
	 * @param version
	 * @param properties
	 * @return
	 */
	public IServiceReference createServiceReference(IServiceProvider serviceProvider, String serviceDeclaration, Object serviceImplementation,Version version,Map properties);

}
