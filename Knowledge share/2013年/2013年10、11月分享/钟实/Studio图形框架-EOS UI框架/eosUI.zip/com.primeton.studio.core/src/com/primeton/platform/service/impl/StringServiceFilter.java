/**
 *
 */
package com.primeton.platform.service.impl;

import org.apache.commons.lang.StringUtils;

import com.eos.system.utility.StringUtil;
import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.spi.IServiceFilter;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����ַ�����ָ����ʵ����������ƥ��<BR>
 *
 * <strong>English Doc��</strong><BR>
 * To filter the service with the specified card name.<BR>
 *
 * Created Time: 2009-8-28 ����04:22:43
 * @author @author wanglei (mailto:wanglei@primeton.com)
 *
 */
/*
 * Update History
 *
 * $Log: StringServiceFilter.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:22  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 *
 */
public class StringServiceFilter implements IServiceFilter {

	private String card;

	/**
	 * @param card
	 */
	public StringServiceFilter(String card) {
		this.card = card;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isAcceptable(IServiceReference serviceReference) {
		if (StringUtils.isEmpty(this.card)) {
			return true;
		}

		String implementation = serviceReference.getServiceImplementation();
		return StringUtil.isWildcardMatch(implementation, this.card, true);
	}
}
