/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */
package com.primeton.studio.core.impl.validator.compound;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.eclipse.core.runtime.IAdapterFactory;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValidator;

/**
 * 
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����֤�������԰��������֤���� <BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The compound validator which contains many validators. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 13:24:22
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: AbstractCompoundValidator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractCompoundValidator implements IValidator
{
	private Set validators = new HashSet();

	// Using Set to avoid repeatition.

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public AbstractCompoundValidator()
	{
		super();
	}

	/**
	 * ����һ����֤����<BR>
	 * 
	 * Add a validator.<BR>
	 * 
	 * @param r_Validator
	 *            It should be <code>null</code>,if the value is <code>null</code>��it will be ignored.<BR>
	 */
	public void doAddValidator(final IValidator r_Validator)
	{
		if (null != r_Validator)
		{
			this.validators.add(r_Validator);
		}
	}

	/**
	 * �Ƴ�һ����֤����<BR>
	 * 
	 * Remove a validator.<BR>
	 * 
	 * @param r_Validator
	 *            It should be <code>null</code>,if the value is <code>null</code>��it will be ignored.<BR>
	 */
	public void doRemoveValidator(final IValidator r_Validator)
	{
		if (null != r_Validator)
		{
			this.validators.remove(r_Validator);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IValidator#validate(java.lang.Object, com.primeton.studio.core.IAdapterFactory,
	 *      com.primeton.studio.core.IMessageCaller)
	 */
	public boolean validate(Object r_Value, IAdapterFactory r_AdapterFactory, IMessageCaller r_MessageCaller)
	{
		if (this.getValidators().isEmpty())
		{
			return true;
		}

		return this.doValidate(r_Value, r_AdapterFactory, r_MessageCaller);
	}

	/**
	 * ������ʵ�ָ÷���������ʵ��������֤��<BR>
	 * 
	 * The derived classes implement this method to do validation.<BR>
	 * 
	 * @param r_Value
	 *            the value for being validated.
	 * @param r_AdapterFactory
	 *            sometime,the parameter of "r_Value" may be not a string or other simple objects.<BR>
	 *            So a adapter factory is needed to convert the value to another type for being validated.
	 * @param r_MessageCaller
	 *            the shower for message.
	 * 
	 * @return
	 */
	public abstract boolean doValidate(Object r_Value, IAdapterFactory r_AdapterFactory, IMessageCaller r_MessageCaller);

	/**
	 * �������е���֤����<BR>
	 * 
	 * Return all the validators.<BR>
	 * 
	 */
	protected Set getValidators()
	{
		return this.validators;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	public final Object clone() throws com.primeton.studio.core.exception.CloneNotSupportedException
	{
		AbstractCompoundValidator t_CompoundValidator;
		try
		{
			t_CompoundValidator = this.cloneSelf();
		}
		catch (Exception e)
		{
			throw new com.primeton.studio.core.exception.CloneNotSupportedException(e);
		}

		for (final Iterator t_Iterator = this.validators.iterator(); t_Iterator.hasNext();)
		{
			final IValidator t_Validator = (IValidator) t_Iterator.next();
			t_CompoundValidator.doAddValidator((IValidator) t_Validator.clone());
		}

		return t_CompoundValidator;
	}

	/**
	 * �����෵�ص�ǰ�����ʵ����<BR>
	 * 
	 * The derived class clone a new instance.<BR>
	 * 
	 * @return
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	protected AbstractCompoundValidator cloneSelf() throws InstantiationException, IllegalAccessException
	{
		return (AbstractCompoundValidator) this.getClass().newInstance();
	}
}
