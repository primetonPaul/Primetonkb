/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/util/FileSystemHelper.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-4-7
 *******************************************************************************/


package com.primeton.studio.core.util;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yourname (mailto:yourname@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: FileSystemHelper.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/07 12:41:07  yanfei
 * updata:����FileSystemHelper����ļ�ϵͳ�����ࡣ
 *
 */
public class FileSystemHelper {
	static {
        System.loadLibrary("FileSystemHelper");
    }
	public native String getFileSystem(String s);
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FileSystemHelper helper = new FileSystemHelper();
		String type = helper.getFileSystem("c:\\");
		System.out.println(type);
	}

}
