/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/exception/XmlUtilException.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2006-10-30
 *******************************************************************************/


package com.primeton.studio.core.exception;

/**
 * XmlUtil����xml�ļ����쳣��
 *
 * @author niegy (mailto:niegy@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: XmlUtilException.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/06/21 14:02:07  wanglei
 * Review:ԭ����û��ע�ͺ����л���־��
 *
 * Revision 1.1  2007/04/08 07:10:29  yangjun
 * add:�ύ��CVS
 *
 */
public class XmlUtilException extends RuntimeException {
	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public XmlUtilException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public XmlUtilException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public XmlUtilException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public XmlUtilException(Throwable cause) {
		super(cause);
	}
}
