/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/impl/validator/ResourcePathValidator.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2007-3-29
 *******************************************************************************/


package com.primeton.studio.core.impl.validator;

import java.io.File;

import org.eclipse.core.runtime.IAdapterFactory;

import com.primeton.studio.core.IMessageCaller;

/**
 * ��֤��Դ·��
 * ·����ָ����ļ����ļ��д���ʱ,����true;����,����false
 *
 * @author yangjun (mailto:yangjun@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ResourcePathValidator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/29 10:11:06  yangjun
 * Add:������Դ·����֤��
 * 
 */
public class ResourcePathValidator extends AbstractValidator
{

	/**
	 * ������
	 */
	public ResourcePathValidator()
	{
		super();		
	}

	/**
	 * ������
	 * @param message ��ʾ��Ϣ
	 */
	public ResourcePathValidator(String message)
	{
		super(message);
	}

	/**
	 * �жϲ���value�����·���Ƿ�Ϊ�ļ���Դ
	 * @param value �ļ�·��
	 * @param adapterFactory
	 * @param messageCaller
	 * @return ���ļ���Դ?true:false
	 */
	protected boolean doValidate(Object value, IAdapterFactory adapterFactory, IMessageCaller messageCaller)
	{		
		if (value instanceof String)
		{			
			String path = (String)value;				
			File file = new File(path);
			if (file.isDirectory() || file.isFile())
			{
				return true;
			}
			else
				return false;			
		}
		else 
			return false;		
	}

}
