/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.model.impl;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;

import com.primeton.studio.core.model.IDataProvider;
import com.primeton.studio.core.util.entry.MapEntry;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * Ϊ��ҪList��Editor�ṩ����<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Provide list for some property editor which need list.<BR>
 * <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 13:12:53
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: MapProvider.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public class MapProvider implements IDataProvider
{
	private List values = new ArrayList();

	/**
	 * ������XML�������л�ʹ��<BR>
	 * 
	 * This method is used for the xml Serialization.<BR>
	 * 
	 */
	protected MapProvider()
	{
		super();
	}

	/**
	 * ֱ��ͨ���������������<BR>
	 * 
	 * Construct a object by the parameter.<BR>
	 * 
	 * @param r_Values
	 *            the parameter should be a list of MapEntry.<BR>
	 * 
	 * @see org.aquarius.util.entry.MapEntry
	 */
	public MapProvider(List r_Values)
	{
		super();
		this.values = r_Values;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.aquarius.ui.editor.IDataProvider#getKeys()
	 */
	public String[] getKeys()
	{
		String[] t_Keys = new String[this.values.size()];

		for (int i = 0; i < t_Keys.length; i++)
		{
			MapEntry t_Entry = (MapEntry) this.values.get(i);
			t_Keys[i] = (String) t_Entry.getKey();
		}

		return t_Keys;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.aquarius.ui.editor.IDataProvider#getKey(java.lang.Object)
	 */
	public String getKey(Object r_Value)
	{
		for (int i = 0; i < this.values.size(); i++)
		{
			MapEntry t_Entry = (MapEntry) this.values.get(i);

			if (t_Entry.getValue().equals(r_Value))
			{
				return (String) t_Entry.getKey();
			}
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.aquarius.ui.editor.IDataProvider#getValue(java.lang.String)
	 */
	public Object getValue(String r_Key)
	{
		for (int i = 0; i < this.values.size(); i++)
		{
			MapEntry t_Entry = (MapEntry) this.values.get(i);

			if (t_Entry.getKey().equals(r_Key))
			{
				return t_Entry.getValue();
			}
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	public Object clone()
	{
		MapProvider t_List = new MapProvider();

		t_List.values = new ArrayList();
		if (null != this.values)
		{
			for (int i = 0; i < this.values.size(); i++)
			{
				MapEntry t_Entry = (MapEntry) this.values.get(i);
				t_List.values.add(t_Entry.clone());
			}
		}

		return t_List;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.aquarius.ui.editor.IDataProvider#build(com.primeton.studio.core.IAdapter)
	 */
	public void build(IAdaptable r_Adaptable)
	{
		// Nothing to do
	}

	/**
	 * �������ݡ�<BR>
	 * 
	 * Return the values.<BR>
	 * 
	 * @return Returns the values.
	 */
	public final List getValues()
	{
		return this.values;
	}

	/**
	 * �������ݡ�<BR>
	 * 
	 * Set the values.<BR>
	 * 
	 * @param r_Values
	 *            the parameter should be a list of MapEntry.<BR>
	 * 
	 * @see org.aquarius.util.entry.MapEntry
	 */
	public final void setValues(List r_Values)
	{
		this.values = r_Values;
	}

}
