/**
 *
 */
package com.primeton.platform.service.internal;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;

import com.eos.system.utility.Assert;
import com.primeton.platform.service.IServiceManager;
import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.ServiceContext;
import com.primeton.platform.service.Version;
import com.primeton.platform.service.spi.IServiceFactory;

/**
 *
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����ͨ���������ʹ��ͨ����չ��ע��ķ���<BR>
 *
 * <strong>English Doc��</strong><BR>
 * The service factory is used to crate the service injected by the extension.<BR>
 *
 * Created Time: 2009-8-14 ����02:44:31
 * @author @author wanglei (mailto:wanglei@primeton.com)
 *
 */
/*
 * Update History
 *
 * $Log: ExtensionServiceFactory.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 *
 */
class ExtensionServiceFactory implements IServiceFactory {

	private boolean isSingle;

	private IConfigurationElement configurationNode;

	private Object service;

	private IServiceReference serviceReference;

	/**
	 *
	 */
	ExtensionServiceFactory(IConfigurationElement configurationNode) {

		Assert.notNull(configurationNode, "the configuration node should not be empty.");
		this.configurationNode = configurationNode;
		this.isSingle = Boolean.valueOf(this.configurationNode.getAttribute("single")).booleanValue();

	}

	void load(IServiceManager serviceManager) {

		Map map = new HashMap();

		IConfigurationElement[] childNodes = configurationNode.getChildren();
		if (null != childNodes && childNodes.length > 0) {
			for (int i = 0; i < childNodes.length; i++) {
				IConfigurationElement childNode = childNodes[i];
				String key = childNode.getAttribute(ExtensionServiceProvider.KEY);
				String value = childNode.getAttribute(ExtensionServiceProvider.VALUE);
				map.put(key, value);
			}
		}

		Version version = Version.parseVersion(configurationNode.getAttribute(Version.VERSION));
		this.serviceReference = serviceManager.createServiceReference(ExtensionServiceProvider.getInstance(), getServiceImplementationClass(), this, version, map);
	}

	/**
	 * @return the serviceReference
	 */
	public IServiceReference getServiceReference() {
		return serviceReference;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getServiceImplementationClass() {
		return this.configurationNode.getAttribute(ExtensionServiceProvider.IMPLEMENTATION);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized Object createService(ServiceContext context) {

		Object object;
		try {
			object = doCreateService();

			if (object instanceof IServiceFactory) {
				IServiceFactory serviceFactory = (IServiceFactory) object;
				return serviceFactory.createService(context);
			} else {
				return object;
			}
		} catch (CoreException e) {
			return null;
		}

	}

	private Object doCreateService() throws CoreException {
		if (this.isSingle) {
			if (null == service) {
				this.service = configurationNode.createExecutableExtension(ExtensionServiceProvider.IMPLEMENTATION);
			}
			return this.service;
		} else {
			return configurationNode.createExecutableExtension(ExtensionServiceProvider.IMPLEMENTATION);
		}
	}
}
