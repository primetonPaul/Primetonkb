/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/log/TraceLogger.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-4-11
 *******************************************************************************/

package com.primeton.studio.core.log;

import org.apache.commons.lang.StringUtils;

import com.eos.system.logging.Logger;
import com.primeton.studio.core.base.AbstractAdaptableObject;

/**
 * ��¼��־��,.
 *
 * @author jiaoly (mailto:jiaoly@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: TraceLogger.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.12  2007/12/18 07:03:49  wanglei
 * Review:����hashCode��equals������������getAdapterʵ�֡�
 *
 * Revision 1.11  2007/12/18 06:36:19  wanglei
 * Review:����EOC�ĵ��������޸ġ�
 *
 * Revision 1.10  2007/12/18 02:23:15  wanglei
 * Review:��EOC���ɡ�
 *
 * Revision 1.9  2007/09/17 02:09:01  wanglei
 * Review:Server�����ع������µ����������ݡ�
 *
 * Revision 1.8  2007/08/09 05:22:10  yangjun
 * Update:��дequals,hashcode����
 *
 * Revision 1.7  2007/05/23 06:32:46  jiaoly
 * UnitTest��Server�޸Ľӿ�
 *
 * Revision 1.6  2007/05/12 07:53:10  jiaoly
 * Update���޸ĳ�����ʹ�� Server ���ṩ�Ľӿ�
 *
 * Revision 1.5  2007/04/24 02:39:54  yangjun
 * Add:�ύ��CVS
 *
 * Revision 1.1  2007/04/20 10:15:52  yangjun
 * Add: �ύ��CVS
 *
 */
public class TraceLogger extends AbstractAdaptableObject {

	/** The product id. */
	String productID = "";

	/** The plugin name. */
	String pluginName = "";

	/** The class name. */
	String className = "";

	/** The logger. */
	Logger logger = null;

	/** The format plugin name. */
	String formatPluginName = "";

	/** The format product id. */
	String formatProductID = "";

	/**
	 * Instantiates a new trace logger.
	 *
	 * @param productID the product id
	 * @param pluginName the plugin name
	 * @param className the class name
	 */
	TraceLogger(Logger logger, String productID, String pluginName, String className) {
		this.productID = productID;
		this.pluginName = pluginName;
		this.className = className;
		this.logger = logger;
		this.formatPluginName = ILogConstants.BUNDLE_PIX.concat(pluginName) + ">";
		this.formatProductID = ILogConstants.PRODUCT_PIX.concat(productID) + ">";
	}

	/**
	 * Checks if is debug enabled.
	 *
	 * @return true, if is debug enabled
	 */
	public boolean isDebugEnabled() {
		return this.logger.isDebugEnabled();
	}

	/**
	 * Debug.
	 *
	 * @param message the message
	 */
	public void debug(String message) {
		this.logger.debug(this.formatMessage(message));
	}

	/**
	 * Debug.
	 *
	 * @param message the message
	 * @param t the t
	 */
	public void debug(String message, Throwable t) {
		this.logger.debug(this.formatMessage(message), t);
	}

	/**
	 * Checks if is info enabled.
	 *
	 * @return true, if is info enabled
	 */
	public boolean isInfoEnabled() {
		return this.logger.isInfoEnabled();
	}

	/**
	 * Info.
	 *
	 * @param message the message
	 */
	public void info(String message) {
		this.logger.info(this.formatMessage(message));
	}

	/**
	 * Info.
	 *
	 * @param message the message
	 * @param t the t
	 */
	public void info(String message, Throwable t) {
		this.logger.info(this.formatMessage(message), t);
	}

	/**
	 * Checks if is warn enabled.
	 *
	 * @return true, if is warn enabled
	 */
	public boolean isWarnEnabled() {
		return this.logger.isWarnEnabled();
	}

	/**
	 * Warn.
	 *
	 * @param message the message
	 */
	public void warn(String message) {
		this.logger.warn(this.formatMessage(message));
	}

	/**
	 * Warn.
	 *
	 * @param message the message
	 * @param t the t
	 */
	public void warn(String message, Throwable t) {
		this.logger.warn(this.formatMessage(message), t);
	}

	/**
	 * Warn.
	 *
	 * @param t the t
	 */
	public void warn(Throwable t) {
		this.warn(this.formatMessage(null), t);
	}

	/**
	 * Checks if is error enabled.
	 *
	 * @return true, if is error enabled
	 */
	public boolean isErrorEnabled() {
		return this.logger.isErrorEnabled();
	}

	/**
	 * Error.
	 *
	 * @param message the message
	 */
	public void error(String message) {
		this.logger.error(this.formatMessage(message));
	}

	/**
	 * Error.
	 *
	 * @param message the message
	 * @param t the t
	 */
	public void error(String message, Throwable t) {
		this.logger.error(this.formatMessage(message), t);
	}

	/**
	 * Error.
	 *
	 * @param t the t
	 */
	public void error(Throwable t) {
		this.logger.error(t);
	}

	/**
	 * Checks if is fatal enabled.
	 *
	 * @return true, if is fatal enabled
	 */
	public boolean isFatalEnabled() {
		return this.logger.isFatalEnabled();
	}

	/**
	 * Fatal.
	 *
	 * @param message the message
	 */
	public void fatal(String message) {
		this.logger.fatal(this.formatMessage(message));
	}

	/**
	 * Fatal.
	 *
	 * @param message the message
	 * @param t the t
	 */
	public void fatal(String message, Throwable t) {
		this.logger.fatal(this.formatMessage(message), t);
	}

	/**
	 * Fatal.
	 *
	 * @param t the t
	 */
	public void fatal(Throwable t) {
		this.fatal(this.formatMessage(null), t);
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	public String getClassName() {
		return this.className;
	}

	/**
	 * Gets the plugin name.
	 *
	 * @return the plugin name
	 */
	public String getPluginName() {
		return this.pluginName;
	}

	/**
	 * Gets the product id.
	 *
	 * @return the product id
	 */
	public String getProductId() {
		return this.productID;
	}

	/**
	 * Format message.
	 *
	 * @param message the message
	 *
	 * @return the string
	 */
	private String formatMessage(String message) {
		if (message == null) {
			return this.formatPluginName;
		}
		else {
			return this.formatPluginName.concat(message);
		}
	}

	/**
	 *
	 * @return
	 */
	public String getLevel() {
		return this.logger.getEffectiveLevel().toString();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.className == null) ? 0 : this.className.hashCode());
		result = PRIME * result + ((this.formatPluginName == null) ? 0 : this.formatPluginName.hashCode());
		result = PRIME * result + ((this.formatProductID == null) ? 0 : this.formatProductID.hashCode());
		result = PRIME * result + ((this.pluginName == null) ? 0 : this.pluginName.hashCode());
		result = PRIME * result + ((this.productID == null) ? 0 : this.productID.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final TraceLogger other = (TraceLogger) obj;
		if (!StringUtils.equals(this.className, other.className)) {
			return false;
		}

		if (!StringUtils.equals(this.formatPluginName, other.formatPluginName)) {
			return false;
		}

		if (!StringUtils.equals(this.formatProductID, other.formatProductID)) {
			return false;
		}

		if (!StringUtils.equals(this.pluginName, other.pluginName)) {
			return false;
		}

		return StringUtils.equals(this.productID, other.productID);
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getAdapter(Class adapter) {

		if (adapter == Logger.class) {
			return this.logger;
		}
		else {
			return super.getAdapter(adapter);
		}
	}
}
