/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/impl/validator/AbstractWrapperValidator.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-4-15
 *******************************************************************************/


package com.primeton.studio.core.impl.validator;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdapterFactory;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValidator;

/**
 * ��װУ����
 *
 * @author ������ (mailto:yujl@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: AbstractWrapperValidator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/04/16 01:46:17  yujl
 * update:������ʾ
 *
 * Revision 1.2  2008/04/15 08:41:46  yujl
 * update:ɾ���������Ĺ�����
 *
 * Revision 1.1  2008/04/15 08:36:50  yujl
 * update:���Ӱ�װ��֤��
 * 
 */
public abstract class AbstractWrapperValidator extends AbstractValidator {
	
	private List<IValidator> beforeValidators = new ArrayList<IValidator>();
	private List<IValidator> afterValidators = new ArrayList<IValidator>();
	
	/**
	 * Ĭ�Ϲ�����
	 *
	 */
	public AbstractWrapperValidator(){		
	}
	
	/**
	 * @param beforeValidator
	 * @param afterValidator
	 */
	public AbstractWrapperValidator(IValidator beforeValidator,IValidator afterValidator){
		addBeforeValidator(beforeValidator);
		addAfterValidator(afterValidator);
	}
	
	/**
	 * @param beforeValidators
	 * @param afterValidators
	 */
	public AbstractWrapperValidator(IValidator[] beforeValidators,IValidator[] afterValidators){		
		addBeforeValidators(beforeValidators);
		addAfterValidators(afterValidators);
	}
	
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.core.impl.validator.AbstractValidator#doValidate(java.lang.Object, org.eclipse.core.runtime.IAdapterFactory, com.primeton.studio.core.IMessageCaller)
	 */
	@Override
	protected boolean doValidate(Object r_Value,IAdapterFactory r_AdapterFactory, IMessageCaller r_MessageCaller) {
		boolean flag = doListValidate(beforeValidators, r_Value, r_AdapterFactory, r_MessageCaller);
		if(flag){
			flag = currentValidate(r_Value, r_AdapterFactory, r_MessageCaller);
		}
		if(flag){
			flag = doListValidate(afterValidators, r_Value, r_AdapterFactory, r_MessageCaller);
		}		
		return flag;
	}
	
	/**
	 * �����б�������֤
	 * @param r_Validators
	 * @param r_Value
	 * @param r_AdapterFactory
	 * @param r_MessageCaller
	 * @return
	 */
	private boolean doListValidate(List<IValidator> r_Validators,Object r_Value,IAdapterFactory r_AdapterFactory, IMessageCaller r_MessageCaller){
		if(!r_Validators.isEmpty()){
			for (IValidator validator : r_Validators) {
				if(!validator.validate(r_Value, r_AdapterFactory, r_MessageCaller)){
					if(validator instanceof AbstractValidator){
						this.setMessage(((AbstractValidator)validator).getMessage());
					}
					return false;
				}
			}
		}
		return true;
	}
	
	
	/**
	 * ��ǰ��֤��ִ�е���֤
	 * @param value
	 * @param adapterFactory
	 * @param messageCaller
	 */
	abstract protected boolean currentValidate(Object value, IAdapterFactory adapterFactory, IMessageCaller messageCaller);


	/**
	 * ���ӵ�ǰ��֤����ǰ����֤
	 * @param beforeValidator
	 */
	public void addBeforeValidator(IValidator beforeValidator){
		if(beforeValidator != null && !beforeValidators.contains(beforeValidator)){
			beforeValidators.add(beforeValidator);
		}
	}
	
	/**
	 * ���ӵ�ǰ��֤���������֤
	 * @param afterValidator
	 */
	public void addAfterValidator(IValidator afterValidator){
		if(afterValidator != null && !afterValidators.contains(afterValidator)){
			afterValidators.add(afterValidator);
		}
	}
	/**
	 * ���ӵ�ǰ��֤����ǰ����֤
	 * @param beforeValidators
	 */
	public void addBeforeValidators(IValidator[] beforeValidators){
		if(beforeValidators == null){
			return;
		}
		for (IValidator validator : beforeValidators) {
			addBeforeValidator(validator);
		}
	}
	
	/**
	 * ���ӵ�ǰ��֤���������֤
	 * @param afterValidators
	 */
	public void addAfterValidators(IValidator[] afterValidators){
		if(afterValidators == null){
			return;
		}
		for (IValidator validator : afterValidators) {
			addAfterValidator(validator);
		}
	}
	
	/**
	 * ������֤
	 * @param afterValidators
	 * @param isBeforeValidator
	 */
	public void addValidator(IValidator validator,boolean isBeforeValidator){
		if(isBeforeValidator){
			addBeforeValidator(validator);
		}else{
			addAfterValidator(validator);
		}		
	}
	
	/**
	 * �ж���֤ǰ����֤�б�����֤����б����Ƿ��е�ǰ��֤��
	 * @param validator
	 */
	public void removeValidator(IValidator validator){
		if(beforeValidators.contains(validator)){
			beforeValidators.remove(validator);
		}
		if(afterValidators.contains(validator)){
			afterValidators.remove(validator);
		}
	}
	
	/**
	 * ���ǰ�����б�
	 *
	 */
	public void clearBeforeValidators(){
		beforeValidators.clear();
	}
	
	/**
	 * ��պ�����б�
	 *
	 */
	public void clearAfterValidators(){
		afterValidators.clear();
	}
}
