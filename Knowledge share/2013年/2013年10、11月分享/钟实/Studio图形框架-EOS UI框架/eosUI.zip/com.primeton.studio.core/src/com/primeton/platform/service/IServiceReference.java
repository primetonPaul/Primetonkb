/**
 * 
 */
package com.primeton.platform.service;

import com.primeton.platform.service.spi.IServiceProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �������á�<BR>
 *
 * <strong>English Doc��</strong><BR>
 * Service Reference.<BR>
 * 
 * Created Time: 2009-8-28 ����01:27:44
 * @author @author wanglei (mailto:wanglei@primeton.com)
 * 
 */
/*
 * Update History
 *
 * $Log: IServiceReference.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 * 
 */
public interface IServiceReference {

	/**
	 * Returns the property value to which the specified property key is mapped
	 * in the properties <code>Dictionary</code> object of the service
	 * referenced by this <code>ServiceReference</code> object.
	 * 
	 * <p>
	 * Property keys are case-insensitive.
	 * 
	 * <p>
	 * This method must continue to return property values after the service has
	 * been unregistered. This is so references to unregistered services (for
	 * example, <code>ServiceReference</code> objects stored in the log) can
	 * still be interrogated.
	 * 
	 * @param key The property key.
	 * @return The property value to which the key is mapped; <code>null</code>
	 *         if there is no property named after the key.
	 */
	public Object getProperty(String key);

	/**
	 * �õ���Ӧ�ķ���ʵ�֡�<BR>
	 * 
	 * Return the implementation object for the declared service.
	 * 
	 * @param serviceContext
	 * 
	 * @return
	 */
	public Object getServiceObject(ServiceContext serviceContext);

	/**
	 * �õ������ķ������ơ�<BR>
	 * 
	 * Return the name of the declared service .<BR>
	 * 
	 * @return
	 */
	public String getServiceDeclaration();

	/**
	 * �õ�ʵ�ֵķ������ơ�<BR>
	 * ������ IServiceFactory�����࣬������������ʵ�������ơ�<BR>
	 * 
	 * Return the name of the declared service .<BR>
	 * The return value can be the subclass of IServiceFactory instead of the real class.<BR>
	 * 
	 * @see com.primeton.platform.service.spi#IServiceFactory
	 * 
	 * @return
	 */
	public String getServiceImplementation();

	/**
	 * �õ��ṩ������ࡣ<BR>
	 * 
	 * Return the service provider for the implementation.<BR>
	 * 
	 * @return
	 */
	public IServiceProvider getServiceProvider();

	/**
	 * Returns an array of the keys in the properties <code>Dictionary</code>
	 * object of the service referenced by this <code>ServiceReference</code>
	 * object.
	 * 
	 * <p>
	 * This method will continue to return the keys after the service has been
	 * unregistered. This is so references to unregistered services (for
	 * example, <code>ServiceReference</code> objects stored in the log) can
	 * still be interrogated.
	 * 
	 * <p>
	 * This method is <i>case-preserving </i>; this means that every key in the
	 * returned array must have the same case as the corresponding key in the
	 * properties <code>Dictionary</code> that was passed to the
	 * {@link BundleContext#registerService(String[],Object,java.util.Dictionary)}
	 * or {@link ServiceRegistration#setProperties} methods.
	 * 
	 * @return An array of property keys.
	 */
	public String[] getPropertyKeys();
	
	/**
	 * 
	 * @return
	 */
	public Version getVersion();
}
