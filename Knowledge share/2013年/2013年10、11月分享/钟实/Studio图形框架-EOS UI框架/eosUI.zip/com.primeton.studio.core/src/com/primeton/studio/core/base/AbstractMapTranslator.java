/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.eos.system.utility.CollectionUtil;
import com.primeton.studio.core.CoreMessages;
import com.primeton.studio.core.IObjectTranslator;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.impl.MapIntrospector;
import com.primeton.studio.core.tree.ITreeNode;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ���ڴ���Map��IObjectTranslator����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The base class to handle jmap. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-3-1 ����05:56:50
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractMapTranslator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2007/12/19 01:14:35  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.5  2007/12/13 05:20:30  yuhl
 * Update:���ʻ�
 *
 * Revision 1.4  2007/11/01 03:08:06  wanglei
 * Review:�������Ƶ�CollectionUtil�С�
 *
 * Revision 1.3  2007/03/20 06:14:43  wanglei
 * Update:����һ��Ψһ��ʶ��Map������ʹ�á�
 * Revision 1.2 2007/03/09 01:24:49 lvyuan �ṩnewObject��Ĭ��ʵ��
 *
 * Revision 1.1 2007/03/05 06:01:56 wanglei �ύ��CVS
 *
 */

public abstract class AbstractMapTranslator implements IObjectTranslator {
	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractMapTranslator() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#getIntrospector()
	 */
	public Introspector getIntrospector() {
		return new MapIntrospector();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#fromProperties(java.lang.String, java.lang.Object,
	 *      java.lang.Object)
	 */
	public void fromProperties(String r_Type, Object r_Moel, Object r_Value) {
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#fromTable(java.lang.String, java.lang.Object, java.util.List)
	 */
	public void fromTable(String r_Type, Object r_Moel, List r_Values) {
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#fromTree(java.lang.String, java.lang.Object,
	 *      com.primeton.studio.core.tree.ITreeNode)
	 */
	public void fromTree(String r_Type, Object r_Moel, ITreeNode r_Node) {
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#toProperties(java.lang.String, java.lang.Object)
	 */
	public Object toProperties(String r_Type, Object r_Moel) {
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#toTable(java.lang.String, java.lang.Object)
	 */
	public List toTable(String r_Type, Object r_Moel) {
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#toTree(java.lang.String, java.lang.Object)
	 */
	public ITreeNode toTree(String r_Type, Object r_Moel) {
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IObjectTranslator#newObject(java.lang.Object, java.lang.String)
	 */
	public Object newObject(Object r_Moel, String r_Type) {
		throw new UnsupportedOperationException(CoreMessages.AbstractPropertyTranslator_NO_OVERRID_METHOD);
	}

	/**
	 * ����һ��Ψһ��ʶ��Map������ʹ�á�<BR>
	 *
	 * Create a identity map for the derived classes.<BR>
	 *
	 * @return
	 */
	public Map newMap() {
		return CollectionUtil.newIdentityMap();
	}
}
