/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.base;

import com.primeton.studio.core.IDescription;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * "IDescription"�ĳ���ʵ�֡�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The abstract class for "IDescription". <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 11:20:30
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: AbstractDescription.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractDescription implements IDescription
{

	// the following field just the values for property.

	private String title;

	private String description;

	private String smallImage;

	private String largeImage;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public AbstractDescription()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IDescription#getTitle()
	 */
	public String getTitle()
	{
		if (null == this.title)
		{
			return "";
		}
		return this.title;
	}

	/**
	 * ���ñ��⡣<BR>
	 * 
	 * Set the title.<BR>
	 * 
	 * @param r_Title
	 *            the title to set
	 */
	public void setTitle(final String r_Title)
	{
		this.title = r_Title;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IDescription#getSmallImage()
	 */
	public String getSmallImage()
	{
		return this.smallImage;
	}

	/**
	 * ����СͼƬ�ĵ�ַ��<BR>
	 * 
	 * Set the small image url.<BR>
	 * 
	 * @param r_SmallImage
	 *            the smallImage to set
	 */
	public void setSmallImage(final String r_SmallImage)
	{
		this.smallImage = r_SmallImage;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IDescription#getLargeImage()
	 */
	public String getLargeImage()
	{
		return this.largeImage;
	}

	/**
	 * ���ô�ͼƬ�ĵ�ַ��<BR>
	 * 
	 * Set the large image url.<BR>
	 * 
	 * @param r_LargeImage
	 *            the largeImage to set
	 */
	public void setLargeImage(final String r_LargeImage)
	{
		this.largeImage = r_LargeImage;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IDescription#getDescription()
	 */
	public String getDescription()
	{
		if (null == this.description)
		{
			return "";
		}
		return this.description;
	}

	/**
	 * ����˵����<BR>
	 * 
	 * Set the description.<BR>
	 * 
	 * @param r_Description
	 *            the description to set
	 */
	public void setDescription(final String r_Description)
	{
		this.description = r_Description;
	}

}
