/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.base;

import java.util.Iterator;
import java.util.Set;

import org.apache.commons.collections.set.ListOrderedSet;

import com.primeton.studio.core.IValidateListener;
import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.IValueContaier;
import com.primeton.studio.core.event.ValidateEvent;
import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.core.exception.ExceptionUtil;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * "IValueContaier"�ĳ�����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The base class for "IValueContaier". <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-9-20 ����01:23:46
 *
 * @author <a href="mailto:wl_95421@hotmail.co">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractValueChangeContainer.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/11/27 06:05:47  chenxp
 * Update:�׳��쳣�Ա�֪���쳣���ڡ�
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.10  2008/04/21 11:50:01  zhuxing
 * Update:�޸����ܴ��ڵ���ѭ������
 *
 * Revision 1.9  2008/03/07 08:58:08  wanglei
 * Review:Ĭ���������Ӧ�ô���֤�ġ�
 *
 * Revision 1.8  2008/03/07 06:02:55  wanglei
 * Add:�����¼�֪ͨ�Ŀ��ء�
 *
 * Revision 1.7  2008/02/26 09:13:26  wanglei
 * Update:ʹ��ListOrderedSet������HashSet���Ա�֤˳��
 *
 * Revision 1.6  2008/02/21 02:02:57  wanglei
 * Update:ʹ��Reflection����clone����ǿ������ʵ��cloneSelf������
 *
 * Revision 1.5  2008/01/14 01:18:54  wanglei
 * Add:��������֤��صķ�����
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractValueChangeContainer implements IValueContaier {
	private Set valueChangeListeners = new ListOrderedSet();

	// ���ݸı�������б�

	private Set validateListeners = new ListOrderedSet();

	// ��֤�������б�

	private transient boolean enableValidateEvent=true;

	private transient boolean enableValueEvent=true;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public AbstractValueChangeContainer() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public void doAddValueChangeListener(IValueChangeListener r_Listener) {
		if (null != r_Listener && this != r_Listener) {
			this.valueChangeListeners.add(r_Listener);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void doRemoveValueChangeListener(IValueChangeListener r_Listener) {
		if (null != r_Listener) {
			this.valueChangeListeners.remove(r_Listener);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void doClearValueChangeListeners() {
		this.valueChangeListeners.clear();
	}

	/**
	 * {@inheritDoc}
	 */
	public IValueChangeListener[] getValueChangeListeners() {
		IValueChangeListener[] t_Listeners = new IValueChangeListener[this.valueChangeListeners.size()];
		this.valueChangeListeners.toArray(t_Listeners);
		return t_Listeners;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void fireValueChanged(ValueChangeEvent r_Event) {

		if (!this.isEnableValueEvent()) {
			return;
		}

		if (null != this.valueChangeListeners) {
			for (Iterator t_Iterator = this.valueChangeListeners.iterator(); t_Iterator.hasNext();) {
				IValueChangeListener t_ChangeListener = (IValueChangeListener) t_Iterator.next();
				try {
					t_ChangeListener.valueChange(r_Event);
				} catch (Exception e) {
					ExceptionUtil.getInstance().logException(e);
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Object clone() {
		AbstractValueChangeContainer t_Container = cloneSelf();
		t_Container.enableValidateEvent = this.enableValidateEvent;
		t_Container.enableValueEvent = this.enableValueEvent;
		return t_Container;
	}

	/**
	 * �����෵�������ĸ��ơ�<BR>
	 *
	 * Return the clone object for this class.<BR>
	 *
	 * @return AbstractPropertyEditor
	 */
	protected AbstractValueChangeContainer cloneSelf() {
		try {
			return this.getClass().newInstance();
		} catch (InstantiationException e) {
			return null;
		} catch (IllegalAccessException e) {
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void doAddValidateListener(IValidateListener r_Listener) {
		if (null != r_Listener && this != r_Listener) {
			this.validateListeners.add(r_Listener);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void doClearValidateListeners() {
		this.validateListeners.clear();
	}

	/**
	 * {@inheritDoc}
	 */
	public void doRemoveValidateListener(IValidateListener r_Listener) {
		if (null != r_Listener) {
			this.validateListeners.remove(r_Listener);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void fireValidateEvent(ValidateEvent r_Event) {

		if (!this.isEnableValidateEvent()) {
			return;
		}

		for (Iterator t_Iterator = this.validateListeners.iterator(); t_Iterator.hasNext();) {
			IValidateListener t_Listener = (IValidateListener) t_Iterator.next();
			t_Listener.validateRequested(r_Event);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IValidateListener[] getValidateListener() {
		IValidateListener[] t_Listeners = new IValidateListener[this.validateListeners.size()];
		this.validateListeners.toArray(t_Listeners);
		return t_Listeners;
	}

	/**
	 * @return Returns the enableValidateEvent.
	 */
	public boolean isEnableValidateEvent() {
		return this.enableValidateEvent;
	}

	/**
	 * @param r_EnableValidateEvent The enableValidateEvent to set.
	 */
	public void setEnableValidateEvent(boolean r_EnableValidateEvent) {
		this.enableValidateEvent = r_EnableValidateEvent;
	}

	/**
	 * @return Returns the enableValueEvent.
	 */
	public boolean isEnableValueEvent() {
		return this.enableValueEvent;
	}

	/**
	 * @param r_EnableValueEvent The enableValueEvent to set.
	 */
	public void setEnableValueEvent(boolean r_EnableValueEvent) {
		this.enableValueEvent = r_EnableValueEvent;
	}

}
