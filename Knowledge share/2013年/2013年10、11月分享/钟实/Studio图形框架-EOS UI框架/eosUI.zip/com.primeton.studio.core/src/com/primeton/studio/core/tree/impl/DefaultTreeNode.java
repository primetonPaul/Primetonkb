/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.tree.impl;

import java.util.Vector;

import com.primeton.studio.core.CoreMessages;
import com.primeton.studio.core.base.AbstractPropertyAwareElement;
import com.primeton.studio.core.tree.ITreeNode;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��Swing�ṩ��DefaultMutableTreeNode���ƣ���ITreeNode��Ĭ��ʵ�֡�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The default implementation for "ITreeNode",it copies "DefaultMutableTreeNode" of swing. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-17 ����09:06:10
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: DefaultTreeNode.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2007/12/13 05:20:30  yuhl
 * Update:���ʻ�
 *
 * Revision 1.4  2007/05/23 05:17:21  wanglei
 * Add:����clear������
 *
 * Revision 1.3  2007/05/18 06:24:02  wanglei
 * Update:�����ⲿ����ϲ��ĵ�Ԫ��
 *
 * Revision 1.2  2007/03/21 11:57:13  wanglei
 * Update:ΪKTree�ṩһЩ������
 *
 *
 *
 * Revision 1.1 2007/03/05 06:01:57 wanglei �ύ��CVS
 *
 */

public class DefaultTreeNode extends AbstractPropertyAwareElement implements ITreeNode {

	private ITreeNode parent;

	private Object userObject;

	private boolean visible = true;

	private boolean expanded = true;

	private boolean mergeChildren = true;

	private Vector children = new Vector();

	private int[] cells;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public DefaultTreeNode() {
		super();
	}

	/**
	 * ���ݵ�ǰ��������ж�����ֱ�ӹ��졣<BR>
	 *
	 * Pass the user object the node owns to construct a new instance.<BR>
	 *
	 * @param r_UserObject
	 */
	public DefaultTreeNode(Object r_UserObject) {
		super();
		this.userObject = r_UserObject;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#getChildAt(int)
	 */
	public ITreeNode getChildAt(int r_ChildIndex) {
		return (ITreeNode) this.children.get(r_ChildIndex);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#getChildCount()
	 */
	public int getChildCount() {
		return this.children.size();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.ktree.ITreeNode#getIndex(org.aquarius.ui.swt.builder.ktree.ITreeNode)
	 */
	public int getIndex(ITreeNode r_TreeNode) {
		return this.children.indexOf(r_TreeNode);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#getParent()
	 */
	public ITreeNode getParent() {
		return this.parent;
	}

	/**
	 * ���õ�ǰ����Ƿ�ɼ���<BR>
	 *
	 * Set the current node visible or not.<BR>
	 *
	 * @param r_Visible
	 */
	public void setVisible(boolean r_Visible) {
		this.visible = r_Visible;
	}

	/**
	 * ���ø���㡣<BR>
	 *
	 * Set the parent node.<BR>
	 *
	 * @param r_Parent
	 */
	public void setParent(ITreeNode r_Parent) {
		this.parent = r_Parent;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#getUserObject()
	 */
	public Object getUserObject() {
		return this.userObject;
	}

	/**
	 * ���õ�ǰ�����еĶ���<BR>
	 *
	 * Set the user object the current node owns.<BR>
	 *
	 * @param r_UserObject
	 */
	public void setUserObject(Object r_UserObject) {
		this.userObject = r_UserObject;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#isLeaf()
	 */
	public boolean isLeaf() {
		return 0 == this.getChildCount();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#isOpen()
	 */
	public boolean isExpanded() {
		return this.expanded;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#isVisible()
	 */
	public boolean isVisible() {
		return this.visible;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.tree.ITreeNode#setOpen(boolean)
	 */
	public void setExpanded(boolean r_Open) {
		this.expanded = r_Open;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.ktree.ITreeNode#belongsToCell(int)
	 */
	public int belongsToCell(int r_Column) {

		if (null == this.cells) {
			return r_Column;
		}

		if (this.cells.length < r_Column) {
			return r_Column;
		}

		return this.cells[r_Column];
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.tree.ITreeNode#add(com.primeton.studio.core.tree.ITreeNode)
	 */
	public void add(ITreeNode r_ChildNode) {
		if (r_ChildNode != null && r_ChildNode.getParent() == this) {
			insert(r_ChildNode, getChildCount() - 1);
		}
		else {
			insert(r_ChildNode, getChildCount());
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.tree.ITreeNode#insert(com.primeton.studio.core.tree.ITreeNode, int)
	 */
	public void insert(ITreeNode r_ChildNode, int r_ChildIndex) {
		if (r_ChildNode == null) {
			throw new IllegalArgumentException(CoreMessages.DefaultTreeNode_CHILD_NULL);
		}
		else if (isNodeAncestor(r_ChildNode)) {
			throw new IllegalArgumentException(CoreMessages.DefaultTreeNode_CHILD_ERROR);
		}

		ITreeNode oldParent = r_ChildNode.getParent();

		if (oldParent != null) {
			oldParent.remove(r_ChildNode);
		}

		r_ChildNode.setParent(this);
		this.children.insertElementAt(r_ChildNode, r_ChildIndex);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.tree.ITreeNode#set(com.primeton.studio.core.tree.ITreeNode, int)
	 */
	public void set(ITreeNode r_ChildNode, int r_ChildIndex) {
		if (r_ChildNode == null) {
			throw new IllegalArgumentException(CoreMessages.DefaultTreeNode_CHILD_NULL);
		}
		else if (isNodeAncestor(r_ChildNode)) {
			throw new IllegalArgumentException(CoreMessages.DefaultTreeNode_CHILD_ERROR);
		}

		r_ChildNode.setParent(this);
		this.children.setElementAt(r_ChildNode, r_ChildIndex);

	}

	/**
	 * Returns true if <code>anotherNode</code> is an ancestor of this node -- if it is this node, this node's parent,
	 * or an ancestor of this node's parent. (Note that a node is considered an ancestor of itself.) If
	 * <code>anotherNode</code> is null, this method returns false. This operation is at worst O(h) where h is the
	 * distance from the root to this node.
	 *
	 * @see #isNodeDescendant
	 * @see #getSharedAncestor
	 * @param r_Node
	 *            node to test as an ancestor of this node
	 * @return true if this node is a descendant of <code>anotherNode</code>
	 */
	public boolean isNodeAncestor(ITreeNode r_Node) {
		if (r_Node == null) {
			return false;
		}

		ITreeNode t_Ancestor = this;

		do {
			if (t_Ancestor == r_Node) {
				return true;
			}
		} while ((t_Ancestor = t_Ancestor.getParent()) != null);

		return false;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.tree.ITreeNode#remove(com.primeton.studio.core.tree.ITreeNode)
	 */
	public void remove(ITreeNode r_ChildNode) {
		if (r_ChildNode == null) {
			throw new IllegalArgumentException(CoreMessages.DefaultTreeNode_ARGUMENT_NULL);
		}

		if (!isNodeChild(r_ChildNode)) {
			throw new IllegalArgumentException(CoreMessages.DefaultTreeNode_ARGUMENT_ERROR);
		}
		remove(getIndex(r_ChildNode)); // linear search
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.tree.ITreeNode#remove(int)
	 */
	public void remove(int r_ChildIndex) {
		ITreeNode child = getChildAt(r_ChildIndex);
		this.children.removeElementAt(r_ChildIndex);
		child.setParent(null);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.aquarius.ui.swt.builder.ktree.ITreeNode#isMergeChildren()
	 */
	public boolean isMergeChildren() {
		return this.mergeChildren;
	}

	/**
	 * �����Ƿ�ϲ��ӽ�㡣<BR>
	 *
	 * Set whether merge children node.<BR>
	 *
	 * @param r_MergeChildren
	 *            The mergeChildren to set.
	 */
	public void setMergeChildren(boolean r_MergeChildren) {
		this.mergeChildren = r_MergeChildren;
	}

	/**
	 * Returns true if <code>aNode</code> is a child of this node. If <code>aNode</code> is null, this method
	 * returns false.
	 *
	 * @return true if <code>aNode</code> is a child of this node; false if <code>aNode</code> is null
	 */
	public boolean isNodeChild(ITreeNode r_Node) {
		boolean t_Result;

		if (r_Node == null) {
			t_Result = false;
		}
		else {
			if (getChildCount() == 0) {
				t_Result = false;
			}
			else {
				t_Result = (r_Node.getParent() == this);
			}
		}

		return t_Result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		if (null != this.userObject) {
			return this.userObject.toString();
		}
		return super.toString();
	}

	/**
	 * Returns the number of levels above this node -- the distance from the root to this node. If this node is the
	 * root, returns 0.
	 *
	 * @see #getDepth
	 * @return the number of levels above this node
	 */
	public int getLevel() {
		ITreeNode ancestor;
		int levels = 0;

		ancestor = this;
		while ((ancestor = ancestor.getParent()) != null) {
			levels++;
		}

		return levels;
	}

	/**
	 * @return the cells
	 */
	public int[] getCells() {
		return this.cells;
	}

	/**
	 * @param r_Cells the cells to set
	 */
	public void setCells(int[] r_Cells) {
		this.cells = r_Cells;
	}

	/**
	 * {@inheritDoc}
	 */
	public void clear() {
		this.children.clear();
	}
}
