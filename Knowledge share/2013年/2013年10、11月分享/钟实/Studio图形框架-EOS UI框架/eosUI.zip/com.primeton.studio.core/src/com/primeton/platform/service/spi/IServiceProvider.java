/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/platform/service/spi/IServiceProvider.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-12-21
 *******************************************************************************/


package com.primeton.platform.service.spi;

import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.ServiceContext;
import com.primeton.platform.service.VersionRange;
import com.primeton.studio.core.IPriority;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����ṩ��<BR>
 *
 * <strong>English Doc��</strong><BR>
 * This class is used to provide service objects.<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IServiceProvider.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:22  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 */
public interface IServiceProvider extends IPriority{
	/**
	 * Returns the namespace name for this extension.
	 *
	 * @return the namespace name for this extension
	 */
	public String getNamespaceIdentifier();

	/**
	 *
	 * @param interfaceName
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public Object[] findServices(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

	/**
	 *
	 * @param interfaceName
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public Object findService(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

	/**
	 *
	 * @param interfaceClass
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public Object[] findServices(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

	/**
	 *
	 * @param interfaceClass
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public Object findService(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

	/**
	 *
	 * @param interfaceName
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public IServiceReference[] findServiceReferences(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

	/**
	 *
	 * @param interfaceName
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public IServiceReference findServiceReference(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

	/**
	 *
	 * @param interfaceClass
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public IServiceReference[] findServiceReferences(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

	/**
	 *
	 * @param interfaceClass
	 * @param serviceContext
	 * @param versionDeclaration
	 * @param serviceFilter
	 * @return
	 */
	public IServiceReference findServiceReference(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter);

}
