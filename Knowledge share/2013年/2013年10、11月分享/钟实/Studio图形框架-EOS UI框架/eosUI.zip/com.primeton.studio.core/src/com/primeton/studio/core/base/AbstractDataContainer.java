/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.base;

import com.primeton.studio.core.IDataContainer;


/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * IDataContainer�ĳ�����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The base class for IDataContainer. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-2-18 ����03:47:37
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractDataContainer.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/18 07:53:50  wanglei
 * Add:�ύ��CVS��
 *
 */

public abstract class AbstractDataContainer extends AbstractAdaptableObject implements IDataContainer
{

	private int state;

	private Object data;

	static final int KEYED_DATA = 1 << 2;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractDataContainer()
	{
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getData()
	{
		return (this.state & KEYED_DATA) != 0 ? ((Object[]) this.data)[0] : this.data;
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getData(String r_Key)
	{

		if (r_Key == null)
		{
			return null;
		}
		if ((this.state & KEYED_DATA) != 0)
		{
			Object[] t_Table = (Object[]) this.data;
			for (int i = 1; i < t_Table.length; i += 2)
			{
				if (r_Key.equals(t_Table[i]))
				{
					return t_Table[i + 1];
				}
			}
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setData(Object r_Data)
	{

		if ((this.state & KEYED_DATA) != 0)
		{
			((Object[]) this.data)[0] = r_Data;
		}
		else
		{
			this.data = r_Data;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void setData(String r_Key, Object r_Data)
	{
		if (r_Key == null)
		{
			return;
		}
		int t_Index = 1;
		Object[] t_Table = null;
		if ((this.state & KEYED_DATA) != 0)
		{
			t_Table = (Object[]) this.data;
			while (t_Index < t_Table.length)
			{
				if (r_Key.equals(t_Table[t_Index]))
				{
					break;
				}
				t_Index += 2;
			}
		}
		if (r_Data != null)
		{
			if ((this.state & KEYED_DATA) != 0)
			{
				if (t_Index == t_Table.length)
				{
					Object[] newTable = new Object[t_Table.length + 2];
					System.arraycopy(t_Table, 0, newTable, 0, t_Table.length);
					this.data = t_Table = newTable;
				}
			}
			else
			{
				t_Table = new Object[3];
				t_Table[0] = this.data;
				this.data = t_Table;
				this.state |= KEYED_DATA;
			}
			t_Table[t_Index] = r_Key;
			t_Table[t_Index + 1] = r_Data;
		}
		else
		{
			if ((this.state & KEYED_DATA) != 0)
			{
				if (t_Index != t_Table.length)
				{
					int t_Length = t_Table.length - 2;
					if (t_Length == 1)
					{
						this.data = t_Table[0];
						this.state &= ~KEYED_DATA;
					}
					else
					{
						Object[] newTable = new Object[t_Length];
						System.arraycopy(t_Table, 0, newTable, 0, t_Index);
						System.arraycopy(t_Table, t_Index + 2, newTable, t_Index, t_Length - t_Index);
						this.data = newTable;
					}
				}
			}
		}
	}
}