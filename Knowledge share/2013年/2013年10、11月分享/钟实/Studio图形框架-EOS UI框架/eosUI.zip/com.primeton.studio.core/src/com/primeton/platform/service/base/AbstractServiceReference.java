/**
 *
 */
package com.primeton.platform.service.base;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;

import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.ServiceContext;
import com.primeton.platform.service.Version;
import com.primeton.platform.service.spi.IServiceFactory;
import com.primeton.platform.service.spi.IServiceProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * <BR>
 *
 * <strong>English Doc��</strong><BR>
 * <BR>
 *
 * Created Time: 2009-8-31 ����05:57:57
 * @author @author wanglei (mailto:wanglei@primeton.com)
 *
 */
/*
 * Update History
 *
 * $Log: AbstractServiceReference.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 *
 */
public abstract class AbstractServiceReference implements IServiceReference {

	private IServiceProvider serviceProvider;

	private String serviceDeclaration;

	private Object serviceImplementation;

	private Version version;

	private Map properties;

	/**
	 *
	 * @param serviceProvider
	 * @param serviceDeclaration
	 * @param serviceImplementation
	 * @param version
	 * @param properties
	 */
	public AbstractServiceReference(IServiceProvider serviceProvider, String serviceDeclaration, Object serviceImplementation, Version version, Map properties) {
		super();
		this.serviceProvider = serviceProvider;
		this.serviceDeclaration = serviceDeclaration;
		this.serviceImplementation = serviceImplementation;
		this.version = version;
		if (null == properties) {
			this.properties = Collections.synchronizedMap(new HashMap());
		} else {
			this.properties = Collections.synchronizedMap(new HashMap(properties));
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getServiceObject(ServiceContext serviceContext) {

		if (this.serviceImplementation instanceof IServiceFactory) {
			IServiceFactory serviceFactory = (IServiceFactory) this.serviceImplementation;
			return serviceFactory.createService(serviceContext);
		} else {
			return this.serviceImplementation;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getProperty(String key) {
		return this.properties.get(key);
	}

	/**
	 * {@inheritDoc}
	 */
	public String[] getPropertyKeys() {
		String[] keys = new String[this.properties.size()];
		this.properties.keySet().toArray(keys);
		return keys;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getServiceDeclaration() {
		return this.serviceDeclaration;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getServiceImplementation() {
		if (this.serviceImplementation instanceof IServiceFactory) {
			IServiceFactory serviceFactory = (IServiceFactory) this.serviceImplementation;
			return serviceFactory.getServiceImplementationClass();
		} else {
			return this.serviceImplementation.getClass().getName();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceProvider getServiceProvider() {
		return this.serviceProvider;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.properties == null) ? 0 : this.properties.hashCode());
		result = prime * result + ((this.serviceDeclaration == null) ? 0 : this.serviceDeclaration.hashCode());
		result = prime * result + ((this.serviceImplementation == null) ? 0 : this.serviceImplementation.hashCode());
		result = prime * result + ((this.serviceProvider == null) ? 0 : this.serviceProvider.hashCode());
		result = prime * result + ((this.version == null) ? 0 : this.version.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public Version getVersion() {
		return this.version;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		AbstractServiceReference other = (AbstractServiceReference) obj;

		if (!ObjectUtils.equals(other.serviceDeclaration, this.serviceDeclaration)) {
			return false;
		}

		if (!ObjectUtils.equals(other.serviceImplementation, this.serviceImplementation)) {
			return false;
		}

		if (!ObjectUtils.equals(other.serviceProvider, this.serviceProvider)) {
			return false;
		}

		if (!ObjectUtils.equals(other.version, this.version)) {
			return false;
		}

		if (!ObjectUtils.equals(other.properties, this.properties)) {
			return false;
		}

		return true;
	}

}
