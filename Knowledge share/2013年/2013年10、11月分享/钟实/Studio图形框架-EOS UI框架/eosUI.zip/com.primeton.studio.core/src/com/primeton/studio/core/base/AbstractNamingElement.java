/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.base;

import org.apache.commons.lang.ObjectUtils;

import com.primeton.studio.core.INamingElement;

/**
 * INamingElement�Ļ��ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractNamingElement.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/04/24 01:49:21  wanglei
 * Update:������equals��hashCode�����������һЩ��
 *
 * Revision 1.3  2007/03/05 07:26:58  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractNamingElement implements INamingElement {
	private String displayName;

	private String name;

	/**
	 * Ĭ�Ϲ��캯��
	 */
	public AbstractNamingElement() {
		super();
	}

	/**
	 * ֱ��ͨ�������������������<BR>
	 */
	public AbstractNamingElement(String displayName, String name) {
		super();
		this.displayName = displayName;
		this.name = name;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.INamingElement#getDisplayName()
	 */
	public String getDisplayName() {
		return this.displayName;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.INamingElement#getName()
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * @param displayName
	 *            The displayName to set.
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @param name
	 *            The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((this.displayName == null) ? 0 : this.displayName.hashCode());
		result = PRIME * result + ((this.name == null) ? 0 : this.name.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		final AbstractNamingElement other = (AbstractNamingElement) obj;
		if (!ObjectUtils.equals(this.displayName, other.displayName)) {
			return false;
		}
		if (!ObjectUtils.equals(this.name, other.name)) {
			return false;
		}

		return true;
	}

}