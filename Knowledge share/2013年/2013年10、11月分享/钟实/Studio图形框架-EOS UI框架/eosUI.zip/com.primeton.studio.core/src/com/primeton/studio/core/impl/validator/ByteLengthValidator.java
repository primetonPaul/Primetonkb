/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/impl/validator/ByteLengthValidator.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-25
 *******************************************************************************/


package com.primeton.studio.core.impl.validator;

public class ByteLengthValidator extends AbstractStringValidator {
	
	private LengthValidator lengthValidator;
	
	/**
	 * �̳��Ը����Ĭ�Ϲ��캯����<BR>
	 * 
	 * The derived default constructor.<BR>
	 */
	public ByteLengthValidator()
	{
		super();
		lengthValidator = new LengthValidator();
	}

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 * 
	 * The derived default constructor.<BR>
	 * 
	 * @param r_Message
	 *            the message to be shown.
	 */
	public ByteLengthValidator(String r_Message)
	{
		super(r_Message);
		lengthValidator = new LengthValidator();
	}
	/**
	 * ֱ��ͨ����������������ݡ�<BR>
	 * 
	 * Build a object by the parameters.<BR>
	 * 
	 * @param r_Message
	 * @param r_Min
	 * @param r_Max
	 */
	public ByteLengthValidator(String r_Message, int min, int max) {
		super(r_Message);
		lengthValidator = new LengthValidator(r_Message,min,max);
	}

	@Override
	protected boolean onValidate(String r_Value) {
		if (r_Value == null)
		{
			return false;
		}
		else
		{
			return this.lengthValidator.validateLength(r_Value.trim().getBytes().length);
		}
	}
	/**
	 * ������󳤶ȡ�<BR>
	 * 
	 * Return the maximum length.
	 * 
	 * @return Returns the max.
	 */
	public int getMax()
	{
		return lengthValidator.getMax();
	}

	/**
	 * ������󳤶ȡ�<BR>
	 * 
	 * Set the maximum length.
	 * 
	 * @param r_Max
	 *            The max to set.
	 */
	public void setMax(final int r_Max)
	{
		lengthValidator.setMax(r_Max);
	}

	/**
	 * ������С���ȡ�<BR>
	 * 
	 * Return the minimum length.
	 * 
	 * @return Returns the min.
	 */
	public int getMin()
	{
		return lengthValidator.getMin();
	}

	/**
	 * ������С���ȡ�<BR>
	 * 
	 * Set the minimum length.
	 * 
	 * @param r_Min
	 *            The min to set.
	 */
	public void setMin(final int r_Min)
	{
		lengthValidator.setMin(r_Min);
	}

	/**
	 * �����Ƿ�������ֵ��<BR>
	 * 
	 * Return whether check the maximum value or not.<BR>
	 * 
	 * @return the checkMax
	 */
	public boolean isCheckMax()
	{
		return lengthValidator.isCheckMax();
	}

	/**
	 * �����Ƿ������ֵ��<BR>
	 * 
	 * Set whether check the maximum value or not.<BR>
	 * 
	 * @param r_CheckMax
	 *            the checkMax to set
	 */
	public void setCheckMax(boolean r_CheckMax)
	{
		lengthValidator.setCheckMax(r_CheckMax);
	}

	/**
	 * �����Ƿ�����Сֵ��<BR>
	 * 
	 * Return whether check the minimum value or not.<BR>
	 * 
	 * @return the checkMin
	 */
	public boolean isCheckMin()
	{
		return lengthValidator.isCheckMin();
	}

	/**
	 * �����Ƿ�����Сֵ��<BR>
	 * 
	 * Set whether check the minimum value or not.<BR>
	 * 
	 * @param r_CheckMin
	 *            the checkMin to set
	 */
	public void setCheckMin(boolean r_CheckMin)
	{
		lengthValidator.setCheckMin(r_CheckMin);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.impl.validator.AbstractValidator#clone()
	 */
	public Object clone()
	{
		final ByteLengthValidator t_Validator = new ByteLengthValidator();
		t_Validator.lengthValidator = (LengthValidator) this.lengthValidator.clone();
		t_Validator.setMessage(this.getMessage());
		return t_Validator;
	}

}
