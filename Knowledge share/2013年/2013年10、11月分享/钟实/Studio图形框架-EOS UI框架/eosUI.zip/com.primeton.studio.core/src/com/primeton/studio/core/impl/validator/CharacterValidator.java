/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/impl/validator/CharacterValidator.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-4-7
 *******************************************************************************/


package com.primeton.studio.core.impl.validator;

/**
 * character validator: Determines if the specified character is a letter or digit.
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: CharacterValidator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/07 08:13:06  zhuxing
 * New:character validator,determines if the specified character is a letter or digit.
 * 
 */
public class CharacterValidator extends AbstractStringValidator {

	/* (non-Javadoc)
	 * @see com.primeton.studio.core.impl.validator.AbstractStringValidator#onValidate(java.lang.String)
	 */
	@Override
	protected boolean onValidate(String r_Value) {
		if (r_Value == null || r_Value.length() != 1)
			return false;
		
		return Character.isLetterOrDigit(r_Value.charAt(0));
	}

}
