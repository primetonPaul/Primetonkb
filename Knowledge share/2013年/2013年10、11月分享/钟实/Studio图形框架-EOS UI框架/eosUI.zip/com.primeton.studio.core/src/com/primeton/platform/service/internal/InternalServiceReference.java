/**
 * 
 */
package com.primeton.platform.service.internal;

import java.util.Map;

import com.primeton.platform.service.Version;
import com.primeton.platform.service.base.AbstractServiceReference;
import com.primeton.platform.service.spi.IServiceProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * <BR>
 *
 * <strong>English Doc��</strong><BR>
 * <BR>
 * 
 * Created Time: 2009-8-28 ����01:47:42
 * @author @author wanglei (mailto:wanglei@primeton.com)
 * 
 */
/*
 * Update History
 *
 * $Log: InternalServiceReference.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 * 
 */
public class InternalServiceReference extends AbstractServiceReference  {

	/**
	 * 
	 * @param serviceProvider
	 * @param serviceDeclaration
	 * @param serviceImplementation
	 * @param version
	 * @param properties
	 */
	public InternalServiceReference(IServiceProvider serviceProvider, String serviceDeclaration, Object serviceImplementation, Version version, Map properties) {
		super(serviceProvider, serviceDeclaration, serviceImplementation, version, properties);
		// TODO Auto-generated constructor stub
	}

	

}
