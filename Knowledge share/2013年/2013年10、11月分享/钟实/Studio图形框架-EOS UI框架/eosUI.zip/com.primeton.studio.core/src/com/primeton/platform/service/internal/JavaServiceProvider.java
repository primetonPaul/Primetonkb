/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/platform/service/internal/JavaServiceProvider.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2010-5-12
 *******************************************************************************/

package com.primeton.platform.service.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.eos.internal.utility.ServiceLoader;
import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.ServiceContext;
import com.primeton.platform.service.VersionRange;
import com.primeton.platform.service.base.AbstractServiceProvider;
import com.primeton.platform.service.spi.IServiceFilter;

/**
 * ʹ��Sun�ṩ��Manifest/services��ʽ���ṩ����<BR>
 * �μ�<href url="http://weblogs.java.net/blog/2008/08/12/simple-dependency-injection-serviceloader-jdk-6">http://weblogs.java.net/blog/2008/08/12/simple-dependency-injection-serviceloader-jdk-6</href>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: JavaServiceProvider.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.3  2010/06/24 09:02:52  hongsq
 * Update:�����ӵ�ǰclassLoader�ʹӵ�ǰ�̵߳�classLoader�в�����
 *
 * Revision 1.2  2010/06/23 03:05:50  hongsq
 * Update:��ǰ�̵߳�ClassLoader�Ǻܿ�����EOS��Ŀ��ClassLoader,������Ӧ��ʹ��com.primeton.studio.core������ClassLoader���ܼ��ص�������ע�����
 *
 * Revision 1.1  2010/05/14 05:00:03  wanglei
 * Jira:����EOSP-243��
 *
 */
class JavaServiceProvider extends AbstractServiceProvider {
	private static final ClassLoader providerClassLoader = new ProviderClassLoader(JavaServiceProvider.class.getClassLoader());
	private static final JavaServiceProvider instance = new JavaServiceProvider();

	/**
	 *
	 */
	private JavaServiceProvider() {
		super();
	}

	/**
	 * @return Returns the instance.
	 */
	public static JavaServiceProvider getInstance() {
		return instance;
	}

	/**
	 * @param interfaceName
	 * @return
	 * @throws ClassNotFoundException
	 */
	protected Class loadClass(String interfaceName) throws ClassNotFoundException {
//		return Thread.currentThread().getContextClassLoader().loadClass(interfaceName);
		return providerClassLoader.loadClass(interfaceName);
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference findServiceReference(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {

		Class interfaceClass;
		try {
			interfaceClass = loadClass(interfaceName);

			ServiceLoader loader = ServiceLoader.load(interfaceClass, this.providerClassLoader);
			Iterator iterator = loader.iterator();

			if (iterator.hasNext()) {
				Object object = iterator.next();
				return new InternalServiceReference(this, interfaceClass.getName(), object, null, null);
			}

			return null;

		} catch (ClassNotFoundException e) {
			return null;
		}

	}

	/* (non-Javadoc)
	 * @see com.primeton.platform.service.base.AbstractServiceProvider#findServiceReference(java.lang.Class, com.primeton.platform.service.ServiceContext, com.primeton.platform.service.VersionRange, com.primeton.platform.service.spi.IServiceFilter)
	 */
	@Override
	public IServiceReference findServiceReference(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		ServiceLoader loader = ServiceLoader.load(interfaceClass, this.providerClassLoader);
		Iterator iterator = loader.iterator();

		if (iterator.hasNext()) {
			Object object = iterator.next();
			return new InternalServiceReference(this, interfaceClass.getName(), object, null, null);
		}

		return null;
	}

	/* (non-Javadoc)
	 * @see com.primeton.platform.service.base.AbstractServiceProvider#findServiceReferences(java.lang.Class, com.primeton.platform.service.ServiceContext, com.primeton.platform.service.VersionRange, com.primeton.platform.service.spi.IServiceFilter)
	 */
	@Override
	public IServiceReference[] findServiceReferences(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		List<IServiceReference> list = new ArrayList<IServiceReference>();
		ServiceLoader loader = ServiceLoader.load(interfaceClass, this.providerClassLoader);
		Iterator iterator = loader.iterator();

		while (iterator.hasNext()) {
			Object object = iterator.next();
			list.add(new InternalServiceReference(this, interfaceClass.getName(), object, null, null));
		}

		IServiceReference[] results = new IServiceReference[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference[] findServiceReferences(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		Class interfaceClass;
		try {
			interfaceClass = loadClass(interfaceName);

			List list = new ArrayList();

			ServiceLoader loader = ServiceLoader.load(interfaceClass, this.providerClassLoader);
			Iterator iterator = loader.iterator();

			while (iterator.hasNext()) {
				Object object = iterator.next();
				list.add(new InternalServiceReference(this, interfaceClass.getName(), object, null, null));
			}

			IServiceReference[] results = new IServiceReference[list.size()];
			list.toArray(results);
			return results;

		} catch (ClassNotFoundException e) {
			return new IServiceReference[0];
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int getPriority() {
		return Integer.MAX_VALUE;
	}
}