/**
 *
 */
package com.primeton.platform.service.impl;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.Version;
import com.primeton.platform.service.VersionRange;
import com.primeton.platform.service.spi.IServiceFilter;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ֧�ִ�������ȡ��֧��ĳ��Bundle�İ汾��Ϣ��Ȼ���ж��Ƿ���ϡ�<BR>
 *
 * <strong>English Doc��</strong><BR>
 * <BR>
 *
 * Created Time: 2009-12-22 ����09:38:50
 * @author wanglei (mailto:wanglei@primeton.com)
 *
 */
/*
 * Update History
 *
 * $Log: BundleVersionFilter.java,v $
 * Revision 1.2  2012/01/12 02:06:40  guwei
 * Update: �汾�������޸ģ�֧��eclipse3.6
 *
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:22  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 */
public class BundleVersionFilter implements IServiceFilter {

	public static final String REQUIRED_BUNDLE = "RequiredBundle";

	public static final String REQUIRED_BUNDLE_Version = "RequiredBundleVersion";

	private boolean allowNullVersion;

	/**
	 *
	 */
	public BundleVersionFilter(boolean allowNullVersion) {
		super();
		this.allowNullVersion = allowNullVersion;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isAcceptable(IServiceReference serviceReference) {
		Object object = serviceReference.getProperty(REQUIRED_BUNDLE);
		if (!(object instanceof String)) {
			if (this.allowNullVersion) {
				return true;
			} else {
				return false;
			}
		}

		String[] bundleInfos = StringUtils.split((String) object, ';');

		object = serviceReference.getProperty(REQUIRED_BUNDLE_Version);
		if (!(object instanceof String)) {
			if (this.allowNullVersion) {
				return true;
			} else {
				return false;
			}
		}

		String[] versionInfos = StringUtils.split((String) object, ';');

		if (bundleInfos.length != versionInfos.length) {
			return false;
		}

		for (int i = 0; i < bundleInfos.length; i++) {
			String bundleInfo = bundleInfos[i];
			String versionInfo = versionInfos[i];

			VersionRange versionRange = new VersionRange(versionInfo);

			Bundle bundle = Platform.getBundle(bundleInfo);
//			if (!(bundle instanceof Bundle)) {
//				return false;
//			}
			if(bundle == null){
				return false;
			}

			Version bundleVersion = Version.parseVersion( "6.0.0");
			if (!versionRange.isIncluded(bundleVersion)) {
				return false;
			}
		}

		return true;
	}
}
