/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.impl;

import java.util.Properties;

import com.primeton.studio.core.IMessageCaller;

/**
 * ��NullObjectģʽΪ������Ƶ�IMessageCallerʵ���ࡣ<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: EmptyMessageCaller.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/01/22 02:10:42  wanglei
 * Review:�ĳ�singleton��
 *
 * Revision 1.1  2007/08/08 08:03:43  wanglei
 * �ύ��CVS��
 *
 */

public class EmptyMessageCaller implements IMessageCaller {

	public static final EmptyMessageCaller INSTANCE = new EmptyMessageCaller();

	/**
	 * �õ�һ���϶���Ϊ <code>null</code>��IMessageCallerʵ����<BR>
	 *
	 * @param r_MessageCaller
	 * @return
	 */
	public static final IMessageCaller getMessageCaller(IMessageCaller r_MessageCaller) {
		if (null == r_MessageCaller) {
			return INSTANCE;
		}
		else {
			return r_MessageCaller;
		}
	}

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private EmptyMessageCaller() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public void clear() {
	//Nothing to do
	}

	/**
	 * {@inheritDoc}
	 */
	public void error(String r_Message, Properties r_Properties) {
	//		Nothing to do
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasError() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public void info(String r_Message, Properties r_Properties) {
	//		Nothing to do
	}

	/**
	 * {@inheritDoc}
	 */
	public void warn(String r_Message, Properties r_Properties) {
	//		Nothing to do
	}

}
