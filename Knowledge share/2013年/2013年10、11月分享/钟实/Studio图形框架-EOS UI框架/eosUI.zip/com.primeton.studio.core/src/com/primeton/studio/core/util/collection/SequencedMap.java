/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.util.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.keyvalue.DefaultMapEntry;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * <BR>
 * �����Map�����Ա�֤����ǰ��˳�����ӳ�䡣<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * A special map implementation,which contains data on sequence.<BR>
 * It will produce a collection with the queue.<BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 10:15:45
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.0
 */

/*
 * �޸���ʷ
 *
 * $Log: SequencedMap.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/01/18 01:31:45  caiwei
 * Update:ȡ����ǩ���Ķ�group������(���ò������˳��),ֻչ��html��ǩ��
 *
 * Revision 1.2  2007/05/31 01:43:56  yanfei
 * JUNIT Test: �޸Ĵ����еı��󣬽�Key�ŵ���Value�С�
 *
 * Revision 1.1  2007/05/30 05:23:41  wanglei
 * �ύ��CVS��
 *
 */

public class SequencedMap implements Map {

	private List keyList = new ArrayList();

	private List valueList = new ArrayList();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public SequencedMap() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public void clear() {
		this.keyList.clear();
		this.valueList.clear();

	}

	/**
	 * {@inheritDoc}
	 */
	public boolean containsKey(Object r_Key) {
		return this.keyList.contains(r_Key);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean containsValue(Object r_Value) {
		return this.valueList.contains(r_Value);
	}

	/**
	 * {@inheritDoc}
	 */
	public Set entrySet() {
		Set t_Set = new HashSet();
		for (int i = 0; i < this.keyList.size(); i++) {
			Object t_Key = this.keyList.get(i);
			Object t_Value = this.valueList.get(i);

			t_Set.add(new DefaultMapEntry(t_Key, t_Value));
		}

		return t_Set;
	}

	/**
	 * {@inheritDoc}
	 */
	public Object get(Object r_Key) {
		int t_Index = this.keyList.indexOf(r_Key);
		if (t_Index != -1) {
			return this.valueList.get(t_Index);
		}
		else {
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isEmpty() {
		return this.keyList.isEmpty();
	}

	/**
	 * {@inheritDoc}
	 */
	public Set keySet() {
		return new HashSet(this.keyList);
	}

	/**
	 * {@inheritDoc}
	 */
	public Object put(Object _Key, Object r_Value) {

		int t_Index = this.keyList.indexOf(_Key);
		if (-1 == t_Index) {
			this.keyList.add(_Key);
			this.valueList.add(r_Value);
			return null;
		}
		else {
			this.keyList.set(t_Index, _Key);
			return this.valueList.set(t_Index, r_Value);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void putAll(Map r_Map) {

		for (Iterator t_Iterator = r_Map.keySet().iterator(); t_Iterator.hasNext();) {
			Object t_Key = t_Iterator.next();
			Object t_Value = r_Map.get(t_Key);
			this.put(t_Key, t_Value);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Object remove(Object _Key) {
		int t_Index = this.keyList.indexOf(_Key);
		if (-1 == t_Index) {
			return null;
		}
		else {
			return this.keyList.remove(t_Index);
		}

	}

	/**
	 * {@inheritDoc}
	 */
	public int size() {
		return this.keyList.size();
	}

	/**
	 * {@inheritDoc}
	 */
	public Collection values() {
		return new ArrayList(this.valueList);
	}
	
	/**
	 * {@inheritDoc}
	 */
	public Collection keys() {
		return new ArrayList(this.keyList);
	}

}
