/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.impl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;

import com.primeton.studio.core.IMessageCaller;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * IMessageCaller�������������������ṩ������ʾ������ͨ���ⲿע���IMessageCaller����ʾ����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The composite of "IMessageCaller".<BR>
 * It can't show messages,but a proxy of the external "IMessageCaller"s. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-12-20 ����02:13:25
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: CompoundMessageCaller.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2008/02/27 02:46:28  wanglei
 * Add:����composite������
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */

public final class CompoundMessageCaller implements IMessageCaller {
	private Set messageCallers = new HashSet();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public CompoundMessageCaller() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#clear()
	 */
	public void clear() {
		for (Iterator t_Iterator = this.messageCallers.iterator(); t_Iterator.hasNext();) {
			IMessageCaller t_Caller = (IMessageCaller) t_Iterator.next();
			t_Caller.clear();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#error(java.lang.String)
	 */
	public void error(String r_Message, Properties r_Properties) {
		for (Iterator t_Iterator = this.messageCallers.iterator(); t_Iterator.hasNext();) {
			IMessageCaller t_Caller = (IMessageCaller) t_Iterator.next();
			t_Caller.error(r_Message, r_Properties);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#info(java.lang.String)
	 */
	public void info(String r_Message, Properties r_Properties) {
		for (Iterator t_Iterator = this.messageCallers.iterator(); t_Iterator.hasNext();) {
			IMessageCaller t_Caller = (IMessageCaller) t_Iterator.next();
			t_Caller.info(r_Message, r_Properties);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#warn(java.lang.String)
	 */
	public void warn(String r_Message, Properties r_Properties) {
		for (Iterator t_Iterator = this.messageCallers.iterator(); t_Iterator.hasNext();) {
			IMessageCaller t_Caller = (IMessageCaller) t_Iterator.next();
			t_Caller.warn(r_Message, r_Properties);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#hasError()
	 */
	public boolean hasError() {
		for (Iterator t_Iterator = this.messageCallers.iterator(); t_Iterator.hasNext();) {
			IMessageCaller t_Caller = (IMessageCaller) t_Iterator.next();
			if (t_Caller.hasError()) {
				return true;
			}
		}

		return false;
	}

	/**
	 * ����һ��MessageCaller�������ڱ���ʱ���������������֤����<BR>
	 * �ͻ���ô�����ʾ�ص��ӿ���ʾ������Ϣ<BR>
	 *
	 * Add a MessageCaller,it will be called when the user input is not vlidated to show the error messages.<BR>
	 *
	 *
	 * @param r_MessageCaller
	 *            the shower to show message.
	 */
	public void doAddMessageCaller(IMessageCaller r_MessageCaller) {
		if (null != r_MessageCaller) {
			this.messageCallers.add(r_MessageCaller);
		}
	}

	/**
	 * ��ȥһ��MessageCaller<BR>
	 *
	 * Remove a MessageCaller.<BR>
	 *
	 * @param r_MessageCaller
	 *            the shower to show message.
	 */
	public void doRemoveMessageCaller(IMessageCaller r_MessageCaller) {
		if (null != r_MessageCaller) {
			this.messageCallers.remove(r_MessageCaller);
		}
	}

	/**
	 * ��ȥ����MessageCaller<BR>
	 *
	 * Remove all the MessageCallers.<BR>
	 *
	 */
	public void doClearMessageCaller() {
		this.messageCallers.clear();
	}

	/**
	 * ���������ʽ�������е�MessageCaller��<BR>
	 *
	 * Return all the message callers in array.<BR>
	 *
	 */
	public IMessageCaller[] getMessageCallers() {
		IMessageCaller[] t_Callers = new IMessageCaller[this.messageCallers.size()];
		this.messageCallers.toArray(t_Callers);
		return t_Callers;
	}

	/**
	 * ��϶��IMessageCaller��<BR>
	 *
	 * Composite multi IMessageCaller.<BR>
	 *
	 * @param r_MessageCallers
	 * @return
	 */
	public static final IMessageCaller composite(IMessageCaller[] r_MessageCallers) {
		if (ArrayUtils.isEmpty(r_MessageCallers)) {
			return EmptyMessageCaller.INSTANCE;
		}
		else {
			CompoundMessageCaller t_CompoundMessageCaller = new CompoundMessageCaller();

			for (int i = 0; i < r_MessageCallers.length; i++) {
				IMessageCaller t_Caller = r_MessageCallers[i];
				t_CompoundMessageCaller.doAddMessageCaller(t_Caller);
			}

			return t_CompoundMessageCaller;
		}
	}
}
