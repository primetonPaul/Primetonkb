/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/platform/service/internal/ProviderClassLoader.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Jun 24, 2010
 *******************************************************************************/


package com.primeton.platform.service.internal;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;

/**
 * �Զ���classLoader,���ڴ�����classloader�ϲ��ң�����Ҳ����ٵ���ǰ���̵�classloader�в���
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ProviderClassLoader.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/06/24 09:07:23  hongsq
 * Update:�����ӵ�ǰclassLoader�ʹӵ�ǰ�̵߳�classLoader�в�����
 *
 * Revision 1.1  2010/06/24 09:03:18  hongsq
 * Update:�����ӵ�ǰclassLoader�ʹӵ�ǰ�̵߳�classLoader�в�����
 *
 */
class ProviderClassLoader extends ClassLoader {
	private ClassLoader delegateClassLoader;

	/**
	 * @param delegateClassLoader
	 */
	public ProviderClassLoader(ClassLoader delegateClassLoader) {
		super();
		this.delegateClassLoader = delegateClassLoader;
	}

	/* (non-Javadoc)
	 * @see java.lang.ClassLoader#getResource(java.lang.String)
	 */
	@Override
	public URL getResource(String name) {
		URL url = delegateClassLoader.getResource(name);
		if(null == url)
			url = Thread.currentThread().getContextClassLoader().getResource(name);
		return url;
	}

	/* (non-Javadoc)
	 * @see java.lang.ClassLoader#getResourceAsStream(java.lang.String)
	 */
	@Override
	public InputStream getResourceAsStream(String name) {
		InputStream inputStream = delegateClassLoader.getResourceAsStream(name);
		if(null == inputStream)
			inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(name);

		return inputStream;
	}

	/* (non-Javadoc)
	 * @see java.lang.ClassLoader#getResources(java.lang.String)
	 */
	@Override
	public Enumeration<URL> getResources(String name) throws IOException {
		Enumeration<URL> urls = null;
		IOException exception = null;
		try {
			urls = delegateClassLoader.getResources(name);
		} catch (IOException e) {
			exception = e;
		}
		if(null == urls || !urls.hasMoreElements()){
			try {
				urls = Thread.currentThread().getContextClassLoader().getResources(name);
			} catch (IOException e) {
				exception = e;
			}
		}

		if(null == urls && null != exception)
			throw exception;

		return urls;
	}

	/* (non-Javadoc)
	 * @see java.lang.ClassLoader#loadClass(java.lang.String)
	 */
	@Override
	public Class<?> loadClass(String name) throws ClassNotFoundException {
		Class<?> clazz = null;
		ClassNotFoundException exception = null;

		try {
			clazz = this.delegateClassLoader.loadClass(name);
		} catch (ClassNotFoundException e) {
			exception = e;
		}
		if(null == clazz){
			try {
				clazz = Thread.currentThread().getContextClassLoader().loadClass(name);
			} catch (ClassNotFoundException e) {
				exception = e;
			}
		}

		if(null == clazz && null != exception)
			throw exception;

		return clazz;
	}
}
