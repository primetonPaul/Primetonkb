/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.impl;

import com.primeton.studio.core.ICommand;
import com.primeton.studio.core.IMemento;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ������¼һ��ObjectEditor�����ݵĸı�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Used to memento the object of a object editor. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2007-2-9 ����04:45:33
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: SimpleCommand.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/06/26 01:11:51  caijing
 * update���ṩһ��get����
 *
 * Revision 1.1  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public class SimpleCommand implements ICommand
{
	private IMemento oldMemento;

	private IMemento newMemento;

	/**
	 * ���캯����<BR>
	 * 
	 * The constructor.<BR>
	 * 
	 * @param r_OldMemento
	 * 
	 * @param r_NewMemento
	 */
	public SimpleCommand(IMemento r_OldMemento, IMemento r_NewMemento)
	{
		super();
		this.oldMemento = r_OldMemento;
		this.newMemento = r_NewMemento;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.ICommand#canExecute()
	 */
	public boolean canExecute()
	{
		return null != this.newMemento;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.ICommand#canUndo()
	 */
	public boolean canUndo()
	{
		return this.canExecute();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.ICommand#execute()
	 */
	public void execute()
	{
		this.newMemento.restore();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.ICommand#redo()
	 */
	public void redo()
	{
		this.execute();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.ICommand#undo()
	 */
	public void undo()
	{
		this.oldMemento.restore();
	}

	/**
	 * @return Returns the newMemento.
	 */
	public IMemento getNewMemento() {
		return newMemento;
	}

	/**
	 * @return Returns the oldMemento.
	 */
	public IMemento getOldMemento() {
		return oldMemento;
	}
	
	
	

}
