/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/manager/ExtensionFilterManager.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2010-4-27
 *******************************************************************************/

package com.primeton.studio.core.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.Platform;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.activator.CoreActivator;
import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.core.extension.IExtensionFilter;

/**
 * ����֧��IExtensionFilter��<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ExtensionFilterManager.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/04/27 10:42:26  wanglei
 * Add:֧�ֶ���չ����й��ˡ�
 *
 */
public final class ExtensionFilterManager{

	private static final String EXTENSION_POINT_ID = "com.primeton.studio.core.extensionFilter";

	private static final String EXTENSION_POINT = "extensionPoint";

	private static final ExtensionFilterManager instance = new ExtensionFilterManager();

	private Map filters = new HashMap();

	/**
	 *
	 */
	private ExtensionFilterManager() {
		super();
		load();
	}

	/**
	 * @return Returns the instance.
	 */
	public static ExtensionFilterManager getInstance() {
		return instance;
	}

	/**
	 * ����չ�㡰com.primeton.studio.core.extensionFilter���м��ء�<BR>
	 *
	 */
	private void load() {

		IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(EXTENSION_POINT_ID);
		IExtension[] extensions = extensionPoint.getExtensions();

		for (int i = 0; i < extensions.length; i++) {
			IExtension extension = extensions[i];
			IConfigurationElement[] configurationNodes = extension.getConfigurationElements();

			for (int j = 0; j < configurationNodes.length; j++) {
				IConfigurationElement configurationNode = configurationNodes[j];

				try {
					Object object = configurationNode.createExecutableExtension(IConstant.CLASS_NAME);
					String extensionPointID = configurationNode.getAttribute(EXTENSION_POINT);

					if (object instanceof IExtensionFilter) {

						List list = (List) this.filters.get(extensionPointID);
						if (null == list) {
							list = new ArrayList();
							this.filters.put(extensionPointID, list);
						}

						list.add(object);
					}

				} catch (CoreException e) {
					ILog log = CoreActivator.getDefault().getLog();
					log.log(e.getStatus());
				}
			}
		}
	}
	
	/**
	 * ������չ�ӽڵ�
	 * @param toFilterExtension
	 * @return
	 */
	public IConfigurationElement[] doFilterChildren(IExtension toFilterExtension, IAdaptable adaptable) {
		List filterList = (List) this.filters.get(toFilterExtension.getExtensionPointUniqueIdentifier());
		IConfigurationElement[] configurationElements = toFilterExtension.getConfigurationElements();
		return doFilter(filterList, toFilterExtension, configurationElements, adaptable);
	}

	/**
	 * @param filterList
	 * @param configurationElements
	 * @return
	 */
	private IConfigurationElement[] doFilter(List filterList, IExtension rootFilterExtension, IConfigurationElement[] configurationElements, IAdaptable adaptable) {
		if (CollectionUtils.isEmpty(filterList)) {
			return configurationElements;
		}
		
		for (int i = 0; i < filterList.size(); i++) {
			IExtensionFilter extensionFilter = (IExtensionFilter) filterList.get(i);
			try {
				configurationElements = extensionFilter.doFilter(rootFilterExtension,configurationElements,adaptable);
			} catch (Exception e) {
				ExceptionUtil.getInstance().logException(e);
			}
		}
		return configurationElements;
	}
	
	/**
	 * @param parentElement
	 * @return
	 */
//	public IConfigurationElement[] doFilterChildren(IConfigurationElement parentElement, IAdaptable adaptable){
//		List filterList = (List) this.filters.get(parentElement.getDeclaringExtension().getExtensionPointUniqueIdentifier());
//		IConfigurationElement[] configurationElements = parentElement.getChildren();
//		return doFilter(filterList, configurationElements,adaptable);
//	}
}
