/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.util.entry;

import com.primeton.studio.core.ICloneable;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ֧�����ַ�ΪKey�ļ�ֵ�ԡ�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The entry with a key of String. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-5-1 14:00:10
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: StringMapEntry.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2008/03/18 05:17:49  wanglei
 * Update:����toString������
 *
 * Revision 1.4  2007/03/05 06:01:57  wanglei
 * �ύ��CVS
 *
 */
public class StringMapEntry implements ICloneable
{
	private String key;

	private Object value;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * Constructs a new <Code>DefaultMapEntry</Code> with a null key and null value.
	 */
	public StringMapEntry()
	{
		//
	}

	/**
	 * ͨ�������������<BR>
	 *
	 * Constructs a new <Code>StringMapEntry</Code> with the given key and given value.
	 *
	 * @param r_Key
	 *            the key for the entry, may be null
	 * @param r_Value
	 *            the value for the entyr, may be null
	 */
	public StringMapEntry(String r_Key, Object r_Value)
	{
		this.key = r_Key;
		this.value = r_Value;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object r_Value)
	{
		if (null == r_Value)
		{
			return false;
		}
		if (this == r_Value)
		{
			return true;
		}

		if (!(r_Value instanceof StringMapEntry))
		{
			return false;
		}
		final StringMapEntry t_Value = (StringMapEntry) r_Value;
		return ((getKey() == null ? t_Value.getKey() == null : getKey().equals(t_Value.getKey())) && (getValue() == null ? t_Value.getValue() == null : getValue().equals(t_Value.getValue())));
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode()
	{
		return ((getKey() == null ? 0 : getKey().hashCode()) ^ (getValue() == null ? 0 : getValue().hashCode()));
	}

	/**
	 * ���ؼ�ֵ��<BR>
	 *
	 * Returns the key.
	 */
	public String getKey()
	{
		return this.key;
	}

	/**
	 * ����ֵ��<BR>
	 *
	 * Returns the value.
	 *
	 */
	public Object getValue()
	{
		return this.value;
	}

	/**
	 * ���ü�ֵ��<BR>
	 *
	 * Sets the key. This method does not modify any map.
	 *
	 * @param r_Key
	 *            the new key
	 */
	public void setKey(final String r_Key)
	{
		this.key = r_Key;
	}

	/**
	 * ���ö���ֵ��<BR>
	 *
	 * Note that this method only sets the local reference inside this object and does not modify the original Map.
	 *
	 * @return the old value of the value
	 * @param r_Value
	 *            the new value
	 */
	public void setValue(final Object r_Value)
	{
		this.value = r_Value;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#clone()
	 */
	public Object clone()
	{
		final StringMapEntry t_Entry = new StringMapEntry();
		t_Entry.key = this.key;

		if (this.value instanceof ICloneable)
		{
			t_Entry.value = ((ICloneable) this.value).clone();
		}
		else
		{
			t_Entry.value = this.value;
		}

		return t_Entry;
	}

	/**
	 * {@inheritDoc}
	 */
	public String toString() {

		return this.key+"="+this.value;
	}


}
