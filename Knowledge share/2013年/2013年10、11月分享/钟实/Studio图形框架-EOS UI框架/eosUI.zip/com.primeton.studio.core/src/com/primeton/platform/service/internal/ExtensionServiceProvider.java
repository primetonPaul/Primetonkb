/**
 *
 */
package com.primeton.platform.service.internal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;

import com.primeton.platform.service.IServiceManager;
import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.ServiceContext;
import com.primeton.platform.service.VersionRange;
import com.primeton.platform.service.base.AbstractServiceProvider;
import com.primeton.platform.service.spi.IServiceFilter;
import com.primeton.platform.service.spi.IServiceProvider;

/**
 *
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����֧��ͨ����չ����ע�����<BR>
 *
 * <strong>English Doc��</strong><BR>
 * Support service injection by extension.<BR>
 *
 * Created Time: 2009-8-14 ����02:46:18
 * @author @author wanglei (mailto:wanglei@primeton.com)
 *
 */
/*
 * Update History
 *
 * $Log: ExtensionServiceProvider.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/05/14 05:00:03  wanglei
 * Jira:����EOSP-243��
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 *
 */
class ExtensionServiceProvider extends AbstractServiceProvider implements IServiceProvider {

	private static final String SERVICE_EXTENSION = "com.primeton.studio.core.service";

	public static final String INTERFACE = "interface";

	public static final String IMPLEMENTATION = "implementation";

	public static final String KEY = "key";

	public static final String VALUE = "value";

	private Map services = new HashMap();

	private static final ExtensionServiceProvider instance = new ExtensionServiceProvider();

	/**
	 *
	 */
	private ExtensionServiceProvider() {
		super();
	}

	/**
	 * @return the instance
	 */
	public static ExtensionServiceProvider getInstance() {
		return instance;
	}

	/**
	 *
	 */
	void load(final IServiceManager serviceManager) {

		ExtensionHelper.loadExtension(new IConfigurationNodeLoader() {

			/**
			 *
			 * {@inheritDoc}
			 */
			public void load(IConfigurationElement configurationNode) throws CoreException {

				String interfaceName = configurationNode.getAttribute(INTERFACE);
				ExtensionServiceFactory serviceFactory = new ExtensionServiceFactory(configurationNode);
				serviceFactory.load(serviceManager);

				List list = (List) services.get(interfaceName);
				if (null == list) {
					list = new ArrayList();
					services.put(interfaceName, list);
				}

				list.add(serviceFactory);

			}
		}, SERVICE_EXTENSION);
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference findServiceReference(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		List list = (List) services.get(interfaceName);
		if (null == list) {
			return null;
		}

		for (int i = 0; i < list.size(); i++) {
			ExtensionServiceFactory factory = (ExtensionServiceFactory) list.get(i);
			if ((null == serviceFilter) || (serviceFilter.isAcceptable(factory.getServiceReference()))) {
				return factory.getServiceReference();
			}
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference[] findServiceReferences(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		List list = (List) services.get(interfaceName);
		if (null == list || list.isEmpty()) {
			return new IServiceReference[0];
		}

		List referenceList = new ArrayList();

		for (int i = 0; i < list.size(); i++) {
			ExtensionServiceFactory factory = (ExtensionServiceFactory) list.get(i);
			if ((null == serviceFilter) || (serviceFilter.isAcceptable(factory.getServiceReference()))) {
				referenceList.add(factory.getServiceReference());
			}
		}

		IServiceReference[] results = new IServiceReference[referenceList.size()];
		referenceList.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getPriority() {
		return Integer.MAX_VALUE;
	}

}
