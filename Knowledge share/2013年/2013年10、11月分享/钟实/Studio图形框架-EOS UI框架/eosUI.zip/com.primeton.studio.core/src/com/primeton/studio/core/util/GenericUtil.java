/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.util;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.primeton.studio.core.IConstant;

/**
 * �������͡�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: GenericUtil.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/08/15 07:12:35  wanglei
 * �ύ��CVS��
 *
 */
public class GenericUtil {

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private GenericUtil() {
		super();
	}

	/**
	 * �õ�һ�����ȫ����<BR>
	 * ����������з�����Ϣ���ͻ᷵�����硣<BR>
	 * <CODE>java.util.Map<java.lang.String[], java.util.Map<java.lang.String[][], java.util.List<java.lang.String>>>[][][][] names;</CODE><BR>
	 *
	 * return the full name of a class.<BR>
	 * If the class has generic types,it will return:<BR>
	 * <CODE>java.util.Map<java.lang.String[], java.util.Map<java.lang.String[][], java.util.List<java.lang.String>>>[][][][] names;</CODE><BR>
	 *
	 * @param r_Class
	 * @param r_GenericType
	 *
	 */
	public static String getName(Class r_Class, Type r_GenericType) {

		List t_List = new ArrayList();

		if (null != r_GenericType) {
			parseTypeForName(r_GenericType, t_List);
		}

		Collections.reverse(t_List);
		return StringUtils.join(t_List.iterator(), "");
	}

	/**
	 * �������з�����Ϣ�����ݣ��Ի�ȡȫ����<BR>
	 *
	 * @param r_GenericType
	 * @param r_List
	 */
	private static void parseTypeForName(Type r_GenericType, List r_List) {

		if (r_GenericType instanceof GenericArrayType) {
			GenericArrayType t_ArrayType = (GenericArrayType) r_GenericType;
			r_List.add(IConstant.CLASS_ARRAY);

			parseTypeForName(t_ArrayType.getGenericComponentType(), r_List);
			return;
		}

		if (r_GenericType instanceof ParameterizedType) {
			ParameterizedType t_ParameterizedType = (ParameterizedType) r_GenericType;

			Type[] t_Types = t_ParameterizedType.getActualTypeArguments();

			if (!ArrayUtils.isEmpty(t_Types)) {
				r_List.add(IConstant.CLASS_GENERIC_END);

				for (int i = t_Types.length - 1; i >= 0; i--) {
					Type t_Type = t_Types[i];
					parseTypeForName(t_Type, r_List);

					if (t_Types.length > 1 && i != 0) {
						r_List.add(",");
					}
				}

				r_List.add(IConstant.CLASS_GENERIC_START);
			}

			Type t_RawType = t_ParameterizedType.getRawType();
			parseTypeForName(t_RawType, r_List);

			return;
		}

		if (r_GenericType instanceof Class) {
			Class t_Class = (Class) r_GenericType;
			r_List.add(t_Class.getName());
		}

	}

}
