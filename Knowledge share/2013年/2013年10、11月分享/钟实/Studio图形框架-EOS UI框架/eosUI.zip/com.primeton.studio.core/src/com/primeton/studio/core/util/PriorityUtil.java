/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/util/PriorityUtil.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-10-13
 *******************************************************************************/

package com.primeton.studio.core.util;

import java.util.HashMap;
import java.util.Map;

/**
 * ��������һЩ���ȼ������ݡ�<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: PriorityUtil.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/04/08 05:23:41  wanglei
 * Add:�ύ��CVS��
 *
 */
public class PriorityUtil {

	private static Map priorityMap = new HashMap();

	public static final String LOWEST = "lowest";

	public static final String LOWER = "lower";

	public static final String LOW = "low";

	public static final String HIGH = "high";

	public static final String HIGHER = "higher";

	public static final String HIGHEST = "highest";

	static {
		priorityMap.put("lowest", new Integer(-100));
		priorityMap.put("lower", new Integer(-60));
		priorityMap.put("low", new Integer(-30));
		priorityMap.put("high", new Integer(30));
		priorityMap.put("higher", new Integer(60));
		priorityMap.put("highest", new Integer(100));
	}

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 */
	private PriorityUtil() {
		super();
	}

	/**
	 *
	 * @param r_Priority
	 * @return
	 */
	public static int getPriority(String r_Priority) {

		if (null == r_Priority) {
			return 0;
		}

		Integer t_Value = (Integer) priorityMap.get(r_Priority.toLowerCase());
		if (null == t_Value) {
			return 0;
		} else {
			return t_Value.intValue();
		}
	}

}
