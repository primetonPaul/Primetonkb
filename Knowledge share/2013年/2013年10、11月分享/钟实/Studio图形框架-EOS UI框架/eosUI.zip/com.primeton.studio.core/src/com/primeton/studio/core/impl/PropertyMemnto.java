/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.impl;

import com.eos.system.utility.ObjectUtil;
import com.primeton.studio.core.IMemento;
import com.primeton.studio.core.Introspector;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����������󵥸����Եı��ݡ�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * To handle the backup a property of the specified object. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2007-2-9 ����04:36:35
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: PropertyMemnto.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2007/12/19 01:14:34  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.4  2007/06/26 01:10:57  caijing
 * update���ṩһ��get����
 *
 * Revision 1.3  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */

public class PropertyMemnto implements IMemento
{
	private Introspector introspector;

	private Object element;

	private Object value;

	private String propertyName;

	/**
	 * 
	 * ���캯����<BR>
	 * 
	 * The constructor.<BR>
	 * 
	 * @param r_Introspector
	 *            the value accessor
	 * @param r_Element
	 *            the object to memnto.
	 * @param r_PropertyName
	 *            the property name to backup value.
	 */
	public PropertyMemnto(Introspector r_Introspector, Object r_Element, String r_PropertyName)
	{
		super();
		this.introspector = r_Introspector;
		this.element = r_Element;
		this.propertyName = r_PropertyName;

		this.backup();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMemento#backup()
	 */
	public void backup()
	{
		Object t_Value = this.introspector.getValue(this.element, this.propertyName);
		this.value = ObjectUtil.copyValue(t_Value);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMemento#restore()
	 */
	public void restore()
	{
		this.introspector.setValue(this.element, this.propertyName, this.value);
	}

	/**
	 * @return Returns the element.
	 */
	public Object getElement() {
		return element;
	}

	/**
	 * @return Returns the introspector.
	 */
	public Introspector getIntrospector() {
		return introspector;
	}

	/**
	 * @return Returns the propertyName.
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/**
	 * @return Returns the value.
	 */
	public Object getValue() {
		return value;
	}
	
	
	
}
