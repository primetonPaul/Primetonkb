/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/platform/service/internal/IConfigurationNodeLoader.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-12-21
 *******************************************************************************/


package com.primeton.platform.service.internal;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IConfigurationNodeLoader.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 */
public interface IConfigurationNodeLoader {
	public void load(IConfigurationElement configurationNode) throws CoreException;
}
