/**
 * 
 */
package com.primeton.platform.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����������<BR>
 *
 * <strong>English Doc��</strong><BR>
 * The context for service.<BR>
 * 
 * Created Time: 2009-8-14 ����02:36:10
 * @author @author wanglei (mailto:wanglei@primeton.com)
 * 
 */
/*
 * Update History
 *
 * $Log: ServiceContext.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 *
 */
public final class ServiceContext {

	private String bundleName;

	private Map properties = new HashMap();

	/**
	 * �������ⲿ�����ö���<BR>
	 * 
	 * The external users can't create a instance.<BR>
	 * 
	 */
	private ServiceContext(String bundleName) {
		super();
		this.bundleName = bundleName;
	}

	/**
	 * Returns the property value to which the specified property key is mapped
	 * in the properties <code>Dictionary</code> object of the service
	 * referenced by this <code>ServiceReference</code> object.
	 * 
	 * <p>
	 * Property keys are case-insensitive.
	 * 
	 * <p>
	 * This method must continue to return property values after the service has
	 * been unregistered. This is so references to unregistered services (for
	 * example, <code>ServiceReference</code> objects stored in the log) can
	 * still be interrogated.
	 * 
	 * @param key The property key.
	 * @return The property value to which the key is mapped; <code>null</code>
	 *         if there is no property named after the key.
	 */
	public Object getProperty(String key) {
		return this.properties.get(key);
	}

	/**
	 * Returns an array of the keys in the properties <code>Dictionary</code>
	 * object of the service referenced by this <code>ServiceReference</code>
	 * object.
	 * 
	 * <p>
	 * This method will continue to return the keys after the service has been
	 * unregistered. This is so references to unregistered services (for
	 * example, <code>ServiceReference</code> objects stored in the log) can
	 * still be interrogated.
	 * 
	 * <p>
	 * This method is <i>case-preserving </i>; this means that every key in the
	 * returned array must have the same case as the corresponding key in the
	 * properties <code>Dictionary</code> that was passed to the
	 * {@link BundleContext#registerService(String[],Object,java.util.Dictionary)}
	 * or {@link ServiceRegistration#setProperties} methods.
	 * 
	 * @return An array of property keys.
	 */
	public String[] getPropertyKeys() {
		Set keySet = this.properties.keySet();
		String[] values = new String[keySet.size()];
		keySet.toArray(values);
		return values;
	}

	/**
	 * ��������ֵ��<BR>
	 * 
	 * Set the property value.<BR>
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	public Object setProperty(String key, Object value) {
		return this.properties.get(key);
	}

	/**
	 * @return the bundleName
	 */
	public String getBundleName() {
		return bundleName;
	}

	/**
	 * Ϊ��Ӧ��Bundle�������������ġ�<BR>
	 * 
	 * Create a service context for the specified bundle.<BR>
	 * 
	 * @param bundleName
	 * @return
	 */
	public static ServiceContext createContext(String bundleName) {
		return new ServiceContext(bundleName);
	}

	/**
	 * ΪĬ�ϵ�Bundle�������������ġ�<BR>
	 * 
	 * Create a service context for the default bundle.<BR>
	 * 
	 * @param bundleName
	 * @return
	 */
	public static ServiceContext createContext() {
		return new ServiceContext(null);
	}
}
