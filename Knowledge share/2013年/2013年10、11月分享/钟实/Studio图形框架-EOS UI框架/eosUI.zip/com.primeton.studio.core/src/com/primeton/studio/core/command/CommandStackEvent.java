/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.command;

import com.primeton.studio.core.ICommand;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * Command�Ķ�ջ�仯��֪ͨ�¼���<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The event for the change for the command stack. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-12-23 ����02:56:05
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: CommandStackEvent.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */

public class CommandStackEvent
{
	private final ICommand command;

	private final int detail;

	/**
	 * Constructs a new event instance. The stack specifies the source of the event. If a command is relevant to the
	 * event context, one should be specified. The detail indicates the type of event occurring.
	 * 
	 * @param r_CommandStack
	 *            the command stack
	 * @param r_Command
	 *            a command or <code>null</code>
	 * @param r_Detail
	 *            an integer identifier
	 */
	public CommandStackEvent(CommandStack r_CommandStack, ICommand r_Command, int r_Detail)
	{
		this.command = r_Command;
		this.detail = r_Detail;
	}

	/**
	 * Returns <code>null</code> or a Command if a command is relevant to the current event.
	 * 
	 * 
	 * @return <code>null</code> or a command
	 */
	public ICommand getCommand()
	{
		return this.command;
	}

	/**
	 * Returns <code>true</code> if this event is fired prior to the stack changing.
	 * 
	 * @return <code>true</code> if pre-change event
	 * 
	 */
	public final boolean isPreChangeEvent()
	{
		return 0 != (getDetail() & CommandStack.PRE_MASK);
	}

	/**
	 * Returns <code>true</code> if this event is fired after the stack having changed.
	 * 
	 * @return <code>true</code> if post-change event
	 * 
	 */
	public final boolean isPostChangeEvent()
	{
		return 0 != (getDetail() & CommandStack.POST_MASK);
	}

	/**
	 * Returns an integer identifying the type of event which has occurred.
	 * 
	 * @return the detail of the event
	 */
	public int getDetail()
	{
		return this.detail;
	}

}
