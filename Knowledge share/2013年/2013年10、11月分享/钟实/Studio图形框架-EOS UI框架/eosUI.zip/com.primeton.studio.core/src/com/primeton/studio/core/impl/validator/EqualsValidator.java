/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/impl/validator/EqualsValidator.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-4-7
 *******************************************************************************/


package com.primeton.studio.core.impl.validator;

import org.eclipse.core.runtime.IAdapterFactory;

import com.primeton.studio.core.IMessageCaller;

/**
 * �����֤��.
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: EqualsValidator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/08 02:37:16  zhuxing
 * New:����equals validator
 * 
 */
public class EqualsValidator extends AbstractValidator {
	private Object target;
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.core.impl.validator.AbstractValidator#doValidate(java.lang.Object, org.eclipse.core.runtime.IAdapterFactory, com.primeton.studio.core.IMessageCaller)
	 */
	@Override
	protected boolean doValidate(Object r_Value,
			IAdapterFactory r_AdapterFactory, IMessageCaller r_MessageCaller) {
		if (target == null)
			return false;
		
		return target.equals(r_Value);
	}

	/**
	 * @return Returns the target.
	 */
	public Object getTarget() {
		return target;
	}

	/**
	 * @param target The target to set.
	 */
	public void setTarget(Object target) {
		this.target = target;
	}

	
}
