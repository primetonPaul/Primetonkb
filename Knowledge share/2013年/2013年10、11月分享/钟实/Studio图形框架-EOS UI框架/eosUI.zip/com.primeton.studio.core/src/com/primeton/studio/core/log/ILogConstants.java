/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/log/ILogConstants.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2007-4-11
 *******************************************************************************/


package com.primeton.studio.core.log;

/**
 * Log ��������
 *
 * @author jiaoly (mailto:jiaoly@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ILogConstants.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/05/12 07:53:10  jiaoly
 * Update���޸ĳ�����ʹ�� Server ���ṩ�Ľӿ�
 *
 * Revision 1.1  2007/04/24 02:39:54  yangjun
 * Add:�ύ��CVS
 *
 * Revision 1.1  2007/04/20 10:15:52  yangjun
 * Add: �ύ��CVS
 *
 * Revision 1.1  2007/04/11 05:39:49  jiaoly
 * Update���ύ log ����
 * 
 */
public interface ILogConstants {
	public final String DEBUG = "debug";
	public final String INFO = "info";
	public final String WARN = "warn";
	public final String ERROR = "error";
	public final String FATAL = "fatal";
	
	public final String PRODUCT_PIX = "<$p_";
	public final String BUNDLE_PIX = "<$c_";
}
