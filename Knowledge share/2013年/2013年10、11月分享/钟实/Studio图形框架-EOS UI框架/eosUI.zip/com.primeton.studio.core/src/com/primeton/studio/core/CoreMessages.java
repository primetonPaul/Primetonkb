/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/CoreMessages.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-12-13
 *******************************************************************************/


package com.primeton.studio.core;

import org.eclipse.osgi.util.NLS;

/**
 * ���ʻ�������
 *
 * @author yuhl (mailto:yuhl@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: CoreMessages.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/04/22 01:24:56  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/12/13 05:20:30  yuhl
 * Update:���ʻ�
 *
 */
public class CoreMessages extends NLS {

	private static final String BUNDLE_NAME = CoreMessages.class.getName();;

	private CoreMessages() {
	}

	static {
		NLS.initializeMessages(BUNDLE_NAME, CoreMessages.class);
	}

	public static String AbstractContent_FILE_PATH_NULL;
	public static String AbstractPropertyTranslator_NO_OVERRID_METHOD;
	public static String ArrayUtil_BOTH_NOT_NULL;
	public static String ArrayUtil_FIRST_NOT_ARRAY;
	public static String ArrayUtil_SECOND_NOT_ARRAY;
	public static String DefaultTreeNode_ARGUMENT_ERROR;
	public static String DefaultTreeNode_ARGUMENT_NULL;
	public static String DefaultTreeNode_CHILD_ERROR;
	public static String DefaultTreeNode_CHILD_NULL;
	public static String MapIntrospector_PREPERTY_NAME_NULL;
	public static String MapIntrospector_TARGET_OBJECT_ERROR;
	public static String NamingRuleValidator_NAME_ERROR;
	public static String NamingRuleValidator_NAME_LONG;
	public static String PropertySetting;
	public static String TARGET_OBJECT_NULL;
	public static String NAMING_ERROR;
	public static String FILE_NOT_EXIST;
	public static String CLASS_NAME_NULL;
	public static String SRC_DIR_UNREADABLE;
	public static String DEST_DIR_EXIST;
	public static String SAME_SRC_DEST;
	public static String CREATE_DEST_DIR_FAILED;
	public static String SRC_NULL;
	public static String DEST_NULL;
	public static String CREATE_DIR;
}
