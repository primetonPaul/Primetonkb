/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.service.impl;

import com.primeton.studio.core.impl.MapIntrospector;
import com.primeton.studio.core.impl.PropertyIntrospector;
import com.primeton.studio.core.impl.validator.EmailValidator;
import com.primeton.studio.core.impl.validator.IntRangeValidator;
import com.primeton.studio.core.impl.validator.IntValidator;
import com.primeton.studio.core.impl.validator.LengthValidator;
import com.primeton.studio.core.impl.validator.NotBlankValidator;
import com.primeton.studio.core.impl.validator.NotEmptyValidator;
import com.primeton.studio.core.impl.validator.PatternValidator;
import com.primeton.studio.core.impl.validator.ReverseValidator;
import com.primeton.studio.core.impl.validator.UniqueStringValidator;
import com.primeton.studio.core.impl.validator.WordValidator;
import com.primeton.studio.core.impl.validator.compound.AndCompoundValidator;
import com.primeton.studio.core.impl.validator.compound.OrCompoundValidator;
import com.primeton.studio.core.impl.validator.io.DirectoryExistValidator;
import com.primeton.studio.core.impl.validator.io.FileExtensionNameValidator;
import com.primeton.studio.core.impl.validator.io.FileNameValidator;
import com.primeton.studio.core.impl.validator.io.FileNotExistValidator;
import com.primeton.studio.core.impl.validator.property.AndCompoundPropertyValidator;
import com.primeton.studio.core.impl.validator.property.OrCompoundPropertyValidator;
import com.primeton.studio.core.impl.validator.property.PropertyDelegateValidator;
import com.primeton.studio.core.model.impl.ListProvider;
import com.primeton.studio.core.model.impl.MapProvider;
import com.primeton.studio.core.service.base.AbstractXmlAliasNaming;
import com.primeton.studio.core.util.entry.MapEntry;
import com.primeton.studio.core.util.entry.StringMapEntry;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * Ϊ"Core"���е����ṩ������<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Provide alias for common classes of "aquarius core". <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-9-16 ����10:22:46
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: CoreXmlAliasNaming.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2007/04/10 09:28:19  wanglei
 * Remove:��������org.eclipse.resources������ȫ���Ƴ���
 *
 * Revision 1.5  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public final class CoreXmlAliasNaming extends AbstractXmlAliasNaming
{

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public CoreXmlAliasNaming()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.service.IXmlAliasNaming#doNaming()
	 */
	public void doNaming()
	{
		this.registerAlias(AndCompoundValidator.class);
		this.registerAlias(OrCompoundValidator.class);
		this.registerAlias(DirectoryExistValidator.class);
		this.registerAlias(FileExtensionNameValidator.class);
		this.registerAlias(FileNotExistValidator.class);
		this.registerAlias(FileNameValidator.class);
		this.registerAlias(IntValidator.class);
		this.registerAlias(LengthValidator.class);
		this.registerAlias(NotBlankValidator.class);
		this.registerAlias(NotEmptyValidator.class);
		this.registerAlias(PatternValidator.class);
		this.registerAlias(EmailValidator.class);
		this.registerAlias(WordValidator.class);
		this.registerAlias(UniqueStringValidator.class);
		this.registerAlias(IntRangeValidator.class);
		this.registerAlias(PropertyDelegateValidator.class);
		this.registerAlias(AndCompoundPropertyValidator.class);
		this.registerAlias(OrCompoundPropertyValidator.class);
		this.registerAlias(ReverseValidator.class);

		this.registerAlias(ListProvider.class);
		this.registerAlias(MapProvider.class);

		this.registerAlias(MapEntry.class);
		this.registerAlias(StringMapEntry.class);

		this.registerAlias(PropertyIntrospector.class);
		this.registerAlias(MapIntrospector.class);

	}
}
