/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.util;

import java.util.HashMap;
import java.util.Map;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����ԭʼ�������͡�
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The helper to handle primitive types.
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 11:15:51
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: PrimitiveUtil.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/04/28 02:25:03  wanglei
 * �ύ��CVS��
 *
 */

public class PrimitiveUtil {

	private static final Map PrimitiveValues = new HashMap();

	private static final Map PrimitiveTypes = new HashMap();

	static {
		loadTypes();
		loadValues();

	}

	/**
	 * ������ͨ�������͵�ԭʼ���͵�ӳ���ϵ��
	 */
	private static void loadTypes() {
		PrimitiveTypes.put(Boolean.class, boolean.class);
		PrimitiveTypes.put(Integer.class, int.class);
		PrimitiveTypes.put(Float.class, float.class);
		PrimitiveTypes.put(Double.class, double.class);
		PrimitiveTypes.put(Long.class, long.class);
		PrimitiveTypes.put(Short.class, short.class);
		PrimitiveTypes.put(Byte.class, byte.class);
	}

	/**
	 * ����ԭʼ���͵�Ĭ��ֵ��<BR>
	 */
	private static void loadValues() {
		PrimitiveValues.put(boolean.class, Boolean.FALSE);
		PrimitiveValues.put(Boolean.class, Boolean.FALSE);

		PrimitiveValues.put(int.class, new Integer(0));
		PrimitiveValues.put(Integer.class, new Integer(0));

		PrimitiveValues.put(float.class, new Float(0));
		PrimitiveValues.put(Float.class, new Float(0));

		PrimitiveValues.put(double.class, new Double(0));
		PrimitiveValues.put(Double.class, new Double(0));

		PrimitiveValues.put(long.class, new Long(0));
		PrimitiveValues.put(Long.class, new Long(0));

		PrimitiveValues.put(short.class, new Short((short) 0));
		PrimitiveValues.put(Short.class, new Short((short) 0));

		PrimitiveValues.put(byte.class, new Byte((byte) 0));
		PrimitiveValues.put(Byte.class, new Byte((byte) 0));
	}

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	public PrimitiveUtil() {
		super();
	}

	/**
	 * ������ͨ��������ӳ���ԭʼ���͡�
	 *
	 * Return the primitive type for the class.<BR>
	 *
	 * @param r_Type
	 *
	 */
	public static Class getPrimitiveClass(Class r_Type)
	{
		return (Class) PrimitiveTypes.get(r_Type);
	}

	/**
	 * ����ԭʼ���͵�Ĭ��ֵ��
	 *
	 * Return the primitive type for the class.<BR>
	 *
	 * @param r_Type
	 *
	 */
	public static Object getDefaultPrimitiveValue(Class r_Type)
	{
		return  PrimitiveValues.get(r_Type);
	}

}
