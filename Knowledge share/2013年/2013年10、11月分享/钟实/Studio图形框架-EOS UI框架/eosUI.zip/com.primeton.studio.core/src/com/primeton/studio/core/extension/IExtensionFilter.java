/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/extension/IExtensionFilter.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2010-4-27
 *******************************************************************************/


package com.primeton.studio.core.extension;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;

/**
 * ��������һ����չ�����ã����Ƿ���ܸ���չ�㡣<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IExtensionFilter.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/04/27 10:42:26  wanglei
 * Add:֧�ֶ���չ����й��ˡ�
 *
 */
public interface IExtensionFilter {
	
	/**
	 * ���˵������в���Ҫ��IConfigurationElement�ڵ㡣<BR>
	 * @param rootFilterExtension IConfigurationElement ���ڵ�Extension�ڵ�
	 * @param toFilterElements ��Ҫ���˵Ľڵ㼯��
	 * @param adaptable
	 * @return
	 */
	public IConfigurationElement[] doFilter(IExtension rootFilterExtension, IConfigurationElement[] toFilterElements, IAdaptable adaptable);
}
