/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.util;

import java.lang.reflect.Array;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.eos.system.utility.ArrayUtil;
import com.eos.system.utility.CollectionUtil;

import ognl.DefaultTypeConverter;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �ṩ����ת���Ĳ�������<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Provide the common functions to convert objects. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-9-20 ����04:08:12
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: CovertorUtil.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2007/12/20 01:18:32  wanglei
 * Review:CollectionUtil�е�addAllӦ����addAllQuietly��
 *
 * Revision 1.5  2007/12/19 01:14:35  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public class CovertorUtil
{
	private static final Map Types = new HashMap();

	static
	{
		Types.put(Collection.class, ArrayList.class);
		Types.put(Set.class, HashSet.class);
		Types.put(SortedSet.class, TreeSet.class);
		Types.put(List.class, ArrayList.class);
	}

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 * 
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private CovertorUtil()
	{
		// Nothing to do
	}

	/**
	 * ��ָ���Ķ���ת����ָ�������͡�<BR>
	 * 
	 * Convert a object to another specified type.<BR>
	 * 
	 * @param r_SourceObject
	 *            the object to be converted.
	 * @param r_TargetType
	 *            the target class type for conveting.
	 * 
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public static Object convert(Object r_SourceObject, Class r_TargetType) throws InstantiationException, IllegalAccessException
	{
		if (null == r_SourceObject)
		{
			return null;
		}

		if (null == r_TargetType)
		{
			return r_SourceObject;
		}

		if (r_TargetType.isArray())
		{
			Object[] t_Objects = ArrayUtil.getArrayValues(r_SourceObject);
			Object[] t_Values = (Object[]) Array.newInstance(r_TargetType.getComponentType(), t_Objects.length);

			ArrayUtil.copyArray(t_Objects, t_Values);
			return t_Values;
		}

		if (Collection.class.isAssignableFrom(r_TargetType))
		{
			Collection t_Values;

			if (((r_TargetType.getModifiers() & Modifier.ABSTRACT) == 1) || (r_TargetType.isInterface()))
			{
				Class t_DefaultType = (Class) Types.get(r_TargetType);
				if (null == t_DefaultType)
				{
					return null;
				}
				else
				{
					t_Values = (Collection) t_DefaultType.newInstance();
				}
			}
			else
			{
				t_Values = (Collection) r_TargetType.newInstance();
			}

			Object[] t_Objects = ArrayUtil.getArrayValues(r_SourceObject);
			CollectionUtil.addAllQuietly(t_Values, t_Objects);

			return t_Values;
		}

		return new DefaultTypeConverter().convertValue(new HashMap(), r_SourceObject, r_TargetType);
	}
}
