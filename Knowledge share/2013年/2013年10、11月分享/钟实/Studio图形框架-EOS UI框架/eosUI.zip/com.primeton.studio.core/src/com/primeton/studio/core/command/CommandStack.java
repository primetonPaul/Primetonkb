/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.command;

import java.util.ArrayList;
import java.util.EventObject;
import java.util.List;
import java.util.Stack;

import com.primeton.studio.core.ICommand;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * Command�Ķ�ջ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The stack for command execution. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-12-23 ����02:55:22
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: CommandStack.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */

public final class CommandStack
{
	/**
	 * Constant indicating notification after a command has been executed (value is 8).
	 */
	public static final int POST_EXECUTE = 8;

	/**
	 * Constant indicating notification after a command has been redone (value is 16).
	 */
	public static final int POST_REDO = 16;

	/**
	 * Constant indicating notification after a command has been undone (value is 32).
	 */
	public static final int POST_UNDO = 32;

	static final int POST_MASK = POST_EXECUTE | POST_UNDO | POST_REDO;

	/**
	 * Constant indicating notification prior to executing a command (value is 1).
	 */
	public static final int PRE_EXECUTE = 1;

	/**
	 * Constant indicating notification prior to redoing a command (value is 2).
	 */
	public static final int PRE_REDO = 2;

	/**
	 * Constant indicating notification prior to undoing a command (value is 4).
	 */
	public static final int PRE_UNDO = 4;

	static final int PRE_MASK = PRE_EXECUTE | PRE_UNDO | PRE_REDO;

	private List eventListeners = new ArrayList();

	private Stack redoable = new Stack();

	private int saveLocation = 0;

	private Stack undoable = new Stack();

	private int undoLimit = 0;

	/**
	 * 
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public CommandStack()
	{
		// Nothing to do
	}

	/**
	 * Appends the listener to the list of command stack listeners. Multiple adds result in multiple notifications.
	 * 
	 * @param r_Listener
	 *            the event listener
	 */
	public void addCommandStackEventListener(CommandStackEventListener r_Listener)
	{
		this.eventListeners.add(r_Listener);
	}

	/**
	 * Removes the first occurrence of the specified listener.
	 * 
	 * @param r_Listener
	 *            the listener
	 */
	public void removeCommandStackEventListener(CommandStackEventListener r_Listener)
	{
		this.eventListeners.remove(r_Listener);
	}

	/**
	 * @return <code>true</code> if it is appropriate to call {@link #redo()}.
	 */
	public boolean canRedo()
	{
		return !this.redoable.isEmpty();
	}

	/**
	 * @return <code>true</code> if {@link #undo()} can be called
	 */
	public boolean canUndo()
	{
		if (this.undoable.size() == 0)
		{
			return false;
		}
		return ((ICommand) this.undoable.lastElement()).canUndo();
	}

	/**
	 * Executes the specified ICommand if possible. Prior to executing the ICommand, a CommandStackEvent for
	 * {@link #PRE_EXECUTE} will be fired to event listeners. Similarly, after attempting to execute the ICommand, an
	 * event for {@link #POST_EXECUTE} will be fired. If the execution of the ICommand completely normally, stack
	 * listeners will receive {@link CommandStackListener#commandStackChanged(EventObject) stackChanged} notification.
	 * <P>
	 * If the ICommand is <code>null</code> or cannot be executed, nothing happens.
	 * 
	 * @param ICommand
	 *            the ICommand to execute
	 * @see CommandStackEventListener
	 */
	public void execute(ICommand r_Command)
	{
		if (r_Command == null || !r_Command.canExecute())
		{
			return;
		}

		notifyListeners(r_Command, PRE_EXECUTE);
		try
		{
			r_Command.execute();

			if (getUndoLimit() > 0)
			{
				while (this.undoable.size() >= getUndoLimit())
				{
					if (this.saveLocation > -1)
					{
						this.saveLocation--;
					}
				}
			}
			if (this.saveLocation > this.undoable.size())
			{
				this.saveLocation = -1; // The save point was somewhere in the redo stack
			}
			this.undoable.push(r_Command);
		}
		finally
		{
			notifyListeners(r_Command, POST_EXECUTE);
		}
	}

	/**
	 * ��ձ���㡣<BR>
	 * 
	 * Clear the save point.<BR>
	 * 
	 */
	public void flush()
	{
		this.saveLocation = 0;
	}

	/**
	 * @return an array containing all commands in the order they were executed
	 */
	public ICommand[] getCommands()
	{
		List t_CommandList = new ArrayList(this.undoable);
		for (int i = this.redoable.size() - 1; i >= 0; i--)
		{
			t_CommandList.add(this.redoable.get(i));
		}

		ICommand[] t_Commands = new ICommand[t_CommandList.size()];
		t_CommandList.toArray(t_Commands);
		return t_Commands;
	}

	/**
	 * Peeks at the top of the <i>redo</i> stack. This is useful for describing to the User what will be redone. The
	 * returned <code>ICommand</code> has a label describing it.
	 * 
	 * @return the top of the <i>redo</i> stack, which may be <code>null</code>
	 */
	public ICommand getRedoCommand()
	{
		return this.redoable.isEmpty() ? null : (ICommand) this.redoable.peek();
	}

	/**
	 * Peeks at the top of the <i>undo</i> stack. This is useful for describing to the User what will be undone. The
	 * returned <code>ICommand</code> has a label describing it.
	 * 
	 * @return the top of the <i>undo</i> stack, which may be <code>null</code>
	 */
	public ICommand getUndoCommand()
	{
		return this.undoable.isEmpty() ? null : (ICommand) this.undoable.peek();
	}

	/**
	 * Returns the undo limit. The undo limit is the maximum number of atomic operations that the User can undo.
	 * <code>-1</code> is used to indicate no limit.
	 * 
	 * @return the undo limit
	 */
	public int getUndoLimit()
	{
		return this.undoLimit;
	}

	/**
	 * Returns true if the stack is dirty. The stack is dirty whenever the last executed or redone ICommand is different
	 * than the ICommand that was at the top of the undo stack when {@link #markSaveLocation()} was last called.
	 * 
	 * @return <code>true</code> if the stack is dirty
	 */
	public boolean isDirty()
	{
		return this.undoable.size() != this.saveLocation;
	}

	/**
	 * Marks the last executed or redone ICommand as the point at which the changes were saved. Calculation of
	 * {@link #isDirty()} will be based on this checkpoint.
	 */
	public void markSaveLocation()
	{
		this.saveLocation = this.undoable.size();
	}

	/**
	 * Calls redo on the ICommand at the top of the <i>redo</i> stack, and pushes that ICommand onto the <i>undo</i>
	 * stack. This method should only be called when {@link #canUndo()} returns <code>true</code>.
	 */
	public void redo()
	{
		if (!canRedo())
		{
			return;
		}

		ICommand command = (ICommand) this.redoable.pop();
		notifyListeners(command, PRE_REDO);
		try
		{
			command.redo();
			this.undoable.push(command);
		}
		finally
		{
			notifyListeners(command, POST_REDO);
		}
	}

	/**
	 * ͨ����������<BR>
	 * 
	 * Notify the listeners.<BR>
	 * 
	 * @param r_Command
	 * @param r_State
	 */
	protected void notifyListeners(ICommand r_Command, int r_State)
	{
		CommandStackEvent event = new CommandStackEvent(this, r_Command, r_State);
		for (int i = 0; i < this.eventListeners.size(); i++)
		{
			((CommandStackEventListener) this.eventListeners.get(i)).stackChanged(event);
		}
	}

	/**
	 * Sets the undo limit. The undo limit is the maximum number of atomic operations that the User can undo.
	 * <code>-1</code> is used to indicate no limit.
	 * 
	 * @param r_UndoLimit
	 *            the undo limit
	 */
	public void setUndoLimit(int r_UndoLimit)
	{
		this.undoLimit = r_UndoLimit;
	}

	/**
	 * Undoes the most recently executed (or redone) ICommand. The ICommand is popped from the undo stack to and pushed
	 * onto the redo stack. This method should only be called when {@link #canUndo()} returns <code>true</code>.
	 */
	public void undo()
	{
		if (!this.canUndo())
		{
			return;
		}

		ICommand command = (ICommand) this.undoable.pop();
		notifyListeners(command, PRE_UNDO);
		try
		{
			command.undo();
			this.redoable.push(command);
		}
		finally
		{
			notifyListeners(command, POST_UNDO);
		}
	}
}
