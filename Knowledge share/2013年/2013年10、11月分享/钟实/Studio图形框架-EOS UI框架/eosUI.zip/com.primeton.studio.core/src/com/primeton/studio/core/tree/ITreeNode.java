/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.tree;

import com.primeton.studio.core.IPropertyAwareElement;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����ṩ�߽ӿڣ�ΪSWT Tree�ṩ���ݺ�����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The interface for a data provider.<BR>
 * It provide the functions of data and order for SWT Tree. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-5-27 ����10:42:40
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ITreeNode.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/05/23 05:17:26  wanglei
 * Add:����clear������
 *
 * Revision 1.2  2007/03/21 11:57:13  wanglei
 * Update:ΪKTree�ṩһЩ������
 *
 *
 * Revision 1.1 2007/03/05 06:01:56 wanglei �ύ��CVS
 *
 */

public interface ITreeNode extends IPropertyAwareElement {
	public static final String Open = "open";

	public static final String Visible = "visible";

	public boolean isExpanded();

	public void setExpanded(boolean r_Expanded);

	public boolean isVisible();

	public boolean isMergeChildren();

	public Object getUserObject();

	public int belongsToCell(int r_Column);

	/**
	 * Returns the child <code>TreeNode</code> at index <code>childIndex</code>.
	 */
	public ITreeNode getChildAt(int r_ChildIndex);

	/**
	 * Removes <code>aChild</code> from this node's child array, giving it a null parent.
	 *
	 * @param r_ChildNode
	 *            a child of this node to remove
	 * @exception IllegalArgumentException
	 *                if <code>aChild</code> is null or is not a child of this node
	 */
	public void remove(ITreeNode r_TreeNode);

	/**
	 * Removes <code>newChild</code> from its present parent (if it has a parent), sets the child's parent to this
	 * node, and then adds the child to this node's child array at index <code>childIndex</code>.
	 * <code>newChild</code> must not be null and must not be an ancestor of this node.
	 *
	 * @param r_ChildNode
	 *            the MutableTreeNode to insert under this node
	 * @param r_ChildIndex
	 *            the index in this node's child array where this node is to be inserted
	 * @exception ArrayIndexOutOfBoundsException
	 *                if <code>childIndex</code> is out of bounds
	 * @exception IllegalArgumentException
	 *                if <code>newChild</code> is null or is an ancestor of this node
	 * @exception IllegalStateException
	 *                if this node does not allow children
	 * @see #isNodeDescendant
	 */
	public void insert(ITreeNode r_ChildNode, int r_ChildIndex);

	/**
	 * Removes <code>newChild</code> from its present parent (if it has a parent), sets the child's parent to this
	 * node, and then adds the child to this node's child array at index <code>childIndex</code>.
	 * <code>newChild</code> must not be null and must not be an ancestor of this node.
	 *
	 * @param r_ChildNode
	 *            the MutableTreeNode to insert under this node
	 * @param r_ChildIndex
	 *            the index in this node's child array where this node is to be inserted
	 * @exception ArrayIndexOutOfBoundsException
	 *                if <code>childIndex</code> is out of bounds
	 * @exception IllegalArgumentException
	 *                if <code>newChild</code> is null or is an ancestor of this node
	 * @exception IllegalStateException
	 *                if this node does not allow children
	 * @see #isNodeDescendant
	 */
	public void set(ITreeNode r_ChildNode, int r_ChildIndex);

	/**
	 * Removes the child at the specified index from this node's children and sets that node's parent to null. The child
	 * node to remove must be a <code>MutableTreeNode</code>.
	 *
	 * @param r_ChildIndex
	 *            the index in this node's child array of the child to remove
	 * @exception ArrayIndexOutOfBoundsException
	 *                if <code>childIndex</code> is out of bounds
	 */
	public void remove(int r_ChildIndex);

	/**
	 * Removes <code>newChild</code> from its parent and makes it a child of this node by adding it to the end of this
	 * node's child array.
	 *
	 * @see #insert
	 * @param r_ChildNode
	 *            node to add as a child of this node
	 * @exception IllegalArgumentException
	 *                if <code>newChild</code> is null
	 * @exception IllegalStateException
	 *                if this node does not allow children
	 */
	public void add(ITreeNode r_ChildNode);

	/**
	 * ���ø��׽�㡣<BR>
	 *
	 * @param r_Parent
	 */
	public void setParent(ITreeNode r_Parent);

	/**
	 * Returns the number of children <code>TreeNode</code>s the receiver contains.
	 */
	public int getChildCount();

	/**
	 * Returns the parent <code>TreeNode</code> of the receiver.
	 */
	public ITreeNode getParent();

	/**
	 * Returns the index of <code>node</code> in the receivers children. If the receiver does not contain
	 * <code>node</code>, -1 will be returned.
	 */
	public int getIndex(ITreeNode r_TreeNode);

	/**
	 * Returns true if the receiver is a leaf.
	 */
	public boolean isLeaf();

	/**
	 * Returns the number of levels above this node -- the distance from the root to this node. If this node is the
	 * root, returns 0.
	 *
	 * @see #getDepth
	 * @return the number of levels above this node
	 */
	public int getLevel();

	/**
	 * ��������ӽ�㡣<BR>
	 *
	 * Remove all the children nodes.<BR>
	 *
	 */
	public void clear();

}
