/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.adapter;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.comparators.ReverseComparator;
import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.expressions.ElementHandler;
import org.eclipse.core.expressions.Expression;
import org.eclipse.core.expressions.ExpressionConverter;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdapterFactory;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.util.PriorityUtil;
import com.primeton.studio.core.util.comparator.PropertyComparator;
import com.primeton.studio.core.util.entry.StringMapEntry;

/**
 * ͨ����չ���������Adapter��<BR>
 * ��Eclipse��Adapter��ȣ���֧������չ��ʹ��expression�����Ը�����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: ExpressionAdapterManager.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/04/08 06:12:53  wanglei
 * Update:���ִ����Ƶ�PriorityUtil���С�
 *
 * Revision 1.2  2008/07/08 07:06:30  wuwj
 * update:��getAdapterFactory().getAdapter()����Ϊnullʱ��������������
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2007/07/23 05:55:46  wanglei
 * Review:������Ľṹ��org.eclipse.core.adapters����һ�£�������adapter�������ý�㡣
 *
 * Revision 1.6  2007/07/19 09:05:18  wanglei
 * Review:ȥ�������õ�println��
 *
 * Revision 1.5  2007/07/05 10:10:41  wanglei
 * UnitTest:��������TreeSet�Ƚ���˳���˵����⡣
 *
 * Revision 1.4  2007/07/05 08:52:18  wanglei
 * UnitTest:�����˴���չ���ж�ȡ��Ϣ��Bug��
 *
 * Revision 1.3  2007/07/03 13:08:49  wanglei
 * UnitTest:����������ʼ��ʱ���Ⱥ�˳�������Bug��
 *
 * Revision 1.2  2007/07/03 07:01:00  wanglei
 * Review:֧�����ȼ���
 *
 * Revision 1.1  2007/07/03 06:20:32  wanglei
 * Add:������չ��com.primeton.studio.core.adapter����Eclipse��Adapter������
 *
 */

public class ExpressionAdapterManager {

	private static final String ExtensionID = "com.primeton.studio.core.adapter";

	private static final String Enablement = "enablement";

	private static final String Adapter = "adapter";

	private static final ExpressionAdapterManager instance = new ExpressionAdapterManager();

	private Map adapterTypes = new HashMap();

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private ExpressionAdapterManager() {
		super();
		load();
	}

	/**
	 *
	 */
	public void load() {
		IExtensionRegistry t_ExtensionRegistry = Platform.getExtensionRegistry();
		IExtensionPoint t_ExtensionPoint = t_ExtensionRegistry.getExtensionPoint(ExtensionID);

		IExtension[] t_Extensions = t_ExtensionPoint.getExtensions();

		for (int i = 0; i < t_Extensions.length; i++) {
			IExtension t_Extension = t_Extensions[i];
			IConfigurationElement[] t_ConfigurationElements = t_Extension.getConfigurationElements();

			for (int j = 0; j < t_ConfigurationElements.length; j++) {
				IConfigurationElement t_ConfigurationElement = t_ConfigurationElements[j];
				this.doLoad(t_ConfigurationElement);
			}
		}
	}

	/**
	 * @param r_ConfigurationElement
	 */
	private void doLoad(IConfigurationElement r_ConfigurationElement) {

		String t_AdaptableType = r_ConfigurationElement.getAttribute(IConstant.ADAPTABLE_TYPE);
		try {
			Object t_Object = r_ConfigurationElement.createExecutableExtension(IConstant.CLASS);

			if (t_Object instanceof IAdapterFactory) {
				StringMapEntry t_Entry = (StringMapEntry) this.adapterTypes.get(t_AdaptableType);
				if (null == t_Entry) {
					t_Entry = new StringMapEntry();
					t_Entry.setKey(t_AdaptableType);
					t_Entry.setValue(this.newSet());
					this.adapterTypes.put(t_AdaptableType, t_Entry);
				}

				final int t_Priority = PriorityUtil.getPriority(r_ConfigurationElement.getAttribute(IConstant.PRIORITY));

				AdapterConfiguration t_Configuration = new AdapterConfiguration();
				t_Configuration.setAdapterFactory((IAdapterFactory) t_Object);
				t_Configuration.setPriority(t_Priority);

				IConfigurationElement[] t_ChildrenConfigurationElements = r_ConfigurationElement.getChildren();
				if (!ArrayUtils.isEmpty(t_ChildrenConfigurationElements)) {

					for (int i = 0; i < t_ChildrenConfigurationElements.length; i++) {
						IConfigurationElement t_Element = t_ChildrenConfigurationElements[i];

						if (Adapter.equals(t_Element.getName())) {
							t_Configuration.addAdapter(t_Element.getAttribute(IConstant.CLASS));
						}

						if (Enablement.equals(t_Element.getName())) {
							Expression t_Expression = ElementHandler.getDefault().create(ExpressionConverter.getDefault(), t_Element);
							t_Configuration.setExpression(t_Expression);
						}
					}
				}

				Collection t_Collection = (Collection) t_Entry.getValue();
				t_Collection.add(t_Configuration);
			}
		} catch (CoreException e) {
			//Nothing to do;
			return;
		}
	}

	/**
	 * @return the instance
	 */
	public static final ExpressionAdapterManager getInstance() {
		return instance;
	}

	/**
	 * ���������Set��<BR>
	 * @return
	 */
	private Set newSet() {
		return new TreeSet(new ReverseComparator(new PropertyComparator(IConstant.PRIORITY)));
	}

	/**
	 * �õ�Adapter��Ķ���<BR>
	 *
	 * @param r_Object
	 * @param r_Adaper
	 * @return
	 */
	public Object getAdapter(Object r_Object, Class r_Adaper) {
		if (null == r_Object || null == r_Adaper) {
			return null;
		}

		StringMapEntry t_Entry = (StringMapEntry) this.adapterTypes.get(r_Object.getClass().getName());
		if (null == t_Entry) {
			return null;
		}

		Collection t_Collection = (Collection) t_Entry.getValue();
		for (Iterator t_Iterator = t_Collection.iterator(); t_Iterator.hasNext();) {
			AdapterConfiguration t_Configuration = (AdapterConfiguration) t_Iterator.next();

			if (t_Configuration.isAdapterable(r_Object, r_Adaper.getName())) {
				Object adapter = t_Configuration.getAdapterFactory().getAdapter(r_Object, r_Adaper);
				if(adapter != null) {
					return adapter;
				}

			}
		}

		return null;
	}

}
