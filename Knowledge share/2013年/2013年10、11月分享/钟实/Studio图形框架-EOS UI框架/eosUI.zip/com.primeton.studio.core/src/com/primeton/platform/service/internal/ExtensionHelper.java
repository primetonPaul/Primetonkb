/**
 *
 */
package com.primeton.platform.service.internal;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.Platform;

import com.primeton.studio.core.activator.CoreActivator;
import com.primeton.studio.core.manager.ExtensionFilterManager;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����࣬��Ҫ��������ɴ���Ļص���<BR>
 *
 * <strong>English Doc��</strong><BR>
 * Helper class to support callback.<BR>
 *
 * @noextend This class is not intended to be extended by clients.
 *
 * Created Time: 2009-8-13 ����10:50:47
 * @author @author wanglei (mailto:wanglei@primeton.com)
 *
 */
/*
 * Update History
 *
 * $Log: ExtensionHelper.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/04/27 10:42:26  wanglei
 * Add:֧�ֶ���չ����й��ˡ�
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 *
 */
public class ExtensionHelper {

	/**
	 * ����̳С�<BR>
	 *
	 * There is no need to extend this class.<BR>
	 *
	 */
	private ExtensionHelper() {
		super();
	}

	/**
	 * ����Eclipse��չ��ʱ������֧�ֻص��ķ�����<BR>
	 * ���ַ�ʽ���ã��������չ���й��ˡ�<BR>
	 *
	 * The method is used to support callback to load extension.<BR>
	 * The extension filters should be diabled.<BR>
	 *
	 * @see IConfigurationNodeLoader#load(IConfigurationNode)
	 * @see #loadExtension(IConfigurationNodeLoader, String, boolean)
	 *
	 * @param loader
	 * @param extensionID
	 */
	public static void loadExtension(IConfigurationNodeLoader loader, String extensionID) {
		loadExtension(loader, extensionID, null, false);
		//��ʹ�ù�������
	}

	/**
	 * ����Eclipse��չ��ʱ������֧�ֻص��ķ�����<BR>
	 * ͨ��������ָ���Ƿ����չ���ݽ��й��ˡ�<BR>
	 *
	 * The method is used to support callback to load extension.<BR>
	 * Use parameter to specify whether the extensions should be filtered.<BR>
	 *
	 * @see IConfigurationNodeLoader#load(IConfigurationNode)
	 *
	 * @param loader
	 * @param extensionID
	 * @param useFilter
	 */
	public static void loadExtension(IConfigurationNodeLoader loader, String extensionID, IAdaptable adaptable, boolean useFilter) {

		IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(extensionID);
		IExtension[] extensions = extensionPoint.getExtensions();

		for (int i = 0; i < extensions.length; i++) {
			IExtension extension = extensions[i];
			doLoadExtension(loader, extension, adaptable, useFilter);
		}
	}

	/**
	 * ����ĳЩ��չ��<BR>
	 *
	 * @param loader
	 * @param extension
	 * @param useFilter 
	 */
	private static void doLoadExtension(IConfigurationNodeLoader loader, IExtension extension, IAdaptable adaptable, boolean useFilter) {
		IConfigurationElement[] configurationNodes;
		if(useFilter){
			configurationNodes = ExtensionFilterManager.getInstance().doFilterChildren(extension,adaptable);
		}else{
			configurationNodes = extension.getConfigurationElements();
		}
		
		for (int j = 0; j < configurationNodes.length; j++) {
			IConfigurationElement configurationNode = configurationNodes[j];

			try {
				loader.load(configurationNode);
			} catch (CoreException e) {
				ILog log = CoreActivator.getDefault().getLog();
				log.log(e.getStatus());
			}
		}
	}

}
