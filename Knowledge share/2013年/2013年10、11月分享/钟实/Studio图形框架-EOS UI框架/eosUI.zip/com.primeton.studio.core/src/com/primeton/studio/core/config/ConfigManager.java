/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/config/ConfigManager.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-5-14
 *******************************************************************************/

package com.primeton.studio.core.config;

import java.io.File;
import java.io.IOException;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;

import com.primeton.studio.core.exception.ExceptionUtil;

/**
 * �����ļ�������
 * �����ļ�·��λ��  EOS Studio�İ�װĿ¼\eclipse\configuration\eos_studio_config\��
 * @author caijing (mailto:caijing@primeton.com)
 */
/*
 *
 * $Log: ConfigManager.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2007/09/21 06:11:40  wanglei
 * Review:�������롣
 *
 * Revision 1.1  2007/05/14 07:49:43  caijing
 * Add:�����ļ�������.�����ļ�·��λ��  EOS Studio�İ�װĿ¼\eclipse\configuration\eos_studio_config\��
 *
 */
public class ConfigManager {

	/**
	 * Eclipse����Ŀ¼
	 */
	public static final String CONFIGURATION_PATH = "configuration";

	/**
	 * EOS����Ŀ¼
	 */
	public static final String EOS_CONFIG_PATH = "eos_studio_config";

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * No instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private ConfigManager() {
		super();
	}

	/**
	 * �õ�����·����<BR>
	 *
	 * @return
	 */
	public static String getConfigurationPath() {
		String path = "";
		try {
			path = FileLocator.toFileURL(Platform.getInstallLocation().getURL()).getFile();
			path = path + File.separator + CONFIGURATION_PATH + File.separator + EOS_CONFIG_PATH;
			File file = new File(path);
			if (!file.exists()) {
				file.mkdirs();
			}
			//���Ŀ¼�����ڣ���ֱ�Ӱ���δ���Ŀ¼
		} catch (IOException e) {
			ExceptionUtil.getInstance().logException(e);
		}
		return path;
	}

}
