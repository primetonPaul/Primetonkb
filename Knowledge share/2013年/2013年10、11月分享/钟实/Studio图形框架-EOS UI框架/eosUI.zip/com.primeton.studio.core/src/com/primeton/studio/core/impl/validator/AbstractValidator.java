/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.impl.validator;

import org.eclipse.core.runtime.IAdapterFactory;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValidator;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * һ��Validator�Ļ���ʵ�֣� ��Ҫ���ṩ������Ϣ�ı���<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * A basic implemetion for validator. It provide message store. <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 13:23:53
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: AbstractValidator.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractValidator implements IValidator
{
	private String message;

	// The error message

	private int level = IConstant.ERROR;

	// the message level

	/**
	 * Ĭ�Ϲ��캯��<BR>
	 * 
	 * The default constructor.<BR>
	 * 
	 */
	public AbstractValidator()
	{
		super();
	}

	/**
	 * �Թ��캯���ķ�ʽ�ṩ��ʾ��Ϣ��<BR>
	 * 
	 * Pass the message by the parameters.<BR>
	 * 
	 * @param r_Message
	 *            the message to be shown.
	 */
	public AbstractValidator(String r_Message)
	{
		super();
		this.message = r_Message;
	}

	/**
	 * ������ʾ��Ϣ<BR>
	 * 
	 * Return the message for prompt.<BR>
	 * 
	 * @return return the message to be shown.
	 */
	public String getMessage()
	{
		return this.message;
	}

	/**
	 * ������ʾ��Ϣ<BR>
	 * 
	 * Set the message for prompt.<BR>
	 * 
	 * @param r_Message
	 *            The message to set.
	 */
	public final void setMessage(final String r_Message)
	{
		this.message = r_Message;
	}

	/**
	 * ������Ϣ��ʾ����<BR>
	 * 
	 * Return the message level.<BR>
	 * 
	 * @see com.primeton.studio.core.IConstant#ERROR
	 * @see com.primeton.studio.core.IConstant#INFO
	 * @see com.primeton.studio.core.IConstant#WARN
	 * 
	 * @return the level
	 */
	public int getLevel()
	{
		return this.level;
	}

	/**
	 * ������Ϣ��ʾ����<BR>
	 * 
	 * Set the message level.<BR>
	 * 
	 * @param r_Level
	 *            the level to set
	 * 
	 * @see com.primeton.studio.core.IConstant#ERROR
	 * @see com.primeton.studio.core.IConstant#INFO
	 * @see com.primeton.studio.core.IConstant#WARN
	 */
	public void setLevel(int r_Level)
	{
		if ((IConstant.WARN == r_Level) || (IConstant.INFO == r_Level))
		{
			this.level = r_Level;
		}
		else
		{
			this.level = IConstant.ERROR;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.ICloneable#clone()
	 */
	public Object clone()
	{
		// Most of these objects are safe for thread.
		// Just return itself.
		return this;
	}

	/**
	 * ��ʾ������Ϣ��<BR>
	 * 
	 * @param r_MessageCaller
	 */
	private void updateMessage(final IMessageCaller r_MessageCaller)
	{
		if (null == r_MessageCaller)
		{
			return;
		}

		if (IConstant.ERROR == this.getLevel())
		{
			r_MessageCaller.error(this.getMessage(), null);
			return;
		}

		if (IConstant.WARN == this.getLevel())
		{
			r_MessageCaller.warn(this.getMessage(), null);
			return;
		}

		if (IConstant.INFO == this.getLevel())
		{
			r_MessageCaller.info(this.getMessage(), null);
			return;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IValidator#validate(java.lang.Object, com.primeton.studio.core.IAdapterFactory,
	 *      com.primeton.studio.core.IMessageCaller)
	 */
	public boolean validate(Object r_Value, IAdapterFactory r_AdapterFactory, IMessageCaller r_MessageCaller)
	{
		if (this.doValidate(r_Value, r_AdapterFactory, r_MessageCaller))
		{
			return true;
		}
		else
		{
			this.updateMessage(r_MessageCaller);
			return IConstant.ERROR != this.getLevel();
		}
	}

	/**
	 * ������ʵ�־����������֤��<BR>
	 * 
	 * The derived classes implement the method to validate data.<BR>
	 * 
	 * @param r_Value
	 * @param r_AdapterFactory
	 * @param r_MessageCaller
	 * @return
	 */
	protected abstract boolean doValidate(Object r_Value, IAdapterFactory r_AdapterFactory, IMessageCaller r_MessageCaller);

}
