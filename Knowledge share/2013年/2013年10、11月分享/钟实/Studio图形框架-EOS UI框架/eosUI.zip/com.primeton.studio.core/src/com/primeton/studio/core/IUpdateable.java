/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/IUpdateable.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-6-26
 *******************************************************************************/


package com.primeton.studio.core;

/**
 * ����������ѡ���ͼԪ
 *
 * @author yanfei (mailto:yanfei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IUpdateable.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 06:47:55  chenxp
 * Update:�ع�IUpdatable�ӿ�
 *
 * Revision 1.3  2007/09/30 01:04:39  chenxp
 * Update:���ӳ���
 *
 * Revision 1.2  2007/07/01 07:55:10  yanfei
 * Update:���ӳ������塣
 *
 * Revision 1.1  2007/06/26 06:42:48  yanfei
 * Update:���Ӱ�סCtrl����˫������ʵ�ֻ�ת��ʵ�ֵĹ��ܡ�
 *
 */
public interface IUpdateable {

	public void update(Object object);
	
}
