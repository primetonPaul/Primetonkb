/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.impl;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;

import ognl.Ognl;
import ognl.OgnlException;
import ognl.OgnlRuntime;

import com.primeton.studio.core.CoreMessages;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.exception.PropertyAccessException;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ͨ��Property�ķ�ʽ������һ��Bean����,��Property �����ڵ�������׳��쳣* <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Access a bean by the property name.<BR>
 * It throws the IntrospectorException while the property name doesn't exist. <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 11:12:43
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: PropertyIntrospector.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2007/12/13 05:20:30  yuhl
 * Update:���ʻ�
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public class PropertyIntrospector implements Introspector
{

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public PropertyIntrospector()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#clone()
	 */
	public Object clone()
	{
		// There is no field,so it's safe for thread
		// so return this.
		return this;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.Introspector#getValue(java.lang.Object, java.lang.String)
	 */
	public Object getValue(final Object r_Element, final String r_PropertyName) throws PropertyAccessException
	{
		this.assertParameter(r_Element, r_PropertyName);
		try
		{
			return Ognl.getValue(r_PropertyName, r_Element);
		}
		catch (OgnlException e)
		{
			throw new PropertyAccessException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.Introspector#getType(java.lang.Object, java.lang.String)
	 */
	public Class getType(final Object r_Element, final String r_PropertyName) throws PropertyAccessException
	{
		this.assertParameter(r_Element, r_PropertyName);
		try
		{
			final PropertyDescriptor t_PropertyDescriptor = OgnlRuntime.getPropertyDescriptor(r_Element.getClass(), r_PropertyName);
			if (null != t_PropertyDescriptor)
			{
				return t_PropertyDescriptor.getPropertyType();
			}

			final Field t_Field = OgnlRuntime.getField(r_Element.getClass(), r_PropertyName);

			if (null != t_Field)
			{
				return t_Field.getType();
			}
		}
		catch (Exception e)
		{
			throw new PropertyAccessException(e);
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.Introspector#setValue(java.lang.Object, java.lang.String, java.lang.Object)
	 */
	public void setValue(final Object r_Element, final String r_PropertyName, final Object r_Value) throws PropertyAccessException
	{
		this.assertParameter(r_Element, r_PropertyName);
		try
		{
			Ognl.setValue(r_PropertyName, r_Element, r_Value);
		}
		catch (OgnlException e)
		{
			throw new PropertyAccessException(e);
		}
	}

	/**
	 * ����ȷ��Ҫ�����Ķ������������Ϊ<code>null</code><BR>
	 *
	 * To assert the target object and the property name are not <code>null</code>.<BR>
	 *
	 * @param r_Element
	 *            the object to be accesed.
	 * @param r_PropertyName
	 *            the name for access data.
	 * @throws PropertyAccessException
	 */
	private void assertParameter(final Object r_Element, final String r_PropertyName) throws PropertyAccessException
	{
		if (r_Element == null)
		{
			throw new PropertyAccessException(CoreMessages.TARGET_OBJECT_NULL);
		}

		if (null == r_PropertyName)
		{
			throw new PropertyAccessException(CoreMessages.MapIntrospector_PREPERTY_NAME_NULL);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.Introspector#hasProperty(java.lang.Object, java.lang.String)
	 */
	public boolean hasProperty(Object r_Element, String r_PropertyName) throws PropertyAccessException
	{
		if (r_Element == null)
		{
			return false;
		}

		if (null == r_PropertyName)
		{
			return false;
		}

		PropertyDescriptor[] t_PropertyDescriptors;
		try
		{
			t_PropertyDescriptors = java.beans.Introspector.getBeanInfo(r_Element.getClass()).getPropertyDescriptors();
		}
		catch (IntrospectionException e)
		{
			throw new PropertyAccessException(e);
		}

		for (int i = 0; i < t_PropertyDescriptors.length; i++)
		{
			PropertyDescriptor t_Descriptor = t_PropertyDescriptors[i];
			if (t_Descriptor.getName().equals(r_PropertyName))
			{
				return true;
			}
		}
		return false;
	}
}
