/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.impl;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import ognl.OgnlException;
import ognl.OgnlRuntime;

import com.eos.system.utility.ObjectUtil;
import com.primeton.studio.core.IMemento;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.exception.ReflectionAccessException;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ʵ�ֶ�һ����ͨ����״̬�ı���ͻָ��� ��ֻ֧���ַ�����ԭʼ���͵Ĵ�����<BR>
 * ֻҪ�ǿ���ѭ�����õ�����Ƚϸ��ӣ����Բ�֧�ֶ������õĵݹ鴦����
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * To backup and restore the properties of a object,just support the primitive type and string.<BR>
 * Other types can't be supported for the recursion references. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 11:31:39
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: SimpleObjectMemento.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2007/12/19 01:14:34  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public final class SimpleObjectMemento implements IMemento
{
	/**
	 * the object for backup and restore
	 */
	private Object element;

	/**
	 * the property descriptor for cache.
	 */
	private Map propertyDescriptors;

	/**
	 * The backuped value for restore.
	 */
	private Map propertiyValues = new HashMap();

	private Introspector propertyIntrospector;

	/**
	 * ͨ�����캯����Ҫ���ݺͻָ��Ķ����롣<BR>
	 * 
	 * The element for backup and restore should't be changed. So using the constructor to set the element.
	 * 
	 * @param r_Element
	 *            the object for memento.
	 */
	public SimpleObjectMemento(final Object r_Element)
	{
		this(r_Element, new PropertyIntrospector());
	}

	/**
	 * ͨ�����캯����Ҫ���ݺͻָ��Ķ����롣<BR>
	 * 
	 * The element for backup and restore should't be changed. So using the constructor to set the element.
	 * 
	 * @param r_Element
	 *            the object for memento.
	 * @param r_Introspector
	 *            the introspector to access the data of a object.
	 */
	public SimpleObjectMemento(final Object r_Element, Introspector r_Introspector)
	{
		super();
		this.element = r_Element;
		this.propertyIntrospector = r_Introspector;

		try
		{
			this.propertyDescriptors = OgnlRuntime.getPropertyDescriptors(this.element.getClass());
		}
		catch (Exception e)
		{
			throw new ReflectionAccessException(e);
		}
		this.backup();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMemento#backup()
	 */
	public void backup()
	{
		try
		{
			for (final Iterator t_Iterator = this.propertyDescriptors.keySet().iterator(); t_Iterator.hasNext();)
			{
				final String t_Name = (String) t_Iterator.next();
				final PropertyDescriptor t_PropertyDescriptor = (PropertyDescriptor) this.propertyDescriptors.get(t_Name);

				if (null == t_PropertyDescriptor)
				{
					continue;
				}

				if ((null != t_PropertyDescriptor.getReadMethod()) && (null != t_PropertyDescriptor.getWriteMethod()))
				{
					// Just support a property with "read" and "write" methods.
					if (this.support(t_PropertyDescriptor))
					{
						final Object t_Object = this.propertyIntrospector.getValue(this.getElement(), t_Name);
						Object t_CloneValue = this.getValue(t_Object, t_PropertyDescriptor.getPropertyType());
						this.propertiyValues.put(t_Name, t_CloneValue);
					}
				}
			}
		}
		catch (Exception e)
		{
			throw new ReflectionAccessException(e);
		}
	}

	/**
	 * ����һ�����Ե�Ԫ������Ϣ�õ���Ӧ��ֵ��<BR>
	 * 
	 * Get the value of a object by the metadata of a property.<BR>
	 * 
	 * @param r_Value
	 *            the value to be converted for backup and restore.
	 * @param r_Type
	 *            the type for target conversion.
	 * @return return the value for backup and restore.
	 * 
	 * @throws OgnlException
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	private Object getValue(final Object r_Value, Class r_Type) throws SecurityException, IllegalArgumentException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		if (null == r_Value)
		{
			return null;
		}

		if (r_Type.isPrimitive())
		{
			return r_Value;
		}

		if (String.class == r_Type)
		{
			return r_Value;
		}

		if (r_Type.isArray())
		{
			int t_Length = Array.getLength(r_Value);
			Object[] t_Objects = (Object[]) Array.newInstance(r_Type.getComponentType(), t_Length);
			for (int i = 0; i < t_Length; i++)
			{
				Object t_Object = Array.get(r_Value, i);
				t_Objects[i] = this.getValue(t_Object, r_Type.getComponentType());
			}

			return t_Objects;
		}
		else
		{
			return ObjectUtil.copyValue(r_Value);
		}
	}

	/**
	 * �÷��������ж�ָ���������Ƿ���Խ��б��ݺͻָ�����Ҫ��֧��ԭʼ���͡�String��Clone�����ͣ��Լ���Ӧ�����顣<BR>
	 * 
	 * Whether this property is support or not.<BR>
	 * Just the primitive type and string,the array of them are supported too.
	 * 
	 * @param r_PropertyDescriptor
	 */
	private boolean support(final PropertyDescriptor r_PropertyDescriptor)
	{
		Class t_Type = r_PropertyDescriptor.getPropertyType();

		if (this.support(t_Type))
		{
			return true;
		}

		if (r_PropertyDescriptor.getPropertyType().isArray())
		{
			final Class t_ArrayClassType = r_PropertyDescriptor.getPropertyType().getComponentType();

			if (this.support(t_ArrayClassType))
			{
				return true;
			}
		}

		return false;
	}

	/**
	 * �÷��������ж�ָ�������Ƿ���Խ��б��ݺͻָ�����Ҫ��֧��ԭʼ���͡�String��Clone�����ͣ��Լ���Ӧ�����顣<BR>
	 * 
	 * Whether this property is support or not.<BR>
	 * Just the primitive type and string,the array of them are supported too.
	 * 
	 * @param r_Type
	 */
	private boolean support(final Class r_Type)
	{
		if (r_Type.isPrimitive())
		{
			return true;
		}

		if (String.class == r_Type)
		{
			return true;
		}

		if (Cloneable.class.isAssignableFrom(r_Type))
		{
			return true;
		}

		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.IMemento#restore()
	 */
	public void restore()
	{
		try
		{
			for (final Iterator t_Iterator = this.propertiyValues.keySet().iterator(); t_Iterator.hasNext();)
			{
				final String t_Name = (String) t_Iterator.next();
				final Object t_Value = this.propertiyValues.get(t_Name);
				this.propertyIntrospector.setValue(this.element, t_Name, t_Value);
			}
		}
		catch (Exception e)
		{
			throw new ReflectionAccessException(e);
		}
	}

	/**
	 * ����Ҫ���ݺͻָ��Ķ���<BR>
	 * 
	 * Return the object to restore and backup.<BR>
	 * 
	 */
	public Object getElement()
	{
		return this.element;
	}

	/**
	 * ����ָ�����ƵĶ���ֵ��<BR>
	 * 
	 * Return the value for the specified property name.<BR>
	 * 
	 * @param r_PropertyName
	 */
	public Object getValue(String r_PropertyName)
	{
		return this.propertiyValues.get(r_PropertyName);
	}

	/**
	 * �ָ�����ָ�����Ե�ֵ��<BR>
	 * 
	 * Restore the value of the object by the specified property name.<BR>
	 * 
	 * @param r_PropertyName
	 */
	public void restore(String r_PropertyName)
	{
		final Object t_Value = this.propertiyValues.get(r_PropertyName);
		this.propertyIntrospector.setValue(this.element, r_PropertyName, t_Value);
	}
}
