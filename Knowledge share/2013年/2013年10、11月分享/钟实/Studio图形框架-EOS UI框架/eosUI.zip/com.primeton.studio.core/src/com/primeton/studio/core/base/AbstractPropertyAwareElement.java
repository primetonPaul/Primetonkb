/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.core.base;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.primeton.studio.core.IPropertyAwareElement;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �ܹ�������Ըı����<BR>
 * �����Ըı�ʱ���ᷢ����Ӧ����Ϣ֪ͨ���еļ�����<BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The calss whick aware for the change of properties.<BR>
 * The PropertyListener will be called when change happens.<BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 11:07:47
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: AbstractPropertyAwareElement.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractPropertyAwareElement implements IPropertyAwareElement
{

	/**
	 * enable or disable the property change notifition.
	 */
	private transient boolean propertyChangeEnable = true;

	/**
	 * the proxy listener.
	 */
	private transient final PropertyChangeSupport listenerDelegate = new PropertyChangeSupport(this);

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public AbstractPropertyAwareElement()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#firePropertyChange(java.lang.String, java.lang.Object,
	 *      java.lang.Object)
	 */
	public final void firePropertyChange(final String r_Property, final Object r_OldValue, final Object r_NewValue)
	{
		if (this.isEnablePropertyChange())
		{
			if (this.listenerDelegate.hasListeners(r_Property))
			{
				final PropertyChangeEvent t_Event = new PropertyChangeEvent(this, r_Property, r_OldValue, r_NewValue);
				this.listenerDelegate.firePropertyChange(t_Event);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#firePropertyChange(java.beans.PropertyChangeEvent)
	 */
	public final void firePropertyChange(final PropertyChangeEvent r_Event)
	{
		if (this.isEnablePropertyChange())
		{
			if (this.listenerDelegate.hasListeners(r_Event.getPropertyName()))
			{
				this.listenerDelegate.firePropertyChange(r_Event);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#doAddPropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public final void doAddPropertyChangeListener(final PropertyChangeListener r_Listener)
	{
		this.listenerDelegate.addPropertyChangeListener(r_Listener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#doRemovePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public final void doRemovePropertyChangeListener(final PropertyChangeListener r_Listener)
	{
		this.listenerDelegate.removePropertyChangeListener(r_Listener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#doAddPropertyChangeListener(java.lang.String,
	 *      java.beans.PropertyChangeListener)
	 */
	public final void doAddPropertyChangeListener(final String r_PropertyName, final PropertyChangeListener r_Listener)
	{
		this.listenerDelegate.addPropertyChangeListener(r_PropertyName, r_Listener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#doRemovePropertyChangeListener(java.lang.String,
	 *      java.beans.PropertyChangeListener)
	 */
	public final void doRemovePropertyChangeListener(final String r_PropertyName, final PropertyChangeListener r_Listener)
	{
		this.listenerDelegate.removePropertyChangeListener(r_PropertyName, r_Listener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#getPropertyChangeListeners()
	 */
	public final PropertyChangeListener[] getPropertyChangeListeners()
	{
		return this.listenerDelegate.getPropertyChangeListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#getPropertyChangeListeners(java.lang.String)
	 */
	public final PropertyChangeListener[] getPropertyChangeListeners(final String r_PropertyName)
	{
		return this.listenerDelegate.getPropertyChangeListeners(r_PropertyName);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#isEnablePropertyChange()
	 */
	public boolean isEnablePropertyChange()
	{
		return this.propertyChangeEnable;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.core.base.IPropertyAwareElement#setEnablePropertyChange(boolean)
	 */
	public void setEnablePropertyChange(final boolean r_PropertyChangeEnable)
	{
		this.propertyChangeEnable = r_PropertyChangeEnable;
	}
}
