/**
 *
 */
package com.primeton.platform.service.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.ObjectUtils;

import com.eos.system.utility.Assert;
import com.eos.system.utility.CollectionUtil;
import com.primeton.platform.Kernel;
import com.primeton.platform.service.IServiceManager;
import com.primeton.platform.service.IServiceReference;
import com.primeton.platform.service.ServiceContext;
import com.primeton.platform.service.Version;
import com.primeton.platform.service.VersionRange;
import com.primeton.platform.service.spi.IServiceFactory;
import com.primeton.platform.service.spi.IServiceFilter;
import com.primeton.platform.service.spi.IServiceProvider;
import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.activator.CoreActivator;
import com.primeton.studio.core.util.comparator.PropertyComparator;

/**
 *
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * IServiceManager��ʵ���ࡣ<BR>
 *
 * <strong>English Doc��</strong><BR>
 * The implementation for IServiceManager<BR>
 *
 * Created Time: 2009-8-14 ����02:49:09
 * @author @author wanglei (mailto:wanglei@primeton.com)
 *
 */
/*
 * Update History
 *
 * $Log: ServiceManager.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.3  2010/05/14 05:00:03  wanglei
 * Jira:����EOSP-243��
 *
 * Revision 1.2  2010/04/29 05:53:08  wanglei
 * Review:�������������ڷ�OSGi�����µ����⡣
 *
 * Revision 1.1  2010/01/11 08:46:21  hongsq
 * Update:�ύС����EOS_6.1.0.10_20100108_P1�Ĵ���
 *
 * Revision 1.1  2009/11/18 07:02:44  wanglei
 * Add:�ύ��CVS��
 *
 */
public class ServiceManager implements IServiceManager {

	public static final String BUNDLE_NAME = "com.primeton.platform";

	private static final ServiceManager instance = new ServiceManager();



	private Set serviceProviders = new TreeSet(new PropertyComparator(IConstant.PRIORITY));

	/**
	 *
	 */
	private ServiceManager() {
		super();

		try {
			load();
		} catch (Exception e) {
			// Nothing to do
		}

	}

	/**
	 * ͨ����չ�����������ע�����<BR>
	 *
	 * Load other service providers by extension.<BR>
	 *
	 */
	private void load() {

		if(CoreActivator.getDefault()==null)
		{
			serviceProviders.add(JavaServiceProvider.getInstance());
		}
		else
		{
			ExtensionServiceProvider extensionServiceProvider= ExtensionServiceProvider.getInstance();

			extensionServiceProvider.load(this);
			serviceProviders.add(extensionServiceProvider);

			Object[] objects = extensionServiceProvider.findServices(IServiceProvider.class, ServiceContext.createContext(BUNDLE_NAME), null, null);
			for (int i = 0; i < objects.length; i++) {
				Object object = objects[i];

				if (object instanceof IServiceFactory) {
					ServiceContext serviceContext = ServiceContext.createContext(BUNDLE_NAME);
					IServiceFactory serviceFactory = (IServiceFactory) object;
					object = serviceFactory.createService(serviceContext);
				}

				if (object instanceof IServiceProvider) {
					IServiceProvider serviceProvider = (IServiceProvider) object;
					this.serviceProviders.add(serviceProvider);
				}
			}
		}
	}

	/**
	 * ���ع�����ʵ����<BR>
	 *
	 * Return the shared instance.<BR>
	 *
	 * @return the instance
	 */
	public static ServiceManager getInstance() {
		return instance;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized Object findService(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {

		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			Object object = serviceProvider.findService(interfaceClass, serviceContext, versionDeclaration, serviceFilter);
			if ((null != object) && (interfaceClass.isAssignableFrom(object.getClass()))) {
				return object;
			}
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized Object findService(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			Object object = serviceProvider.findService(interfaceName, serviceContext, versionDeclaration, serviceFilter);

			if ((null != object) && (hasInterface(object.getClass(), interfaceName))) {
				return object;
			}
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized Object[] findServices(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {

		List list = new ArrayList();

		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			Object[] objects = serviceProvider.findServices(interfaceClass, serviceContext, versionDeclaration, serviceFilter);
			CollectionUtil.addAllQuietly(list, objects);
		}

		return list.toArray();

	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized Object[] findServices(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		List list = new ArrayList();

		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			Object[] objects = serviceProvider.findServices(interfaceName, serviceContext, versionDeclaration, serviceFilter);
			CollectionUtil.addAllQuietly(list, objects);
		}

		return list.toArray();
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference findServiceReference(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			IServiceReference serviceReference = serviceProvider.findServiceReference(interfaceClass, serviceContext, versionDeclaration, serviceFilter);
			if ((null != serviceReference) && (ObjectUtils.equals(interfaceClass.getName(), serviceReference.getServiceDeclaration()))) {
				return serviceReference;
			}
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference findServiceReference(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			IServiceReference serviceReference = serviceProvider.findServiceReference(interfaceName, serviceContext, versionDeclaration, serviceFilter);
			if ((null != serviceReference) && (ObjectUtils.equals(interfaceName, serviceReference.getServiceDeclaration()))) {
				return serviceReference;
			}
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference[] findServiceReferences(Class interfaceClass, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		List list = new ArrayList();

		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			IServiceReference[] objects = serviceProvider.findServiceReferences(interfaceClass, serviceContext, versionDeclaration, serviceFilter);
			CollectionUtil.addAllQuietly(list, objects);
		}

		IServiceReference[] results = new IServiceReference[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference[] findServiceReferences(String interfaceName, ServiceContext serviceContext, VersionRange versionDeclaration, IServiceFilter serviceFilter) {
		List list = new ArrayList();

		for (Iterator iterator = this.serviceProviders.iterator(); iterator.hasNext();) {
			IServiceProvider serviceProvider = (IServiceProvider) iterator.next();
			IServiceReference[] objects = serviceProvider.findServiceReferences(interfaceName, serviceContext, versionDeclaration, serviceFilter);
			CollectionUtil.addAllQuietly(list, objects);
		}

		IServiceReference[] results = new IServiceReference[list.size()];
		list.toArray(results);
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getNamespaceIdentifier() {
		return ServiceManager.class.getName();
	}

	/**
	 * ����ָ��BundleҪ�õ�Service��<BR>
	 *
	 * Find the service which can be used the specified bundle.<BR>
	 *
	 */
	public static Object findService(Class serviceClass, String bundleName) {
		IServiceManager serviceManager = Kernel.getServiceManager();
		ServiceContext serviceContext = ServiceContext.createContext(bundleName);
		Object service = serviceManager.findService(serviceClass, serviceContext, null, null);

		Assert.isInstanceOf(serviceClass, service, "the service " + serviceClass.getName() + " is not available");

		return service;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getPriority() {
		return Integer.MAX_VALUE;
	}

	/**
	 * {@inheritDoc}
	 */
	public IServiceReference createServiceReference(IServiceProvider serviceProvider, String serviceDeclaration, Object serviceImplementation, Version version, Map properties) {
		return new InternalServiceReference(serviceProvider, serviceDeclaration, serviceImplementation, version, properties);
	}

	/**
	 * ���ָ�����Ƿ�ʵ����ָ���ӿڡ�<BR>
	 *
	 * Check whether the class implements the specified interface.<BR>
	 *
	 * @param cls
	 * @param interfaceName
	 * @return
	 */
	public static boolean hasInterface(Class cls, String interfaceName) {
		List list = getAllInterfacesAsString(cls);
		return list.contains(interfaceName);
	}

	/**
	 * <p>Gets a <code>List</code> of all interfaces implemented by the given
	 * class and its superclasses.</p>
	 *
	 * <p>The order is determined by looking through each interface in turn as
	 * declared in the source file and following its hierarchy up. Then each
	 * superclass is considered in the same way. Later duplicates are ignored,
	 * so the order is maintained.</p>
	 *
	 * @param cls  the class to look up, may be <code>null</code>
	 * @return the <code>List</code> of interfaces in order,
	 *  <code>null</code> if null input
	 */
	public static List getAllInterfacesAsString(Class cls) {
		if (cls == null) {
			return null;
		}
		List list = new ArrayList();
		while (cls != null) {
			Class[] interfaces = cls.getInterfaces();
			for (int i = 0; i < interfaces.length; i++) {
				if (list.contains(interfaces[i].getName()) == false) {
					list.add(interfaces[i].getName());
				}
				List superInterfaces = ClassUtils.getAllInterfaces(interfaces[i]);
				for (Iterator it = superInterfaces.iterator(); it.hasNext();) {
					Class intface = (Class) it.next();
					if (list.contains(intface.getName()) == false) {
						list.add(intface.getName());
					}
				}
			}
			cls = cls.getSuperclass();
		}
		return list;
	}
}
