/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.core.exception;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.comparators.ReverseComparator;
import org.apache.commons.lang.math.NumberUtils;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.activator.CoreActivator;
import com.primeton.studio.core.util.comparator.PropertyComparator;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ���������쳣�Ĺ�����<BR>
 * ��ͨ����չ����������쳣�����Ķ����ࡣ
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The helper to process exception. <BR>
 * It load exception handlers from the extension-points.<BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-9-13 ����09:47:15
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ExceptionUtil.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/08/21 02:56:35  yanfei
 * Update:�����з�ʽ��¼��־ʱ��CoreActivator.getDefault()Ϊ�ա�
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2007/04/10 02:13:42  wanglei
 * Remove:ȥ����Դ����Aquarius���ַ�����
 *
 * Revision 1.5  2007/03/07 05:24:03  wanglei
 * UnitTest:������չ�㶨��Ĵ���
 *
 * Revision 1.4  2007/03/05 06:01:56  wanglei
 * �ύ��CVS
 *
 */

public final class ExceptionUtil
{
	// The extension-point ID for IPreferenceStore
	public static final String ERROR_HANDLER_ID = "org.primeton.studio.core.exception.exceptionHandler";

	public static final String EXCEPTION_HANDLER = "exceptionHandler";

	public static final String ERROR_CODE_HANDLER = "errorCodeHandler";

	public static final String EXCEPTION = "exception";

	public static final String ERROR_CODE = "errorCode";

	private final Map exceptionHandlers = new HashMap();

	private final Map errorCodeHandlers = new HashMap();

	private static ExceptionUtil instance = new ExceptionUtil();

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private ExceptionUtil()
	{
		super();
	}

	/**
	 * ����Ψһʵ����<BR>
	 *
	 * Return the shared instance.<BR>
	 *
	 * @return the instance
	 */
	public static ExceptionUtil getInstance()
	{
		return instance;
	}

	/**
	 * ͨ����չ�������쳣�����ࡣ<BR>
	 *
	 * Load the exception handlers from the extension-point.<BR>
	 *
	 */
	public synchronized void loadErrorHandlers()
	{
		final IExtensionRegistry t_ExtensionRegistry = Platform.getExtensionRegistry();
		final IExtensionPoint t_ExtensionPoint = t_ExtensionRegistry.getExtensionPoint(ERROR_HANDLER_ID);

		if (null == t_ExtensionPoint)
		{
			return;
		}

		final IExtension[] t_Extensions = t_ExtensionPoint.getExtensions();

		for (int i = 0; i < t_Extensions.length; i++)
		{
			final IExtension t_Extension = t_Extensions[i];
			final IConfigurationElement[] t_ConfigurationElements = t_Extension.getConfigurationElements();

			for (int j = 0; j < t_ConfigurationElements.length; j++)
			{
				final IConfigurationElement t_ConfigurationElement = t_ConfigurationElements[j];

				if (EXCEPTION_HANDLER.equals(t_ConfigurationElement.getName()))
				{
					loadExceptionHandler(t_ConfigurationElement);
				}

				if (ERROR_CODE_HANDLER.equals(t_ConfigurationElement.getName()))
				{
					loadErrorCodeHandler(t_ConfigurationElement);
				}
			}
		}
	}

	/**
	 * ������չ��errorCodeHandler�����ݡ�<BR>
	 *
	 * Load the error code handlers from the extension-point.<BR>
	 *
	 * @param r_ConfigurationElement
	 */
	private void loadErrorCodeHandler(IConfigurationElement r_ConfigurationElement)
	{
		try
		{
			Object t_Object = r_ConfigurationElement.createExecutableExtension(IConstant.CLASS_NAME);

			if (t_Object instanceof IExceptionHandler)
			{
				IExceptionHandler t_Handler = (IExceptionHandler) t_Object;
				updateHandler(t_Handler, r_ConfigurationElement);

				String t_Name = r_ConfigurationElement.getAttribute(ERROR_CODE);

				Set t_Set = (Set) this.errorCodeHandlers.get(t_Name);
				if (null == t_Set)
				{
					t_Set = buildSortSet();
					this.errorCodeHandlers.put(t_Name, t_Set);
				}

				t_Set.add(t_Handler);
			}
		}
		catch (CoreException e)
		{
			// Nothing to do
		}
	}

	/**
	 * ������չ��exceptionHnalder�����ݡ�<BR>
	 *
	 * Load the exception-handlers from the extension-point.<BR>
	 *
	 * @param r_ConfigurationElement
	 */
	private void loadExceptionHandler(IConfigurationElement r_ConfigurationElement)
	{
		try
		{
			Object t_Object = r_ConfigurationElement.createExecutableExtension(IConstant.CLASS_NAME);

			if (t_Object instanceof IExceptionHandler)
			{
				IExceptionHandler t_Handler = (IExceptionHandler) t_Object;
				updateHandler(t_Handler, r_ConfigurationElement);

				String t_Name = r_ConfigurationElement.getAttribute(EXCEPTION);

				Set t_Set = (Set) this.exceptionHandlers.get(t_Name);
				if (null == t_Set)
				{
					t_Set = buildSortSet();
					this.exceptionHandlers.put(t_Name, t_Set);
				}

				t_Set.add(t_Handler);
			}
		}
		catch (CoreException e)
		{
			// Nothing to do
		}
	}

	/**
	 * ����һ������priority�����ܹ���Hanlder���������Set��<BR>
	 * ����Ӵ�С��<BR>
	 *
	 * Build a sorted set by the property of "priority".<BR>
	 * It sort the handlers desc.<BR>
	 *
	 * @return return the sorted set.
	 */
	private Set buildSortSet()
	{
		ReverseComparator t_Comparator = new ReverseComparator(new PropertyComparator(IConstant.PRIORITY));
		return new TreeSet(t_Comparator);
	}

	/**
	 * ����չ���ж�ȡ����������Handler�����ԡ�<BR>
	 *
	 * Update the properties of exception-handler from the extension-point.<BR>
	 *
	 * @param r_Handler
	 *            The exception handler to be updated by the content of extension-point.
	 * @param r_ConfigurationElement
	 *            the content of extension-point.
	 */
	private void updateHandler(IExceptionHandler r_Handler, IConfigurationElement r_ConfigurationElement)
	{
		String t_LogEnableString = r_ConfigurationElement.getAttribute(IExceptionHandler.LOG_ENABLE);
		boolean t_LogEnable = Boolean.valueOf(t_LogEnableString).booleanValue();

		String t_PriorityString = r_ConfigurationElement.getAttribute(IConstant.PRIORITY);
		int t_Priority = NumberUtils.toInt(t_PriorityString);

		String t_LogLayout = r_ConfigurationElement.getAttribute(IExceptionHandler.LOG_LAYOUT);

		r_Handler.setLogEnable(t_LogEnable);
		r_Handler.setLogLayout(t_LogLayout);
		r_Handler.setPriority(t_Priority);
	}

	/**
	 * �����쳣��<BR>
	 *
	 * Handle the exception.<BR>
	 *
	 * @param r_Exception
	 *            the exception to be handled.
	 */
	public void handleException(final Exception r_Exception)
	{
		this.handleException(new ExceptionAdapter(r_Exception));
	}

	/**
	 * �����쳣��<BR>
	 *
	 * Handle the exception.<BR>
	 *
	 * @param r_Exception
	 *            the exception to be handled.
	 */
	public void handleException(final ExceptionAdapter r_Exception)
	{
		if (null == r_Exception)
		{
			return;
		}

		boolean t_Flag = false;

		if (ExceptionAdapter.NONE != r_Exception.getErrorCode())
		{
			if (processExceptionByErrorCode(r_Exception))
			{
				t_Flag = true;
			}
		}

		if (null != r_Exception.getCause())
		{
			if (processException(r_Exception.getCause()))
			{
				t_Flag = true;
			}
		}

		if (!t_Flag)
		{
			logException(r_Exception);
		}
	}

	/**
	 * ����ָ�������ŵĴ���<BR>
	 *
	 * Handle the exception with a error code.<BR>
	 *
	 * @param r_Exception
	 *            the exception to be handled.
	 */
	private boolean processExceptionByErrorCode(ExceptionAdapter r_Exception)
	{
		Set t_Set = (Set) this.errorCodeHandlers.get(Integer.toString(r_Exception.getErrorCode()));

		if ((null == t_Set) || (t_Set.isEmpty()))
		{
			return false;
		}

		boolean t_Flag = false;

		for (Iterator t_Iterator = t_Set.iterator(); t_Iterator.hasNext();)
		{
			IExceptionHandler t_ExceptionHandler = (IExceptionHandler) t_Iterator.next();

			try
			{
				t_ExceptionHandler.handleException(r_Exception.getErrorCode());
				t_Flag = true;
			}
			catch (Exception e)
			{
				// Nothing to do
			}

			if (t_ExceptionHandler.isLogEnable())
			{
				this.logException(r_Exception);
			}
		}

		return t_Flag;
	}

	/**
	 * �����쳣��<BR>
	 *
	 * Handle the real exception.<BR>
	 *
	 * @param r_Cause
	 *            the exception to be handled.
	 */
	private boolean processException(Throwable r_Cause)
	{
		Set t_Set = (Set) this.errorCodeHandlers.get(r_Cause);

		if ((null == t_Set) || (t_Set.isEmpty()))
		{
			return false;
		}

		boolean t_Flag = false;

		for (Iterator t_Iterator = t_Set.iterator(); t_Iterator.hasNext();)
		{
			IExceptionHandler t_ExceptionHandler = (IExceptionHandler) t_Iterator.next();

			try
			{
				t_ExceptionHandler.handleException(r_Cause);
				t_Flag = true;
			}
			catch (Exception e)
			{
				// Nothing to do
			}

			if (t_ExceptionHandler.isLogEnable())
			{
				this.logException(r_Cause);
			}
		}

		return t_Flag;

	}

	/**
	 * ���޷��������쳣д����־��<BR>
	 *
	 * If a exception can't be handled,it will be logged.<BR>
	 *
	 * @param r_Cause
	 *            the exception to be handled.
	 */
	public void logException(Throwable r_Cause)
	{
		Status t_Status = new Status(IStatus.ERROR, CoreActivator.PlugID, IStatus.OK, "Primeton Studio Exception", r_Cause);
		if (CoreActivator.getDefault() != null)
			CoreActivator.getDefault().getLog().log(t_Status);
	}
}
