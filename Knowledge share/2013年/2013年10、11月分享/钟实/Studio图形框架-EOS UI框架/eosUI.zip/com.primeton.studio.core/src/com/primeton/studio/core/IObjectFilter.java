/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-core/develop/core/studio/com.primeton.studio.core/src/com/primeton/studio/core/IObjectFilter.java,v 1.1 2011/06/01 02:39:05 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 02:39:05 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Apr 29, 2008
 *******************************************************************************/


package com.primeton.studio.core;

/**
 * �ж�һ�������Ƿ���Ա�����
 *
 * @author hongsq (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: IObjectFilter.java,v $
 * Revision 1.1  2011/06/01 02:39:05  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:45  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:44:23  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/06 02:27:23  hongsq
 * Update:�ж�һ�������Ƿ���Ա�����
 *
 */
public interface IObjectFilter {
	/**
	 * �����ж�һ�������Ƿ���Ա����ܡ�<BR>
	 *
	 * Used to judge whether a string is accepted or not.<BR>
	 *
	 * @param object
	 * @return
	 */
	public boolean isAcceptable(Object object);
}
