/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/properties/ComboPropertyDescriptor.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-7-14
 *******************************************************************************/


package com.primeton.studio.ui.swt.properties;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import com.primeton.studio.core.model.IDataProvider;
import com.primeton.studio.ui.swt.editor.ComboBoxCellEditor;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �� {#link com.primeton.studio.ui.swt.editor#ComboBoxCellEditor} ���ʹ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Used with {#link com.primeton.studio.ui.swt.editor#ComboBoxCellEditor}.<BR>
 * <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-7-14 ����11:48:34
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * Update History
 *
 * $Log: ComboPropertyDescriptor.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/08/20 07:09:56  yanfei
 * Update:��IListProvider��ΪIDataProvider�ӿ�
 *
 * Revision 1.1  2008/07/14 03:51:40  wanglei
 * Add:�ύ��CVS��
 *
 */

public class ComboPropertyDescriptor extends PropertyDescriptor
{
	private IDataProvider dataProvider;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_ID
	 * @param r_DisplayName
	 * @param r_DataProvider
	 */
	public ComboPropertyDescriptor(Object r_ID, String r_DisplayName, IDataProvider r_DataProvider)
	{
		super(r_ID, r_DisplayName);
		this.dataProvider = r_DataProvider;
	}

	/**
	 * The <code>ComboBoxPropertyDescriptor</code> implementation of this <code>IPropertyDescriptor</code> method
	 * creates and returns a new <code>ComboBoxCellEditor</code>.
	 * <p>
	 * The editor is configured with the current validator if there is one.
	 * </p>
	 */
	public CellEditor createPropertyEditor(Composite r_Parent)
	{
		CellEditor editor = new ComboBoxCellEditor(r_Parent, this.dataProvider, SWT.READ_ONLY);
		if (getValidator() != null)
		{
			editor.setValidator(getValidator());
		}
		return editor;
	}

	/**
	 * The <code>ComboBoxPropertyDescriptor</code> implementation of this <code>IPropertyDescriptor</code> method
	 * returns the value set by the <code>setProvider</code> method or, if no value has been set it returns a
	 * <code>ComboBoxLabelProvider</code> created from the valuesArray of this <code>ComboBoxPropertyDescriptor</code>.
	 *
	 * @see #setLabelProvider
	 */
	public ILabelProvider getLabelProvider()
	{
		if (isLabelProviderSet())
		{
			return super.getLabelProvider();
		}
		else
		{
			return new ComboBoxLabelProvider(this.dataProvider);
		}
	}
}