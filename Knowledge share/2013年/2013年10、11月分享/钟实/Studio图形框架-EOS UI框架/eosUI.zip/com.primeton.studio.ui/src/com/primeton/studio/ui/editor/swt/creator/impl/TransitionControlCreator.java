/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/editor/swt/creator/impl/TransitionControlCreator.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-6-18
 *******************************************************************************/


package com.primeton.studio.ui.editor.swt.creator.impl;

import org.apache.commons.lang.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.primeton.studio.core.IValidateListener;
import com.primeton.studio.swt.util.LayoutUtil;
import com.primeton.studio.ui.ResourceMessages;
import com.primeton.studio.ui.UIConstant;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.base.AbstractControlCreator;
import com.primeton.studio.ui.swt.helper.AbstractAssitantHelper;

/**
 *
 * �������õ����߿ؼ�
 *
 * @author <a href="mailto:yujl@primeton.com">Yu J Lin</a>
 */
/*
 * �޸���ʷ
 * $Log: TransitionControlCreator.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.6  2009/04/22 09:38:12  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.5  2008/08/11 05:26:48  yanfei
 * FIXBUG#10946[������][�Զ��][�������ñ�]�������ֵ��,�����"->",�ٰ����� BackSpace����Delete���쳣
 * �޸�һ����ָ�뵼�µĿؼ������쳣
 *
 * Revision 1.4  2008/08/01 12:40:12  yanfei
 * bugfix10934:ҳ�����༭�����жԻ���(label,��ť���ֵ�)ȱ��ð��(Ӣ�İ��) huanglin
 *
 * Revision 1.3  2008/07/31 08:49:02  wuwj
 * update:��Labelֵ������ð��
 *
 * Revision 1.2  2008/07/30 11:41:31  yujl
 * update:�޸����߱߿�
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/06/20 08:49:24  yujl
 * update:�޸����߿ؼ���ʾ
 *
 * Revision 1.1  2008/06/18 02:55:25  yujl
 * update:�ع���ȡ������controlCreator
 *
 */
public class TransitionControlCreator extends AbstractControlCreator {

	private Button isDefaultButton;

	private Button simpleButton;

	private Button complexButton;

	private Control leftValueLabel;

	private Text leftValueText;

	private Control compareTypeLabel;

	private Combo compareTypeCombo;

	private Control valueTypeLabel;

	private Combo valueTypeCombo;

	private Control rightValueLabel;

	private Text rightValueText;

	private Text complexText;

	private String[] compareTypeItems;

	private String[] valueTypeItems;

	private static final int DEFAULT = 0;
	private static final int SIMPLE = 1;
	private static final int COMPLEX = 2;

	private AbstractPropertyEditor editor;
	private AbstractAssitantHelper helper;

	/**
	 * ������
	 * @param editor
	 * @param compareTypeProvider
	 * @param valueTypeProvider
	 */
	public TransitionControlCreator(AbstractPropertyEditor editor, String[] compareTypeItems, String[] valueTypeItems,AbstractAssitantHelper helper){
		this.editor = editor;
		this.compareTypeItems = compareTypeItems;
		this.valueTypeItems = valueTypeItems;
		this.helper = helper;
	}


	/*
	 * (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.creator.base.AbstractControlCreator#doCreateControl(org.eclipse.swt.widgets.Composite, int)
	 */
	@Override
	protected Control doCreateControl(Composite parent, int style) {
		Composite newParent = new Composite(parent, style | SWT.NONE);
		newParent.setLayout(LayoutUtil.createCompactGridLayout(1));
		newParent.setLayoutData(new GridData(GridData.FILL_BOTH));
		isDefaultButton = new Button(newParent, SWT.CHECK);
		isDefaultButton.setText(ResourceMessages.DefaultLine);
		buildSimpleConditionComp(newParent);
		initListener();
		return newParent;
	}
	/**
	 * �����ȽϿؼ�
	 * @param parent
	 */
	private void buildSimpleConditionComp(Composite parent) {
		Composite newParent = new Composite(parent, SWT.NONE);
		newParent.setLayout(new GridLayout(1,false));
		newParent.setLayoutData(new GridData(GridData.FILL_BOTH));
		this.simpleButton = new Button(newParent, SWT.RADIO);
		this.simpleButton.setText(ResourceMessages.SimpleExpression);
		Control control = createSimpleArea(newParent);
		GridData controlData = new GridData(GridData.FILL_HORIZONTAL);
		controlData.heightHint = 40;
		control.setLayoutData(controlData);
		this.complexButton = new Button(newParent, SWT.RADIO);
		this.complexButton.setText(ResourceMessages.ComplexExpression);
		this.complexText = new Text(newParent, SWT.BORDER | SWT.WRAP | SWT.V_SCROLL);
		GridData data = new GridData(GridData.FILL_BOTH);
		this.complexText.setLayoutData(data);
	}

	/**
	 * �����򵥱���ʽ
	 * @param parent
	 * @return
	 */
	private Control createSimpleArea(Composite parent) {
		SashForm sashForm = new SashForm(parent,SWT.NONE);
		sashForm.SASH_WIDTH = 1;
		Composite[] composites = new Composite[4];
		for (int i = 0; i < composites.length; i++) {
			composites[i] = new Composite(sashForm,SWT.NONE);
			GridLayout layout = new GridLayout(1, true);
			layout.marginHeight = 0;
			layout.marginWidth = 0;
			layout.horizontalSpacing = 0;
			layout.verticalSpacing = 2;
			composites[i].setLayout(layout);
			composites[i].setLayoutData(new GridData(GridData.FILL_BOTH));
		}

		leftValueLabel = createLabelText(composites[0], ResourceMessages.Lvalue);
		compareTypeLabel = createLabelText(composites[1], ResourceMessages.CompareAction);
		rightValueLabel = createLabelText(composites[2], ResourceMessages.Rvalue);
		valueTypeLabel = createLabelText(composites[3], ResourceMessages.RvalueType);

		leftValueText = new Text(composites[0],SWT.BORDER);
		compareTypeCombo = createCombo(composites[1], this.compareTypeItems);
		rightValueText = new Text(composites[2],SWT.BORDER);
		valueTypeCombo = createCombo(composites[3], this.valueTypeItems);

		helper.addContentProposal(leftValueText);
		helper.addContentProposal(rightValueText);

		GridData labelData = new GridData(GridData.FILL_HORIZONTAL);
		labelData.horizontalIndent = 3;
		leftValueLabel.setLayoutData(labelData);
		compareTypeLabel.setLayoutData(labelData);
		rightValueLabel.setLayoutData(labelData);
		valueTypeLabel.setLayoutData(labelData);
		
		GridData comboData = new GridData(GridData.FILL_HORIZONTAL);
		compareTypeCombo.setLayoutData(comboData);
		valueTypeCombo.setLayoutData(comboData);
		
		GridData textData = new GridData(GridData.FILL_HORIZONTAL);
		textData.heightHint = 15;
		leftValueText.setLayoutData(textData);
		rightValueText.setLayoutData(textData);
		sashForm.setWeights(new int[]{40,28,40,15});
		return sashForm;
	}

	/**
	 * ������ʾLabel
	 * @param newParent
	 * @param label
	 * @return
	 */
	private Control createLabelText(Composite newParent,String label){
		Label text = new Label(newParent,SWT.NONE);
		text.setText(label);
//		text.setEditable(false);
		return text;
	}

	/**
	 * ����һ��CCombo
	 * @param newParent
	 * @param items
	 * @return
	 */
	private Combo createCombo(Composite newParent,String[] items){
		Combo combo = new Combo(newParent,SWT.BORDER | SWT.FLAT | SWT.DROP_DOWN | SWT.READ_ONLY);
		combo.setItems(items);
		combo.setVisibleItemCount(15);
		return combo;
	}


	/**
	 * ���Ӽ�����
	 *
	 */
	private void initListener() {

		this.isDefaultButton.addSelectionListener(new SelectionAdapter() {
			/*
			 * (non-Javadoc)
			 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			@Override
			public void widgetSelected(SelectionEvent e) {
				setAllEnable();
				fireValidateRequested();
			}
		});

		this.simpleButton.addSelectionListener(new SelectionAdapter() {
			/*
			 * (non-Javadoc)
			 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			@Override
			public void widgetSelected(SelectionEvent e) {
				setEnable(SIMPLE);
				fireValidateRequested();
			}
		});

		this.complexButton.addSelectionListener(new SelectionAdapter() {
			/*
			 * (non-Javadoc)
			 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			@Override
			public void widgetSelected(SelectionEvent e) {
				setEnable(COMPLEX);
				fireValidateRequested();
			}
		});

		final ModifyListener modifyListener = new ModifyListener() {
					/*
					 * (non-Javadoc)
					 * @see org.eclipse.swt.events.ModifyListener#modifyText(org.eclipse.swt.events.ModifyEvent)
					 */
					public void modifyText(ModifyEvent e) {
						fireValidateRequested();
					}
				};
		this.complexText.addModifyListener(modifyListener);
		this.leftValueText.addModifyListener(modifyListener);



		this.compareTypeCombo.addSelectionListener(new SelectionAdapter(){
			/*
			 * (non-Javadoc)
			 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			@Override
			public void widgetSelected(SelectionEvent event) {
				boolean needRightValue = isNeedRightValue(compareTypeCombo.getItem(compareTypeCombo.getSelectionIndex()));
				rightValueText.setEnabled(needRightValue);
				valueTypeCombo.setEnabled(needRightValue);
				super.widgetSelected(event);
			}
		});
	}

	/**
	 * ���ÿؼ���ʾ����
	 * @param style
	 */
	private void setEnable(int style){
		simpleButton.setEnabled(style != DEFAULT);
		complexButton.setEnabled(style != DEFAULT);
		leftValueLabel.setEnabled(style == SIMPLE);
		compareTypeLabel.setEnabled(style == SIMPLE);
		valueTypeLabel.setEnabled(style == SIMPLE);
		rightValueLabel.setEnabled(style == SIMPLE);
		leftValueText.setEnabled(style == SIMPLE);
		compareTypeCombo.setEnabled(style == SIMPLE);
		if(compareTypeCombo.getSelectionIndex() == -1)
			compareTypeCombo.select(0);
		if(valueTypeCombo.getSelectionIndex() == -1)
			valueTypeCombo.select(0);
		boolean flag = isNeedRightValue(compareTypeCombo.getItem(compareTypeCombo.getSelectionIndex()));
		valueTypeCombo.setEnabled(style == SIMPLE && flag);
		rightValueText.setEnabled(style == SIMPLE && flag);
		complexText.setEnabled(style == COMPLEX);
	}

	/**
	 * �ж��Ƿ���Ҫ������ֵ
	 * @param r_Element
	 * @return
	 */
	private boolean isNeedRightValue(String object){
		return !(StringUtils.equals(object, UIConstant.IS_NULL)
				  || StringUtils.equals(object, UIConstant.NOT_NULL)
				  || StringUtils.equals(object, UIConstant.NULL_EMPTY)
				  || StringUtils.equals(object, UIConstant.NOT_NULL_EMPTY));
	}

	/**
	 * ���ó�ʼֵ
	 * @return
	 */
	public void setAllEnable() {
		boolean flag = isDefaultButton.getSelection();
		int style = DEFAULT;
		if(!flag){
			style = simpleButton.getSelection() ? SIMPLE : COMPLEX;
		}
		setEnable(style);
	}

	/**
	 * ������֤����
	 * @param event
	 */
	private void fireValidateRequested(){
		for (IValidateListener listener : editor.getValidateListener()) {
			listener.validateRequested(null);
		}
	}

	/**
	 * �ж��Ƿ�ΪĬ������
	 * @return
	 */
	public boolean isDefaultTransition(){
		return isDefaultButton.getSelection();
	}

	/**
	 * ����Ĭ������
	 * @param isDefault
	 */
	public void setDefaultTransition(boolean isDefault){
		isDefaultButton.setSelection(isDefault);
	}

	/**
	 * ���ü򵥱���ʽ
	 * @return
	 */
	public boolean isSimpleTransition(){
		return simpleButton.getSelection();
	}

	/**
	 * �ж��Ƿ�Ϊ�򵥱���ʽ
	 * @param isSimple
	 */
	public void setSimpleTransition(boolean isSimple){
		simpleButton.setSelection(isSimple);
	}

	/**
	 * ��ȡ�Ƚ�����
	 * @return
	 */
	public String getCompareType() {
		int index = compareTypeCombo.getSelectionIndex();
		index = index == -1 ? 0 : index;
		return compareTypeCombo.getItem(index);
	}

	/**
	 * ���ñȽ�����
	 * @param item
	 */
	public void setCompareType(String item) {
		int index = compareTypeCombo.indexOf(item);
		index = index == -1 ? 0 : index;
		compareTypeCombo.select(index);
	}

	/**
	 * �ж��Ƿ�Ϊ���ӱ���ʽ
	 * @return
	 */
	public boolean isComplexTransition() {
		return complexButton.getSelection();
	}

	/**
	 * �����Ƿ�Ϊ���ӱ���ʽ
	 * @param isComplex
	 */
	public void setComplexTransition(boolean isComplex) {
		this.complexButton.setSelection(isComplex);
	}

	/**
	 * ��ȡ���ӱ���ʽ
	 * @return
	 */
	public String getComplexValue() {
		return complexText.getText();
	}

	/**
	 * ���ø��ӱ���ʽ
	 * @param complexValue
	 */
	public void setComplexValue(String complexValue) {
		this.complexText.setText(complexValue);
	}

	/**
	 * ��ȡ��ֵ
	 * @return
	 */
	public String getLeftValue() {
		return leftValueText.getText();
	}

	/**
	 * ������ֵ
	 * @param leftValue
	 */
	public void setLeftValue(String leftValue) {
		this.leftValueText.setText(leftValue);
	}

	/**
	 * ��ȡ��ֵ
	 * @return
	 */
	public String getRightValue() {
		return rightValueText.getText();
	}

	/**
	 * ������ֵ
	 * @param rightValue
	 */
	public void setRightValue(String rightValue) {
		this.rightValueText.setText(rightValue);
	}

	/**
	 * ��ȡ��ֵ���
	 * @return
	 */
	public String getValueType() {
		int index = valueTypeCombo.getSelectionIndex();
		index = index == -1 ? 0 : index;
		return valueTypeCombo.getItem(index);
	}

	/**
	 * ������ֵ���
	 * @param valueType
	 */
	public void setValueType(String item) {
		int index = valueTypeCombo.indexOf(item);
		index = index == -1 ? 0 : index;
		valueTypeCombo.select(index);
	}

}
