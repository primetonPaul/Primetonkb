/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/validator/KTreeNotRepleateValidator.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Id: KTreeNotRepleateValidator.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Name:  $
 * $Date: 2011/06/01 01:25:08 $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * �й��������а�Ȩ����.
 *
 *******************************************************************************/


package com.primeton.studio.ui.swt.validator;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.helper.IntrospectorHelper;
import com.primeton.studio.core.tree.ITreeNode;
import com.primeton.studio.ui.swt.builder.ktree.KTreeBuilder;
import com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider;

/**
 * 
 * KTree������ֵ�����ظ�(��Columnʹ��)
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: KTreeNotRepleateValidator.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/09/01 07:27:56  hongsq
 * Update:�ṩKTable,KTree,Table���е�������֤����������ģ��ʹ��
 *
 */
public class KTreeNotRepleateValidator extends AbstractTableValidator {

	private KTreeBuilder treeBuilder;

	private String propertyName;

	private int column;

	/**
	 * @param treeBuilder
	 * @param message
	 */
	public KTreeNotRepleateValidator(KTreeBuilder treeBuilder, String propertyName, int column, String message) {
		super(message);
		this.column = column;
		this.propertyName = propertyName;
		this.treeBuilder = treeBuilder;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.swt.validator.AbstractTableValidator#doValidate(java.lang.Object, java.lang.Object, int, int, com.primeton.studio.core.IMessageCaller)
	 */
	@Override
	protected boolean doValidate(Object value, Object builder, int column, int row, IMessageCaller messageCaller) {
		if(null == value)
			return true;//������У���е����Ĺ�����

		if ((value instanceof String) && StringUtils.isEmpty((String) value)) {
			return true;
		}

		if(column != this.column)
			return true;

		ITableDataProvider provider = treeBuilder.getModel().getDataProvider();
		int count = provider.size();
		for (int i = 0; i < count; i++) {
			if(i == (row - this.treeBuilder.getModel().getFixedHeaderRowCount()))
				continue;//���ж��Լ�

			Object element = provider.get(i);
			if((null == element) && (element instanceof ITreeNode) )
				return true;

			Object userObject = ((ITreeNode)element).getUserObject();
			
			Introspector introspector = IntrospectorHelper.getInstance().getIntrospector(userObject.getClass());

			if((value instanceof String) && StringUtils.equalsIgnoreCase((String) value, (String) introspector.getValue(userObject, this.propertyName))){
				return false;
			}else if(value.equals(introspector.getValue(userObject, this.propertyName)))
				return false;
		}

		return true;
	}

//	/**
//	 * ��ָ֤���ڵ㼰���ӽڵ��Ƿ��в������
//	 * @param treeNode
//	 * @param value
//	 * @param row
//	 * @return
//	 */
//	private boolean validateTreeNode(ITreeNode treeNode, Object value, int row){
//		int childCount = treeNode.getChildCount();
//		for (int i = 0; i < childCount; i++) {
//			if(i == (row - this.treeBuilder.getModel().getFixedHeaderRowCount()))
//				continue;//���ж��Լ�
//			ITreeNode childTreeNode = treeNode.getChildAt(i);
//			Object element = childTreeNode.getUserObject();
//			Introspector introspector = IntrospectorHelper.getInstance().getIntrospector(element.getClass());
//			
//			if((value instanceof String) && StringUtils.equalsIgnoreCase((String) value, (String) introspector.getValue(element, this.propertyName))){
//				return false;
//			}else if(value.equals(introspector.getValue(element, this.propertyName))){
//				return false;
//			}
//			
//			//ֻҪ�ӽڵ��в�����ļ�����false
//			if(!validateTreeNode(childTreeNode, value, row)){
//				return false;
//			}
//		}
//
//		return true;
//	}
}
