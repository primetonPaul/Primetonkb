/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.editor.swt.impl;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import com.primeton.studio.ui.editor.ILayoutDataBuilder;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.LabelControlCreator;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ������һ���ܹ��༭���ݵı༭����ֻ��һ����ʾ��Ϣ�����ݡ�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Just show information instead of editing data. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-1-13 ����07:47:48
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: LabelPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/08/11 08:39:42  yanfei
 * BugFix:11202  ����̫��,������
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/03/11 10:12:19  hongsq
 * Update:Fix�л��ؼ�ʱ��ֵ��ʧ��Bug
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.3  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public class LabelPropertyEditor extends AbstractPropertyEditor
{

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public LabelPropertyEditor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf()
	{
		return new LabelPropertyEditor();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator()
	{
		return new LabelControlCreator(this);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#buildLabelControl(org.eclipse.swt.widgets.Composite,
	 *      com.primeton.studio.core.IAdapter)
	 */
	protected Label buildLabelControl(Composite r_Composite, IAdaptable r_Adaptable)
	{
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		return this.getEditorLabel().getText();//modify by hongsq
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value)
	{
		if (r_Value != null)
		{
			if (r_Value instanceof String)
			{
				this.getEditorLabel().setText((String) r_Value);
			}
		}
		else
		{
			this.getEditorLabel().setText("");
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#isEnable()
	 */
	public boolean isEnable()
	{
		return true;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#isReadonly()
	 */
	public boolean isReadonly()
	{
		return true;
	}

	/**
	 * ���������༭��ʹ�õ�Label��<BR>
	 *
	 * Return the label as a editor.<BR>
	 *
	 * @return
	 */
	public Label getEditorLabel()
	{
		return this.getLabelControlCreator().getLabel();
	}

	/**
	 * ����ǿ��ת�͵ĺ��ControlCreator��<BR>
	 *
	 * Return the real control creator.<BR>
	 *
	 * @return
	 */
	public LabelControlCreator getLabelControlCreator()
	{
		return (LabelControlCreator) this.getControlCreator();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createLayoutDataBuilder()
	 */
	protected ILayoutDataBuilder createLayoutDataBuilder()
	{
		return GridLayoutDataBuilder.newSpanLayout();
	}

}
