/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/factory/impl/CompoundGroupControlFactory.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Apr 21, 2008
 *******************************************************************************/


package com.primeton.studio.ui.swt.factory.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;

import com.primeton.studio.core.ICommand;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.IValueRepository;
import com.primeton.studio.core.command.CompoundCommand;
import com.primeton.studio.core.event.Event;
import com.primeton.studio.core.impl.UIElementDescription;
import com.primeton.studio.core.util.entry.MapEntry;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.UIDefinition;
import com.primeton.studio.ui.swt.factory.base.AbstractControlFactory;
import com.primeton.studio.ui.swt.factory.base.AbstractKTableFactory;
import com.primeton.studio.ui.swt.factory.base.AbstractKTreeFactory;
/**
 *
 * ���ControlFactory��ɣ�ÿ��ControlFactory�����ŵ�һ��Group��
 *
 * ÿ��MapEntry��keyΪ��Ӧ��Group���ı�,valueΪObjectEditor
 *
 * @author hongsq (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: CompoundGroupControlFactory.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:33  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/06 03:30:46  hongsq
 * Update:���ControlFactory��ɣ�ÿ��ControlFactory�����ŵ�һ��Group��
 *
 */
public class CompoundGroupControlFactory extends AbstractControlFactory {
	protected List factoryEntrys = new ArrayList();

	private boolean needGroup = true;//�Ƿ�ʹ��Group

	private boolean needEmptyGroup = true;//�Ƿ�����GroupTextΪ�յ�group

	private Map<IControlFactory, GridData> gridDataMap = new HashMap<IControlFactory, GridData>();//Ϊָ�Ķ���Group���ò���

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public CompoundGroupControlFactory() {
		super();
	}

	/**
	 * ����һ���ؼ����������������ؼ���<BR>
	 *
	 * Add a control factory to create control.<BR>
	 *
	 * @param groupText
	 * @param r_Factory
	 */
	public void doAddFactory(String groupText, IControlFactory r_Factory) {
		if (null != r_Factory) {
			if(groupText == null)	groupText = "";

			this.factoryEntrys.add(new MapEntry(groupText, r_Factory));
			r_Factory.doAddValidateListener(this);
			r_Factory.doAddValueChangeListener(this);
		}
	}

	/**
	 * ɾ��һ���ؼ�������<BR>
	 *
	 * Remove a control factory.<BR>
	 *
	 * @param r_Factory
	 */
	public void doRemoveFactory(IControlFactory r_Factory) {
		if (null != r_Factory) {
			for (Iterator iter = this.factoryEntrys.iterator(); iter.hasNext();) {
				MapEntry entry = (MapEntry) iter.next();
				if(r_Factory.equals(entry.getValue())){
					this.factoryEntrys.remove(entry);
					r_Factory.doRemoveValidateListener(this);
					r_Factory.doRemoveValueChangeListener(this);
				}
			}
		}
	}
	/**
	 * ɾ��һ���ؼ�������<BR>
	 *
	 * Remove a control factory.<BR>
	 *
	 * @param groupText
	 */
	public void doRemoveFactory(String groupText){
		if(groupText == null)	groupText = "";
		for (Iterator iter = this.factoryEntrys.iterator(); iter.hasNext();) {
			MapEntry entry = (MapEntry) iter.next();

			if(StringUtils.equals(groupText, (String) entry.getKey())){
				IControlFactory factory = (IControlFactory) entry.getValue();
				if(factory == null)
					continue;

				this.factoryEntrys.remove(entry);
				factory.doRemoveValidateListener(this);
				factory.doRemoveValueChangeListener(this);
			}
		}
	}

	/**
	 * ����ؼ�������<BR>
	 *
	 * Clear all control factories.<BR>
	 *
	 * @param r_Factory
	 */
	public void doClearFactory() {

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);

			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			if(t_Factory == null)
				continue;

			t_Factory.doRemoveValidateListener(this);
			t_Factory.doRemoveValueChangeListener(this);
		}

		this.factoryEntrys.clear();
	}

	/**
	 * �������пؼ�������<BR>
	 *
	 * Return all the control factories.<BR>
	 *
	 * @param r_Factory
	 */
	public IControlFactory[] getFactories() {
		IControlFactory[] t_Factories = new IControlFactory[this.factoryEntrys.size()];

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			t_Factories[i] = (IControlFactory) entry.getValue();
		}
		return t_Factories;
	}

	/**
	 * ���ؿؼ�������������<BR>
	 *
	 * return the size of control factories.<BR>
	 */
	public int size() {
		return this.factoryEntrys.size();
	}

	/**
	 * ����ָ�������Ŀؼ�������<BR>
	 *
	 * Return the factory on the specified index.<BR>
	 *
	 * @param r_Index
	 */
	public IControlFactory getFactory(int r_Index) {
		MapEntry entry = (MapEntry) this.factoryEntrys.get(r_Index);

		IControlFactory t_Factory = (IControlFactory) entry.getValue();

		return t_Factory;
	}

	/**
	 * ����UI��Ϣ��<BR>
	 *
	 * Update the ui desciption.<BR>
	 *
	 */
	protected void updateUIDescription() {
		UIElementDescription t_Description = this.getUIDescription();
		if (null == t_Description) {
			return;
		}

		if (t_Description.getWidth() > 0 || t_Description.getHeight() > 0) {
			return;
		}

		int t_Width = 0;
		int t_Height = 0;

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();

			if (t_Factory.isVisible()) {
				UIElementDescription t_NewDescription = t_Factory.getUIDescription();
				if (null != t_NewDescription) {
					t_Width = Math.max(t_Width, t_NewDescription.getWidth());
					t_Height = Math.max(t_Height, t_NewDescription.getHeight());

					if (StringUtils.isBlank(t_Description.getWindowTitle()) && (StringUtils.isNotBlank(t_NewDescription.getWindowTitle()))) {
						t_Description.setWindowTitle(t_NewDescription.getWindowTitle());
					}

					if (StringUtils.isBlank(t_Description.getTitle()) && (StringUtils.isNotBlank(t_NewDescription.getTitle()))) {
						t_Description.setTitle(t_NewDescription.getTitle());
					}
				}
			}
		}

		t_Description.setWidth(t_Width);
		t_Description.setHeight(t_Height);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.base.AbstractControlFactory#doCreateControl(org.eclipse.swt.widgets.Composite,
	 *      int)
	 */
	protected Control doCreateControl(Composite r_Parent, UIDefinition r_UIDefinition) {

		this.updateUIDescription();

		ScrolledComposite t_RootParent = new ScrolledComposite(r_Parent, getDefaultScrollStyle());
		t_RootParent.setBackground(r_Parent.getBackground());
		t_RootParent.setExpandHorizontal(true);
		t_RootParent.setExpandVertical(true);
		t_RootParent.setLayoutData(new GridData(GridData.FILL_BOTH));

		Composite t_Parent = new Composite(t_RootParent, SWT.NONE);
		t_Parent.setBackground(t_RootParent.getBackground());
		t_Parent.setLayout(this.createGridLayout());

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			String groupText = (String) entry.getKey();

			if(t_Factory.isVisible() == false){
				continue;
			}

			if((StringUtils.isNotEmpty(groupText) && needGroup) || (StringUtils.isEmpty(groupText) && needGroup && needEmptyGroup)){
				Group group = new Group(t_Parent, SWT.NONE);
				group.setText(groupText);
				group.setLayout(new GridLayout(1,false));

				if(gridDataMap.get(t_Factory) != null){
					group.setLayoutData(gridDataMap.get(t_Factory));
				}else{
					//���ͱ���һ�㶼��Ҫ�ſ�
					if((t_Factory instanceof AbstractKTableFactory) || (t_Factory instanceof AbstractKTreeFactory)){
					}else{
						group.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
					}
				}

				t_Factory.createControl(group, r_UIDefinition);
			}else{
				t_Factory.createControl(t_Parent, r_UIDefinition);
			}
		}
		t_RootParent.setContent(t_Parent);
		//		t_RootParent.setMinSize(200, 200);
		return t_RootParent;
	}

	/**
	 * �������֡�<BR>
	 *
	 * Create Grid Layout��<BR>
	 *
	 */
	protected int getDefaultScrollStyle() {
		return SWT.NONE | SWT.V_SCROLL | SWT.H_SCROLL;
	}

	/**
	 * �������֡�<BR>
	 *
	 * Create Grid Layout��<BR>
	 *
	 */
	public GridLayout createGridLayout() {
		return new GridLayout(1, false);
	}

	public void addGridLayoutData(IControlFactory controlFactory, GridData gridData){
		this.gridDataMap.put(controlFactory, gridData);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.IControlFactory#getCommand()
	 */
	public ICommand getCommand() {
		CompoundCommand t_CompoundCommand = new CompoundCommand();

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			ICommand t_Command = t_Factory.getCommand();
			if (null != t_Command) {
				t_CompoundCommand.doAddCommand(t_Command);
			}
		}

		return t_CompoundCommand;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	public void load() {
		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			t_Factory.load();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#save()
	 */
	public void save() {
		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			t_Factory.save();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.base.AbstractControlFactory#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value) {
		super.doSetValue(r_Value);

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			t_Factory.setValue(r_Value);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.IControlFactory#isDirty()
	 */
	public boolean isDirty() {
		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();

			if (t_Factory.isDirty()) {
				return true;
			}
		}

		return false;
	}

	/**
	 * {@inheritDoc}
	 */

	public void doInitContext(IValueRepository r_Context) {
		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			t_Factory.initContext(r_Context);
		}
	}

	/**
	 * {@inheritDoc}
	 */

	public void doAddValueChangeListener(IValueChangeListener r_Listener) {
		super.doAddValueChangeListener(r_Listener);

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			t_Factory.doAddValueChangeListener(r_Listener);
		}

	}

	/**
	 * {@inheritDoc}
	 */
	public void doClearValueChangeListeners() {
		super.doClearValueChangeListeners();

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			t_Factory.doClearValueChangeListeners();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void doRemoveValueChangeListener(IValueChangeListener r_Listener) {

		super.doRemoveValueChangeListener(r_Listener);

		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();
			t_Factory.doRemoveValueChangeListener(r_Listener);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean validate(IMessageCaller r_MessageCaller, Event r_Event) {
		for (int i = 0; i < this.factoryEntrys.size(); i++) {
			MapEntry entry = (MapEntry) this.factoryEntrys.get(i);
			IControlFactory t_Factory = (IControlFactory) entry.getValue();

			if (!t_Factory.validate(r_MessageCaller, r_Event)) {
				return false;
			}
		}

		return true;
	}

	public boolean isNeedEmptyGroup() {
		return needEmptyGroup;
	}

	public void setNeedEmptyGroup(boolean needEmptyGroup) {
		this.needEmptyGroup = needEmptyGroup;
	}

	public boolean isNeedGroup() {
		return needGroup;
	}

	public void setNeedGroup(boolean needGroup) {
		this.needGroup = needGroup;
	}

}
