/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.editor.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.ui.editor.swt.layout.base.AbstractLayoutDataBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����ΪGridLayout����GridData��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Used for setting the GridData for GridLayout. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-9-21 ����04:38:26
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: GridLayoutDataBuilder.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.10  2008/03/24 02:10:41  yujl
 * Update��cvsUpdata
 *
 * Revision 1.9  2007/07/13 09:23:23  zhangzh
 * updata:�����ؼ�Indent
 *
 * Revision 1.7  2007/03/22 12:13:48  wanglei
 * ��������
 *
 *
 *
 *
 * Revision 1.6  2007/03/07 05:50:42  wanglei
 * ��ǩ�����
 *
 * Revision 1.5  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public final class GridLayoutDataBuilder extends AbstractLayoutDataBuilder
{
	private boolean horizontalFill = true;

	// �Ƿ�ˮƽ���

	private boolean verticalFill = false;

	// �Ƿ���ֱ���

	private int preferredWidth;

	// �ؼ����ֿ���

	private int preferredHeight;

	// �ؼ����ָ߶�

	private int labelHorizontalAlignment = SWT.LEFT;

	private int labelVerticalAlignment = SWT.CENTER;

	private int horizontalSpan = 1;

	private int verticalSpan = 1;

	private boolean allowLabel = true;

	public int labelHorizontalIndent = 5;

	public int labelVerticalIndent = 5;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public GridLayoutDataBuilder()
	{
		super();
	}

	/**
	 * ����һ��ˮƽ�ʹ�ֱ�����Ĳ��֡�<BR>
	 *
	 * build a layout data to fill both.<BR>
	 */
	public static GridLayoutDataBuilder newFullBothLayout()
	{
		GridLayoutDataBuilder t_Builder = new GridLayoutDataBuilder();

		t_Builder.verticalFill = true;
		t_Builder.horizontalFill = true;

		t_Builder.labelVerticalAlignment = SWT.TOP;

		return t_Builder;
	}

	/**
	 * ����һ����ֱ���еĲ��֡�<BR>
	 *
	 * build a layout data to fill both.<BR>
	 */
	public static GridLayoutDataBuilder newVerticalCenterLabelLayout()
	{
		GridLayoutDataBuilder t_Builder = new GridLayoutDataBuilder();
		t_Builder.setLabelVerticalAlignment(SWT.CENTER);
		return t_Builder;
	}

	/**
	 * ����һ��ˮƽ����Ϊ2�Ĳ��֡�<BR>
	 *
	 * build a layout data which has 2 span cell.<BR>
	 */
	public static GridLayoutDataBuilder newSpanLayout()
	{
		GridLayoutDataBuilder t_Builder = new GridLayoutDataBuilder();
		t_Builder.horizontalSpan = 2;

		t_Builder.verticalFill = true;
		t_Builder.horizontalFill = true;

		return t_Builder;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.layout.base.AbstractLayoutDataBuilder#doLayoutControl(org.eclipse.swt.widgets.Control)
	 */
	protected void doLayoutControl(Control r_LayoutControl)
	{
		if (null != r_LayoutControl)
		{
			GridData t_GridData = new GridData();

			if (this.preferredWidth > 0)
			{
				t_GridData.widthHint = this.preferredWidth;
			}

			if (this.preferredHeight > 0)
			{
				t_GridData.heightHint = this.preferredHeight;
			}

			if (this.horizontalFill)
			{
				t_GridData.horizontalAlignment = GridData.FILL;
				t_GridData.grabExcessHorizontalSpace = true;
			}

			if (this.verticalFill)
			{
				t_GridData.verticalAlignment = GridData.FILL;
				t_GridData.grabExcessVerticalSpace = true;
			}

			t_GridData.horizontalSpan = this.getHorizontalSpan();
			t_GridData.verticalSpan = this.getVerticalSpan();
			t_GridData.verticalIndent = this.labelVerticalIndent;
			t_GridData.horizontalIndent = this.labelHorizontalIndent;
			r_LayoutControl.setLayoutData(t_GridData);
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.layout.base.AbstractLayoutDataBuilder#doLayoutLabel(org.eclipse.swt.widgets.Control)
	 */
	protected void doLayoutLabel(Control r_LabelControl)
	{
		if (null != r_LabelControl)
		{
			GridData t_LabelData = new GridData();
			t_LabelData.verticalAlignment = this.labelVerticalAlignment;
			t_LabelData.horizontalAlignment = this.labelHorizontalAlignment;

			t_LabelData.verticalIndent = this.labelVerticalIndent;
			t_LabelData.horizontalIndent = this.labelHorizontalIndent;

			r_LabelControl.setLayoutData(t_LabelData);
		}

	}

	/**
	 * �����Ƿ�ˮƽ��䵱ǰ�ı༭�ؼ���<BR>
	 *
	 * Return whether fill the editorControl horizontally.<BR>
	 *
	 */
	public final boolean isHorizontalFill()
	{
		return this.horizontalFill;
	}

	/**
	 * �����Ƿ�ˮƽ��䵱ǰ�ı༭�ؼ���<BR>
	 *
	 * Set whether fill the editorControl horizontally.<BR>
	 *
	 * @param r_HorizontalFill
	 *            the horizontalFill to set
	 */
	public final void setHorizontalFill(boolean r_HorizontalFill)
	{
		this.horizontalFill = r_HorizontalFill;
	}

	/**
	 * �����Ƿ�ֱ��䵱ǰ�ı༭�ؼ���<BR>
	 *
	 * Return whether fill the editorControl vertically.<BR>
	 *
	 */
	public final boolean isVerticalFill()
	{
		return this.verticalFill;
	}

	/**
	 * �����Ƿ�ֱ��䵱ǰ�ı༭�ؼ���<BR>
	 *
	 * Set whether fill the editorControl vertically.<BR>
	 *
	 * @param r_VerticalFill
	 *            the verticalFill to set
	 */
	public final void setVerticalFill(boolean r_VerticalFill)
	{
		this.verticalFill = r_VerticalFill;
	}

	/**
	 * ���ص�ǰ�ؼ��Ŀ��ȡ�<BR>
	 *
	 * Return the width for the property editor editorControl.<BR>
	 *
	 */
	public final int getPreferredWidth()
	{
		return this.preferredWidth;
	}

	/**
	 * ���õ�ǰ�ؼ��Ŀ��ȡ�<BR>
	 *
	 * Set the width for the property editor editorControl.<BR>
	 *
	 * @param r_PreferredWidth
	 *            the PreferredWidth to set
	 */
	public final void setPreferredWidth(int r_PreferredWidth)
	{
		this.preferredWidth = r_PreferredWidth;
	}

	/**
	 * ���ص�ǰ�ؼ��ĸ߶ȡ�<BR>
	 *
	 * Return the height for the property editor editorControl.<BR>
	 *
	 */
	public final int getPreferredHeight()
	{
		return this.preferredHeight;
	}

	/**
	 * ���õ�ǰ�ؼ��ĸ߶ȡ�<BR>
	 *
	 * Set the height for the property editor editorControl.<BR>
	 *
	 * @param r_PreferredHeight
	 *            the preferredHeight to set
	 */
	public final void setPreferredHeight(int r_PreferredHeight)
	{
		this.preferredHeight = r_PreferredHeight;
	}

	/**
	 * �����Ƿ�Ա�ǩ���в��ִ�����<BR>
	 *
	 * Return whether layout the label.<BR>
	 *
	 */
	public boolean isAllowLabel()
	{
		return this.allowLabel;
	}

	/**
	 * �����Ƿ�Ա�ǩ���в��ִ�����<BR>
	 *
	 * Set whether layout the label.<BR>
	 *
	 * @param r_AllowLabel
	 *            the allowLabel to set
	 */
	public void setAllowLabel(boolean r_AllowLabel)
	{
		this.allowLabel = r_AllowLabel;
	}

	/**
	 * ����ˮƽ�е�ռλ��<BR>
	 *
	 * Return the horizontal span.<BR>
	 *
	 */
	public int getHorizontalSpan()
	{
		if (this.horizontalSpan < 1)
		{
			this.horizontalSpan = 1;
		}
		return this.horizontalSpan;
	}

	/**
	 * ����ˮƽ�е�ռλ��<BR>
	 *
	 * Return the horizontal span.<BR>
	 *
	 *
	 * @param r_horizontalSpan
	 *            the horizontalSpan to set
	 */
	public void setHorizontalSpan(int r_horizontalSpan)
	{
		this.horizontalSpan = r_horizontalSpan;
	}

	/**
	 * ���ش�ֱ�е�ռλ��<BR>
	 *
	 * Return the vertical span.<BR>
	 *
	 */
	public int getVerticalSpan()
	{
		if (this.verticalSpan < 1)
		{
			this.verticalSpan = 1;
		}
		return this.verticalSpan;
	}

	/**
	 * ���ô�ֱ�е�ռλ��<BR>
	 *
	 * Set the vertical span.<BR>
	 *
	 * @param r_verticalSpan
	 *            the verticalSpan to set
	 */
	public void setVerticalSpan(int r_verticalSpan)
	{
		this.verticalSpan = r_verticalSpan;
	}

	/**
	 * @return the labelHorizontalAlignment
	 */
	public int getLabelHorizontalAlignment()
	{
		return this.labelHorizontalAlignment;
	}

	/**
	 * @param r_LabelHorizontalAlignment
	 *            the labelHorizontalAlignment to set
	 */
	public void setLabelHorizontalAlignment(int r_LabelHorizontalAlignment)
	{
		this.labelHorizontalAlignment = r_LabelHorizontalAlignment;
	}

	/**
	 * @return the labelVerticalAlignment
	 */
	public int getLabelVerticalAlignment()
	{
		return this.labelVerticalAlignment;
	}

	/**
	 * @param r_LabelVerticalAlignment
	 *            the labelVerticalAlignment to set
	 */
	public void setLabelVerticalAlignment(int r_LabelVerticalAlignment)
	{
		this.labelVerticalAlignment = r_LabelVerticalAlignment;
	}

	/**
	 * @return the labelHorizontalIndent
	 */
	public int getLabelHorizontalIndent()
	{
		return this.labelHorizontalIndent;
	}

	/**
	 * @param r_LabelHorizontalIndent
	 *            the labelHorizontalIndent to set
	 */
	public void setLabelHorizontalIndent(int r_LabelHorizontalIndent)
	{
		this.labelHorizontalIndent = r_LabelHorizontalIndent;
	}

	/**
	 * @return the labelVerticalIndent
	 */
	public int getLabelVerticalIndent()
	{
		return this.labelVerticalIndent;
	}

	/**
	 * @param r_LabelVerticalIndent
	 *            the labelVerticalIndent to set
	 */
	public void setLabelVerticalIndent(int r_LabelVerticalIndent)
	{
		this.labelVerticalIndent = r_LabelVerticalIndent;
	}

}
