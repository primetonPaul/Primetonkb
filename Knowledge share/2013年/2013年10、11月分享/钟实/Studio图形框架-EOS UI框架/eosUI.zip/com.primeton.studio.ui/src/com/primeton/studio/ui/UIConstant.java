/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui;


/**
 * UI�����ʹ�õĳ���<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: UIConstant.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/04/27 10:53:08  wanglei
 * Jira:����EOSP-189��
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/06/18 02:55:25  yujl
 * update:�ع���ȡ������controlCreator
 *
 * Revision 1.1  2007/05/16 10:09:13  wanglei
 * �ύ��CVS��
 *
 */
public interface UIConstant {

	public static final String INNER = "inner";

	public static final String TARGET_FOLDER = "targetFolder";

	public static final String AUTO_RECOVER = "autoRecover";

	public static final String PLUGIN_NAME = "pluginName";

	public static final String TARGET_PLUGIN_NAME = "targetPluginName";
	
	public static final String EQ = "==";

	public static final String NE = "!=";

	public static final String GT = ">";

	public static final String GE = ">=";

	public static final String LT = "<";

	public static final String LE = "<=";

	public static final String EQUAL = "ObjEqual";

	public static final String NOT_EQUAL = "ObjNotEqual";

	public static final String IS_NULL = "IsNull";

	public static final String NOT_NULL = "NotNull";

	public static final String NULL_EMPTY = "NullOrEmpty";

	public static final String NOT_NULL_EMPTY = "NotNullAndEmpty";
	
	public static final String TESTER = "tester";
}
