/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */
package com.primeton.studio.ui.swt.builder.ktable.impl;

import org.apache.commons.lang.math.NumberUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.studio.core.util.IntRange;
import com.primeton.studio.ui.swt.builder.ktable.base.AbstractKTableCellEditor;

import de.kupzog.ktable.KTable;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����û�ʹ��Spinner���༭���֡�<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Support editing the number by spinner. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-7-15 ����12:31:23
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: KTableCellEditorNumber.java,v $
 * Revision 1.2  2012/01/12 02:21:29  guwei
 * Update: �汾�������޸ģ�֧��eclipse3.6
 *
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */
public final class KTableCellEditorNumber extends AbstractKTableCellEditor
{
	private Text spinner;

	private IntRange range;

	private boolean validable = false;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public KTableCellEditorNumber()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.kupzog.ktable.KTableCellEditor#open(de.kupzog.ktable.KTable, int, int,
	 *      org.eclipse.swt.graphics.Rectangle)
	 */
	public void open(KTable r_Table, int r_Col, int r_Row, Rectangle r_Rect)
	{
		super.open(r_Table, r_Col, r_Row, r_Rect);

		Object t_Object = super.m_Model.getContentAt(super.m_Col, super.m_Row);

		if (null != t_Object)
		{
			this.spinner.setText(t_Object.toString());
		}

		this.spinner.setVisible(true);
		this.spinner.setFocus();
		this.spinner.selectAll();
	}

	/**
	 * ����û�����������Ƿ���Ч�������ǰ�༭��֧�����ݼ�飬�����ݲ����ϵ�ʱ�򣬻��Զ�����Ϊ���ֵ��<BR>
	 * 
	 * Validate the user input.The the editor support validation,the invalid data will be set to the max value.<BR>
	 * 
	 * @param r_Value
	 *            the value to be validated.
	 */
	protected int doCheck(int r_Value)
	{
		if (this.validable && null != this.range)
		{
			int t_Value = Math.min(this.range.getMax(), r_Value);
			t_Value = Math.max(this.range.getMin(), t_Value);
			return t_Value;
		}
		else
		{
			return r_Value;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.kupzog.ktable.KTableCellEditor#close(boolean)
	 */
	public void close(boolean r_Save)
	{
		if (this.spinner != null)
		{
			if (r_Save)
			{
				String t_Text = this.spinner.getText();
				int t_Value = NumberUtils.toInt(t_Text, 0);

				t_Value = this.doCheck(t_Value);

				super.m_Model.setContentAt(super.m_Col, super.m_Row, new Integer(t_Value));

			}
			this.spinner.removeKeyListener(this.getKeyListener());
			this.spinner.removeTraverseListener(this.getTraverseListener());
		}
		
		Shell topShell = Display.getDefault().getActiveShell();
		Shell comboShell = this.getControl().getShell();
		if(topShell != comboShell){
			return;
		}
		
		super.close(r_Save);
		if (this.spinner != null)
		{
			this.spinner.dispose();
			this.spinner = null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.kupzog.ktable.KTableCellEditor#createControl()
	 */
	protected Control createControl()
	{
		this.spinner = new Text(super.m_Table, SWT.NONE);
		this.spinner.addKeyListener(this.getKeyListener());
		this.spinner.addTraverseListener(this.getTraverseListener());
		return this.spinner;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.kupzog.ktable.KTableCellEditor#setContent(java.lang.Object)
	 */
	public void setContent(Object r_Content)
	{
		this.spinner.setText(super.m_Model.getContentAt(super.m_Col, super.m_Row).toString());
	}

	/**
	 * �����Ƿ��������������Ч�ԡ�<BR>
	 * 
	 * Return whether this editor support validation.<BR>
	 * 
	 * @return Return validable��
	 */
	public boolean isValidable()
	{
		return this.validable;
	}

	/**
	 * �����Ƿ��������������Ч�ԡ�<BR>
	 * 
	 * Set whether this editor support validation.<BR>
	 * 
	 * @param r_Validable
	 *            Set validable��
	 */
	public void setValidable(boolean r_Validable)
	{
		this.validable = r_Validable;
	}

	/**
	 * ����������Ч�ķ�Χ��<BR>
	 * 
	 * Return the valid range for the input.<BR>
	 * 
	 * @return Return range��
	 */
	public IntRange getRange()
	{
		return this.range;
	}

	/**
	 * ����������Ч�ķ�Χ��<BR>
	 * 
	 * Set the valid range for the input.<BR>
	 * 
	 * @param r_Range
	 *            Set range��
	 */
	public void setRange(IntRange r_Range)
	{
		this.range = r_Range;
	}

}
