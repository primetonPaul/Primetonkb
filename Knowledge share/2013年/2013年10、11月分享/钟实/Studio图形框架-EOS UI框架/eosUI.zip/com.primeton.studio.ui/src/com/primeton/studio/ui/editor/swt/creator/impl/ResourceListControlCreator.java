/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/editor/swt/creator/impl/ResourceListControlCreator.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2007-3-18
 *******************************************************************************/


package com.primeton.studio.ui.editor.swt.creator.impl;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.ui.editor.swt.creator.base.AbstractControlCreator;
import com.primeton.studio.ui.editor.swt.impl.ResourceListPropertyEditor;
import com.primeton.studio.ui.swt.component.impl.ResourceListComponent;

/**
 * ������Դ�б��ؼ�
 *
 * @author yangjun (mailto:yangjun@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ResourceListControlCreator.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2007/03/18 09:58:49  yangjun
 * add:�ύ��CVS
 * 
 */
public class ResourceListControlCreator extends AbstractControlCreator
{
	private ResourceListPropertyEditor resourceListPropertyEditor;

	/**
	 * @param r_FileListPropertyEditor
	 */
	public ResourceListControlCreator(ResourceListPropertyEditor resourceListPropertyEditor)
	{
		super();
		this.resourceListPropertyEditor = resourceListPropertyEditor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.swt.creator.base.AbstractControlCreator#doCreateControl(org.eclipse.swt.widgets.Composite,
	 *      int)
	 */
	protected Control doCreateControl(Composite r_Parent, int r_Style)
	{
		ResourceListComponent t_Composite = new ResourceListComponent(r_Parent, SWT.NONE);
		t_Composite.setEditable(!this.resourceListPropertyEditor.isReadonly());

		t_Composite.setFileName(this.resourceListPropertyEditor.getFileName());
		t_Composite.setFileExtension(this.resourceListPropertyEditor.getFileExtension());

		return t_Composite;
	}
}