/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.ktree;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.eclipse.jface.viewers.Viewer;

import com.primeton.studio.core.IBuildable;
import com.primeton.studio.core.tree.ITreeNode;
import com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����ΪKTree�ṩ����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Provide data for KTree. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-21 ����04:51:38
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: TreeDataProvider.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/05/22 08:37:22  wanglei
 * Add:������clear������
 *
 * Revision 1.2  2007/05/22 01:12:43  wanglei
 * UnitTest:�����˶Ա߽�ļ�顣
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public class TreeDataProvider implements ITableDataProvider, IBuildable
{
	private ITreeNode rootNode;

	private List children = new ArrayList();

	/**
	 * ֱ�Ӵ��ݲ��������졣<BR>
	 *
	 * Pass the parameter to constructo a new object.<BR>
	 *
	 * @param r_RootNode
	 */
	public TreeDataProvider(ITreeNode r_RootNode)
	{
		super();
		this.rootNode = r_RootNode;
		this.build();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#clone()
	 */
	public Object clone()
	{
		TreeDataProvider t_Provider = new TreeDataProvider(this.rootNode);
		return t_Provider;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#add(java.lang.Object)
	 */
	public void add(Object r_Object)
	{
		throw new UnsupportedOperationException("add operation is not supported.");
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#get(int)
	 */
	public Object get(int r_Index)
	{
		if(-1==r_Index)
		{
			return null;
		}
		else
		{
			return this.children.get(r_Index);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#getIndex(java.lang.Object)
	 */
	public int indexOf(Object r_Object)
	{
		return this.children.indexOf(r_Object);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#insert(int, java.lang.Object)
	 */
	public void insert(int r_Index, Object r_Object)
	{
		throw new UnsupportedOperationException("insert operation is not supported.");
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#remove(java.lang.Object)
	 */
	public void remove(Object r_Object)
	{
		throw new UnsupportedOperationException("remove operation is not supported.");
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#remove(int)
	 */
	public void remove(int r_Index)
	{
		throw new UnsupportedOperationException("remove operation is not supported.");
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#set(int, java.lang.Object)
	 */
	public Object set(int r_Index, Object r_Object)
	{
		throw new UnsupportedOperationException("set operation is not supported.");
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#size()
	 */
	public int size()
	{
		return this.children.size();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider#sort(java.util.Comparator, boolean)
	 */
	public void sort(Comparator r_Comparator, boolean r_ASC)
	{
		throw new UnsupportedOperationException("sort operation is not supported.");

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.IStructuredContentProvider#getElements(java.lang.Object)
	 */
	public Object[] getElements(Object r_InputElement)
	{
		throw new UnsupportedOperationException("getElements operation is not supported.");
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.IContentProvider#dispose()
	 */
	public void dispose()
	{
		this.children.clear();

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.IContentProvider#inputChanged(org.eclipse.jface.viewers.Viewer, java.lang.Object,
	 *      java.lang.Object)
	 */
	public void inputChanged(Viewer r_Viewer, Object r_OldInput, Object r_NewInput)
	{
		throw new UnsupportedOperationException("inputChanged operation is not supported.");
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IBuildable#build()
	 */
	public void build()
	{
		this.children.clear();

		List tempList = new ArrayList();
		List swapList = new ArrayList();

		for (int i = 0; i < this.rootNode.getChildCount(); i++)
		{
			tempList.add(this.rootNode.getChildAt(i));
		}

		while (tempList.size() > 0)
		{
			ITreeNode child = (ITreeNode) tempList.get(0);

			if (child.isVisible())
			{
				this.children.add(child);
			}

			tempList.remove(0);
			swapList.clear();
			swapList.addAll(tempList);
			tempList.clear();

			if (child.isExpanded() && (!child.isLeaf()))
			{
				for (int i = 0; i < child.getChildCount(); i++)
				{
					tempList.add(child.getChildAt(i));
				}
			}

			tempList.addAll(swapList);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void clear() {
		this.children.clear();
	}
}
