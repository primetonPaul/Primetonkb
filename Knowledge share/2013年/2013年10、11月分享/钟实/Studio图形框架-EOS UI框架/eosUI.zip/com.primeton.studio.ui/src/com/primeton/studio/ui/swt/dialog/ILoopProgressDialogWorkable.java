/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/dialog/ILoopProgressDialogWorkable.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Aug 14, 2008
 *******************************************************************************/


package com.primeton.studio.ui.swt.dialog;

/**
 * ѭ���Ľ������ĺ�̨������work�н��С�
 *
 * @author hongsq (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ILoopProgressDialogWorkable.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/09/01 10:12:09  chenxp
 * Update:��ѭ���Ľ������Ƶ�studio.ui����� (hongsq).
 *
 * Revision 1.1  2008/08/14 06:51:16  hongsq
 * Update:�ṩһ������ѭ���Ľ�����
 *
 */
public interface ILoopProgressDialogWorkable {

	void work(LoopProgressFlag loopProgressFlag);
}
