/**
 * 
 */
package com.primeton.studio.ui.swt.properties.tabbed.entries;

import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.expressions.ElementHandler;
import org.eclipse.core.expressions.EvaluationContext;
import org.eclipse.core.expressions.EvaluationResult;
import org.eclipse.core.expressions.Expression;
import org.eclipse.core.expressions.ExpressionConverter;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.core.util.comparator.PropertyComparator;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.impl.TabbedControlFactory;

/**
 * tab��չ��ڵ�İ�װ,����������ȼ�
 * ��ע������ͨ��elementClassPath��testClassPathΨһ��λһ��element��
 *
 * @author <a href="mailto:yujl@primeton.com">Yu J Lin</a>
 */
/*
 * �޸���ʷ
 * $Log: ElementEntry.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/04/27 10:53:08  wanglei
 * Jira:����EOSP-189��
 * 
 */
public class ElementEntry {
	private static final String FACTORY = "factory";
	protected static final String ENABLEMENT = "enablement";
	private String elementClassPath;
	private Expression expression;
	private TreeSet<ControlFactoryEntry> controlEntrySet = new TreeSet<ControlFactoryEntry>(new PropertyComparator(IConstant.PRIORITY));
	
	/**
	 * Ĭ�Ϲ��췽��
	 * @param element
	 */
	public ElementEntry(IConfigurationElement element) {
		super();
		Assert.isNotNull(element);
		this.elementClassPath = element.getAttribute(IConstant.NAME);
		IConfigurationElement[] children = element.getChildren(ElementEntry.ENABLEMENT);
		if(!ArrayUtils.isEmpty(children)){
			try {
				this.expression = ElementHandler.getDefault().create(ExpressionConverter.getDefault(), children[0]);
			} catch (CoreException e) {
				ExceptionUtil.getInstance().logException(e);
			}
			
		}
		addAllConfigurationElement(element);
	}
	
	/**
	 * @return the elementClassPath
	 */
	public final String getElementClassPath() {
		return elementClassPath;
	}
	
	/**
	 * ��Ҫ���ںϲ���ͬ���õĽڵ�
	 * @param parentElement
	 */
	public void addAllConfigurationElement(IConfigurationElement parentElement) {
		for (IConfigurationElement childElement : parentElement.getChildren()) {
			if(FACTORY.equals(childElement.getName())){
				addControlFactoryEntry(childElement);
			}
			
		}
	}

	/**
	 * ��ʼ��ElementEntry
	 * @param element
	 */
	public void addControlFactoryEntry(IConfigurationElement element){
		ControlFactoryEntry newEntry = new ControlFactoryEntry(element);
		String tab = newEntry.getTab();
		int newPriority = newEntry.getPriority();
		ControlFactoryEntry oldEntry = (ControlFactoryEntry) CollectionUtils.find(controlEntrySet, ControlFactoryEntry.getPredicate(tab));
		if(oldEntry == null){//�����µ�ControlFactoryEntryʱ��Ҫ�������ȼ�����
			controlEntrySet.add(newEntry);
			return;
		}else{
			int oldPriority = oldEntry.getPriority();
			if(oldPriority >= newPriority){
				controlEntrySet.remove(oldEntry);
				controlEntrySet.add(newEntry);
			}
		}
	}
	
	/**
	 * ��ʼ��һ��TabbedControlFactory
	 * @param pluginID
	 * @return
	 */
	public TabbedControlFactory getTabbedControlFactory(String pluginID) {
		TabbedControlFactory factory = new TabbedControlFactory();
		for (Object object : this.controlEntrySet) {
			ControlFactoryEntry entry = (ControlFactoryEntry) object;
			IControlFactory controlFactory = entry.newInstanceControlFactory(pluginID);
			factory.doAddFactory(controlFactory);
		}
		return factory;
	}
	
	/**
	 * ��ʼ��һ��IControlFactory
	 * @param tab
	 * @param pluginID
	 * @return
	 */
	public IControlFactory getControlFactory(String tab, String pluginID) {
		ControlFactoryEntry controlFactoryEntry = (ControlFactoryEntry) CollectionUtils.find(controlEntrySet, ControlFactoryEntry.getPredicate(tab));
		if(controlFactoryEntry == null){
			return null;
		}
		return controlFactoryEntry.newInstanceControlFactory(pluginID);
	}

	/**
	 * �жϽڵ��Ƿ����
	 * @param anElement
	 * @return
	 */
	public boolean isEnable(Object anElement) {
		if (expression == null || anElement == null) {
			return false;
		}

		try {
			EvaluationContext context = new EvaluationContext(null, anElement);
			context.setAllowPluginActivation(true);
			return (expression.evaluate(context) == EvaluationResult.TRUE);
		} catch (CoreException e) {
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((elementClassPath == null) ? 0 : elementClassPath.hashCode());
		result = PRIME * result + ((expression == null) ? 0 : expression.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final ElementEntry other = (ElementEntry) obj;
		if (elementClassPath == null) {
			if (other.elementClassPath != null)
				return false;
		} else if (!elementClassPath.equals(other.elementClassPath))
			return false;
		if (expression == null) {
			if (other.expression != null)
				return false;
		} else if (!expression.equals(other.expression))
			return false;
		return true;
	}

	/**
	 * @return the expression
	 */
	public final Expression getExpression() {
		return expression;
	}
	
}
