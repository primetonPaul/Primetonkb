/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.editor.swt.impl;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;

/**
 *
 *����checkBox��editor��ֻռһ��
 *
 * @author caiwei (mailto:caiwei@primeton.com)
 */
/*
 * $Log: CheckBoxPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/06/04 08:36:01  wanglei
 * Update:֧�ֱ����������ݣ����������ݸı�ʱ������Ӧ�ļ�������
 *
 * Revision 1.1  2008/04/21 11:50:32  zhuxing
 * Update:���ӻ������͵�property editor
 *
 * Revision 1.4  2008/03/03 07:44:36  wanglei
 * Review:�ع�AbstractPropertyEditor����ȥ��doFullValidate����������֮�Է��¼��ķ�ʽ��
 *
 * Revision 1.3  2008/02/28 08:26:27  caiwei
 * update:fix bug3362&3342
 *
 * Revision 1.2  2008/02/20 12:01:33  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2008/01/09 07:11:03  caiwei
 * Update:����������ĵ���
 *
 */

public final class CheckBoxPropertyEditor extends AbstractPropertyEditor {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public CheckBoxPropertyEditor() {
		super();
		setUseLabel(false);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator() {
		return new BooleanControlCreator(this);
	}

	class BooleanControlCreator implements IControlCreator {

		CheckBoxPropertyEditor checkBoxPropertyEditor;

		public BooleanControlCreator(CheckBoxPropertyEditor checkBoxPropertyEditor) {
			super();
			this.checkBoxPropertyEditor = checkBoxPropertyEditor;
		}

		/* (non-Javadoc)
		 * @see org.eclipse.jface.fieldassist.IControlCreator#createControl(org.eclipse.swt.widgets.Composite, int)
		 */
		public Control createControl(Composite parent, int style) {

			Button t_Button = new Button(parent, SWT.CHECK);
			t_Button.setEnabled(!this.checkBoxPropertyEditor.isReadonly());

			t_Button.addSelectionListener(new SelectionAdapter() {
				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
				 */
				public void widgetSelected(SelectionEvent r_Event) {
					CheckBoxPropertyEditor t_BooleanPropertyEditor = BooleanControlCreator.this.checkBoxPropertyEditor;

					Boolean t_BooleanValue=(Boolean)t_BooleanPropertyEditor.getValue();
					t_BooleanPropertyEditor.fireValueChanged(new ValueChangeEvent(t_BooleanPropertyEditor, Boolean.valueOf(!t_BooleanValue.booleanValue()),t_BooleanValue));
				}
			});

			t_Button.setText(this.checkBoxPropertyEditor.getLabel());
			return t_Button;

		}

	}

	/**
	 * ����������BooleanControlCreator��<BR>
	 *
	 * Return the real boolean control creator.<BR>
	 *
	 * @return
	 */
	public BooleanControlCreator getBooleanControlCreator() {
		return (BooleanControlCreator) this.getControlCreator();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue() {
		return Boolean.valueOf(this.getButton().getSelection());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value) {
		Button t_Button = this.getButton();

		if (r_Value instanceof Boolean) {
			t_Button.setSelection(((Boolean) r_Value).booleanValue());
		}
		else if(r_Value instanceof String)
		{
			t_Button.setSelection(Boolean.valueOf((String)r_Value));
		}
		else {
			t_Button.setSelection(false);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf() {
		CheckBoxPropertyEditor t_PropertyEditor = new CheckBoxPropertyEditor();
		return t_PropertyEditor;
	}

	/**
	 * ��������ѡ��İ�ť��<BR>
	 *
	 * Return the button for selection.<BR>
	 *
	 */
	public Button getButton() {
		return (Button) this.getEditorControl();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#afterBuild(com.primeton.studio.core.IAdapter)
	 */
	public void afterBuild(IAdaptable r_Adaptable) {
		super.afterBuild(r_Adaptable);
	}
}
