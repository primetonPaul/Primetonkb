/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.swt.builder.ktable.impl;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.studio.swt.ITextLengthProvider;
import com.primeton.studio.ui.swt.builder.ktable.IKTableColumn;
import com.primeton.studio.ui.swt.builder.ktable.base.AbstractKTableCellEditor;
import com.primeton.studio.ui.swt.builder.model.base.ITableColumnContextHelper;

import de.kupzog.ktable.KTable;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ֧�ֵ������ɱ༭���ı��༭��<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The editor is used to edit a string,it will be activated by a single-click. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-7-15 ����12:30:36
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: KTableCellEditorSingleClickText.java,v $
 * Revision 1.2  2012/01/12 02:21:29  guwei
 * Update: �汾�������޸ģ�֧��eclipse3.6
 *
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.11  2008/04/17 08:44:46  wanglei
 * Update:֧�ֶԱ������ı���Ԫ��༭ʱ�ĳ������ơ�
 *
 * Revision 1.10  2008/04/16 06:31:46  yangmd
 * Bug:�޸�δ�����ٿؼ���bug
 *
 * Revision 1.9  2008/04/12 04:09:17  yangmd
 * Bug:6166,�޸�������ʾʱ������ʹ�������ѡ����ʾ������
 *
 * Revision 1.8  2008/03/18 06:07:07  wanglei
 * Review:����KTable�ؼ��е�Bug��
 *
 * Revision 1.7  2007/07/16 11:59:36  caijing
 * update:ȥ��final
 *
 * Revision 1.6  2007/06/29 09:55:41  wanglei
 * Review:֧��KTable�Ĵ�����ʾ��
 *
 * Revision 1.5  2007/05/22 01:12:07  wanglei
 * UnitTest:�������������Ϊnullʱ��NPE�쳣��
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */
public class KTableCellEditorSingleClickText extends AbstractKTableCellEditor {
	protected Text text;

	private ITextLengthProvider lengthProvider;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public KTableCellEditorSingleClickText() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.KTableCellEditor#open(de.kupzog.ktable.KTable, int, int,
	 *      org.eclipse.swt.graphics.Rectangle)
	 */
	public void open(KTable table, int r_Col, int r_Row, Rectangle r_Rect) {
		if (isKeyAssistant()) {
			this.setInAssitant(true);
		}
		super.open(table, r_Col, r_Row, r_Rect);
		Object t_Value = super.m_Model.getContentAt(super.m_Col, super.m_Row);
		this.text.setText(ObjectUtils.toString(t_Value));
		this.text.selectAll();
		this.text.setVisible(true);
		this.text.setFocus();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.KTableCellEditor#close(boolean)
	 */
	public void close(boolean r_Save) {
		if (isInAssitant()) {
			this.setInAssitant(false);
			return;
		}
		if (null != this.text) {
			this.text.removeKeyListener(this.getKeyListener());
			this.text.removeTraverseListener(this.getTraverseListener());

			if (r_Save) {
				super.m_Model.setContentAt(super.m_Col, super.m_Row, this.text.getText());
			}

		}
		
		Shell topShell = Display.getDefault().getActiveShell();
		Shell comboShell = this.getControl().getShell();
		if(topShell != comboShell){
			return;
		}
		
		super.close(r_Save);
		if (null != this.text) {
			this.text.dispose();
			this.text = null;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.KTableCellEditor#createControl()
	 */
	protected Control createControl() {
		this.text = new Text(super.m_Table, SWT.BORDER);

		if (null != this.lengthProvider) {
			int maxLength = this.lengthProvider.getMaxLength();
			if (maxLength > 0) {
				this.text.setTextLimit(maxLength);
			}
		}

		this.text.addKeyListener(this.getKeyListener());
		this.text.addTraverseListener(this.getTraverseListener());

		KPropertyTableSortedModel t_Model = (KPropertyTableSortedModel) this.m_Model;
		IKTableColumn t_Column = t_Model.getColumn(this.m_Col);
		if (null != t_Column.getAssitantHelper()) {
			t_Column.getAssitantHelper().addContentProposal(this.text, this);
		}
		ITableColumnContextHelper t_ContextHelper = t_Column.getContextHelper();
		if (null != t_ContextHelper) {
			t_ContextHelper.setHelp(t_Column, this.text);
		}

		return this.text;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.KTableCellEditor#setContent(java.lang.Object)
	 */
	public void setContent(Object r_Content) {
		this.text.setText(r_Content.toString());
		this.text.setSelection(r_Content.toString().length());
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableCellEditor#getActivationSignals()
	 */
	public int getActivationSignals() {
		return SINGLECLICK | KEY_ANY;
	}

	/**
	 * @return Returns the lengthProvider.
	 */
	public ITextLengthProvider getLengthProvider() {
		return this.lengthProvider;
	}

	/**
	 * @param lengthProvider The lengthProvider to set.
	 */
	public void setLengthProvider(ITextLengthProvider lengthProvider) {
		this.lengthProvider = lengthProvider;
	}
}
