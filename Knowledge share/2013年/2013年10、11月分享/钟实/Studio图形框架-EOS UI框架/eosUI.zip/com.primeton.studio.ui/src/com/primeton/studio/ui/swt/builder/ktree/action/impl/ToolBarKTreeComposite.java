/**
 * *****************************************************************************
 *
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.ktree.action.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.jface.action.CoolBarManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.CoolBar;
import org.eclipse.swt.widgets.Label;

import com.primeton.studio.swt.util.LayoutUtil;
import com.primeton.studio.ui.swt.builder.ktree.KTreeBuilder;
import com.primeton.studio.ui.swt.builder.ktree.action.IKTreeActionProvider;
import com.primeton.studio.ui.swt.builder.ktree.action.base.AbstractKTreeAction;
import com.primeton.studio.ui.swt.builder.ktree.action.base.AbstractKTreeComposite;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ʹ�ù����������ò�����ť��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Using toolbar to operate the table. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-3-2 ����11:57:20
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ToolBarKTreeComposite.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.5  2007/11/05 02:03:59  zhangzh
 * UntTest:������ʹ�ù�����
 *
 * Revision 1.4  2007/08/29 04:05:22  wanglei
 * Review:��סCoolBar�������϶���
 *
 * Revision 1.3  2007/08/09 04:35:10  wanglei
 * UnitTest:��������������ɫ����ȷ��Bug��ͬʱ��ס���������������϶���
 *
 * Revision 1.2  2007/08/03 05:39:41  wanglei
 * Review:������Table,KTable,KTree�ȸ��ӿؼ�����������ʽ������Ӧ�����˶�Ӧ��Action��
 *
 * Revision 1.1  2007/03/21 12:00:47  wanglei
 * �ύ��CVS
 *
 *
 */

public class ToolBarKTreeComposite extends AbstractKTreeComposite {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_Parent
	 * @param r_Style
	 * @param r_Title
	 * @param r_TreeBuilder
	 * @param r_TableActionProvider
	 * @param r_ActionStyle
	 */
	public ToolBarKTreeComposite(Composite r_Parent, int r_Style, String r_Title, KTreeBuilder r_TreeBuilder, IKTreeActionProvider r_KTreeActionProvider, int r_ActionStyle) {
		super(r_Parent, r_Style, r_Title, r_TreeBuilder, r_KTreeActionProvider, r_ActionStyle);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.component.base.AbstractTableComposite#buildComponent(org.eclipse.swt.widgets.Composite,
	 *      java.lang.String)
	 */
	protected Control createControl(Composite r_Parent, String r_Title, int r_ActionStyle) {
		Composite t_ActionParent = new Composite(this, SWT.FLAT);
		t_ActionParent.setBackground(this.getBackground());

		GridLayout t_Layout = LayoutUtil.createCompactGridLayout(1);
		t_ActionParent.setLayout(t_Layout);

		AbstractKTreeAction[] t_TreeActions = this.getActions();

		if (null != r_Title){
			t_Layout.numColumns = 2;
			Label t_Label = new Label(t_ActionParent, SWT.NONE);
			t_Label.setBackground(this.getBackground());
			t_Label.setText(r_Title);
		}

		if (!ArrayUtils.isEmpty(t_TreeActions)) {
			buildActions(t_ActionParent, t_TreeActions);
		}

		t_ActionParent.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		this.buildTable(r_Parent);
		this.getTreeBuilder().getKTable().setLayoutData(new GridData(GridData.FILL_BOTH));

		this.updateActionStatus();

		return t_ActionParent;
	}

	/**
	 *  ����Action��<BR>
	 *
	 * Build actions.<BR>
	 *
	 * @param r_ActionParent
	 * @param r_TreeActions
	 */
	private void buildActions(Composite r_ActionParent, AbstractKTreeAction[] r_TreeActions) {
		CoolBarManager t_CoolBarManager = new CoolBarManager();

		TreeMap t_ActionMap = new TreeMap();
		for (int i = 0; i < r_TreeActions.length; i++) {
			AbstractKTreeAction t_TableAction = r_TreeActions[i];
			Integer t_GroupID = new Integer(t_TableAction.getGroup());
			List t_List = (List) t_ActionMap.get(t_GroupID);
			if (null == t_List) {
				t_List = new ArrayList(2);
				t_ActionMap.put(t_GroupID, t_List);
			}

			t_List.add(t_TableAction);
		}
		// Sort by group id

		for (Iterator t_Iterator = t_ActionMap.keySet().iterator(); t_Iterator.hasNext();) {
			Integer t_GroupID = (Integer) t_Iterator.next();
			List t_List = (List) t_ActionMap.get(t_GroupID);
			ToolBarManager t_ToolBarManager = new ToolBarManager();

			for (int i = 0; i < t_List.size(); i++) {
				AbstractKTreeAction t_TableAction = (AbstractKTreeAction) t_List.get(i);
				t_ToolBarManager.add(t_TableAction.getAction(this));
			}

			t_CoolBarManager.add(t_ToolBarManager);
		}

		CoolBar t_CoolBar = t_CoolBarManager.createControl(r_ActionParent);
		t_CoolBar.setLocked(true);
		t_CoolBar.setBackgroundMode(SWT.INHERIT_FORCE);
		t_CoolBar.setBackground(this.getBackground());
		GridData t_GridData = new GridData(GridData.FILL_HORIZONTAL);
		t_GridData.horizontalAlignment = SWT.RIGHT;
		t_CoolBar.setLayoutData(t_GridData);


	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.component.base.AbstractTableComposite#getColumnCount()
	 */
	protected int getColumnCount() {
		return 1;
	}

}
