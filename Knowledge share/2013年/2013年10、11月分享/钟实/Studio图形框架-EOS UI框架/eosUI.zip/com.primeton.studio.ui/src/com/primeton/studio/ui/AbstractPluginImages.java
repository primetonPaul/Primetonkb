/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;

import com.primeton.studio.swt.resource.PooledImageDescriptor;

/**
 * �����ṩ���ʹ�õ�ͼƬ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractPluginImages.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/03/19 05:36:44  wanglei
 * Add:�ύ��CVS��
 *
 */

public class AbstractPluginImages {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	protected AbstractPluginImages() {
		super();
	}

	/**
	 * Utility method to create an <code>ImageDescriptor</code> from a path to
	 * a file.
	 */
	public static PooledImageDescriptor createImageDescriptor(String pluginId, String path) {
		ImageDescriptor imageDescriptor = AbstractUIPlugin.imageDescriptorFromPlugin(pluginId, path);
		return PooledImageDescriptor.getImageDescriptor(imageDescriptor);
	}
}
