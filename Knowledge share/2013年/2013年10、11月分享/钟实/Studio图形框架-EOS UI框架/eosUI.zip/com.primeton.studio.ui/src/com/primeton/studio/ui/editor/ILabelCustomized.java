/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/editor/ILabelCustomized.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-4-21
 *******************************************************************************/


package com.primeton.studio.ui.editor;

/**
 * ������ǩ�ɶ��Ƶ���Ϊ.
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ILabelCustomized.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/04/21 04:35:11  zhuxing
 * Update:refactoring, extract label customized interface
 * 
 */
public interface ILabelCustomized {
	/**
	 * �趨��ǩ
	 * 
	 * @param label ��ǩtext
	 */
	public void setLabel(String label);
}
