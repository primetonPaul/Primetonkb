/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.ktree.impl;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.draw2d.ColorConstants;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;

import com.primeton.studio.core.tree.ITreeNode;
import com.primeton.studio.swt.util.SwtResourceUtil;
import com.primeton.studio.ui.swt.builder.ktable.IKTableColumn;
import com.primeton.studio.ui.swt.builder.ktree.KTreeModel;

import de.kupzog.ktable.KTableModel;
import de.kupzog.ktable.renderers.FixedCellRenderer;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��������KTable�̶��е����ṹ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * To paint the tree for the ktable fixed column. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-21 ����10:22:05
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: KTreeFixedCellRenderer.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/10/21 07:32:21  chenxp
 * BUG: 22323 ��web����ͼԪ�У�ѡ�񸽼��е�wsdl��˫�����������У�ʹ������Ӧ��С������˫���󣬺��������û���� (hongsq)
 *
 * Revision 1.2  2009/09/19 06:52:54  chenty
 * BUG��20704
 * [ws��������]�������Զ�������С�ᱨ��ָ�����
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/03/03 06:34:26  wanglei
 * Review:KTableBuilder�е�closeEditor��Ϊͨ�÷����ƶ���KTableUtil�С�
 *
 * Revision 1.5  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.4  2007/11/01 03:34:41  wanglei
 * UnitTest:�����˼������ʱ������Ϊ����Ϊnull���׳��쳣��Bug��
 *
 * Revision 1.3  2007/05/22 05:49:09  lvyuan
 * UnitTest:Fix NullpointException
 *
 * Revision 1.2  2007/05/22 01:26:41  wanglei
 * UnitTest:�������������Ϊnullʱ��NPE�쳣��
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public class KTreeFixedCellRenderer extends FixedCellRenderer
{
	public static final int IMAGE_WIDTH = 10;

	public static final int IMAGE_HEIGHT = 8;

	private ILabelProvider labelProvider;

	private boolean drawSign = true;

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * The derived constructor.<BR>
	 *
	 * @param r_Style
	 */
	public KTreeFixedCellRenderer(int r_Style)
	{
		super(r_Style);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.renderers.FixedCellRenderer#drawCell(org.eclipse.swt.graphics.GC,
	 *      org.eclipse.swt.graphics.Rectangle, int, int, java.lang.Object, boolean, boolean, boolean,
	 *      de.kupzog.ktable.KTableModel)
	 */
	public void drawCell(GC r_GC, Rectangle r_Rect, int r_Col, int r_Row, Object r_Content, boolean r_Focus, boolean r_Fixed, boolean r_Clicked, KTableModel r_Model)
	{
		super.drawCell(r_GC, r_Rect, r_Col, r_Row,  ObjectUtils.toString(r_Content), r_Focus, r_Fixed, r_Clicked, r_Model);

		KTreeModel t_Model = (KTreeModel) r_Model;
		ITreeNode t_Node = t_Model.getNode(r_Row);
		if (0 != r_Col)
		{
			return;
		}

		if (t_Node != null && (!t_Node.isLeaf()) && this.isDrawSign())
		{
			if (t_Node.isExpanded())
			{
				drawExpand(r_GC, r_Rect, t_Node);
			}
			else
			{
				drawCollapse(r_GC, r_Rect, t_Node);
			}
		}

		if (null != t_Node)
		{
			Image t_Image = this.getImage(t_Node);

			try
			{
				if (null != t_Image)
				{
					int t_ImageSpanY = (r_Rect.height - t_Image.getBounds().height) / 2;
					int t_Expansion;

					if (this.isDrawSign())
					{
						t_Expansion = IMAGE_WIDTH * t_Node.getLevel();
					}
					else
					{
						t_Expansion = IMAGE_WIDTH * (t_Node.getLevel() - 1);
					}

					r_GC.drawImage(t_Image, r_Rect.x + t_Expansion, r_Rect.y + t_ImageSpanY);
				}
			}
			finally
			{
				SwtResourceUtil.dispose(t_Image);
			}
		}
	}

	/**
	 * @param r_GC
	 * @param r_Rect
	 * @param t_Node
	 */
	private void drawCollapse(GC r_GC, Rectangle r_Rect, ITreeNode t_Node)
	{
		int t_ImageSpanY = (r_Rect.height - IMAGE_WIDTH) / 2;

		int[] t_Points = new int[6];
		t_Points[0] = r_Rect.x + t_Node.getLevel() * IMAGE_WIDTH - IMAGE_WIDTH + 2;
		t_Points[1] = r_Rect.y + t_ImageSpanY;
		t_Points[2] = t_Points[0];
		t_Points[3] = t_Points[1] + IMAGE_WIDTH-1;
		t_Points[4] = t_Points[0] + IMAGE_WIDTH-1;
		t_Points[5] = t_Points[1] + IMAGE_WIDTH / 2;

		Color t_Background = r_GC.getBackground();
		r_GC.setBackground(ColorConstants.darkGray);
		r_GC.setAntialias(SWT.ON);
		r_GC.fillPolygon(t_Points);
		r_GC.setForeground(t_Background);
	}

	/**
	 * @param r_GC
	 * @param r_Rect
	 * @param t_Node
	 */
	private void drawExpand(GC r_GC, Rectangle r_Rect, ITreeNode t_Node)
	{
		int t_ImageSpanY = (r_Rect.height - IMAGE_HEIGHT) / 2;

		int[] t_Points = new int[6];
		t_Points[0] = r_Rect.x + t_Node.getLevel() * IMAGE_WIDTH - IMAGE_WIDTH + 2;
		t_Points[1] = r_Rect.y + t_ImageSpanY;
		t_Points[2] = t_Points[0] + IMAGE_WIDTH / 2;
		t_Points[3] = t_Points[1] + IMAGE_HEIGHT-1;
		t_Points[4] = t_Points[0] + IMAGE_WIDTH-1;
		t_Points[5] = t_Points[1];

		Color t_Background = r_GC.getBackground();
		r_GC.setBackground(ColorConstants.darkGray);
		r_GC.setAntialias(SWT.ON);
		r_GC.fillPolygon(t_Points);
		r_GC.setForeground(t_Background);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.renderers.FixedCellRenderer#drawCellContent(org.eclipse.swt.graphics.GC,
	 *      org.eclipse.swt.graphics.Rectangle, int, int, java.lang.Object, de.kupzog.ktable.KTableModel,
	 *      org.eclipse.swt.graphics.Color, org.eclipse.swt.graphics.Color)
	 */
	protected void drawCellContent(GC r_GC, Rectangle r_Rect, int r_Col, int r_Row, Object r_Content, KTableModel r_Model, Color r_Background, Color r_Foreground)
	{
		KTreeModel t_Model = (KTreeModel) r_Model;
		IKTableColumn t_Column=t_Model.getColumn(r_Col);
		ITreeNode t_Node = t_Model.getNode(r_Row);

        if(null!=t_Node)
        {
            Color t_Foreground=t_Column.getForeground(t_Node.getUserObject(), r_Col, r_Row);
            Color t_Background=t_Column.getBackground(t_Node.getUserObject(), r_Col, r_Row);

            if(null!=t_Background)
            {
                r_Background=t_Background;
            }

            if(null!=t_Foreground)
            {
                r_Foreground=t_Foreground;
            }
        }

		if (null == t_Node)
		{
			super.drawCellContent(r_GC, r_Rect, r_Col, r_Row, r_Content, r_Model, r_Background, r_Foreground);
			return;
		}
		else
		{
			int t_Expansion = IMAGE_WIDTH * t_Node.getLevel() + this.getExtraImageWidth(t_Node);
			Rectangle t_Rect = new Rectangle(r_Rect.x + t_Expansion, r_Rect.y, r_Rect.width - t_Expansion, r_Rect.height);

			Object t_Content = this.getText(t_Node);
			if (null == t_Content)
			{
				t_Content = r_Content;
			}

			super.drawCellContent(r_GC, t_Rect, r_Col, r_Row, ObjectUtils.toString(t_Content), r_Model, r_Background, r_Foreground);

			t_Rect.x = 1;
			t_Rect.width = t_Expansion;

			r_GC.fillRectangle(t_Rect);
		}
	}

	/**
	 * �����ı���<BR>
	 *
	 * Return the text for the specified object.<BR>
	 *
	 * @param r_Node
	 */
	public String getText(ITreeNode r_Node)
	{
		if (null != this.labelProvider)
		{
			return this.labelProvider.getText(r_Node);
		}
		else
		{
			return null;
		}
	}

	/**
	 * ����ͼƬ��<BR>
	 *
	 * Return the image for the specified object.<BR>
	 *
	 * @param r_Node
	 *
	 */
	public Image getImage(ITreeNode r_Node)
	{
		if (null == this.labelProvider)
		{
			return null;
		}
		else
		{
			return this.labelProvider.getImage(r_Node);
		}
	}

	/**
	 * ����ͼƬ�Ŀ��ȡ�<BR>
	 *
	 * Return the image width for the specified object.<BR>
	 *
	 * @param r_Node
	 */
	public int getExtraImageWidth(ITreeNode r_Node)
	{
		Image t_Image = null;

		try
		{
			if (null != this.labelProvider && null != r_Node)
			{
				t_Image = this.labelProvider.getImage(r_Node);
				if (null != t_Image)
				{
					return t_Image.getImageData().width;
				}
			}
		}
		finally
		{
			SwtResourceUtil.dispose(t_Image);
		}

		return 0;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.renderers.DefaultCellRenderer#getOptimalWidth(org.eclipse.swt.graphics.GC, int, int,
	 *      java.lang.Object, boolean, de.kupzog.ktable.KTableModel)
	 */
	public int getOptimalWidth(GC r_GC, int r_Col, int r_Row, Object r_Content, boolean r_Fixed, KTableModel r_Model)
	{
		KTreeModel t_Model = (KTreeModel) r_Model;
		ITreeNode t_Node = t_Model.getNode(r_Row);
		
		String content = ObjectUtils.toString(r_Content);
		if(null != t_Node){
			content = this.getText(t_Node);
		}
		
		int t_Width = super.getOptimalWidth(r_GC, r_Col, r_Row, content, r_Fixed, r_Model);

		t_Width = t_Width + this.getExtraImageWidth(t_Node);

		if (null == t_Node)
		{
			return t_Width;
		}
		else
		{
			if (this.isDrawSign())
			{
				return t_Width + IMAGE_WIDTH * t_Node.getLevel();
			}
			else
			{
				return t_Width + IMAGE_WIDTH * (t_Node.getLevel() - 1);
			}
		}
	}

	/**
	 * @return Returns the labelProvider.
	 */
	public ILabelProvider getLabelProvider()
	{
		return this.labelProvider;
	}

	/**
	 * @param r_LabelProvider
	 *            The labelProvider to set.
	 */
	public void setLabelProvider(ILabelProvider r_LabelProvider)
	{
		this.labelProvider = r_LabelProvider;
	}

	/**
	 * @return Returns the drawSign.
	 */
	public boolean isDrawSign()
	{
		return this.drawSign;
	}

	/**
	 * @param r_drawSign
	 *            The drawSign to set.
	 */
	public void setDrawSign(boolean r_drawSign)
	{
		this.drawSign = r_drawSign;
	}
}
