/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.model.impl;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.widgets.Composite;

import com.primeton.studio.core.util.entry.StringMapEntry;
import com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn;
import com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumnDescriptor;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ʹ��������������ݱ༭<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Edit data by a combobox.<BR>
 * <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-5-1 14:37:40
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ComboTableColumnDescriptor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.2  2010/06/24 09:17:54  hongsq
 * Update:jira EOSP-286
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/06/05 04:38:00  yujl
 * update:�޸������б����Ĭ����ʾ����
 *
 * Revision 1.6  2007/06/21 12:25:49  lvyuan
 * Update:�ع�������cellEidtor��ʱ�����е����
 *
 * Revision 1.5  2007/03/07 05:05:41  wanglei
 * UnitTest:������ʾ����ʱ�Ĵ��󣬼�����getText����������ʾ��ȷ�����ݡ�
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */
public class ComboTableColumnDescriptor extends AbstractTableColumnDescriptor
{
	private List keys = new ArrayList();

	private List values = new ArrayList();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public ComboTableColumnDescriptor()
	{
		super();
	}

	/**
	 * ����������ʾ�;���Ķ�ֵ��<BR>
	 *
	 * Set the key for display and the value for setting in the format of entry.<BR>
	 *
	 * @param r_Values
	 */
	public void setValues(StringMapEntry[] r_Values)
	{
		this.keys.clear();
		this.values.clear();

		if (null != r_Values)
		{
			for (int i = 0; i < r_Values.length; i++)
			{
				this.keys.add(r_Values[i].getKey());
				this.values.add(r_Values[i].getValue());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#newCellEditor(org.eclipse.jface.viewers.TableViewer)
	 */
	public CellEditor newCellEditor(StructuredViewer r_Viewer, int column)
	{
		String[] t_Values = new String[this.values.size()];
		this.keys.toArray(t_Values);

		ComboBoxCellEditor t_CellEditor = new ComboBoxCellEditor((Composite) r_Viewer.getControl(), t_Values, SWT.READ_ONLY | SWT.FLAT);
		((CCombo) t_CellEditor.getControl()).setVisibleItemCount(15);
		if (null != this.getAssitantHelper())
		{
			CCombo t_Combo = (CCombo) t_CellEditor.getControl();
			this.getAssitantHelper().addContentProposal(t_Combo);
		}

		return t_CellEditor;
	}



	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumnDescriptor#getText(java.lang.Object, org.eclipse.jface.viewers.StructuredViewer)
	 */
	public String getText(Object r_Element, StructuredViewer r_Viewer)
	{
		Object t_Value = super.getValue(r_Element);
		int t_Index = this.values.indexOf(t_Value);
		if(-1!=t_Index)
		{
			String t_String=(String) this.keys.get(t_Index);
			return t_String;
		}
		return super.getText(r_Element, r_Viewer);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#getValue(java.lang.Object)
	 */
	public Object getValue(Object r_Element)
	{
		Object t_Value = super.getValue(r_Element);
		int t_Index = this.values.indexOf(t_Value);
		return new Integer(t_Index);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#setValue(java.lang.Object,
	 *      java.lang.Object)
	 */
	public void setValue(Object r_Element, Object r_Value)
	{
		Object t_Value = r_Value;

		if(r_Value instanceof Integer)
		{
			Integer t_Index = (Integer) r_Value;

			if ((t_Index.intValue() >= 0) && (t_Index.intValue() < this.values.size()))
			{
				t_Value = this.values.get(t_Index.intValue());
			}
		}

		super.setValue(r_Element, t_Value);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn#doClone()
	 */
	public AbstractTableColumn doClone()
	{
		return new ComboTableColumnDescriptor();
	}
}
