/***********************************************************************************************************************
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 1999-2003 The Apache Software Foundation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
 * following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
 * following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any, must include the following acknowlegement:
 * "This product includes software developed by the Apache Software Foundation (http://www.apache.org/)." Alternately,
 * this acknowlegement may appear in the software itself, if and wherever such third-party acknowlegements normally
 * appear.
 *
 * 4. The names "The Jakarta Project", "Commons", and "Apache Software Foundation" must not be used to endorse or
 * promote products derived from this software without prior written permission. For written permission, please contact
 * apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache" nor may "Apache" appear in their names without
 * prior written permission of the Apache Group.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * APACHE SOFTWARE FOUNDATION OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This software consists of voluntary contributions made by many individuals on behalf of the Apache Software
 * Foundation. For more information on the Apache Software Foundation, please see <http://www.apache.org/>.
 *
 */

package com.primeton.studio.ui.swt.builder.ktree.action.base;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.runtime.Assert;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.swt.util.LayoutUtil;
import com.primeton.studio.ui.swt.builder.ktree.KTreeBuilder;
import com.primeton.studio.ui.swt.builder.ktree.action.IKTreeActionProvider;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableCellSelectionAdapter;
import de.kupzog.ktable.SWTX;

/**
 *
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * һ�����ؼ���������������һ��KTree�Ͷ��Action����ЩAction����ͨ��Button����ʾ��Ҳ����ͨ����������<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * A parent composite which contains a ktree and multi actions.<BR>
 * These actions can show in buttons ,it also support toolbar. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-10-29 ����10:39:40
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractKTreeComposite.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/07/18 08:21:20  yangmd
 * Update:֧�ֶ�ѡ
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/03/06 09:45:07  wanglei
 * Review:������KTableBuilderһЩ����ϵĲ��㡣
 *
 * Revision 1.6  2008/02/20 12:01:09  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.5  2007/08/03 05:39:41  wanglei
 * Review:������Table,KTable,KTree�ȸ��ӿؼ�����������ʽ������Ӧ�����˶�Ӧ��Action��
 *
 * Revision 1.4  2007/07/04 01:19:44  wanglei
 * Review:��ȡgetKTableStyle����������̳С�
 *
 * Revision 1.3  2007/06/29 07:28:01  wanglei
 * Review:֧��ȫ���ü��̴�����
 *
 * Revision 1.2  2007/04/12 05:42:37  lvyuan
 * Update:���������ʽ
 *
 * Revision 1.1  2007/03/21 12:03:26  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractKTreeComposite extends Composite {
	private transient AbstractKTreeAction[] actions;

	private transient KTreeBuilder treeBuilder;

	/**
	 * �̳��Ը���Ĺ��캯����<BR>
	 *
	 * Inheried from the super classes.<BR>
	 *
	 * @param r_Parent
	 * @param r_Style
	 * @param r_TreeBuilder
	 * @param r_TreeActionProvider
	 * @param r_ActionStyle
	 */
	public AbstractKTreeComposite(Composite r_Parent, int r_Style, String r_Title, KTreeBuilder r_TreeBuilder, IKTreeActionProvider r_TreeActionProvider, int r_ActionStyle) {
		super(r_Parent, r_Style);
		this.setBackground(r_Parent.getBackground());

		Assert.isNotNull(r_TreeBuilder, "the table builder should not be null.");

		this.treeBuilder = r_TreeBuilder;
		this.setLayout(LayoutUtil.createCompactGridLayout(this.getColumnCount()));

		if (this.treeBuilder.isReadonly()) {
			this.buildTable(this);
			this.treeBuilder.getKTable().setLayoutData(new GridData(GridData.FILL_BOTH));
			return;
		}

		if (null != r_TreeActionProvider) {
			this.actions = r_TreeActionProvider.buildActions(r_TreeBuilder);
		}

		createControl(this, r_Title, r_ActionStyle);

		if (null != this.actions) {
			this.treeBuilder.getKTable().addCellSelectionListener(new KTableCellSelectionAdapter() {

				/*
				 * (non-Javadoc)
				 *
				 * @see de.kupzog.ktable.KTableCellSelectionAdapter#cellSelected(int, int, int)
				 */
				public void cellSelected(int r_Col, int r_Row, int r_Statemask) {
					updateActionStatus();
				}

				/*
				 * (non-Javadoc)
				 *
				 * @see de.kupzog.ktable.KTableCellSelectionAdapter#fixedCellSelected(int, int, int)
				 */
				public void fixedCellSelected(int r_Col, int r_Row, int r_Statemask) {
					this.cellSelected(r_Col, r_Row, r_Statemask);
				}

			});
		}
	}

	/**
	 * ���ഴ�����������߰�ť��������Ӧ��Table��<BR>
	 *
	 * The derived class should implement this method to create toolbar/buttons and table.<BR>
	 *
	 * @param r_Parent
	 * @param r_Title
	 * @param r_ActionStyle
	 */
	protected abstract Control createControl(Composite r_Parent, String r_Title, int r_ActionStyle);

	/**
	 * ����SWT����<BR>
	 *
	 * Build swt table.<BR>
	 *
	 * @param r_Parent
	 *
	 */
	protected void buildTable(Composite r_Parent) {
		KTable t_Table = new KTable(r_Parent, this.getKTableStyle());
		t_Table.setBackground(r_Parent.getBackground());
		this.treeBuilder.setKTable(t_Table);
		this.treeBuilder.build(t_Table,null);
	}

	/**
	 * �õ�KTable����ʽ��<BR>
	 *
	 * Return the style for the KTable.<BR>
	 *
	 * @return
	 */
	protected int getKTableStyle() {
		return SWTX.AUTO_SCROLL | SWT.BORDER | SWT.FULL_SELECTION | SWTX.EDIT_ON_KEY | SWTX.FILL_WITH_LASTCOL|SWT.MULTI;
	}

	/**
	 * GridLayout���ֵ�������<BR>
	 *
	 * The column count for grid layout.<BR>
	 */
	protected abstract int getColumnCount();

	/**
	 * ����Action��״̬����Ϊ�������ѡ����ֱ仯ʱ����Щ�������ܻᱻ��ֹ������Ҫ����Action��״̬��<BR>
	 *
	 * Update the status for actions.<BR>
	 * Because when the selection of the table changes,some actions maybe updated.<BR>
	 *
	 */
	public void updateActionStatus() {
		AbstractKTreeAction[] t_TableActions = this.getActions();
		if (!ArrayUtils.isEmpty(t_TableActions)) {
			for (int i = 0; i < t_TableActions.length; i++) {
				AbstractKTreeAction t_TreeAction = t_TableActions[i];
				t_TreeAction.updateStatus(getTreeBuilder());
			}
		}
	}

	/**
	 * ����KTableBuilder��<BR>
	 *
	 * Return the table builder.<BR>
	 *
	 * @return the treeBuilder
	 */
	public KTreeBuilder getTreeBuilder() {
		return this.treeBuilder;
	}

	/**
	 * @return Returns the actions.
	 */
	public AbstractKTreeAction[] getActions() {
		return this.actions;
	}

}
