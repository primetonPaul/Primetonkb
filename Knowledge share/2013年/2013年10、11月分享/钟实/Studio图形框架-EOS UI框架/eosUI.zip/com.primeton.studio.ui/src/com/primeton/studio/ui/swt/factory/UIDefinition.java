/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.factory;


/**
 * UI��������<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: UIDefinition.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/02/18 05:24:36  wanglei
 * Add:����getStyle������
 *
 * Revision 1.1  2008/02/18 05:06:55  wanglei
 * Add:�ύ��CVS��
 *
 */

public interface UIDefinition {

	/**
	 * �Ƿ�ֻ����<BR>
	 *
	 * @return
	 */
	public boolean isView();

	/**
	 * �Ƿ��������档<BR>
	 *
	 * @return
	 */
	public boolean isEagerSave();

	/**
	 * �õ��ؼ���ʽ��<BR>
	 *
	 * @return
	 */
	public int getStyle();

}
