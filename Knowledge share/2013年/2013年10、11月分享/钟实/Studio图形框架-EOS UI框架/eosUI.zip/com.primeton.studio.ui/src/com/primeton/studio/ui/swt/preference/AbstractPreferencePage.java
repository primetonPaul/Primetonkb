/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.preference;

import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValidateListener;
import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.event.ValidateEvent;
import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.core.util.PropertiesUtil;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.impl.DefaultUIDefinition;
import com.primeton.studio.ui.swt.util.ValidateUtil;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * PreferencePage�Ļ��ࡣ<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The base class for "PreferencePage". <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-1-21 ����05:44:14
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractPreferencePage.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:33  guwei
 * Add: PTP
 *
 * Revision 1.2  2011/03/23 09:32:54  guwei
 * BUG: 33005
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/02/26 09:25:24  wanglei
 * Review:�����ظ����롣
 *
 * Revision 1.6  2008/02/26 03:34:06  wanglei
 * Update:������getControlFactory������
 *
 * Revision 1.5  2008/02/26 02:50:51  wanglei
 * Review:�����ط�setFinished������
 *
 * Revision 1.4  2008/02/26 02:14:39  wanglei
 * Update:������AbstractWorkbenchPreferencePage.
 *
 * Revision 1.3  2007/11/21 06:27:54  wanglei
 * Review:�ڴ����ؼ��ڼ䲻���ܴ�����Ϣ��
 *
 * Revision 1.2  2007/05/24 08:49:17  wanglei
 * UnitTest:����clearʱû����ȷ�����Bug��
 *
 * Revision 1.1  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractPreferencePage extends AbstractWorkbenchPreferencePage implements IMessageCaller, IValueChangeListener, IValidateListener {
	private IControlFactory controlFactory;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 */
	public AbstractPreferencePage() {
		super();
	}

	/**
	 * �ṩҳ��ı����ͼƬ��<BR>
	 *o
	 * Provide a title and image for the preference page.<BR>
	 *
	 * @param r_Title
	 * @param r_Image
	 */
	public AbstractPreferencePage(String r_Title, ImageDescriptor r_Image) {
		super(r_Title, r_Image);
	}

	/**
	 * �ṩҳ��ı��⡣<BR>
	 *
	 * Provide a title for the preference page.<BR>
	 *
	 * @param r_Title
	 */
	public AbstractPreferencePage(String r_Title) {
		super(r_Title);
	}

	/**
	 * {@inheritDoc}
	 */
	protected Control createContents(Composite r_Parent) {
		this.controlFactory = this.getControlFactory();

		if (null != this.controlFactory) {
			Control t_Control = this.controlFactory.createControl(r_Parent, DefaultUIDefinition.DEFAULT_INSTANCE);
			this.controlFactory.doAddValueChangeListener(this);
			this.controlFactory.doAddValidateListener(this);
			return t_Control;
		}
		else {
			return new Composite(r_Parent, SWT.NONE);
		}

	}

	/**
	 * @return
	 */
	protected abstract IControlFactory createControlFactory();

	/**
	 * @return Returns the controlFactory.
	 */
	public IControlFactory getControlFactory() {

		if (null == this.controlFactory) {
			this.controlFactory = this.createControlFactory();
		}

		return this.controlFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public void clear() {
		this.setErrorMessage(null);
	}

	/**
	 * {@inheritDoc}
	 */
	public void error(String r_Message, Properties r_Properties) {
		this.setErrorMessage(r_Message + PropertiesUtil.toString(r_Properties));
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasError() {
		return StringUtils.isNotEmpty(this.getErrorMessage());
	}

	/**
	 * {@inheritDoc}
	 */
	public void info(String r_Message, Properties r_Properties) {
		this.setMessage(r_Message + PropertiesUtil.toString(r_Properties));
	}

	/**
	 * {@inheritDoc}
	 */
	public void warn(String r_Message, Properties r_Properties) {
		this.setMessage(r_Message + PropertiesUtil.toString(r_Properties), IMessageProvider.WARNING);
	}

	/**
	 * {@inheritDoc}
	 */
	public void validateRequested(ValidateEvent r_Event) {
		this.clear();
		if (ValidateUtil.validate(this.controlFactory, this, r_Event)) {
			this.clear();
			this.setValid(true);
		}
		else {
			this.setValid(false);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void valueChange(ValueChangeEvent r_Event) {
		this.validateRequested(r_Event);
	}

}
