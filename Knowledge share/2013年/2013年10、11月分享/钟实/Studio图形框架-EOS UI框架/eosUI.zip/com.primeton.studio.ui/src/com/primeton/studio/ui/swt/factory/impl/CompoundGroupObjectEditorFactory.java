/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/factory/impl/CompoundGroupObjectEditorFactory.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-4-7
 *******************************************************************************/


package com.primeton.studio.ui.swt.factory.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;

import com.primeton.studio.core.ICommand;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.command.CompoundCommand;
import com.primeton.studio.core.event.Event;
import com.primeton.studio.core.model.impl.MapProvider;
import com.primeton.studio.core.util.entry.MapEntry;
import com.primeton.studio.ui.editor.ObjectEditor;
import com.primeton.studio.ui.swt.component.impl.PropertyComposite;
import com.primeton.studio.ui.swt.factory.UIDefinition;
import com.primeton.studio.ui.swt.factory.base.AbstractControlFactory;

/**
 *
 * ���԰Ѷ��ObjectEditor��װ�����Group��
 *
 * ʹ�÷�����
 * 	ͨ��������������MapProvider  ÿ��MapEntry��keyΪ��Ӧ��Group���ı�,valueΪObjectEditor
 *
 * @author hongsq (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: CompoundGroupObjectEditorFactory.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:33  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/05/06 03:30:58  hongsq
 * Update:���԰Ѷ��ObjectEditor��װ�����Group��
 *
 */
public class CompoundGroupObjectEditorFactory extends AbstractControlFactory {
	private ObjectEditor[] objectEditors;

	private MapProvider mapProvider;//ÿ��MapEntry��keyΪ��Ӧ��Group���ı�,valueΪObjectEditor

	private boolean needGroup = true;//�Ƿ�ʹ��Group

	private boolean needEmptyGroup = false;//�ǲ�����GroupTextΪ�յ�group

	private Map<ObjectEditor, GridData> gridDataMap = new HashMap<ObjectEditor, GridData>();//ÿ��ObjectEditor����Group�Ĳ���

	/**
	 * @param objectEditorMap
	 */
	public CompoundGroupObjectEditorFactory(MapProvider mapProvider) {
		super();
		this.mapProvider = mapProvider;
	}

	/**
	 * @return Returns the objectEditor.
	 */
	public final ObjectEditor[] getObjectEditor() {

		if (null == this.objectEditors) {
			this.objectEditors = this.createObjectEditor();
			for (ObjectEditor objectEditor : this.objectEditors) {
				objectEditor.doAddValidateListener(this);
				objectEditor.doAddValueChangeListener(this);
			}
		}

		return this.objectEditors;
	}

	/**
	 * The derived class should implements this method to return a object editor.
	 *
	 * @return
	 */
	public ObjectEditor[] createObjectEditor(){
		this.objectEditors = new ObjectEditor[mapProvider.getValues().size()];

		for(int i = 0; i < mapProvider.getValues().size(); i++){
			MapEntry entry = (MapEntry) mapProvider.getValues().get(i);
			this.objectEditors[i] = (ObjectEditor) entry.getValue();
		}

		return this.objectEditors;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.base.AbstractControlFactory#doCreateControl(org.eclipse.swt.widgets.Composite,
	 *      int)
	 */
	protected Control doCreateControl(Composite parent, UIDefinition uiDefinition) {
		ObjectEditor[] editors = this.getObjectEditor();

		Composite topComposite = new Composite(parent, uiDefinition.getStyle());
		topComposite.setLayout(getGridLayout());
		topComposite.setLayoutData(new GridData(GridData.FILL_BOTH));

		for (ObjectEditor editor : editors) {
			editor.setEagerSave(uiDefinition.isEagerSave());
			editor.setImportant(uiDefinition.isView());

			if (null == editor.getElement() && null != this.getValue()) {
				editor.setElement(this.getValue());
			}

			String groupText = this.mapProvider.getKey(editor);
			if((StringUtils.isNotEmpty(groupText) && needGroup) || (StringUtils.isEmpty(groupText) && needEmptyGroup)){
				Group group = new Group(topComposite, SWT.NONE);
				group.setText(groupText);
				group.setLayout(new GridLayout(1,false));

				GridData gridData = this.gridDataMap.get(editor);
				if(null == gridData){
					gridData = new GridData(GridData.FILL_HORIZONTAL);
				}
				group.setLayoutData(gridData);

				PropertyComposite t_Composite = new PropertyComposite(group, uiDefinition.getStyle(), editor);
				t_Composite.setLayoutData(getGridData());
			}else{
				PropertyComposite t_Composite = new PropertyComposite(topComposite, uiDefinition.getStyle(), editor);
				t_Composite.setLayoutData(getGridData());
			}

		}
		return topComposite;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.IControlFactory#getCommand()
	 */
	public ICommand getCommand() {
		CompoundCommand compoundCommand = new CompoundCommand();

		for (ObjectEditor objectEditor : this.objectEditors) {
			ICommand command = objectEditor.getCommand();
			if(null != command){
				compoundCommand.doAddCommand(command);
			}
		}

		return compoundCommand;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	public void load() {
		for (ObjectEditor objectEditor : this.objectEditors) {
			objectEditor.load();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#save()
	 */
	public void save() {
		try {
			for (ObjectEditor objectEditor : this.objectEditors) {
				objectEditor.save();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected GridData getGridData() {
		return new GridData(GridData.FILL_BOTH);
	}

	protected GridLayout getGridLayout() {
		return new GridLayout();
	}

	public void addGridLayoutData(ObjectEditor objectEditor, GridData gridData){
		this.gridDataMap.put(objectEditor, gridData);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.IControlFactory#isDirty()
	 */
	public boolean isDirty() {
		for (ObjectEditor objectEditor : this.objectEditors) {
			if(objectEditor.isDirty())
				return true;
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean validate(IMessageCaller r_MessageCaller, Event r_Event) {
		for (ObjectEditor objectEditor : this.objectEditors) {
			if(objectEditor.validate(r_MessageCaller, r_Event) == false){
				return false;
			}
		}
		return true;
	}

	public boolean isNeedEmptyGroup() {
		return needEmptyGroup;
	}

	public void setNeedEmptyGroup(boolean needEmptyGroup) {
		this.needEmptyGroup = needEmptyGroup;
	}

	public boolean isNeedGroup() {
		return needGroup;
	}

	public void setNeedGroup(boolean needGroup) {
		this.needGroup = needGroup;
	}

}
