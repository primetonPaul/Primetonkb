/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/component/impl/ResourceListComponent.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-3-18
 *******************************************************************************/


package com.primeton.studio.ui.swt.component.impl;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.FileDialog;

import com.primeton.studio.ui.ResourceMessages;

/**
 * �����û�ѡȡ����ļ����ļ���
 *
 * @author yangjun (mailto:yangjun@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ResourceListComponent.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.3  2010/05/31 08:47:45  wanglei
 * Bug:����26046��
 *
 * Revision 1.2  2009/04/22 09:38:12  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/02/15 09:46:43  wanglei
 * Review:��Դ��messages�����Ƶ������棬���������һ�¡�
 *
 * Revision 1.2  2007/03/23 09:47:41  yangjun
 * update:��������BUG
 *
 * Revision 1.1  2007/03/18 09:58:49  yangjun
 * add:�ύ��CVS
 *
 */
public class ResourceListComponent extends Composite{

	private ListViewer listViewer;

	private Button addFileButton;

	private Button addDirButton;

	private Button removeButton;

	/**
	 * using Set to avoid duplicated file.
	 */
	Set items = new HashSet();

	/**
	 * @param r_Parent
	 * @param r_Style
	 */
	public ResourceListComponent(Composite parent, int style) {
		super(parent, style);
		this.build();
	}
	/**
	 * ��������Ŀؼ�<BR>
	 *
	 * Construct the real controls.<BR>
	 *
	 */
	private void build()
	{
		this.listViewer = new ListViewer(this, SWT.BORDER | SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);

		this.addFileButton = new Button(this, SWT.PUSH);
		this.addFileButton.setText(ResourceMessages.ADD_FILE);

		this.addDirButton = new Button(this, SWT.PUSH);
		this.addDirButton.setText(ResourceMessages.ADD_PATH);

		this.removeButton = new Button(this, SWT.PUSH);
		this.removeButton.setText(ResourceMessages.REMOVE);

		buildLayout();
		buildListener();
	}

	/**
	 * ������ť������<BR>
	 *
	 * Build the listeners for button<BR>
	 */
	private void buildListener()
	{
		this.addFileButton.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent r_Event)
			{
				String[] t_FileNames = doSelect();

				if (null != t_FileNames)
				{
					for (int i = 0; i < t_FileNames.length; i++)
					{
						if (!ResourceListComponent.this.items.contains(t_FileNames[i]))
						{
							ResourceListComponent.this.items.add(t_FileNames[i]);
							ResourceListComponent.this.listViewer.getList().add(t_FileNames[i]);
						}
					}
				}
			}
		});

		this.addDirButton.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent r_Event)
			{
				String[] t_FileNames = new String[]{doSelectOuterResource()};

				if (null != t_FileNames)
				{
					for (int i = 0; i < t_FileNames.length; i++)
					{
						if (t_FileNames[i] != null &&!ResourceListComponent.this.items.contains(t_FileNames[i]))
						{
							ResourceListComponent.this.items.add(t_FileNames[i]);
							ResourceListComponent.this.listViewer.getList().add(t_FileNames[i]);
						}
					}
				}
			}
		});
		// build the listener for "add" button.

		this.removeButton.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent r_Event)
			{
				String[] seletedItems = ResourceListComponent.this.listViewer.getList().getSelection();
				for (String seletedItem : seletedItems) {
					ResourceListComponent.this.items.remove(seletedItem);
					ResourceListComponent.this.listViewer.getList().remove(seletedItem);
				}
			}
		});
		// build the listener for "delete" button.
	}

	/**
	 * �����ؼ��Ĳ���<BR>
	 *
	 * Build the layout for this component<BR>
	 */
	private void buildLayout()
	{
		GridLayout t_Layout = new GridLayout(2, false);
		t_Layout.horizontalSpacing = 0;
		t_Layout.verticalSpacing = 0;
		t_Layout.marginHeight = 0;
		t_Layout.marginWidth = 0;

		this.setLayout(t_Layout);

		GridData t_ListGridData = new GridData(GridData.FILL_BOTH);
		t_ListGridData.verticalSpan = 3;
		t_ListGridData.grabExcessVerticalSpace = true;
		this.listViewer.getList().setLayoutData(t_ListGridData);

		GridData t_GridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL | GridData.VERTICAL_ALIGN_CENTER);

		this.addFileButton.setLayoutData(t_GridData);
		this.removeButton.setLayoutData(t_GridData);
	}

	/**
	 * ��������<BR>
	 *
	 * Set the items of the list viewer.<BR>
	 *
	 * @param r_Items
	 *            the items for the list.
	 */
	public void setItems(String[] r_Items)
	{
		this.items.clear();
		this.listViewer.getList().removeAll();

		if (null == r_Items)
		{
			return;
		}

		this.listViewer.getList().setItems(r_Items);

		for (int i = 0; i < r_Items.length; i++)
		{
			this.items.add(r_Items[i]);
		}
	}

	/**
	 * ��������<BR>
	 *
	 * Return the items of the list viewer.<BR>
	 *
	 */
	public String[] getItems()
	{
		return this.listViewer.getList().getItems();
	}

	/**
	 * @return Returns the listViewer.
	 */
	public ListViewer getListViewer()
	{
		return this.listViewer;
	}

	//

	private boolean editable;

	private String fileName;

	private String fileExtension;

	private boolean inner;

	/**
	 * ����ѡ��Eclipse����Դ�ļ���<BR>
	 *
	 * This method is used to select the eclipse project files.<BR>
	 *
	 */
	String[] doSelectInnerFiles()
	{
		return doSelectOuterFiles();
	}

	/**
	 * ����ѡ��ϵͳ�ļ���<BR>
	 *
	 * This method is used to select the files.<BR>
	 *
	 */
	String[] doSelectOuterFiles()
	{
		FileDialog t_Dialog = new FileDialog(this.getListViewer().getList().getShell(), SWT.MULTI);
		t_Dialog.setFilterNames(StringUtils.split(this.fileName, ','));
		t_Dialog.setFilterExtensions(StringUtils.split(this.fileExtension, ','));

		if (null != t_Dialog.open())
		{
			String t_PathName = t_Dialog.getFilterPath();
			String[] t_FileNames = t_Dialog.getFileNames();

			for (int i = 0; i < t_FileNames.length; i++)
			{
				t_FileNames[i] = t_PathName + File.separator + t_FileNames[i];
			}

			return t_FileNames;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractResourcePropertyEditor#doSelectOuterResource(org.eclipse.swt.widgets.Shell)
	 */
	public String doSelectOuterResource()
	{
		DirectoryDialog t_Dialog = new DirectoryDialog(this.getListViewer().getList().getShell());
		t_Dialog.setText(ResourceMessages.SelectDirectory);
		return t_Dialog.open();
	}

	/**
	 * ���ص�ǰ�ؼ��Ƿ������༭��<BR>
	 *
	 * Return whether this control is editable or not.<BR>
	 *
	 */
	public boolean isEditable()
	{
		return this.editable;
	}

	/**
	 * ���õ�ǰ�ؼ��Ƿ������༭��<BR>
	 *
	 * Set whether this control is editable or not.<BR>
	 *
	 * @param r_Editable
	 *            Set editable��
	 */
	public void setEditable(boolean r_Editable)
	{
		this.editable = r_Editable;
		this.setEnabled(r_Editable);
	}

	/**
	 * ����ѡ���ļ�ʱ�޶�����չ����<BR>
	 *
	 * Return the file extension name for selecting the file.<BR>
	 *
	 * @return Returns the fileExtension.
	 */
	public final String getFileExtension()
	{
		return this.fileExtension;
	}

	/**
	 * ����ѡ���ļ�ʱ�޶�����չ����<BR>
	 *
	 * Set the file extension name for selecting the file.<BR>
	 *
	 * @param r_FileExtension
	 *            The fileExtension to set.
	 */
	public final void setFileExtension(String r_FileExtension)
	{
		this.fileExtension = r_FileExtension;
	}

	/**
	 * ����ѡ����ļ�����<BR>
	 *
	 * Return the selected file name.<BR>
	 *
	 * @return Returns the fileName.
	 */
	public final String getFileName()
	{
		return this.fileName;
	}

	/**
	 * ����ѡ����ļ�����<BR>
	 *
	 * Set the selected file name.<BR>
	 *
	 * @param r_FileName
	 *            The fileName to set.
	 */
	public final void setFileName(String r_FileName)
	{
		this.fileName = r_FileName;
	}

	/**
	 * �����ж���ѡ��Eclipse�ڲ��ļ���Դ����ϵͳ���ļ���Դ���������ֵΪ <code>false</code>����ѡ��ϵͳ�ļ���Դ������ѡ��Eclipse���ļ���Դ��<BR>
	 *
	 * Return whether the selected is for eclipse file resources or the OS file resources.<BR>
	 * If the return value is <code>false</code>,the operation of selection for OS file resources will be called.<BR>
	 * Otherwise,the operation of selection for eclipse file resources will be called.<BR>
	 *
	 * @return Returns the inner.
	 */
	public final boolean isInner()
	{
		return this.inner;
	}

	/**
	 * ����������ѡ��Eclipse�ڲ��ļ���Դ����ϵͳ���ļ���Դ���������ֵΪ <code>false</code>����ѡ��ϵͳ�ļ���Դ������ѡ��Eclipse���ļ���Դ��<BR>
	 *
	 * Set whether the selected is for eclipse file resources or the OS file resources.<BR>
	 * If the parameter value is <code>false</code>,the operation of selection for OS file resources will be called.<BR>
	 * Otherwise,the operation of selection for eclipse file resources will be called.<BR>
	 *
	 * @param r_Inner
	 *            The inner to set.
	 */
	public final void setInner(boolean r_Inner)
	{
		this.inner = r_Inner;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.component.AbstractElementListComponent#doSelect()
	 */
	protected String[] doSelect()
	{
		if (isInner())
		{
			return doSelectInnerFiles();
		}
		else
		{
			return doSelectOuterFiles();
		}
	}

}
