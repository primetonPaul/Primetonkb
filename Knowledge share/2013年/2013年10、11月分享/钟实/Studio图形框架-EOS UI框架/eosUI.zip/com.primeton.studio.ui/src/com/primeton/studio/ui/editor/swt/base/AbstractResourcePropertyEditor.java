/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.editor.swt.base;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.studio.ui.editor.ILayoutDataBuilder;
import com.primeton.studio.ui.editor.ObjectEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.ResourceControlCreator;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ѡ���ļ�������Ŀ¼����Դ<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Select files ,directory or other resources.<BR>
 * <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractResourcePropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/04/08 08:27:30  chenxp
 * Update: ����updateViewMode��������ȷ�û�browser button.
 *
 * Revision 1.2  2008/02/29 03:29:13  yujl
 * Update���޸Ŀ�ָ���쳣
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.6  2007/08/29 08:47:58  yangmd
 * Update:���Ӵ�����ʾ����
 *
 * Revision 1.5  2007/05/23 01:13:33  wanglei
 * UnitTest:�ı���Ҳ֧�ּ����¼���
 *
 * Revision 1.4  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractResourcePropertyEditor extends AbstractListenerPropertyEditor
{
	private boolean allowMultiSelect = false;

	private boolean inner = false;

	private String innerBinding;

	private String innerReverseBinding;

	

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public AbstractResourcePropertyEditor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator()
	{
		return new ResourceControlCreator(this);
	}

	/**
	 * ����������ResourceControlCreator��<BR>
	 *
	 * Return the real resource control creator.<BR>
	 *
	 * @return
	 */
	public ResourceControlCreator getResourceControlCreator()
	{
		return (ResourceControlCreator) this.getControlCreator();
	}

	/**
	 * ����ѡ��Eclipse�ڲ����ļ���Դ��<BR>
	 *
	 * This method is used to select the eclipse inner files.<BR>
	 *
	 * @param r_Shell
	 *            the window shell.
	 */
	public abstract String doSelectInnerResource(Shell r_Shell);

	/**
	 * ����ѡ�����֧�ֵ��ļ���Դ��<BR>
	 *
	 * This method is used to select the OS files.<BR>
	 *
	 * @param r_Shell
	 *            the window shell.
	 */
	public abstract String doSelectOuterResource(Shell r_Shell);

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		return this.getText().getText();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value)
	{
		if (r_Value instanceof String)
		{
			this.getText().setText((String) r_Value);
		}
	}

	/**
	 * �����Ƿ�֧����Դ�Ķ�ѡ��<BR>
	 *
	 * Return whether the selection of resources support multi or not.<BR>
	 *
	 * @return Returns the allowMultiSelect.
	 */
	public final boolean isAllowMultiSelect()
	{
		return this.allowMultiSelect;
	}

	/**
	 * �����Ƿ�֧����Դ�Ķ�ѡ��<BR>
	 *
	 * Set whether the selection of resources support multi or not.<BR>
	 *
	 * @param r_AllowMultiSelect
	 *            The allowMultiSelect to set.
	 */
	public final void setAllowMultiSelect(boolean r_AllowMultiSelect)
	{
		this.allowMultiSelect = r_AllowMultiSelect;
	}

	/**
	 * �������true,��ѡ�����Դ��ָEclipseƽ̨�ڵ���Դ<BR>
	 *
	 * If the return value is "true", the resources should be in the eclipse workbench.<BR>
	 *
	 * @return Returns the inner.
	 */
	public final boolean isInner()
	{
		return this.inner;
	}

	/**
	 * ������Դ��ʽ���������true,����ѡ�����Դ��ָEclipseƽ̨�ڵ���Դ<BR>
	 *
	 * If the setted value is "true", the resources should be in the eclipse workbench.<BR>
	 *
	 * @param r_Inner
	 *            The inner to set.
	 */
	public final void setInner(boolean r_Inner)
	{
		this.inner = r_Inner;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneProperty(com.primeton.studio.ui.editor.swt.AbstractPropertyEditor)
	 */
	public void cloneProperty(AbstractPropertyEditor r_PropertyEditor)
	{
		super.cloneProperty(r_PropertyEditor);
		((AbstractResourcePropertyEditor) r_PropertyEditor).allowMultiSelect = this.allowMultiSelect;
		((AbstractResourcePropertyEditor) r_PropertyEditor).inner = this.inner;
		((AbstractResourcePropertyEditor) r_PropertyEditor).innerBinding = this.innerBinding;
		((AbstractResourcePropertyEditor) r_PropertyEditor).innerReverseBinding = this.innerReverseBinding;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#afterBuild(com.primeton.studio.core.IAdapter)
	 */
	public void afterBuild(IAdaptable r_Adaptable)
	{
		super.afterBuild(r_Adaptable);

		if (StringUtils.isNotEmpty(this.innerBinding))
		{
			ObjectEditor t_ObjectEditor = (ObjectEditor) r_Adaptable.getAdapter(ObjectEditor.class);
			final Button t_InnerButton = (Button) t_ObjectEditor.getPropertyEditor(this.innerBinding).getAdapter(Control.class);

			t_InnerButton.addSelectionListener(new SelectionAdapter()
			{
				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
				 */
				public void widgetSelected(SelectionEvent r_Event)
				{
					setInner(t_InnerButton.getSelection());
					AbstractResourcePropertyEditor.this.getText().setText("");
				}
			});
		}

		if (StringUtils.isNotEmpty(this.innerReverseBinding))
		{
			ObjectEditor t_ObjectEditor = (ObjectEditor) r_Adaptable.getAdapter(ObjectEditor.class);
			final Button t_InnerButton = (Button) t_ObjectEditor.getPropertyEditor(this.innerReverseBinding).getAdapter(Control.class);
			ResourceControlCreator t_Creator=this.getResourceControlCreator();
			t_Creator.getBrowseButton().setEnabled(!t_InnerButton.getSelection());

			t_InnerButton.addSelectionListener(new SelectionAdapter()
			{
				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
				 */
				public void widgetSelected(SelectionEvent r_Event)
				{
					setInner(!t_InnerButton.getSelection());
					AbstractResourcePropertyEditor.this.getText().setText("");
				}
			});
		}

		Text t_Text = this.getText();

		t_Text.addFocusListener(this);
		t_Text.addKeyListener(this);
		t_Text.addSelectionListener(this);
		t_Text.addModifyListener(this);
		
		if (null != this.getAssitantHelper())
		{
			this.getAssitantHelper().addContentProposal(t_Text);
		}
	}

	/**
	 * ���ذ󶨵����ԣ���������������ѡ���ⲿ��Դ����Eclipse�ڲ���Դ��<BR>
	 *
	 * Return the binding name for the selection of inner or outer resources.<BR>
	 *
	 * @return Returns the innerBinding.
	 */
	public final String getInnerBinding()
	{
		return this.innerBinding;
	}

	/**
	 * ���ð󶨵����ԣ���������������ѡ���ⲿ��Դ����Eclipse�ڲ���Դ��<BR>
	 *
	 * Set the binding name for the selection of inner or outer resources.<BR>
	 *
	 * @param r_InnerBinding
	 *            The innerBinding to set.
	 */
	public final void setInnerBinding(String r_InnerBinding)
	{
		this.innerBinding = r_InnerBinding;
	}

	/**
	 * ���ط���󶨵����ԣ������������������ѡ���ⲿ��Դ����Eclipse�ڲ���Դ��<BR>
	 *
	 * Return the reverse binding name for the selection of inner or outer resources.<BR>
	 *
	 * @return Returns the innerReverseBinding.
	 */
	public final String getInnerReverseBinding()
	{
		return this.innerReverseBinding;
	}

	/**
	 * ���÷���󶨵����ԣ���������������ѡ���ⲿ��Դ����Eclipse�ڲ���Դ��<BR>
	 *
	 * Set the reverse binding name for the selection of inner or outer resources.<BR>
	 *
	 * @param r_InnerReverseBinding
	 *            The innerReverseBinding to set.
	 */
	public final void setInnerReverseBinding(String r_InnerReverseBinding)
	{
		this.innerReverseBinding = r_InnerReverseBinding;
	}

	/**
	 * ������Դ���ı������<BR>
	 *
	 * Return the text to input resource.<BR>
	 *
	 * @return the resourceText
	 */
	public Text getText()
	{
		ResourceControlCreator t_ControlCreator = (ResourceControlCreator) this.getControlCreator();
		if(t_ControlCreator == null){
			return null;
		}
		return t_ControlCreator.getResourceText();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createLayoutDataBuilder()
	 */
	protected ILayoutDataBuilder createLayoutDataBuilder()
	{
		return GridLayoutDataBuilder.newVerticalCenterLabelLayout();
	}

	@Override
	protected void updateViewMode() {
		ResourceControlCreator t_Creator=this.getResourceControlCreator();
		t_Creator.getBrowseButton().setEnabled(this.isEnable() && (!this.isViewMode()));
		
		super.updateViewMode();
	}


}
