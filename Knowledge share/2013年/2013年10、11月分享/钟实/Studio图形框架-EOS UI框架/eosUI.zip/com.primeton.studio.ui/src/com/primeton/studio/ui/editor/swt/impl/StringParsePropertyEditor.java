/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/editor/swt/impl/StringParsePropertyEditor.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-3-15
 *******************************************************************************/


package com.primeton.studio.ui.editor.swt.impl;

import java.util.StringTokenizer;

import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;

/**
 * ���ı���༭������������<br>
 * ��:���ı���֧��int��ֵ�༭��
 *
 * @author yangjun (mailto:yangjun@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: StringParsePropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.3  2008/02/14 09:43:22  yangmd
 * Update:�ع�����
 *
 * Revision 1.2  2007/06/19 01:50:31  wanglei
 * Update:����setReadonly������
 *
 * Revision 1.1  2007/03/18 08:00:33  yangjun
 * Add:�ύ��CVS
 *
 */
public class StringParsePropertyEditor extends StringPropertyEditor
{
	private Class clazz = String.class;
	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public StringParsePropertyEditor()
	{
		super();
	}

	/**
	 * ���ô��༭������<br>
	 * ��:��ֵ��<b>int</b> setClazz(int.class)
	 * @param clazz The clazz to set.
	 */
	public void setClazz(Class clazz) {
		this.clazz = clazz;
	}
	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		if (null == this.getText())
		{
			return null;
		}

		if (clazz == String.class){
			return this.getText().getText();
		}

		if (clazz == String[].class){
			String text = this.getText().getText();

			//���ַ�����"_"�ָ������
			StringTokenizer toker = new StringTokenizer(text, " ");
			String[] result = new String[toker.countTokens()];

		    int k = 0;
		    while (toker.hasMoreTokens()) {
			    result[k] = toker.nextToken();
			    k++;
			}

			return result;
		}

		if (clazz == int.class || clazz == Integer.class){
			String text = this.getText().getText();
			if(text.equals(""))
				return null;
			try{
				return Integer.parseInt(text);
			}catch (Exception e) {
				return text;
			}


		}

		return this.getText().getText();



		//return this.getText().getText();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object value)
	{
		if (value != null)
		{
			if (value instanceof String)
			{
				this.getText().setText((String) value);
			}

			if (clazz == String[].class)
			{
				String[] values = (String[]) value;
				StringBuffer sb = new StringBuffer();
				for (int i = 0; i < values.length; i++) {
					if (i != 0)
						sb.append(" ");
					sb.append(values[i]);
				}
				this.getText().setText(sb.toString());
			}

			if (clazz == int.class || clazz == Integer.class)
			{
				this.getText().setText(((Integer)value).toString());
			}
		}
		else
		{
			this.getText().setText("");
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf()
	{
		StringParsePropertyEditor t_Editor = new StringParsePropertyEditor();

		t_Editor.setValidateStrategy(this.getValidateStrategy());
		t_Editor.setUsePassword(this.isUsePassword());
		t_Editor.setMulti(this.isMulti());
		t_Editor.setClazz(this.clazz);
		
		return t_Editor;
	}

}