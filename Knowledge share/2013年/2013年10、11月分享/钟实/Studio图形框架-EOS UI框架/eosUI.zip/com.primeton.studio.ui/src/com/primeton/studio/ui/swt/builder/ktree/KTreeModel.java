/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.ktree;

import org.eclipse.swt.graphics.Point;

import com.primeton.studio.core.tree.ITreeNode;
import com.primeton.studio.ui.swt.builder.ktable.IKTableColumn;
import com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel;
import com.primeton.studio.ui.swt.builder.ktree.impl.KTreeFixedCellRenderer;

import de.kupzog.ktable.KTableCellEditor;
import de.kupzog.ktable.KTableCellRenderer;
import de.kupzog.ktable.renderers.DefaultCellRenderer;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��KTable�Ϲ���һ������<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Build a tree on ktable. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-21 ����04:19:43
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: KTreeModel.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.4  2009/04/23 07:58:18  lvyuan
 * BugFix:fix bug 17729 by chenxp
 *
 * Revision 1.3  2008/12/03 05:21:00  lvyuan
 * BugFix:fix bug 13277
 *
 * Revision 1.2  2008/09/10 08:48:16  yanfei
 * BUG 10952 WSDL�ļ�,�ڱ༭������ȫ��ʱ,,�༭�ᵼ��Table�β��
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.12  2008/05/27 02:39:43  wanglei
 * UnitTest:����û����ȷ���㵥Ԫ��ϲ���Bug��
 *
 * Revision 1.11  2008/03/06 09:45:07  wanglei
 * Review:������KTableBuilderһЩ����ϵĲ��㡣
 *
 * Revision 1.10  2008/02/25 09:20:23  wanglei
 * Review:ΪIValidable��validate��������IMessageCaller��Event����������
 *
 * Revision 1.9  2007/10/08 01:30:31  chenxp
 * UnitTest:fix a bug.Ӧ�������õ�Ԫ����ֵ֮ǰȡ�þ�ֵ
 *
 * Revision 1.8  2007/07/19 01:28:33  wanglei
 * Reivew:��validate����valueChangeǰ�棬������֤����֪ͨ��
 *
 * Revision 1.7  2007/06/06 10:04:07  wanglei
 * Update:������ITableValueChangeListener�ӿڡ�
 *
 * Revision 1.6  2007/06/05 09:08:11  wanglei
 * UnitTest:������ӳ��ʱ���ݲ��������Bug��
 *
 * Revision 1.5  2007/05/23 09:13:27  wanglei
 * UnitTest:����getNode��Bug��
 *
 * Revision 1.4  2007/05/22 01:10:47  wanglei
 * Refactor:��getRowObject����������
 *
 * Revision 1.3  2007/03/21 12:22:46  wanglei
 * Update:�ع�KTreeCellRenderer����ı仯��
 *
 *
 *
 * Revision 1.2  2007/03/21 12:00:33  wanglei
 * Update:����moveDown,moveUp�Ȳ�����
 *
 *
 *
 * Revision 1.1 2007/03/05 06:06:34 wanglei �ύ��CVS
 *
 */

public class KTreeModel extends KPropertyTableSortedModel {
	private TreeDataProvider treeDataProvider;

	private KTreeFixedCellRenderer treeCellRenderer = new KTreeFixedCellRenderer(DefaultCellRenderer.STYLE_FLAT);

	/**
	 * ֱ��ͨ�����캯��������ص�ֵ��<BR>
	 *
	 * Pass the value by the constructor parameter.<BR>
	 *
	 * @param r_TableColumns
	 *            the definations for table columns.
	 * @param r_HeaderVisible
	 *            set the table header visible or not.
	 * @param r_DataProvider
	 *            the data provider to provide the data for the ktable.
	 * @param r_RootNode
	 *            the root node for the tree.
	 */
	public KTreeModel(IKTableColumn[] r_TableColumns, boolean r_HeaderVisible, ITreeNode r_RootNode) {
		super(r_TableColumns, r_HeaderVisible, new TreeDataProvider(r_RootNode));
		this.treeDataProvider = (TreeDataProvider) this.getDataProvider();
	}

	/**
	 * ����ָ���ж�Ӧ������㡣<BR>
	 *
	 * Return the tree node for the specified row.<BR>
	 *
	 * @param r_Row
	 */
	public ITreeNode getNode(int r_Row) {

		if (r_Row < 0 || r_Row >= this.getRowCount()) {
			return null;
		}

		Object t_Content = null;

		if (this.isHeaderVisible()) {
			if (0 == r_Row) {
				return null;
			}

			t_Content = this.treeDataProvider.get(r_Row - 1);
		}
		else {
			t_Content = this.treeDataProvider.get(r_Row);
		}

		if (t_Content instanceof ITreeNode) {
			return (ITreeNode) t_Content;
		}
		else {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#doBelongsToCell(int, int)
	 */
	public Point doBelongsToCell(int r_Column, int r_Row) {
//		if (this.getFixedHeaderColumnCount() != 1) {
//			return new Point(r_Column, r_Row);
//		}

		if (0 > r_Row || r_Row >= this.getRowCount()) {
			return new Point(r_Column, r_Row);
		}

		if (0 > r_Column || r_Column >= this.getColumnCount()) {
			return new Point(r_Column, r_Row);
		}

		ITreeNode t_ChildNode = this.getNode(r_Row);
		if (null == t_ChildNode) {
			return new Point(r_Column, r_Row);
		}

		if (r_Column != 0) {

			if(t_ChildNode.getChildCount()==0)
			{
				return new Point(r_Column, r_Row);
			}
			else
			{
				int t_NewColumn = t_ChildNode.belongsToCell(r_Column);
				return new Point(t_NewColumn, r_Row);
			}
		}

		if (0 == r_Row && this.isHeaderVisible()) {
			return new Point(r_Column, r_Row);
		}

		if (!t_ChildNode.isLeaf()) {
			return new Point(r_Column, r_Row);
		}

		ITreeNode t_ParentNode = t_ChildNode.getParent();

		if (null == t_ParentNode || (!t_ParentNode.isMergeChildren())) {
			return new Point(r_Column, r_Row);
		}

		for (int i = 0; i < t_ParentNode.getChildCount(); i++) {
			if (t_ParentNode.getChildAt(i) == t_ChildNode) {
				return new Point(r_Column, r_Row - i);
			}
		}

		return new Point(r_Column, r_Row);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel#doGetCellRenderer(int, int)
	 */
	public KTableCellRenderer doGetCellRenderer(int r_Column, int r_Row) {
		if (0 == r_Column) {
			return this.treeCellRenderer;
		}
		return super.doGetCellRenderer(r_Column, r_Row);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel#doGetCellEditor(int, int)
	 */
	public KTableCellEditor doGetCellEditor(int r_Column, int r_Row) {
		if (0 == r_Column) {
			return null;
		}
		return super.doGetCellEditor(r_Column, r_Row);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel#isRowResizable(int)
	 */
	public boolean isRowResizable(int r_Row) {
		ITreeNode t_Node = this.getNode(r_Row);
		if (null == t_Node || null == t_Node.getParent()) {
			return super.isRowResizable(r_Row);
		}

		if (!t_Node.isLeaf()) {
			return super.isRowResizable(r_Row);
		}

		ITreeNode t_ParentNode = t_Node.getParent();
		if (t_ParentNode.getIndex(t_Node) == (t_ParentNode.getChildCount() - 1)) {
			return true;
		}
		else {
			return false;
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel#doGetContentAt(int, int)
	 */
	public Object doGetContentAt(int r_Column, int r_Row) {
		if (this.isHeaderVisible()) {
			if (0 == r_Row) {
				return this.getColumn(r_Column).getTitle();
			}
		}

		ITreeNode t_Node = this.getNode(r_Row);
		if(t_Node==null)
			return null;
		
		Object t_Value = this.getColumn(r_Column).getContent(t_Node.getUserObject(), r_Column, r_Row);

		return t_Value;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel#doSetContentAt(int, int,
	 *      java.lang.Object)
	 */
	public void doSetContentAt(int r_Column, int r_Row, Object r_Value) {
		if (this.isFixedCell(r_Column, r_Row)) {
			return;
		}

		Object t_OldValue = this.getContentAt(r_Column, r_Row);

		ITreeNode t_Node = this.getNode(r_Row);
		
		if(t_Node != null){
			this.getColumn(r_Column).setContent(t_Node.getUserObject(), r_Column, r_Row, r_Value);
		}
	

		this.fireValueChanged(t_OldValue, r_Value, r_Column, r_Row);


	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel#getValidateObject(int)
	 */
	public Object getRowObject(int r_Row) {
		ITreeNode t_Node = this.getNode(r_Row);
		if (null == t_Node) {
			return null;
		}
		else {
			return t_Node.getUserObject();
		}
	}

	/**
	 * @return Returns the treeCellRenderer.
	 */
	public KTreeFixedCellRenderer getTreeCellRenderer() {
		return this.treeCellRenderer;
	}

	/**
	 * @return Returns the treeDataProvider.
	 */
	public TreeDataProvider getTreeDataProvider() {
		return this.treeDataProvider;
	}

	/**
	 * {@inheritDoc}
	 */
	public int mapRowIndexToModel(int r_Row) {
		return r_Row;
	}

	/**
	 * {@inheritDoc}
	 */
	public int mapRowIndexToTable(int r_Row) {
		return r_Row;
	}

}
