/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */
package com.primeton.studio.ui.swt.component.base;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

import com.primeton.studio.ui.ResourceMessages;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * һ��ʹ���б�֧��ѡ����Ԫ�صĻ���<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * The abstract class for the multi selection elements.<BR>
 * <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 13:12:53
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: AbstractElementListComponent.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/02/15 09:46:43  wanglei
 * Review:��Դ��messages�����Ƶ������棬���������һ�¡�
 *
 * Revision 1.2  2007/07/23 12:32:59  yangmd
 * Unitest:�޸�ɾ���Ժ������ӵ�bug
 *
 * Revision 1.1  2007/03/05 06:06:35  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractElementListComponent extends Composite
{
	private ListViewer listViewer;

	private Button addButton;

	private Button removeButton;

	/**
	 * using Set to avoid duplicated file.
	 */
	Set items = new HashSet();

	/**
	 * Inherited from the super constructor.<BR>
	 * 
	 * @param r_Parent
	 * @param r_Style
	 */
	public AbstractElementListComponent(Composite r_Parent, int r_Style)
	{
		super(r_Parent, r_Style);
		this.build();
	}

	/**
	 * ��������Ŀؼ�<BR>
	 * 
	 * Construct the real controls.<BR>
	 * 
	 */
	private void build()
	{
		this.listViewer = new ListViewer(this, SWT.BORDER | SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);

		this.addButton = new Button(this, SWT.PUSH);
		this.addButton.setText(ResourceMessages.ADD);

		this.removeButton = new Button(this, SWT.PUSH);
		this.removeButton.setText(ResourceMessages.REMOVE);

		buildLayout();
		buildListener();
	}

	/**
	 * ������ť������<BR>
	 * 
	 * Build the listeners for button<BR>
	 */
	private void buildListener()
	{
		this.addButton.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent r_Event)
			{
				String[] t_FileNames = doSelect();

				if (null != t_FileNames)
				{
					for (int i = 0; i < t_FileNames.length; i++)
					{
						if (!AbstractElementListComponent.this.items.contains(t_FileNames[i]))
						{
							AbstractElementListComponent.this.items.add(t_FileNames[i]);
							AbstractElementListComponent.this.listViewer.getList().add(t_FileNames[i]);
						}
					}
				}
			}
		});
		// build the listener for "add" button.

		this.removeButton.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent r_Event)
			{
				String[] t_FilwNames = AbstractElementListComponent.this.listViewer.getList().getSelection();
				if(t_FilwNames != null){
					for(String temp : t_FilwNames){
						AbstractElementListComponent.this.items.remove(temp);
						AbstractElementListComponent.this.listViewer.getList().remove(temp);
					}
				}
			}
		});
		// build the listener for "delete" button.
	}

	/**
	 * ִ��ѡ�������<BR>
	 * 
	 * Execute the operation of "selection".<BR>
	 * 
	 */
	protected abstract String[] doSelect();

	/**
	 * �����ؼ��Ĳ���<BR>
	 * 
	 * Build the layout for this component<BR>
	 */
	private void buildLayout()
	{
		GridLayout t_Layout = new GridLayout(2, false);
		t_Layout.horizontalSpacing = 0;
		t_Layout.verticalSpacing = 0;
		t_Layout.marginHeight = 0;
		t_Layout.marginWidth = 0;

		this.setLayout(t_Layout);

		GridData t_ListGridData = new GridData(GridData.FILL_BOTH);
		t_ListGridData.verticalSpan = 2;
		t_ListGridData.grabExcessVerticalSpace = true;
		this.listViewer.getList().setLayoutData(t_ListGridData);

		GridData t_GridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL | GridData.VERTICAL_ALIGN_CENTER);

		this.addButton.setLayoutData(t_GridData);
		this.removeButton.setLayoutData(t_GridData);
	}

	/**
	 * ��������<BR>
	 * 
	 * Set the items of the list viewer.<BR>
	 * 
	 * @param r_Items
	 *            the items for the list.
	 */
	public void setItems(String[] r_Items)
	{
		this.items.clear();
		this.listViewer.getList().removeAll();

		if (null == r_Items)
		{
			return;
		}

		this.listViewer.getList().setItems(r_Items);

		for (int i = 0; i < r_Items.length; i++)
		{
			this.items.add(r_Items[i]);
		}
	}

	/**
	 * ��������<BR>
	 * 
	 * Return the items of the list viewer.<BR>
	 * 
	 */
	public String[] getItems()
	{
		return this.listViewer.getList().getItems();
	}

	/**
	 * @return Returns the listViewer.
	 */
	public ListViewer getListViewer()
	{
		return this.listViewer;
	}

}
