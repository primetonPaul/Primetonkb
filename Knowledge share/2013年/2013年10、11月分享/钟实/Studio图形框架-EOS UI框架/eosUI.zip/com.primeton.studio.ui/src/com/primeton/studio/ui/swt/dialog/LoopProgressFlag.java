/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/dialog/LoopProgressFlag.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Aug 14, 2008
 *******************************************************************************/


package com.primeton.studio.ui.swt.dialog;

import com.primeton.studio.ui.ResourceMessages;

/**
 * ѭ���������ı�־
 *
 * @author hongsq (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: LoopProgressFlag.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/04/22 09:38:12  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.2  2008/09/11 06:05:52  yanfei
 * Bug:fix��ָ��
 *
 * Revision 1.1  2008/09/01 10:12:09  chenxp
 * Update:��ѭ���Ľ������Ƶ�studio.ui����� (hongsq).
 *
 * Revision 1.1  2008/08/14 06:51:16  hongsq
 * Update:�ṩһ������ѭ���Ľ�����
 *
 */
public final class LoopProgressFlag {
	private boolean stopFlag = false;

	private String taskName = ResourceMessages.Executing;

	private String oldTaskName = taskName;

	private String subTaskName;

	private String oldSubTaskName;

	/**
	 *
	 */
	public LoopProgressFlag() {
		super();
		this.oldTaskName = this.taskName;
	}

	/**
	 * @param taskName
	 */
	public LoopProgressFlag(String taskName) {
		super();
		this.taskName = taskName;
		this.oldTaskName = taskName;
	}

	/**
	 * @return Returns the stopFlag.
	 */
	public synchronized final boolean getStopFlag() {
		return stopFlag;
	}

	/**
	 * @param stopFlag The stopFlag to set.
	 */
	public synchronized final void setStopFlag(boolean stopFlag) {
		this.stopFlag = stopFlag;
	}

	/**
	 * @return Returns the taskName.
	 */
	public synchronized final String getTaskName() {
		if(null == taskName)
			return ""; //$NON-NLS-1$
		return taskName;
	}

	/**
	 * @param taskName The taskName to set.
	 */
	public synchronized final void setTaskName(String taskName) {
		this.oldTaskName = this.taskName;
		this.taskName = taskName;
	}

	/**
	 * @return Returns the oldTaskName.
	 */
	public synchronized final String getOldTaskName() {
		if(null == oldTaskName)
			return ""; //$NON-NLS-1$
		return oldTaskName;
	}

	/**
	 * @return Returns the subTaskName.
	 */
	public synchronized final String getSubTaskName() {
		if(null == subTaskName)
			return ""; //$NON-NLS-1$
		return subTaskName;
	}

	/**
	 * @param subTaskName The subTaskName to set.
	 */
	public synchronized final void setSubTaskName(String subTaskName) {
		this.oldSubTaskName = this.subTaskName;
		this.subTaskName = subTaskName;
	}

	/**
	 * @return Returns the oldSubTaskName.
	 */
	public synchronized final String getOldSubTaskName() {
		if(null == oldSubTaskName)
			return ""; //$NON-NLS-1$
		return oldSubTaskName;
	}

}
