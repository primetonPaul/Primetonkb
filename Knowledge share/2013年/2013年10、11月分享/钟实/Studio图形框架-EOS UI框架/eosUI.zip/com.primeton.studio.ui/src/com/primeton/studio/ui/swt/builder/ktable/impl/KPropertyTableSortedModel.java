/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.swt.builder.ktable.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValidable;
import com.primeton.studio.core.event.Event;
import com.primeton.studio.core.impl.CompoundMessageCaller;
import com.primeton.studio.swt.tooltip.ITooltipProvider;
import com.primeton.studio.swt.tooltip.Tooltip;
import com.primeton.studio.ui.swt.builder.base.AbstractKTableBuilder;
import com.primeton.studio.ui.swt.builder.ktable.IKTableColumn;
import com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider;
import com.primeton.studio.ui.swt.builder.table.TableValueChangeEvent;
import com.primeton.studio.ui.swt.builder.table.ViewerMessageCaller;
import com.primeton.studio.ui.swt.validator.ITableValidator;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableCellEditor;
import de.kupzog.ktable.KTableCellRenderer;
import de.kupzog.ktable.KTableSortedModel;
import de.kupzog.ktable.renderers.DefaultCellRenderer;
import de.kupzog.ktable.renderers.FixedCellRenderer;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ������չKTable֧�ֵ�KModel�����һ�֧�������Լ���Ӧ���������á�<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * This model extends the function just like "sorting","fixed columns" to the KTable model. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-7-15 ����12:31:35
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: KPropertyTableSortedModel.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/08/13 05:52:23  chenxp
 * Update:�����õ�Ԫ��ֵ֮ǰ����һ���ص��ӿڡ�
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.34  2008/03/27 13:48:14  yangmd
 * Update:���KTableΪδ����򲻽�����֤��
 *
 * Revision 1.33  2008/03/20 05:01:48  wanglei
 * UnitTest:����δ����ȷ�������ݸı��¼���Bug��
 *
 * Revision 1.32  2008/03/18 06:07:07  wanglei
 * Review:����KTable�ؼ��е�Bug��
 *
 * Revision 1.31  2008/03/13 08:56:08  chenxp
 * Update:�������ܣ�������Ϣ��ͬ��ʱ���ظ�ˢ��
 *
 * Revision 1.29  2008/03/13 07:21:42  wanglei
 * Update:���¶��ˢ������ͼƬ������Dispose�����Crash���⡣
 *
 * Revision 1.28  2008/03/11 02:15:06  wanglei
 * Update:��֤����Ҫ����ˢ�£��Ա���ȷ��ʾ���еĵ�Ԫ���Ƿ��д�����Ϣ��
 *
 * Revision 1.27  2008/03/06 09:45:07  wanglei
 * Review:������KTableBuilderһЩ����ϵĲ��㡣
 *
 * Revision 1.26  2008/02/27 08:57:57  wanglei
 * Update:����UI��ܵ��ع����е�����
 *
 * Revision 1.25  2008/02/27 06:06:13  wanglei
 * Review:����validate������
 *
 * Revision 1.24  2008/02/26 06:34:27  wanglei
 * Update:����UI��ܺ���ʱ����һЩ����������������⻹�ܶ࣬����������
 *
 * Revision 1.23  2008/02/25 09:20:23  wanglei
 * Review:ΪIValidable��validate��������IMessageCaller��Event����������
 *
 * Revision 1.22  2008/02/21 09:58:20  wanglei
 * Review:��ȥITableValueChangeListener��ֻʹ��IValueChangeListener��
 *
 * Revision 1.21  2008/02/21 09:20:11  wanglei
 * Review:�����¼�֪ͨ���ơ�
 *
 * Revision 1.20  2008/02/20 12:01:09  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.19  2008/01/14 01:24:30  wanglei
 * Add:���Ӷ�ˢ�±����е�֧�֡�
 *
 * Revision 1.18  2007/12/12 05:16:01  wanglei
 * Update:ITooltipProvider�ƶ���λ�á�
 *
 * Revision 1.17  2007/09/13 09:30:55  wanglei
 * Review:�������ɷ���KTree��û����ȷ����IMessageCaller��Bug��
 *
 * Revision 1.16  2007/09/12 02:50:39  wanglei
 * Review:֧�������С�п��Ķ��ƣ�������ֽ����϶�ʧ�������
 *
 * Revision 1.15  2007/07/26 06:14:05  wanglei
 * Review:������ͼ���ƣ�ʹ֮���Ի��档
 *
 * Revision 1.14  2007/07/26 03:23:01  wanglei
 * Update:������֤���ƣ�ʹ��ITableValidator������IValidator��
 *
 * Revision 1.13  2007/07/19 01:28:33  wanglei
 * Reivew:��validate����valueChangeǰ�棬������֤����֪ͨ��
 *
 * Revision 1.12  2007/07/13 03:36:33  hongsq
 * Update:����KTableˢ�µ�����
 *
 * Revision 1.11  2007/06/29 01:28:29  wanglei
 * UnitTest:������ȡ����ʱ���п��ܳ�������Խ���BUG��
 *
 * Revision 1.10  2007/06/19 03:27:58  wanglei
 * UnitTest:�ָ��ϵİ汾��
 *
 * Revision 1.9  2007/06/19 01:45:59  wanglei
 * Update:�����˲�С�Ľ����������ص�Bug��
 *
 * Revision 1.8  2007/06/18 09:07:04  wanglei
 * Update:����setNumberVisible������
 *
 * Revision 1.7  2007/06/06 10:04:07  wanglei
 * Update:������ITableValueChangeListener�ӿڡ�
 *
 * Revision 1.6  2007/05/22 01:10:47  wanglei
 * Refactor:��getRowObject����������
 *
 * Revision 1.5  2007/04/28 02:25:52  wanglei
 * UnitTest:������ԭ��ȡ������ʱ����ʹ��getRowObject������Bug��
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */
public class KPropertyTableSortedModel extends KTableSortedModel implements IValidable{
	private transient final FixedCellRenderer fixedRenderer = new FixedCellRenderer(DefaultCellRenderer.STYLE_FLAT);

	private int fixedColumnCount = 1;

	private int fixedRowCount = 1;

	private List columns = new ArrayList();

	private ITableDataProvider dataProvider;

	private transient ViewerMessageCaller viewerMessageCaller;

	private transient ITooltipProvider tooltipProvider;

	private boolean readonly = false;

	// ��ǰ�ؼ��Ƿ�ֻ��

	private static int defaultMinColumnWidth = 10;

	private static int defaultMaxColumnWidth = 800;

	private boolean autoRefreshRow = false;

	private AbstractKTableBuilder kTableBuilder;

	private IKTableCellModifier cellModifier;

	/**
	 * ֱ��ͨ�����캯��������ص�ֵ��<BR>
	 *
	 * Pass the value by the constructor parameter.<BR>
	 *
	 * @param r_TableColumns
	 *            the definations for table columns.
	 * @param r_HeaderVisible
	 *            set the table header visible or not.
	 * @param r_DataProvider
	 *            the data provider to provide the data for the ktable.
	 */
	public KPropertyTableSortedModel(IKTableColumn[] r_TableColumns, boolean r_HeaderVisible, ITableDataProvider r_DataProvider) {
		super();
		this.dataProvider = r_DataProvider;

		for (int i = 0; i < r_TableColumns.length; i++) {
			this.columns.add(r_TableColumns[i]);
			r_TableColumns[i].setDataProvider(r_DataProvider);
		}
		this.setHeaderVisible(r_HeaderVisible);
		this.initialize();

		this.viewerMessageCaller = new ViewerMessageCaller(this.tooltipProvider);

	}

	/**
	 * ���ر�������Ϣ��<BR>
	 *
	 * Return the table columns.<BR>
	 *
	 */
	public IKTableColumn[] getColumns() {
		IKTableColumn[] t_Columns = new IKTableColumn[this.columns.size()];
		this.columns.toArray(t_Columns);
		return t_Columns;
	}

	/**
	 * ����ָ��λ�õı�������Ϣ��<BR>
	 *
	 * Return the table column at the specified position.<BR>
	 *
	 */
	public IKTableColumn getColumn(int r_Index) {
		return (IKTableColumn) this.columns.get(r_Index);
	}

	/**
	 * �������ݹ�Ӧ����<BR>
	 *
	 * Return the data provider.<BR>
	 *
	 */
	public ITableDataProvider getDataProvider() {
		return this.dataProvider;
	}

	/**
	 * ���������ж�һ��KTable��ĳ����Ԫ���Ƿ������޸ĵĻص��ӿڡ�<BR>
	 *
	 * @return
	 */
	public IKTableCellModifier getCellModifier() {
		return this.cellModifier;
	}

	/**
	 * ���������ж�һ��KTable��ĳ����Ԫ���Ƿ������޸ĵĻص��ӿڡ�<BR>
	 *
	 * @param r_CellModifier
	 */

	public void setCellModifier(IKTableCellModifier r_CellModifier) {
		this.cellModifier = r_CellModifier;
	}

	/**
	 * �������ݹ�Ӧ����<BR>
	 *
	 * Set the data provider.<BR>
	 *
	 */
	public boolean isHeaderVisible() {
		return this.fixedRowCount == 1;
	}

	/**
	 * ���ñ�ͷ�Ƿ�ɼ���<BR>
	 *
	 * Set whether the table header is visible or not.<BR>
	 *
	 * @param r_HeaderVisible
	 *            Set headerVisible��
	 */
	public void setHeaderVisible(boolean r_HeaderVisible) {
		if (!r_HeaderVisible) {
			this.fixedRowCount = 0;
		}
	}

	/**
	 * ����������Ƿ�ɼ���<BR>
	 *
	 * Return the number column visible or not.<BR>
	 *
	 */
	protected boolean isNumberVisible() {
		return this.fixedColumnCount == 1;
	}

	/**
	 * ����������Ƿ�ɼ���<BR>
	 *
	 * Set the number column visible or not.<BR>
	 *
	 * @param r_NumberVisible
	 *            Set numberVisible��
	 */
	public void setNumberVisible(boolean r_NumberVisible) {
		if (r_NumberVisible) {
			this.fixedColumnCount = 1;
		}
		else {
			this.fixedColumnCount = 0;
		}
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#getInitialColumnWidth(int)
	 */
	public int getInitialColumnWidth(int r_Column) {
		return ((IKTableColumn) this.columns.get(r_Column)).getWidth();
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#getInitialRowHeight(int)
	 */
	public int getInitialRowHeight(int r_Row) {
		return 20;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#doGetContentAt(int, int)
	 */
	public Object doGetContentAt(int r_Column, int r_Row) {
		if (this.isHeaderVisible()) {
			if (0 == r_Row) {
				return ((IKTableColumn) this.columns.get(r_Column)).getTitle();
			}
		}
		Object t_Element = this.getRowObject(r_Row);
		r_Row = r_Row - this.fixedRowCount;

		Object t_Value = ((IKTableColumn) this.columns.get(r_Column)).getContent(t_Element, r_Column, r_Row);
		return t_Value;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#doGetCellEditor(int, int)
	 */
	public KTableCellEditor doGetCellEditor(int r_Column, int r_Row) {
		if (this.readonly) {
			return null;
		}

		if (this.isFixedCell(r_Column, r_Row)) {
			return null;
		}

		Object t_Element = this.getRowObject(r_Row);
		r_Row = r_Row - this.fixedRowCount;

		IKTableColumn t_TableColumn = (IKTableColumn) this.columns.get(r_Column);

		if (t_TableColumn.isEditable(t_Element, r_Column, r_Row)) {
			return t_TableColumn.getCellEditor(t_Element, r_Column, r_Row);
		}
		else {
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void setContentAt(int r_Column, int r_Row, Object r_Value) {
		if(null==this.cellModifier)
		{
			super.setContentAt(r_Column, r_Row, r_Value);
		}
		else
		{
			KTable t_KTable=null;
			if(null!=this.kTableBuilder)
			{
				t_KTable=this.kTableBuilder.getKTable();
			}

			if(null!=t_KTable)
			{
				if(this.cellModifier.allowSetContentAt(t_KTable, r_Column, r_Row, r_Value))
				{
					super.setContentAt(r_Column, r_Row, r_Value);
				}
			}
		}
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#doSetContentAt(int, int, java.lang.Object)
	 */
	public void doSetContentAt(int r_Column, int r_Row, Object r_Value) {
		if (this.isFixedCell(r_Column, r_Row)) {
			return;
		}

		Object t_Element = this.getRowObject(r_Row);
		r_Row = r_Row - this.fixedRowCount;

		((IKTableColumn) this.columns.get(r_Column)).setContent(t_Element, r_Column, r_Row, r_Value);

		Object t_OldValue = this.getContentAt(r_Column, r_Row);
		this.fireValueChanged(t_OldValue, r_Value, r_Column, r_Row);
	}

	/**
	 * ������Ӧ��Listener��֪ͨ��Ԫ�����ݵĸı䡣<BR>
	 *
	 * Invoke the listeners to notify the value change in table cell.<BR>
	 *
	 * @param r_OldValue
	 * @param r_NewValue
	 * @param r_Column
	 * @param r_Row
	 */
	public void fireValueChanged(Object r_OldValue, Object r_NewValue, int r_Column, int r_Row) {
		TableValueChangeEvent t_Event = new TableValueChangeEvent();
		t_Event.setSource(this);
		t_Event.setOldValue(r_OldValue);
		t_Event.setNewValue(r_NewValue);
		t_Event.setRow(r_Row);
		t_Event.setColumn(r_Column);

		this.kTableBuilder.fireValueChanged(t_Event);
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#doGetCellRenderer(int, int)
	 */
	public KTableCellRenderer doGetCellRenderer(int r_Column, int r_Row) {
		if (this.isFixedCell(r_Column, r_Row)) {
			return this.fixedRenderer;
		}

		Object t_Element = this.getRowObject(r_Row);
		r_Row = r_Row - this.fixedRowCount;

		KTableCellRenderer t_Renderer = ((IKTableColumn) this.columns.get(r_Column)).getCellRenderer(t_Element, r_Column, r_Row);
		return t_Renderer;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#doGetRowCount()
	 */
	public int doGetRowCount() {
		return this.dataProvider.size() + this.fixedRowCount;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableDefaultModel#doGetColumnCount()
	 */
	public int doGetColumnCount() {
		return this.columns.size();
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableModel#getFixedHeaderRowCount()
	 */
	public int getFixedHeaderRowCount() {
		return this.fixedRowCount;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableModel#getFixedSelectableRowCount()
	 */
	public int getFixedSelectableRowCount() {
		return 0;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableModel#getFixedHeaderColumnCount()
	 */
	public int getFixedHeaderColumnCount() {
		return this.fixedColumnCount;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableModel#getFixedSelectableColumnCount()
	 */
	public int getFixedSelectableColumnCount() {
		return 0;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableModel#isColumnResizable(int)
	 */
	public boolean isColumnResizable(int r_Column) {
		return true;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableModel#isRowResizable(int)
	 */
	public boolean isRowResizable(int r_Row) {
		return true;
	}

	/*
	 * ��non-Javadoc��
	 *
	 * @see de.kupzog.ktable.KTableModel#getRowHeightMinimum()
	 */
	public int getRowHeightMinimum() {
		return 18;
	}

	/**
	 * ��Ϊ"setSortColumn"������protected������final������Ҫ�ṩ����һ��������Ϊ����������"setSortColumn".<BR>
	 *
	 * This method is the proxy of "setSortColumn", because the method of "setSortColumn" is protected and final.<BR>
	 *
	 * @param r_SortColumn
	 *            Set the column to be sorted.
	 */
	public void setSortColumnProxy(int r_SortColumn) {
		super.setSortColumn(r_SortColumn);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.KTableSortedModel#getTooltipAt(int, int)
	 */
	public String getTooltipAt(int r_Column, int r_Row) {
		if (r_Row < 0 || r_Row >= this.getRowCount()) {
			return super.getTooltipAt(r_Column, r_Row);
		}

		if (r_Column < 0 || r_Column >= this.getColumnCount()) {
			return super.getTooltipAt(r_Column, r_Row);
		}

		Tooltip t_Tooltip = getTooltip(r_Column, r_Row);
		if (null == t_Tooltip) {
			return super.getTooltipAt(r_Column, r_Row);
		}
		else {
			return t_Tooltip.getContent();
		}
	}

	/**
	 * @param r_Column
	 * @param r_Row
	 * @return
	 */
	public Tooltip getTooltip(int r_Column, int r_Row) {
		Object t_Object = this.getRowObject(r_Row);

		Tooltip t_Tooltip = this.viewerMessageCaller.getTooltip(t_Object, r_Column);
		return t_Tooltip;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IValidable#validate()
	 */
	public final boolean validate(IMessageCaller r_MessageCaller, Event r_Event) {

		ViewerMessageCaller t_ViewerMessageCaller = this.getViewerMessageCaller();
		Map t_OldErrors = t_ViewerMessageCaller.getClonedErrors();
		t_ViewerMessageCaller.clearAll();

		IMessageCaller t_MessageCaller = CompoundMessageCaller.composite(new IMessageCaller[] {
			r_MessageCaller,
			t_ViewerMessageCaller
		});

		AbstractKTableBuilder  ktableBuilder = this.getKTableBuilder();
		if(ktableBuilder != null){
			KTable ktable = ktableBuilder.getKTable();
			if(ktable != null && !ktable.isDisposed() && !ktable.isEnabled()){
				return true;//���KTableΪδ����򲻽�����֤ update by yangmd 200080327
			}
		}

		for (int t_Row = this.fixedRowCount; t_Row < this.getRowCount(); t_Row++) {
			for (int t_Column = 0; t_Column < this.getColumnCount(); t_Column++) {
				if (this.isFixedCell(t_Column, t_Row)) {
					continue;
				}

				Object t_Object = this.getRowObject(t_Row);
				this.validate(t_Object, t_Column, t_Row, t_MessageCaller);
			}
		}

		Map t_NewErrors = t_ViewerMessageCaller.getClonedErrors();

		if (!checkErrorEquals(t_OldErrors, t_NewErrors)) {
			this.kTableBuilder.refresh();
		}

		return !t_MessageCaller.hasError();
	}

	/**
	 * @param r_OldErrors
	 * @param r_NewErrors
	 */
	private boolean checkErrorEquals(Map r_OldErrors, Map r_NewErrors) {

		if (r_OldErrors.size() != r_NewErrors.size()) {
			return false;
		}

		for (Iterator t_Iterator = r_OldErrors.entrySet().iterator(); t_Iterator.hasNext();) {
			Map.Entry t_OldEntry = (Map.Entry) t_Iterator.next();
			Integer t_OldColumn = (Integer) t_OldEntry.getKey();
			Map t_OldMap = (Map) t_OldEntry.getValue();

			Map t_NewMap = (Map) r_NewErrors.get(t_OldColumn);

			if (null != t_OldMap && null != t_NewMap) {
				if (!t_NewMap.keySet().equals(t_OldMap.keySet())) {
					return false;
				}
			}

		}

		return true;
	}

	/**
	 * �����ж���<BR>
	 *
	 * Return the object in the specified row.<BR>
	 *
	 * @param r_Row
	 */
	public Object getRowObject(final int r_Row) {
		int t_NewRow = r_Row - this.fixedRowCount;

		if (t_NewRow >= 0 && t_NewRow < this.getDataProvider().size()) {
			return this.getDataProvider().get(t_NewRow);
		}
		else {
			return null;
		}
	}

	/**
	 *
	 * @param r_Object
	 * @param r_Column
	 * @param r_Row
	 * @param r_MessageCaller TODO
	 */
	public boolean validate(Object r_Object, int r_Column, int r_Row, IMessageCaller r_MessageCaller) {
		IKTableColumn t_Column = this.getColumn(r_Column);
		ITableValidator[] t_Validators = t_Column.getValidators();

		if (!ArrayUtils.isEmpty(t_Validators)) {
			Object t_Value = t_Column.getContent(r_Object, r_Column, r_Row);
			this.getViewerMessageCaller().setCurrentCololumn(r_Column);
			this.getViewerMessageCaller().setCurrentObject(r_Object);

			for (int i = 0; i < t_Validators.length; i++) {
				ITableValidator t_Validator = t_Validators[i];

				if (!t_Validator.validate(t_Value, this, r_Column, r_Row, r_MessageCaller)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * @return Returns the viewerMessageCaller.
	 */
	public ViewerMessageCaller getViewerMessageCaller() {
		return this.viewerMessageCaller;
	}

	/**
	 * @return Returns the tooltipProvider.
	 */
	public ITooltipProvider getTooltipProvider() {
		return this.tooltipProvider;
	}

	/**
	 * @param r_TooltipProvider
	 *            The tooltipProvider to set.
	 */
	public void setTooltipProvider(ITooltipProvider r_TooltipProvider) {
		this.tooltipProvider = r_TooltipProvider;
		this.viewerMessageCaller.setTooltipProvider(r_TooltipProvider);
	}

	/**
	 * ���ص�ǰ�ؼ��Ƿ���Ա༭<BR>
	 * �������true����Control�����Խ��б༭.<BR>
	 *
	 * To judge this editor control is editable or not.<BR>
	 * If the return value is "true",the control isn't editable..<BR>
	 *
	 * @return boolean
	 */
	public boolean isReadonly() {
		return this.readonly;
	}

	/**
	 * ���õ�ǰ�ؼ��Ƿ���Ա༭<BR>
	 * �������true����Control�����Խ��б༭.<BR>
	 *
	 * To judge this editor control is editable or not.<BR>
	 * If the return value is "true",the control is readonly.<BR>
	 *
	 */
	public void setReadonly(boolean r_Readonly) {
		this.readonly = r_Readonly;
	}

	public void setDataProvider(ITableDataProvider r_DataProvider) {
		this.dataProvider = r_DataProvider;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setColumnWidth(int r_Column, int r_Width) {

		IKTableColumn t_Column = this.getColumn(r_Column);
		if (null == t_Column) {
			r_Width = Math.max(r_Width, defaultMinColumnWidth);
			r_Width = Math.min(r_Width, defaultMaxColumnWidth);
		}
		else {
			if (t_Column.getMinWidth() == 0) {
				r_Width = Math.max(r_Width, defaultMinColumnWidth);
			}
			else {
				r_Width = Math.max(r_Width, t_Column.getMinWidth());
			}

			if (t_Column.getMaxWidth() == 0) {
				r_Width = Math.min(r_Width, defaultMaxColumnWidth);
			}
			else {
				r_Width = Math.min(r_Width, t_Column.getMaxWidth());
			}
		}
		super.setColumnWidth(r_Column, r_Width);
	}

	/**
	 * �õ�����Ĭ���п���<BR>
	 * Ĭ��Ϊ800��<BR>
	 *
	 * Return the default max width for a column.<BR>
	 * The default value is 800.<BR>
	 *
	 * @return the defaultMaxColumnWidth
	 */
	public static final int getDefaultMaxColumnWidth() {
		return defaultMaxColumnWidth;
	}

	/**
	 * ��������Ĭ���п���<BR>
	 *
	 * Set the default max width for a column.<BR>
	 *
	 * @param r_DefaultMaxColumnWidth the defaultMaxColumnWidth to set
	 */
	public static final void setDefaultMaxColumnWidth(int r_DefaultMaxColumnWidth) {
		KPropertyTableSortedModel.defaultMaxColumnWidth = r_DefaultMaxColumnWidth;
	}

	/**
	 * �õ���С��Ĭ���п���<BR>
	 * Ĭ��Ϊ10��<BR>
	 *
	 * Return the default min width for a column.<BR>
	 * The default value is 10.<BR>
	 *
	 * @return the defaultMinColumnWidth
	 */
	public static final int getDefaultMinColumnWidth() {
		return defaultMinColumnWidth;
	}

	/**
	 * ������С��Ĭ���п���<BR>
	 *
	 * Set the default min width for a column.<BR>
	 *
	 * @param r_DefaultMinColumnWidth the defaultMinColumnWidth to set
	 */
	public static final void setDefaultMinColumnWidth(int r_DefaultMinColumnWidth) {
		KPropertyTableSortedModel.defaultMinColumnWidth = r_DefaultMinColumnWidth;
	}

	/**
	 * @return the autoRefreshRow
	 */
	public boolean isAutoRefreshRow() {
		return this.autoRefreshRow;
	}

	/**
	 * @param r_AutoRefreshRow the autoRefreshRow to set
	 */
	public void setAutoRefreshRow(boolean r_AutoRefreshRow) {
		this.autoRefreshRow = r_AutoRefreshRow;
	}

	/**
	 * @return Returns the kTableBuilder.
	 */
	public AbstractKTableBuilder getKTableBuilder() {
		return this.kTableBuilder;
	}

	/**
	 * @param r_KTableBuilder The kTableBuilder to set.
	 */
	public void setKTableBuilder(AbstractKTableBuilder r_KTableBuilder) {
		this.kTableBuilder = r_KTableBuilder;
	}

}
