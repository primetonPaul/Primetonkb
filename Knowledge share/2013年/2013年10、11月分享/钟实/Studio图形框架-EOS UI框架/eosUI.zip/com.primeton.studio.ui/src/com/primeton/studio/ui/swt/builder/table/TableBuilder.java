/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.table;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.event.Event;
import com.primeton.studio.core.impl.CompoundMessageCaller;
import com.primeton.studio.ui.swt.builder.base.ViewerBuilder;
import com.primeton.studio.ui.swt.builder.model.base.ITableColumnDescriptor;
import com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider;
import com.primeton.studio.ui.swt.builder.model.impl.ListTableDataProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��������Table������ͨ��TableColumnDescriptor�����ñ���ĸ��������У���������TableColumnDescriptor���嵥Ԫ��༭�����Լ�����<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * It is used to build a swt table,it uses "TableColumnDescriptor" to set the column of a swt table.<BR>
 * The developers can define cell editor in "TableColumnDescriptor",it also support sorting. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-5-1 13:53:35
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: TableBuilder.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.21  2008/03/27 13:02:15  yangmd
 * Update:���TableΪδ����򲻽�����֤��
 *
 * Revision 1.20  2008/02/27 03:31:59  wanglei
 * Review:������֤������֧��IMessageCaller��
 *
 * Revision 1.19  2008/02/26 06:34:27  wanglei
 * Update:����UI��ܺ���ʱ����һЩ����������������⻹�ܶ࣬����������
 *
 * Revision 1.18  2008/02/25 09:20:23  wanglei
 * Review:ΪIValidable��validate��������IMessageCaller��Event����������
 *
 * Revision 1.17  2008/02/21 09:20:11  wanglei
 * Review:�����¼�֪ͨ���ơ�
 *
 * Revision 1.16  2008/02/21 02:18:15  wanglei
 * Update:���ӱ����ˢ�²��ԡ�
 *
 * Revision 1.15  2008/02/21 02:04:24  wanglei
 * Review:���ټ̳�UIElementDescription�����Ǽ̳�AbstractValueChangeContainer������֧���¼�������
 *
 * Revision 1.14  2008/02/20 09:14:06  wanglei
 * Update:����Ӧ�ķ����Ƶ�������У������Ƕ�����TableUtil�С�
 *
 * Revision 1.13  2008/01/08 09:37:30  yangmd
 * Update:TODO fixme ����Listener
 *
 * Revision 1.12  2008/01/08 03:58:09  yangmd
 * Update:TODO fixme ����Listener
 *
 * Revision 1.11  2007/08/23 03:27:06  yangmd
 * Unitest:�޸������Լ����ñ�����ȵ�bug
 *
 * Revision 1.10  2007/08/16 06:07:19  wanglei
 * Review:�Զ����������һ������߶��롣
 *
 * Revision 1.9  2007/07/26 03:23:01  wanglei
 * Update:������֤���ƣ�ʹ��ITableValidator������IValidator��
 *
 * Revision 1.8  2007/06/23 01:48:11  zhangzh
 * add:�޸�dispoise bug
 *
 * Revision 1.7  2007/06/21 08:13:46  lvyuan
 * UnitTest:��������ε��Ⱥ�˳����Ҫ���޸Ĵ�����ʾ����ͨ������ѡ������
 *
 * Revision 1.6  2007/04/16 05:55:15  wanglei
 * UnitTest:����setItemStateʱ��û����ȷͬ��ѡ�����ݵ�Bug��
 *
 * Revision 1.5  2007/04/16 04:09:25  wanglei
 * Update:������Dispose����ؼ��Ժ󣬻�����ȡ�ñ�ѡ�е�ֵ��
 *
 * Revision 1.4  2007/03/05 06:06:33  wanglei
 * �ύ��CVS
 *
 */
public class TableBuilder extends ViewerBuilder {
	private transient CheckboxTableViewer checkboxViewer;

	private List checkedElements = new ArrayList();

	private List checkedIndecies = new ArrayList();

	private transient ICheckStateListener checkStatekListener;

	/**
	 * ������XML�������л�ʹ��<BR>
	 *
	 * This method is used for the xml Serialization.<BR>
	 *
	 */
	public TableBuilder() {
	// Nothing to do
	}

	/**
	 * Ĭ���Ը���Ĺ��캯����<BR>
	 *
	 * Inheried from the super class.<BR>
	 *
	 * @param r_Viewer
	 *            the swt table viewer.
	 * @param r_DataProvider
	 *            the data provider for tree.
	 * @param r_TableColumnDescriptors
	 *            the column defintions.
	 */
	protected TableBuilder(TableViewer r_Viewer, ITableDataProvider r_DataProvider, ITableColumnDescriptor[] r_TableColumnDescriptors) {
		super(r_Viewer, r_DataProvider, r_TableColumnDescriptors);
	}

	/**
	 * Ϊ�˷����û���������ʹ��ListTableDataProvider������List<BR>
	 *
	 * For the convenience of the deveopers ,use the "ListTableDataProvider" to support 'List" directly. <BR>
	 *
	 * @param r_Viewer
	 *            the swt table viewer.
	 * @param r_DataProvider
	 *            the data provider for tree.
	 * @param r_TableColumnDescriptors
	 *            the column defintions.
	 *
	 * @see com.primeton.ui.swt.builder.model.impl.ListTableDataProvider
	 */
	public static TableBuilder newInstance(final TableViewer r_Viewer, final List r_List, final ITableColumnDescriptor[] r_TableColumnDescriptors) {
		return newInstance(r_Viewer, new ListTableDataProvider(r_List), r_TableColumnDescriptors);
	}

	/**
	 * �̳и���Ĺ��캯��<BR>
	 *
	 * The default construtor from the parent class<BR>
	 *
	 * @param r_Viewer
	 *            the swt table viewer.
	 * @param r_DataProvider
	 *            the data provider for tree.
	 * @param r_TableColumnDescriptors
	 *            the column defintions.
	 */
	public static TableBuilder newInstance(final TableViewer r_Viewer, final ITableDataProvider r_DataProvider, final ITableColumnDescriptor[] r_TableColumnDescriptors) {
		TableBuilder t_TableBuilder = new TableBuilder(r_Viewer, r_DataProvider, r_TableColumnDescriptors);

		t_TableBuilder.build();
		return t_TableBuilder;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public void build() {
		super.build();

		if ((this.getTable().getStyle() & SWT.CHECK) != 0) {
			this.checkboxViewer = new CheckboxTableViewer(this.getTableViewer().getTable());

			this.checkStatekListener = new ICheckStateListener() {

				public void checkStateChanged(CheckStateChangedEvent r_Event) {

					TableItem t_TableItem = (TableItem) TableBuilder.this.checkboxViewer.testFindItem(r_Event.getElement());

					if (r_Event.getChecked()) {
						TableBuilder.this.checkedElements.add(r_Event.getElement());
						TableBuilder.this.checkedIndecies.add(new Integer(TableBuilder.this.checkboxViewer.getTable().indexOf(t_TableItem)));
					}
					else {
						TableBuilder.this.checkedElements.remove(r_Event.getElement());
						TableBuilder.this.checkedIndecies.remove(new Integer(TableBuilder.this.checkboxViewer.getTable().indexOf(t_TableItem)));
					}

				}
			};

			this.checkboxViewer.addCheckStateListener(this.checkStatekListener);

		}

		try {
			TableLayout t_TableLayout = new TableLayout();
			int t_ColumnCount = this.getTable().getColumnCount();
			//			int t_TotalWidth = 0;

			for (int i = 0; i < t_ColumnCount; i++) {
				TableColumn t_TableColumn = this.getTable().getColumn(i);
				//				t_TotalWidth = t_TotalWidth + t_TableColumn.getWidth();
				t_TableLayout.addColumnData(new ColumnWeightData(t_TableColumn.getWidth()));
			}

			//			for (int i = 0; i < t_ColumnCount; i++) {
			//				TableColumn t_TableColumn = this.getTable().getColumn(i);
			//				t_TableLayout.addColumnData(new ColumnWeightData((t_TableColumn.getWidth() / t_TotalWidth)));
			//			}

			this.getTable().setLayout(t_TableLayout);
		} catch (Exception e) {
			this.getTable().setLayout(null);
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.base.ViewerBuilder#initModifier()
	 */
	@Override
	protected void initModifier() {
		this.getTableViewer().setCellModifier(this.newModifier());
	}

	/**
	 * ������ص���������Table����ʾ���<BR>
	 *
	 * Update the table for the setting.<BR>
	 *
	 */
	@Override
	protected void initUI() {
		ITableColumnDescriptor[] t_ColumnDescriptors = this.getTableColumnDescriptors();

		for (int i = 0; i < t_ColumnDescriptors.length; i++) {
			final ITableColumnDescriptor t_TableColumnDescriptor = t_ColumnDescriptors[i];

			final TableColumn t_TableColumn = new TableColumn(this.getTable(), SWT.None);

			String t_Title = t_TableColumnDescriptor.getTitle();
			if (null != t_Title) {
				t_TableColumn.setText(t_Title);
			}

			int t_Width = t_TableColumnDescriptor.getWidth();
			if (t_Width > 0) {
				t_TableColumn.setWidth(t_Width);
			}

			final int t_Index = i;

			t_TableColumn.addSelectionListener(new SelectionAdapter() {
				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
				 */
				@Override
				public void widgetSelected(SelectionEvent r_Event) {
					if (t_TableColumnDescriptor.isSortable()) {
						t_TableColumnDescriptor.sort(getViewer(), t_TableColumn);
						updateSortState(t_TableColumnDescriptor, t_Index);
						getViewer().refresh();
					}
				}
			});
		}

		TableViewer t_Viewer = this.getTableViewer();
		t_Viewer.setColumnProperties(this.getProperties());
		t_Viewer.setCellEditors(this.getCellEditors());
		t_Viewer.getTable().setLinesVisible(true);
		t_Viewer.getTable().setHeaderVisible(true);

	}

	/**
	 * �����û����϶Ժŵ�������<BR>
	 *
	 * Return the checked item.<BR>
	 *
	 */
	public Object getCheckedItem() {
		int t_Index = this.getCheckedIndex();
		if (-1 == t_Index) {
			return null;
		}
		else {
			Table t_Table = ((TableViewer) this.getViewer()).getTable();
			return t_Table.getItem(t_Index).getData();
		}
	}

	/**
	 * �����û����϶Ժŵ��к�<BR>
	 *
	 * Return the number of the checked item.<BR>
	 *
	 */
	public int getCheckedIndex() {
		Table t_Table = this.getTableViewer().getTable();

		if ((t_Table.getStyle() & SWT.CHECK) != 0) {
			TableItem[] t_Items = t_Table.getItems();
			for (int i = 0; i < t_Items.length; i++) {
				TableItem t_Item = t_Items[i];
				if (t_Item.getChecked()) {
					return i;
				}
			}

			return -1;
		}
		else {
			return -1;
		}
	}

	/**
	 * �����û����϶Ժŵ��к�<BR>
	 *
	 * Return the numbers of the checked item.<BR>
	 *
	 */
	public int[] getCheckedIndices() {
		Integer[] t_Values = new Integer[this.checkedIndecies.size()];
		this.checkedIndecies.toArray(t_Values);
		return ArrayUtils.toPrimitive(t_Values);
	}

	/**
	 * �����û����϶Ժŵ�������<BR>
	 *
	 * Return the checked items.<BR>
	 *
	 */
	public Object[] getCheckedItems() {
		Object[] t_Values = new Object[this.checkedElements.size()];
		this.checkedElements.toArray(t_Values);
		return t_Values;
	}

	/**
	 * ��ָ���Ķ����ڱ����д��϶Ժ�<BR>
	 *
	 * Make the selected objects checked.<BR>
	 *
	 * @param r_Values
	 *            the datas to be checked or not.
	 * @param r_State
	 *            the state for the assigned data.
	 *
	 */
	public void setItemState(Object[] r_Values, boolean r_State) {
		if (null == this.checkboxViewer) {
			return;
		}

		if (null == r_Values) {
			return;
		}

		for (int i = 0; i < r_Values.length; i++) {
			Object t_Object = r_Values[i];
			if (null != t_Object) {
				this.checkboxViewer.setChecked(t_Object, r_State);
				TableItem t_TableItem = (TableItem) this.checkboxViewer.testFindItem(t_Object);

				if (r_State) {
					this.checkedIndecies.add(new Integer(this.checkboxViewer.getTable().indexOf(t_TableItem)));
					this.checkedElements.add(t_Object);
				}
				else {
					this.checkedIndecies.remove(new Integer(this.checkboxViewer.getTable().indexOf(t_TableItem)));
					this.checkedElements.remove(t_Object);
				}
			}
		}
	}

	/**
	 * ����ʵ��ʹ�õ������б�����<BR>
	 *
	 * Return the actual table viewer.<BR>
	 *
	 */
	public TableViewer getTableViewer() {
		return (TableViewer) this.getViewer();
	}

	/**
	 * ����ʵ��ʹ�õ�Table��<BR>
	 *
	 * Return the actual table.<BR>
	 */
	public Table getTable() {
		return this.getTableViewer().getTable();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.base.ViewerBuilder#getColumn(int)
	 */
	@Override
	protected Item getColumn(int r_Index) {
		return this.getTable().getColumn(r_Index);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.base.ViewerBuilder#updateSortState(com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor,
	 *      int)
	 */
	@Override
	protected void updateSortState(ITableColumnDescriptor r_TableColumnDescriptor, int r_ColumnIndex) {
		Table t_Table = this.getTable();

		TableColumn t_TableColumn = t_Table.getColumn(r_ColumnIndex);
		t_Table.setSortColumn(t_TableColumn);
		t_Table.setSortDirection(r_TableColumnDescriptor.getSortState());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IValidable#validate()
	 */
	public synchronized boolean validate(IMessageCaller r_MessageCaller, Event r_Event) {

		this.getViewerMessageCaller().clearAll();
		//FIXME

		IMessageCaller t_MessageCaller = CompoundMessageCaller.composite(new IMessageCaller[] {
			r_MessageCaller,
			this.getViewerMessageCaller()
		});

		Table t_Table = this.getTable();

		if (null != t_Table && (!t_Table.isDisposed())) {
			if(!t_Table.isEnabled()){//���TableΪδ����򲻽�����֤ update by yangmd 200080327
				return true;
			}
			for (int t_Row = 0; t_Row < t_Table.getItemCount(); t_Row++) {
				TableItem t_Item = t_Table.getItem(t_Row);

				for (int t_Column = 0; t_Column < t_Table.getColumnCount(); t_Column++) {
					this.validate(t_Item.getData(), t_Column, t_Row, t_MessageCaller);
				}
			}
			return !t_MessageCaller.hasError();
		}

		return true;
	}

	/**
	 * @return
	 */
	public static List<Map> getTableData(TableBuilder tableBuilder) {
		ITableDataProvider dataProvider = tableBuilder.getDataProvider();
		List<Map> list = null;
		if (!(dataProvider instanceof ListTableDataProvider)) {
			return null;
		}
		list = ((ListTableDataProvider) dataProvider).getValues();
		return list;
	}

	/**
	 * {@inheritDoc}
	 */
	public void fireValueChanged(Object r_Element, String r_Property, Object r_OldValue, Object r_NewValue) {

		TableValueChangeEvent t_Event = new TableValueChangeEvent();
		t_Event.setSource(this);
		TableItem t_TableItem = (TableItem) r_Element;
		int t_Row = this.getTable().indexOf(t_TableItem);
		int t_Column = this.indexOf(r_Property);

		t_Event.setRefreshStrategy(this.getRefreshStrategy());
		t_Event.setOldValue(r_OldValue);
		t_Event.setNewValue(r_NewValue);
		t_Event.setColumn(t_Column);
		t_Event.setRow(t_Row);

		this.fireValueChanged(t_Event);
	}
}
