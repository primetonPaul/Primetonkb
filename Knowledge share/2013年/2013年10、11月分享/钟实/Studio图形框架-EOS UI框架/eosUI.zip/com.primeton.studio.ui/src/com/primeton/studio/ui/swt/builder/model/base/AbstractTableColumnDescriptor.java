/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.model.base;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Item;

import com.primeton.studio.core.model.IDataProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * "ITableColumnDescriptor"�ĳ���ʵ�֣��ṩһЩ�����Ĺ��ܡ�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The abstract implementation for "ITableColumnDescriptor" to provide some common functions. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-5-1 13:48:57
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractTableColumnDescriptor.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.8  2008/04/12 05:52:25  wanglei
 * Review:����getImage�����Ĳ�����
 *
 * Revision 1.7  2007/06/21 12:25:49  lvyuan
 * Update:�ع�������cellEidtor��ʱ�����е����
 *
 * Revision 1.6  2007/04/28 02:28:52  wanglei
 * UnitTest:������getIntrospector��������ϵͳע������ȡ������Ĭ��ʹ�õ�PropertyIntrospector��
 *
 * Revision 1.5  2007/04/24 07:52:49  wanglei
 * Add:Ϊ��������������ӳ�书�ܣ��������Ե�����ʾ�ı���
 *
 * Revision 1.4  2007/03/05 06:06:33  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractTableColumnDescriptor extends AbstractTableColumn implements ITableColumnDescriptor
{

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public AbstractTableColumnDescriptor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#getCellEditor(org.eclipse.jface.viewers.StructuredViewer)
	 */
	public CellEditor getCellEditor(StructuredViewer r_Viewer, int column)
	{
		if (!this.isEditable())
		{
			return null;
		}

		CellEditor t_CellEditor = this.newCellEditor(r_Viewer, column);
		// If this column is editable and not inited.
		// newCellEditor will be invoked to create a new CellEditor.<BR>

		ITableColumnContextHelper t_Helper = this.getContextHelper();
		if (null != t_CellEditor && null != t_CellEditor.getControl() && null != t_Helper)
		{
			t_Helper.setHelp(this, t_CellEditor.getControl());
		}

		return t_CellEditor;
	}

	/**
	 * ��������һ���µĵ�Ԫ��༭����<BR>
	 *
	 * This method is invoked to create a new cell editor.<BR>
	 *
	 * @param r_Viewer
	 *            the swt viewer
	 * @param column TODO
	 */
	public abstract CellEditor newCellEditor(StructuredViewer r_Viewer, int column);

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#getText(java.lang.Object,
	 *      org.eclipse.jface.viewers.TableViewer)
	 */
	public String getText(Object r_Element, StructuredViewer r_Viewer)
	{
		if (null == r_Element)
		{
			return "";
		}

		if (this.getIntrospector(r_Element).hasProperty(r_Element, getPropertyName()))
		{
			Object t_Value = this.getValue(r_Element);

			if (null == t_Value)
			{
				return "";
			}

			IDataProvider t_Provider=this.getProvider();
			if(null!=t_Provider)
			{
				String t_Text=t_Provider.getKey(t_Value);
				if(null!=t_Text)
				{
					return t_Text;
				}
			}

			if (t_Value instanceof String)
			{
				return (String) t_Value;
			}

			return t_Value.toString();
		}
		else
		{
			return "";
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#getImage(java.lang.Object)
	 */
	public Image getImage(Object r_Element, int r_Column, int r_Row, StructuredViewer r_Viewer)
	{
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#getValue(java.lang.Object)
	 */
	public Object getValue(Object r_Element)
	{
		return this.getIntrospector(r_Element).getValue(r_Element, this.getPropertyName());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#setValue(java.lang.Object, java.lang.Object)
	 */
	public void setValue(Object r_Element, Object r_Value)
	{
		this.getIntrospector(r_Element).setValue(r_Element, getPropertyName(), r_Value);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#sort(org.eclipse.jface.viewers.TableViewer,
	 *      org.eclipse.swt.widgets.TableColumn)
	 */
	public final void sort(StructuredViewer r_Viewer, Item r_Item)
	{
		if (SORT_NONE == this.getSortState())
		{
			this.setSortState(SORT_ASC);
		}
		else
		{
			if (SORT_ASC == this.getSortState())
			{
				this.setSortState(SORT_DESC);
			}
			else
			{
				this.setSortState(SORT_ASC);
			}
		}

		this.doSort(SORT_ASC == this.getSortState());
	}

	/**
	 * ��������<BR>
	 *
	 * This method is used to sort.<BR>
	 *
	 * @param r_ASC
	 *            the parameter is to set the sort direction.
	 */
	protected void doSort(boolean r_ASC)
	{
		this.getDataProvider().sort(this.getComparator(), r_ASC);
	}

}