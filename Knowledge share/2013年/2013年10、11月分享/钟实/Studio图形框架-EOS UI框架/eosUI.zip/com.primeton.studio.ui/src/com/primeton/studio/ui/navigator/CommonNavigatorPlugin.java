/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/navigator/CommonNavigatorPlugin.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-4-9
 *******************************************************************************/


package com.primeton.studio.ui.navigator;

import org.osgi.framework.BundleContext;

import com.primeton.studio.ui.activator.AbstractSecurityUIPlugin;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: CommonNavigatorPlugin.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/04/14 08:04:02  wanglei
 * Add:������Navigator�Ļ��ࡣ
 *
 */
public class CommonNavigatorPlugin extends AbstractSecurityUIPlugin {

	/**
	 * The plug-in ID
	 */
	public static final String PLUGIN_ID = "com.primeton.studio.navigator.common";

	/*8
	 * The shared instance
	 */
	private static CommonNavigatorPlugin plugin;
	/**
	 * The constructor
	 */
	public CommonNavigatorPlugin() {
		plugin = this;
	}

	/**
	 * {@inheritDoc}
	 */
	protected void doStop(BundleContext r_Context) {
		plugin = null;
		super.doStop(r_Context);
	}

	/**
	 * {@inheritDoc}
	 */
	protected void doStart(BundleContext r_Context) {
		super.doStart(r_Context);


	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static CommonNavigatorPlugin getDefault() {
		return plugin;
	}


}
