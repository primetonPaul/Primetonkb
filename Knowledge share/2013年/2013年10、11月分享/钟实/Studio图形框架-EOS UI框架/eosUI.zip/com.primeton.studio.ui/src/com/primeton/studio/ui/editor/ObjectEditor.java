/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.editor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.runtime.IAdaptable;

import com.primeton.studio.core.ICloneable;
import com.primeton.studio.core.ICommand;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IStore;
import com.primeton.studio.core.IValidable;
import com.primeton.studio.core.IValidateListener;
import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.IValueContaier;
import com.primeton.studio.core.event.Event;
import com.primeton.studio.core.event.ValidateEvent;
import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.core.impl.CompoundMemento;
import com.primeton.studio.core.impl.DefaultValueChangeContainer;
import com.primeton.studio.core.impl.SimpleCommand;
import com.primeton.studio.core.impl.UIElementDescription;
import com.primeton.studio.core.util.CovertorUtil;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����༭����֧���û�ͨ��UI���༭����������Ϣ��<BR
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The editor for a oject to support the user to edit a object by UI. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ObjectEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.6  2008/07/16 02:10:33  zhanchuan
 * *** empty log message ***
 *
 * Revision 1.5  2008/07/16 02:01:10  zhanchuan
 * *** empty log message ***
 *
 * Revision 1.4  2008/07/16 02:00:21  zhanchuan
 * update:
 *
 * Revision 1.3  2008/07/15 08:45:55  zhanchuan
 * *** empty log message ***
 *
 * Revision 1.2  2008/07/15 08:32:29  zhanchuan
 * update:jira����EOS-2126������װʱ����ġ����ߡ��͡����š���ʾ����ѡ����
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.19  2008/05/14 01:35:58  wanglei
 * Review:���״μ��ص�ʱ��,�������¼���
 *
 * Revision 1.18  2008/03/27 12:18:40  yangmd
 * Update:�޸�һ������
 *
 * Revision 1.17  2008/02/27 08:57:57  wanglei
 * Update:����UI��ܵ��ع����е�����
 *
 * Revision 1.16  2008/02/26 07:09:52  wanglei
 * Update:ObjectEditor����֧����ҵ���֤����
 *
 * Revision 1.15  2008/02/26 06:34:27  wanglei
 * Update:����UI��ܺ���ʱ����һЩ����������������⻹�ܶ࣬����������
 *
 * Revision 1.14  2008/02/25 09:20:23  wanglei
 * Review:ΪIValidable��validate��������IMessageCaller��Event����������
 *
 * Revision 1.13  2008/02/22 08:39:54  wanglei
 * Review:�����¼�֪ͨ���ơ�
 *
 * Revision 1.12  2008/02/19 09:19:43  wanglei
 * Update:��getOrderedPropertyEditors�����ĳ�public
 *
 * Revision 1.11  2007/12/13 09:44:07  chenxp
 * Update:�����final���η�ȥ�����Ա����า��
 *
 * Revision 1.10  2007/05/31 10:05:41  wanglei
 * Add:���Ӷ��ⲿIValidable��֧�֡�
 *
 * Revision 1.9  2007/05/28 08:47:12  wanglei
 * UnitTest:����allowAutoFoucs���ܣ���������������"������ͼ"�н���setFocusʱ�����쳣��
 *
 * Revision 1.8  2007/04/16 02:59:42  wanglei
 * Add:���ӽ����Զ���ʾ�ڿ�����Ŀؼ��ϡ�
 *
 * Revision 1.7  2007/03/08 03:39:22  wanglei
 * Update:�ع�UIElementDescription�����Խ�width��height����ȥ����
 *
 *
 *
 *
 *
 * Revision 1.6 2007/03/05 06:06:32 wanglei �ύ��CVS
 *
 */
public class ObjectEditor extends UIElementDescription implements IStore, IAdaptable, ICloneable, IValidable, IValueContaier, IValueChangeListener, IValidateListener {

	private boolean important;

	private transient Object element;

	private List propertyEditors = new ArrayList();

	private transient IAdaptable adaptable;

	private DefaultValueChangeContainer valueChangeContainer = new DefaultValueChangeContainer();

	private boolean viewMode;

	private String viewTitle;

	private String viewDescription;

	private String viewWindowTitle;

	private ILayoutBuilder layoutBuilder;

	private SimpleCommand simpleCommand;

	private String focusProeprtyName;

	private boolean allowAutoFocus = false;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public ObjectEditor() {
		super();
	}

	/**
	 * ���ص�ǰ���ڱ༭�Ķ���<BR>
	 *
	 * Return the object for being edited.<BR>
	 *
	 */
	public Object getElement() {
		return this.element;
	}

	/**
	 * �������ڱ༭�Ķ���<BR>
	 * ���е��ӱ༭��Ҳ�ᱻ���ø����ԡ�<BR>
	 *
	 * Set the editing element.<BR>
	 * The children property editor's will be setted.<BR>
	 *
	 * @param r_Element
	 *            the element to set
	 */
	public void setElement(Object r_Element) {
		this.element = r_Element;

		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_PropertyEditor = (IPropertyEditor) this.propertyEditors.get(i);
			t_PropertyEditor.setElement(r_Element);
		}
	}

	/**
	 * ����ָ��Property���Ƶı༭��<BR>
	 *
	 * Return the property editor by the assigned name.
	 *
	 * @param r_PropertyName
	 *            the name for the property editor
	 */
	public IPropertyEditor getPropertyEditor(String r_PropertyName) {
		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_PropertyEditor = (IPropertyEditor) this.propertyEditors.get(i);

			if (t_PropertyEditor.getPropertyName().equals(r_PropertyName)) {
				return t_PropertyEditor;
			}
		}
		return null;
	}

	/*
	 * ���� Javadoc��
	 *
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() {
		ObjectEditor t_Editor = new ObjectEditor();

		t_Editor.copyFrom(this);

		t_Editor.viewTitle = this.viewTitle;
		t_Editor.viewDescription = this.viewDescription;
		t_Editor.important = this.important;
		t_Editor.focusProeprtyName = this.focusProeprtyName;

		t_Editor.important = this.important;
		t_Editor.viewTitle = this.viewTitle;
		t_Editor.viewDescription = this.viewDescription;

		t_Editor.propertyEditors = new ArrayList();

		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_PropertyEditor = (IPropertyEditor) this.propertyEditors.get(i);
			Object t_Object = t_PropertyEditor.clone();
			t_Editor.propertyEditors.add(t_Object);
		}

		t_Editor.layoutBuilder = this.layoutBuilder;

		return t_Editor;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	public void load() {
		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);
			t_Editor.load();
		}
	}

	/**
	 * ָ����������ĳ�����Զ�Ӧ�Ŀؼ���<BR>
	 *
	 * Force the property editor with the specified name.<BR>
	 *
	 * @param r_PropertyName
	 */
	public void load(String r_PropertyName) {
		IPropertyEditor t_Editor = this.getPropertyEditor(r_PropertyName);
		if (null != t_Editor) {
			t_Editor.load();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#save()
	 */
	public void save() {
		CompoundMemento t_OldMemento = new CompoundMemento();
		CompoundMemento t_NewMemento = new CompoundMemento();

		Collection t_Col = this.getOrderedPropertyEditors();

		for (Iterator t_Iterator = t_Col.iterator(); t_Iterator.hasNext();) {
			IPropertyEditor t_Editor = (IPropertyEditor) t_Iterator.next();
			t_OldMemento.doAddMemento(t_Editor.getMemento());
			t_Editor.save();
			t_NewMemento.doAddMemento(t_Editor.getMemento());
		}

		this.simpleCommand = new SimpleCommand(t_OldMemento, t_NewMemento);
	}

	/**
	 * ��������������Ա༭����<BR>
	 *
	 * Return the property editors in order.<BR>
	 *
	 * @return the sorted collection.
	 */
	public Collection getOrderedPropertyEditors() {
		Set t_Set = new TreeSet(new Comparator() {
			public int compare(Object r_FirstObject, Object r_SecondObject) {
				IPropertyEditor t_FirstEditor = (IPropertyEditor) r_FirstObject;
				IPropertyEditor t_SecondEditor = (IPropertyEditor) r_SecondObject;

				if (t_FirstEditor.getOrder() <= t_SecondEditor.getOrder()) {
					return 1;
				}
				else {
					return -1;
				}
			}
		});

		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);
			t_Set.add(t_Editor);
		}
		// Order the property editors by the assigned order.

		return t_Set;
	}

	/**
	 * �����༭��<BR>
	 *
	 * Build the editor<BR>
	 *
	 * @param r_Adaptable
	 *            the context
	 */
	public void build(IAdaptable r_Adaptable) {
		this.adaptable = r_Adaptable;

		this.getLayoutBuilder().doLayout(this);

		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);

			if (t_Editor.isVisible()) {
				t_Editor.beforeBuild(this);
			}
		}

		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);

			if (t_Editor.isVisible()) {
				t_Editor.build(this, this.isImportant());
				t_Editor.load();
			}
		}

		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);
			t_Editor.doAddValidateListener(this);
			t_Editor.doAddValueChangeListener(this);

			if (t_Editor.isVisible()) {
				t_Editor.afterBuild(this);
			}
		}

		if (this.isAllowAutoFocus()) {
			if (null != this.focusProeprtyName) {
				IPropertyEditor t_Editor = this.getPropertyEditor(this.focusProeprtyName);
				t_Editor.setFocus();
			}
			else {
				for (int i = 0; i < this.propertyEditors.size(); i++) {
					IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);

					if (t_Editor.isEnable() && t_Editor.isVisible() && (!t_Editor.isViewMode())) {
						t_Editor.setFocus();
						return;
					}
				}
			}
		}
	}

	/**
	 * �ж��û��Ƿ��Ѿ�������ԭ���������<BR>
	 *
	 * To judge the user changed the data of the object or not.<BR>
	 *
	 * @return if the value changed,return <code>true</code>.
	 */
	public boolean isDirty() {
		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);
			if (t_Editor.isDirty()) {
				return true;
			}
		}

		return false;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IAdapter#getAdapter(java.lang.Class)
	 */
	public Object getAdapter(final Class r_Class) {
		if (r_Class == Object.class) {
			return this.element;
		}

		if (r_Class == ObjectEditor.class) {
			return this;
		}

		if (r_Class == IValidable.class) {
			return this;
		}

		if (r_Class == IMessageCaller.class) {
			return this;
		}

		if (r_Class == Map.class) {
			Map t_Map = new HashMap();

			for (int i = 0; i < this.propertyEditors.size(); i++) {
				IPropertyEditor t_PropertyEditor = (IPropertyEditor) this.propertyEditors.get(i);
				t_Map.put(t_PropertyEditor.getPropertyName(), t_PropertyEditor.getValue());
			}

			return t_Map;
		}

		if (null != this.adaptable) {
			return this.adaptable.getAdapter(r_Class);
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IValidable#validate()
	 */
	public boolean validate(IMessageCaller r_MessageCaller, Event r_Event) {

		Collection t_Col = this.getOrderedPropertyEditors();

		for (Iterator t_Iterator = t_Col.iterator(); t_Iterator.hasNext();) {
			IPropertyEditor t_Editor = (IPropertyEditor) t_Iterator.next();

			if (t_Editor.isSupportValidate()) {
				if (!t_Editor.validate(r_MessageCaller, r_Event)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * �������е����Ա༭����<BR>
	 *
	 * Return all the property editors.<BR>
	 *
	 */
	public IPropertyEditor[] getPropertyEditors() {
		if (null != this.propertyEditors) {
			IPropertyEditor[] t_PropertyEditors = new IPropertyEditor[this.propertyEditors.size()];
			this.propertyEditors.toArray(t_PropertyEditors);

			return t_PropertyEditors;
		}
		return null;
	}

	/**
	 * ����һ�����Ա༭����<BR>
	 *
	 * Add a property editor.<BR>
	 *
	 * @param r_PropertyEditor
	 *            the property editor to add.
	 */
	public void doAddPropertyEditor(IPropertyEditor r_PropertyEditor) {
		if (null != r_PropertyEditor) {
			this.propertyEditors.add(r_PropertyEditor);
			if (null != this.element) {
				r_PropertyEditor.setElement(this.element);
			}
		}
	}

	/**
	 * �������������Ƴ�һ�����Ա༭����<BR>
	 *
	 * Remove a property editor by the property name.<BR>
	 *
	 * @param r_PropertyName
	 *            the property editor with the specified name to add.
	 */
	public void doRemovePropertyEditor(String r_PropertyName) {
		doRemovePropertyEditor(this.getPropertyEditor(r_PropertyName));
	}

	/**
	 * ɾ��һ�����Ա༭����<BR>
	 *
	 * Remove a property editor.<BR>
	 *
	 * @param r_PropertyEditor
	 *            the property editor to remove.
	 */
	public void doRemovePropertyEditor(IPropertyEditor r_PropertyEditor) {
		if (null != r_PropertyEditor) {
			this.propertyEditors.remove(r_PropertyEditor);
		}
	}

	/**
	 * ɾ���������Ա༭����<BR>
	 *
	 * Remove all the property editor.<BR>
	 *
	 */
	public void doClearPropertyEditor() {
		this.propertyEditors.clear();
	}

	/**
	 * ���ص�ǰ֧�ֵ��������ơ�<BR>
	 *
	 * Return all the property editor names.<BR>
	 */
	public String[] getProperyEditorNames() {
		String[] t_Names = new String[this.propertyEditors.size()];
		for (int i = 0; i < t_Names.length; i++) {
			IPropertyEditor t_PropertyEditor = (IPropertyEditor) this.propertyEditors.get(i);
			t_Names[i] = t_PropertyEditor.getPropertyName();
		}

		return t_Names;
	}

	/**
	 * ���ص�ǰ�����Ƿ�Ϊ�鿴ģʽ���������ֵΪ <code>true</code>���ݱ��ֻ������ʽ��<BR>
	 *
	 * Return the current mode. If the return value is <code>true</code>, the property editor will be readonly.<BR>
	 *
	 */
	public boolean isViewMode() {
		return this.viewMode;
	}

	/**
	 * ���õ�ǰ����Ϊ�鿴ģʽ���������ݱ��ֻ������ʽ��<BR>
	 *
	 * Set the current mode to be "view",the property editor will be readonly.<BR>
	 *
	 * @param r_ViewMode
	 *            the viewMode to set
	 */
	public void setViewMode(boolean r_ViewMode) {
		if (this.viewMode == r_ViewMode) {
			return;
		}

		this.viewMode = r_ViewMode;

		Collection t_Col = this.getOrderedPropertyEditors();

		for (Iterator t_Iterator = t_Col.iterator(); t_Iterator.hasNext();) {
			IPropertyEditor t_Editor = (IPropertyEditor) t_Iterator.next();
			t_Editor.setViewMode(this.viewMode);
		}
	}

	/**
	 * ���ز鿴ģʽ�µ�˵����Ϣ��<BR>
	 *
	 * Return the description for view mode.<BR>
	 *
	 */
	public String getViewDescription() {
		return this.viewDescription;
	}

	/**
	 * ���ò鿴ģʽ�µ�˵����Ϣ��<BR>
	 *
	 * Set the description for view mode.<BR>
	 *
	 * @param r_ViewDescription
	 *            the viewDescription to set
	 */
	public void setViewDescription(String r_ViewDescription) {
		this.viewDescription = r_ViewDescription;
	}

	/**
	 * ���ز鿴ģʽ�µı�����Ϣ��<BR>
	 *
	 * Return the title for view mode.<BR>
	 *
	 */
	public String getViewTitle() {
		return this.viewTitle;
	}

	/**
	 * ���ò鿴ģʽ�µı�����Ϣ��<BR>
	 *
	 * Set the title for view mode.<BR>
	 *
	 * @param r_ViewTitle
	 *            the viewTitle to set
	 */
	public void setViewTitle(String r_ViewTitle) {
		this.viewTitle = r_ViewTitle;
	}

	/**
	 * ���ز鿴ģʽ�µĴ��ڱ�����Ϣ��<BR>
	 *
	 * Return the window title for view mode.<BR>
	 *
	 */
	public String getViewWindowTitle() {
		return this.viewWindowTitle;
	}

	/**
	 * ���ò鿴ģʽ�µĴ��ڱ�����Ϣ��<BR>
	 *
	 * Set the window title for view mode.<BR>
	 *
	 * @param r_ViewWindowTitle
	 *            the viewWindowTitle to set
	 */
	public void setViewWindowTitle(String r_ViewWindowTitle) {
		this.viewWindowTitle = r_ViewWindowTitle;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.impl.UIElementDescription#getWindowTitle()
	 */
	@Override
	public String getWindowTitle() {
		if (this.isViewMode() && (null != this.viewWindowTitle)) {
			return this.viewWindowTitle;
		}

		return super.getWindowTitle();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.base.AbstractDescription#getDescription()
	 */
	@Override
	public String getDescription() {
		if (this.isViewMode() && (null != this.viewDescription)) {
			return this.viewDescription;
		}

		return super.getDescription();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.base.AbstractDescription#getTitle()
	 */
	@Override
	public String getTitle() {
		if (this.isViewMode() && (null != this.viewTitle)) {
			return this.viewTitle;
		}

		return super.getTitle();
	}

	/**
	 * ���ض��ƵĲ������������Ա�Ը��ؼ����в��֡�<BR>
	 *
	 * Return the layout builder to handle the layout of the parent control.<BR>
	 *
	 */
	public ILayoutBuilder getLayoutBuilder() {
		if (null == this.layoutBuilder) {
			this.layoutBuilder = new GridLayoutBuilder();
		}
		return this.layoutBuilder;
	}

	/**
	 * ���ö��ƵĲ������������Ա�Ը��ؼ����в��֡�<BR>
	 *
	 * Set the layout builder to handle the layout of the parent control.<BR>
	 *
	 * @param r_LayoutBuilder
	 *            the layoutBuilder to set
	 */
	public void setLayoutBuilder(ILayoutBuilder r_LayoutBuilder) {
		this.layoutBuilder = r_LayoutBuilder;
	}

	/**
	 * @return Returns the command to handl undo and redo..
	 */
	public ICommand getCommand() {
		return this.simpleCommand;
	}

	/**
	 * �����Ƿ��������档<BR>
	 * �������Ϊ<code>true</code>�����κ�һ���ؼ���ֵ�ĸı䶼���������浽�����С�<BR>
	 *
	 * Set wheher the save process is eager or not.<BR>
	 * If the parameter value is <code>true</code>,any value change will be saved.<BR>
	 *
	 * @param r_EagerSave
	 */
	public void setEagerSave(boolean r_EagerSave) {
		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);
			t_Editor.setEagerSave(r_EagerSave);
		}
	}

	/**
	 * �����Ƿ���Բ�����ǰ�ؼ�<BR>
	 * �������true����Editor�����Խ��в���.<BR>
	 *
	 * To judge this editor control is enable or not.<BR>
	 * If the return value is "true",the control is disabled..<BR>
	 *
	 * @return boolean
	 */
	public boolean isImportant() {
		return this.important;
	}

	/**
	 * ���õ�ǰ�ؼ��Ƿ���Ҫ<BR>
	 * �������Ϊtrue������һЩ��������£��������༭������ͼ����Ϊ�����״���Undo��Redo�Ȳ���.<BR>
	 *
	 * To Set this editor control is important or not.<BR>
	 * If the return value is "true",the control is readon under some conditions,like property view.<BR>
	 *
	 * @param r_Important
	 *            set the control enable or not.
	 */
	public void setImportant(boolean r_Important) {
		this.important = r_Important;
	}

	/**
	 * ��Map����ʽ�õ���δ��������ݡ�<BR>
	 *
	 * Return the unsaved value in map.<BR>
	 */
	public Map getUnSavedValue() {
		Map t_Map = new HashMap();

		for (int i = 0; i < this.propertyEditors.size(); i++) {
			IPropertyEditor t_Editor = (IPropertyEditor) this.propertyEditors.get(i);
			Class t_Type = t_Editor.getIntrospector().getType(t_Editor.getElement(), t_Editor.getPropertyName());

			Object t_Value = t_Editor.getValue();
			if (null != t_Type) {
				try {
					t_Value = CovertorUtil.convert(t_Value, t_Type);
				} catch (InstantiationException e) {
					// Nothing to do
				} catch (IllegalAccessException e) {
					// Nothing to do
				}
			}

			t_Map.put(t_Editor.getPropertyName(), t_Editor.getValue());
		}

		return t_Map;
	}

	/**
	 * ����Ĭ�ϵĽ������Ա༭����������ObjectEditor����ʱ�Զ����н��㡣<BR>
	 *
	 * Return the default property editor which will be focused while the object editor is activated.<BR>
	 *
	 * @return the focusProeprtyName
	 */
	public String getFocusProeprtyName() {
		return this.focusProeprtyName;
	}

	/**
	 *
	 * ����Ĭ�ϵĽ������Ա༭����������ObjectEditor����ʱ�Զ����н��㡣<BR>
	 *
	 * Set the default property editor which will be focused while the object editor is activated.<BR>
	 *
	 * @param r_FocusProeprtyName
	 *            the focusProeprtyName to set
	 */
	public void setFocusProeprtyName(String r_FocusProeprtyName) {
		this.focusProeprtyName = r_FocusProeprtyName;
	}

	/**
	 * @return the allowAutoFocus
	 */
	public boolean isAllowAutoFocus() {
		return this.allowAutoFocus;
	}

	/**
	 * @param r_AllowAutoFocus the allowAutoFocus to set
	 */
	public void setAllowAutoFocus(boolean r_AllowAutoFocus) {
		this.allowAutoFocus = r_AllowAutoFocus;
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doAddValidateListener(com.primeton.studio.core.IValidateListener)
	 */
	public void doAddValidateListener(IValidateListener r_Listener) {
		this.valueChangeContainer.doAddValidateListener(r_Listener);
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doAddValueChangeListener(com.primeton.studio.core.IValueChangeListener)
	 */
	public void doAddValueChangeListener(IValueChangeListener r_Listener) {
		this.valueChangeContainer.doAddValueChangeListener(r_Listener);
	}

	/**
	 *
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doClearValidateListeners()
	 */
	public void doClearValidateListeners() {
		this.valueChangeContainer.doClearValidateListeners();
	}

	/**
	 *
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doClearValueChangeListeners()
	 */
	public void doClearValueChangeListeners() {
		this.valueChangeContainer.doClearValueChangeListeners();
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doRemoveValidateListener(com.primeton.studio.core.IValidateListener)
	 */
	public void doRemoveValidateListener(IValidateListener r_Listener) {
		this.valueChangeContainer.doRemoveValidateListener(r_Listener);
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doRemoveValueChangeListener(com.primeton.studio.core.IValueChangeListener)
	 */
	public void doRemoveValueChangeListener(IValueChangeListener r_Listener) {
		this.valueChangeContainer.doRemoveValueChangeListener(r_Listener);
	}

	/**
	 * @param r_Event
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#fireValidateEvent(com.primeton.studio.core.event.ValidateEvent)
	 */
	public void fireValidateEvent(ValidateEvent r_Event) {
		this.valueChangeContainer.fireValidateEvent(r_Event);
	}

	/**
	 * @param r_Event
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#fireValueChanged(com.primeton.studio.core.event.ValueChangeEvent)
	 */
	public void fireValueChanged(ValueChangeEvent r_Event) {
		this.valueChangeContainer.fireValueChanged(r_Event);
	}

	/**
	 * @return
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#getValidateListener()
	 */
	public IValidateListener[] getValidateListener() {
		return this.valueChangeContainer.getValidateListener();
	}

	/**
	 * @return
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#getValueChangeListeners()
	 */
	public IValueChangeListener[] getValueChangeListeners() {
		return this.valueChangeContainer.getValueChangeListeners();
	}

	/**
	 * {@inheritDoc}
	 */
	public void valueChange(ValueChangeEvent r_Event) {
		this.valueChangeContainer.fireValueChanged(r_Event);
	}

	/**
	 * {@inheritDoc}
	 */
	public void validateRequested(ValidateEvent r_Event) {
		this.valueChangeContainer.fireValidateEvent(r_Event);
	}
}
