/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/editor/swt/impl/ButtonPropertyEditor.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-4-21
 *******************************************************************************/


package com.primeton.studio.ui.editor.swt.impl;

import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;

/**
 * Button Property Editor, ��ȡ��jsp tag���д���.
 *
 * @author zhuxing (mailto:zhuxing@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ButtonPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2008/04/25 12:07:03  zhuxing
 * Update:���ƶ�style��֧��
 *
 * Revision 1.3  2008/04/22 02:36:34  zhuxing
 * Update:ɾ������Ҫ�ı�ǩ
 *
 * Revision 1.2  2008/04/22 02:20:32  zhuxing
 * Update:����������
 *
 * Revision 1.1  2008/04/21 11:50:32  zhuxing
 * Update:���ӻ������͵�property editor
 * 
 */
public class ButtonPropertyEditor extends AbstractPropertyEditor {
	//Ĭ��styleΪPUSH
	private int style = SWT.PUSH;
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor#cloneSelf()
	 */
	@Override
	public AbstractPropertyEditor cloneSelf() {
		return new ButtonPropertyEditor();
	}

	/**
	 * customized button style.
	 * 
	 * @param style The style to set.
	 */
	public void setStyle(int style) {
		this.style = style;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor#createControlCreator()
	 */
	@Override
	protected IControlCreator createControlCreator() {
		IControlCreator creator = new IControlCreator() {
			/* (non-Javadoc)
			 * @see org.eclipse.jface.fieldassist.IControlCreator#createControl(org.eclipse.swt.widgets.Composite, int)
			 */
			public Control createControl(Composite parent, int style) {
				Button button = new Button(parent, ButtonPropertyEditor.this.style);
				button.setText(getLabel());
				button.setToolTipText(getToolTip());
				return button;
			}
		};
		return creator;
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor#getLabelControl()
	 */
	@Override
	public Control getLabelControl() {
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor#isUseLabel()
	 */
	@Override
	public boolean isUseLabel() {
		return false;
	}
	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor#doGetValue()
	 */
	@Override
	protected Object doGetValue() {
		return super.getLabel();
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	@Override
	protected void doSetValue(Object r_Value) {
		//nothing to do
	}

}
