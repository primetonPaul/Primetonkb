/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.ui.editor.swt.layout;

import org.eclipse.swt.widgets.Control;

import com.primeton.studio.ui.editor.swt.layout.base.AbstractLayoutDataBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �û�ͨ�������ķ�ʽ������SWT�ؼ��Ĳ��֡�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Set the layou data according by delegate. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2007-2-10 ����01:53:00
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: DelegateLayoutDataBuilder.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public final class DelegateLayoutDataBuilder extends AbstractLayoutDataBuilder
{
	private Object labelLayoutData;

	private Object controlLayoutData;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public DelegateLayoutDataBuilder()
	{
		super();
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public DelegateLayoutDataBuilder(Object r_labelLayoutData, Object r_controlLayoutData)
	{
		super();
		this.labelLayoutData = r_labelLayoutData;
		this.controlLayoutData = r_controlLayoutData;
	}

	/**
	 * @return Returns the controlLayoutData.
	 */
	public Object getControlLayoutData()
	{
		return this.controlLayoutData;
	}

	/**
	 * @param r_controlLayoutData
	 *            The controlLayoutData to set.
	 */
	public void setControlLayoutData(Object r_controlLayoutData)
	{
		this.controlLayoutData = r_controlLayoutData;
	}

	/**
	 * @return Returns the labelLayoutData.
	 */
	public Object getLabelLayoutData()
	{
		return this.labelLayoutData;
	}

	/**
	 * @param r_labelLayoutData
	 *            The labelLayoutData to set.
	 */
	public void setLabelLayoutData(Object r_labelLayoutData)
	{
		this.labelLayoutData = r_labelLayoutData;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.layout.base.AbstractLayoutDataBuilder#doLayoutControl(org.eclipse.swt.widgets.Control)
	 */
	protected void doLayoutControl(Control r_LayoutControl)
	{
		r_LayoutControl.setLayoutData(this.controlLayoutData);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.layout.base.AbstractLayoutDataBuilder#doLayoutLabel(org.eclipse.swt.widgets.Control)
	 */
	protected void doLayoutLabel(Control r_LabelControl)
	{
		r_LabelControl.setLayoutData(this.labelLayoutData);

	}

}
