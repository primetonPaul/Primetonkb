/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.ktree.action.impl;

import com.primeton.studio.core.IObjectTranslator;
import com.primeton.studio.core.tree.ITreeNode;
import com.primeton.studio.core.tree.impl.DefaultTreeNode;
import com.primeton.studio.ui.ResourceImages;
import com.primeton.studio.ui.ResourceMessages;
import com.primeton.studio.ui.swt.builder.ktable.KTableBuilder;
import com.primeton.studio.ui.swt.builder.ktree.KTreeBuilder;
import com.primeton.studio.ui.swt.builder.ktree.action.base.AbstractKTreeAction;

/**
 * ����ΪKTree����һ��������<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AddKTreeAction.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2008/02/15 09:46:43  wanglei
 * Review:��Դ��messages�����Ƶ������棬���������һ�¡�
 *
 * Revision 1.3  2007/09/04 08:20:35  wanglei
 * Review:�����������¶����,ͨ��getActiveObject�Զ�ѡ�в���ʼ�༭��Ӧ����
 *
 * Revision 1.2  2007/06/18 07:10:11  wanglei
 * UnitTest:����updateStatus��������Ϊ�ò���������Ч��
 *
 * Revision 1.1  2007/03/21 12:03:45  wanglei
 * �ύ��CVS
 *
 */

public class AddKTreeAction extends AbstractKTreeAction {

	private IObjectTranslator translator;

	private Object model;

	private String type;

	private ITreeNode currentNode;

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param r_Translator
	 * @param r_Model
	 * @param r_Type
	 */
	public AddKTreeAction(IObjectTranslator r_Translator, Object r_Model, String r_Type) {
		super();
		this.translator = r_Translator;
		this.model = r_Model;
		this.type = r_Type;

		this.setImageDescriptor(ResourceImages.ADD_ICON);
		this.setText(ResourceMessages.ADD);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.ktable.action.base.AbstractKTreeAction#doRun(com.primeton.studio.ui.swt.builder.ktree.KTreeBuilder)
	 */
	public void doRun(KTreeBuilder r_TreeBuilder) {
		ITreeNode t_Parent = r_TreeBuilder.getSelectionNode();
		if (null == t_Parent) {
			return;
		}

		Object t_Object = this.translator.newObject(this.model, this.type);

		if (null != t_Object) {

			this.currentNode = new DefaultTreeNode(t_Object);
			t_Parent.add(this.currentNode);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateStatus(KTableBuilder r_TableBuilder) {
	//Nothing to do
	}

	/**
	 * {@inheritDoc}
	 */
	protected ITreeNode getActiveNode() {
		return this.currentNode;
	}

}
