/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.factory.impl;

import org.apache.commons.lang.ArrayUtils;

import com.primeton.studio.core.IMemento;
import com.primeton.studio.core.impl.CompoundMemento;
import com.primeton.studio.core.util.AdapterUtil;
import com.primeton.studio.ui.swt.factory.ICommandFactory;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.base.AbstractCommandFactory;


/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��Ӧ��CompoundControlFactory��ICommandFactoryʵ�֡�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The implementation of ICommandFactory for CompoundControlFactory. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-2-19 ����04:07:58
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: CompoundCommandFactory.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/19 08:10:30  wanglei
 * Add:�ύ��CVS��
 *
 */

public class CompoundCommandFactory extends AbstractCommandFactory
{
	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public CompoundCommandFactory()
	{
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public IMemento createMemento(IControlFactory r_ControlFactory)
	{
		if (r_ControlFactory instanceof CompoundControlFactory)
		{
			CompoundControlFactory t_CompoundControlFactory = (CompoundControlFactory) r_ControlFactory;
			IControlFactory[] t_ControlFactories = t_CompoundControlFactory.getFactories();

			if (ArrayUtils.isEmpty(t_ControlFactories))
			{
				return null;
			}

			CompoundMemento t_Result = new CompoundMemento();

			for (int i = 0; i < t_ControlFactories.length; i++)
			{
				IControlFactory t_ControlFactory = t_ControlFactories[i];
				Object t_Object = AdapterUtil.getAdapter(t_ControlFactory, ICommandFactory.class);

				if (t_Object instanceof ICommandFactory)
				{
					ICommandFactory t_CommandFactory = (ICommandFactory) t_Object;
					IMemento t_Memento = t_CommandFactory.createMemento(r_ControlFactory);
					t_Result.doAddMemento(t_Memento);
					//TBD �в�֪���Ƿ���Ҫ������null������
				}
			}
		}

		return null;
	}

}