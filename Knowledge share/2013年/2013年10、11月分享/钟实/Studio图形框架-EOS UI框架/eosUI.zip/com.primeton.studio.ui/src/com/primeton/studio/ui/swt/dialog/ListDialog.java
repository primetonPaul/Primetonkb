/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/dialog/ListDialog.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2007-8-6
 *******************************************************************************/

package com.primeton.studio.ui.swt.dialog;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.dialogs.SelectionDialog;

/**
 * 
 * �ɶ�ѡ��ListDialog
 *
 * @author yujl (mailto:yujl@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ListDialog.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/10/24 08:43:33  liu-jun
 * Update:��ֹ������༭�� commit by yujl
 *
 * Revision 1.1  2008/07/04 11:59:14  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/11/21 00:24:03  yujl
 * update:���������¼��߼�
 *
 */

public class ListDialog extends SelectionDialog {

	private IStructuredContentProvider fContentProvider;

	private ILabelProvider fLabelProvider;

	private Object fInput;

	private TableViewer fTableViewer;

	private boolean fAddCancelButton;

	/**
	 *  ������,���Ի�addCancelButton
	 *
	 */
	public ListDialog(Shell parent) {
		super(parent);
		this.fAddCancelButton = false;
	}

	/**
	 * ����table��ʽ�Ĺ�����
	 * @param parent
	 * @param tableStyle
	 */
	public ListDialog(Shell parent, int tableStyle) {
		super(parent);
		if ((tableStyle == SWT.SINGLE) || (tableStyle == SWT.MULTI)) {
			this.singleOrMulti = tableStyle;
		}
		this.fAddCancelButton = false;
	}

	public void setInput(Object input) {
		this.fInput = input;
	}

	public void setContentProvider(IStructuredContentProvider sp) {
		this.fContentProvider = sp;
	}

	public void setLabelProvider(ILabelProvider lp) {
		this.fLabelProvider = lp;
	}

	public void setAddCancelButton(boolean addCancelButton) {
		this.fAddCancelButton = addCancelButton;
	}

	public TableViewer getTableViewer() {
		return this.fTableViewer;
	}

	public boolean hasFilters() {
		return (this.fTableViewer.getFilters() != null)
				&& (this.fTableViewer.getFilters().length != 0);
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.jface.dialogs.Dialog#create()
	 */
	@Override
	public void create() {
		this.setShellStyle(this.getShellStyle() | SWT.DIALOG_TRIM | SWT.RESIZE);
		super.create();
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.dialogs.SelectionDialog#createButtonsForButtonBar(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		if (!this.fAddCancelButton) {
			this.createButton(parent, IDialogConstants.OK_ID,
					IDialogConstants.OK_LABEL, true);
		} else {
			super.createButtonsForButtonBar(parent);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	protected Control createDialogArea(Composite container) {
		Composite parent = (Composite) super.createDialogArea(container);
		this.createMessageArea(parent);
		this.fTableViewer = new TableViewer(parent, this.getTableStyle());
		this.fTableViewer.setContentProvider(this.fContentProvider);
		Table table = this.fTableViewer.getTable();
		this.fTableViewer.setLabelProvider(this.fLabelProvider);
		this.fTableViewer.setInput(this.fInput);
		GridData gd = new GridData(GridData.FILL_BOTH);
		gd.heightHint = this.convertHeightInCharsToPixels(15);
		gd.widthHint = this.convertWidthInCharsToPixels(55);
		table.setLayoutData(gd);
		Dialog.applyDialogFont(parent);
		return parent;
	}

	private int singleOrMulti = SWT.SINGLE;

	/**
	 * ȡ�� table ��ʽ
	 * @return
	 */
	protected int getTableStyle() {
		return this.singleOrMulti | SWT.H_SCROLL | SWT.V_SCROLL | SWT.BORDER;
	}
}
