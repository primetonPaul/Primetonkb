/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.editor.swt.impl;


import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.jface.preference.ColorSelector;
import org.eclipse.swt.graphics.RGB;

import com.primeton.studio.swt.resource.ColorInfo;
import com.primeton.studio.swt.resource.ResourceConvertUtil;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.ColorControlCreator;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �༭��ɫ�ı༭��<BR>
 * ֧��Swt��Font��ϵͳ�Զ����FontInfo<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The edtiro for editing color <BR>
 * Support the font of swt and the defined FontInfo<BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ColorPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.9  2008/02/15 09:45:51  wanglei
 * Update:��ɾ�����ָ���
 *
 * Revision 1.7  2007/05/25 09:48:13  zhangzh
 * add:����ע��
 *
 * Revision 1.6  2007/05/18 10:37:17  zhangzh
 * updata:����16�����ַ���תRGB
 *
 * Revision 1.5  2007/05/18 02:32:36  zhangzh
 * updata:���ӷ���16������ɫ
 *
 * Revision 1.4  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public final class ColorPropertyEditor extends AbstractPropertyEditor
{

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public ColorPropertyEditor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator()
	{
		return new ColorControlCreator(this);
	}

	/**
	 * ����������ColorControlCreator��<BR>
	 *
	 * Return the real color control creator.<BR>
	 *
	 * @return
	 */
	public ColorControlCreator getColorControlCreator()
	{
		return (ColorControlCreator) this.getControlCreator();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf()
	{
		return new ColorPropertyEditor();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		Class t_Class = this.getIntrospector().getType(getElement(), getPropertyName());

		if (t_Class == RGB.class)
		{
			ColorSelector t_ColorSelector = this.getColorSelector();
			return t_ColorSelector.getColorValue();
		}

		if (t_Class == ColorInfo.class)
		{
			ColorSelector t_ColorSelector = this.getColorSelector();
			return ResourceConvertUtil.convertColor(t_ColorSelector.getColorValue());
		}
        if(t_Class == String.class)
        {
        	ColorSelector t_ColorSelector = this.getColorSelector();
        	if(t_ColorSelector.getColorValue()==null){
        		return null;
        	}
        	String red = this.ColortoHexString(Integer.toHexString(t_ColorSelector.getColorValue().red));
        	String green = this.ColortoHexString(Integer.toHexString(t_ColorSelector.getColorValue().green));
        	String blue = this.ColortoHexString(Integer.toHexString(t_ColorSelector.getColorValue().blue));

        	String colorString ="#"+red+green+blue;
			return colorString;

        }

		return null;
	}

	private String ColortoHexString(String str){
		if("0".equals(str)){
			return str+"0";
		}
		return str;

	}
	/**
	 * 16�����ַ���ת��int����
	 */
	public  final int hexToInt(String hex) throws NumberFormatException {
		int len = hex.length();
		if (len > 16)
			throw new NumberFormatException();

		int l = 0;
		for (int i = 0; i < len; i++) {
			l <<= 4;
			int c = Character.digit(hex.charAt(i), 16);
			if (c < 0)
				throw new NumberFormatException();
			l |= c;
		}
		return l;
	}
	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value)
	{
		if(r_Value instanceof String){
			//TODO���ж��ַ����Ƿ�16�����ַ�
			if(((String)r_Value).startsWith("#")){
		String red = ((String)r_Value).substring(1,3);
		String green = ((String)r_Value).substring(3,5);
		String blue = ((String)r_Value).substring(5,7);
		ColorSelector t_ColorSelector = this.getColorSelector();
		RGB rgb = new RGB(this.hexToInt(red), this.hexToInt(green), this.hexToInt(blue));
		t_ColorSelector.setColorValue(rgb);
			}
		}
		if (r_Value instanceof RGB)
		{
			ColorSelector t_ColorSelector = this.getColorSelector();
			t_ColorSelector.setColorValue((RGB) r_Value);
		}

		if (r_Value instanceof ColorInfo)
		{
			ColorSelector t_ColorSelector = this.getColorSelector();
			t_ColorSelector.setColorValue(ResourceConvertUtil.convertColor((ColorInfo) r_Value));
		}

	}


	/**
	 * ������ɫѡ������<BR>
	 *
	 * Return the color selecter.<BR>
	 *
	 */
	public ColorSelector getColorSelector()
	{
		ColorControlCreator t_Creator = (ColorControlCreator) this.getControlCreator();
		return t_Creator.getColorSelector();
	}

}
