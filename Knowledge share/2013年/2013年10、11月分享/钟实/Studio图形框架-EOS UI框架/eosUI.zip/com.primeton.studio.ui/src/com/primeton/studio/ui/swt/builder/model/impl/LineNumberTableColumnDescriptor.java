/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.model.impl;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.graphics.Image;

import com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn;
import com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumnDescriptor;
import com.primeton.studio.ui.swt.validator.ITableValidator;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��ʾ���<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Show the line number <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-5-1 14:39:51
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: LineNumberTableColumnDescriptor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/04/12 05:54:33  wanglei
 * Review:ȥ�����õĵ��롣
 *
 * Revision 1.6  2007/07/26 03:23:02  wanglei
 * Update:������֤���ƣ�ʹ��ITableValidator������IValidator��
 *
 * Revision 1.5  2007/06/21 12:25:49  lvyuan
 * Update:�ع�������cellEidtor��ʱ�����е����
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */
public class LineNumberTableColumnDescriptor extends AbstractTableColumnDescriptor
{

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public LineNumberTableColumnDescriptor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#isMovable()
	 */
	public boolean isMovable()
	{
		return false;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#isSortable()
	 */
	public boolean isSortable()
	{
		return false;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#isEditable()
	 */
	public boolean isEditable()
	{
		return false;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#newCellEditor(org.eclipse.jface.viewers.TableViewer)
	 */
	public CellEditor newCellEditor(StructuredViewer r_Viewer, int column)
	{
		// Nothing to do
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#getImage(java.lang.Object)
	 */
	public Image getImage(Object r_Element, int r_Column, int r_Row, StructuredViewer r_Viewer)
	{
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#getText(java.lang.Object,
	 *      org.eclipse.jface.viewers.TableViewer)
	 */
	public String getText(Object r_Element, StructuredViewer r_Viewer)
	{
		if (null == this.getDataProvider())
		{
			return "";
		}

		int t_Index = this.getDataProvider().indexOf(r_Element);
		if (t_Index >= 0)
		{
			return Integer.toString(t_Index + 1);
		}
		else
		{
			return "";
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.AbstractTableColumnDescriptor#setValue(java.lang.Object,
	 *      java.lang.Object)
	 */
	public void setValue(Object r_Element, Object r_Value)
	{
		// nothing to do
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn#doClone()
	 */
	public AbstractTableColumn doClone()
	{
		return new LineNumberTableColumnDescriptor();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn#getValidators()
	 */
	public ITableValidator[] getValidators()
	{
		return ITableValidator.NullValidators;
	}

}
