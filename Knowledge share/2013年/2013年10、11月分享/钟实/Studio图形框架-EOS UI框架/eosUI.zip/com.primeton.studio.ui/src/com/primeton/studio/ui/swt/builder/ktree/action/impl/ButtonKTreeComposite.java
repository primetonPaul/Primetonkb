/**
 * *****************************************************************************
 *
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.ktree.action.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

import com.primeton.studio.swt.util.LayoutUtil;
import com.primeton.studio.ui.swt.builder.base.AbstractControlAction;
import com.primeton.studio.ui.swt.builder.ktree.KTreeBuilder;
import com.primeton.studio.ui.swt.builder.ktree.action.IKTreeActionProvider;
import com.primeton.studio.ui.swt.builder.ktree.action.base.AbstractKTreeAction;
import com.primeton.studio.ui.swt.builder.ktree.action.base.AbstractKTreeComposite;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ʹ�ù����������ò�����ť��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Using toolbar to operate the table. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-3-2 ����11:57:20
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ButtonKTreeComposite.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.4  2007/08/03 05:39:41  wanglei
 * Review:������Table,KTable,KTree�ȸ��ӿؼ�����������ʽ������Ӧ�����˶�Ӧ��Action��
 *
 * Revision 1.3  2007/07/04 12:51:00  wanglei
 * UnitTest:������ť��������ߵ�Bug��
 *
 * Revision 1.2  2007/07/04 02:09:38  wanglei
 * UnitTest:�����˴�����ToolBar����Button��Bug��
 *
 * Revision 1.1  2007/07/04 01:20:10  wanglei
 * Update:�ṩ��CVS��
 *
 *
 *
 */

public class ButtonKTreeComposite extends AbstractKTreeComposite {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_Parent
	 * @param r_Style
	 * @param r_Title
	 * @param r_TreeBuilder
	 * @param r_TableActionProvider
	 * @param r_ActionStyle
	 */
	public ButtonKTreeComposite(Composite r_Parent, int r_Style, String r_Title, KTreeBuilder r_TreeBuilder, IKTreeActionProvider r_KTreeActionProvider, int r_ActionStyle) {
		super(r_Parent, r_Style, r_Title, r_TreeBuilder, r_KTreeActionProvider, r_ActionStyle);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.component.base.AbstractTableComposite#buildComponent(org.eclipse.swt.widgets.Composite,
	 *      java.lang.String)
	 */
	protected Control createControl(Composite r_Parent, String r_Title, int r_ActionStyle) {

		this.buildTable(r_Parent);
		this.getTreeBuilder().getKTable().setLayoutData(new GridData(GridData.FILL_BOTH));

		Composite t_ActionParent = new Composite(this, SWT.FLAT);
		t_ActionParent.setBackground(this.getBackground());
		GridLayout t_Layout = LayoutUtil.createCompactGridLayout(1);
		t_Layout.verticalSpacing = 5;

		if (null != r_Title && null != this.getActions()) {
			t_Layout.numColumns = 1;
			Label t_Label = new Label(t_ActionParent, SWT.NONE);
			t_Label.setBackground(this.getBackground());
			t_Label.setText(r_Title);
		}
		t_ActionParent.setLayout(t_Layout);
		GridData t_GridData = new GridData(GridData.VERTICAL_ALIGN_BEGINNING);
		t_ActionParent.setLayoutData(t_GridData);

		AbstractKTreeAction[] t_TreeActions = this.getActions();
		if (!ArrayUtils.isEmpty(t_TreeActions)) {
			buildActions(t_ActionParent, t_TreeActions);
			this.updateActionStatus();
		}

		return t_ActionParent;
	}

	/**
	 * ����Action��<BR>
	 *
	 * Create actions.<BR>
	 *
	 * @param r_ActionParent
	 * @param r_TreeActions
	 */
	private void buildActions(Composite r_ActionParent, AbstractKTreeAction[] r_TreeActions) {
		Map t_ActionMap = AbstractControlAction.sort(r_TreeActions);
		//Sort by group id

		for (Iterator t_Iterator = t_ActionMap.keySet().iterator(); t_Iterator.hasNext();) {
			Integer t_GroupID = (Integer) t_Iterator.next();
			List t_List = (List) t_ActionMap.get(t_GroupID);

			for (int i = 0; i < t_List.size(); i++) {
				AbstractKTreeAction t_TableAction = (AbstractKTreeAction) t_List.get(i);

				Button t_Button = t_TableAction.getButton(r_ActionParent, this);
				t_Button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.component.base.AbstractTableComposite#getColumnCount()
	 */
	protected int getColumnCount() {
		return 2;
	}

}
