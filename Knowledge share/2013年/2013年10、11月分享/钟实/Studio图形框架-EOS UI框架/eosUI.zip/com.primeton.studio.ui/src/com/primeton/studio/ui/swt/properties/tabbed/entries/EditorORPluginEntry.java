/**
 *
 */
package com.primeton.studio.ui.swt.properties.tabbed.entries;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.core.expressions.ElementHandler;
import org.eclipse.core.expressions.Expression;
import org.eclipse.core.expressions.ExpressionConverter;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.ui.IWorkbenchPart;

import com.eos.system.utility.StringUtil;
import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.activator.CoreActivator;
import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.impl.TabbedControlFactory;

/**
 * ����tab��չ��򵥷�װ
 *
 * @author <a href="mailto:yujl@primeton.com">Yu J Lin</a>
 */
/*
 * �޸���ʷ
 * $Log: EditorORPluginEntry.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.3  2010/06/17 06:50:50  hongsq
 * Update:���ӿ�ָ���ж�
 *
 * Revision 1.2  2010/06/10 09:58:40  hongsq
 * Upate:BUG26867
 *
 * Revision 1.1  2010/04/27 10:53:08  wanglei
 * Jira:����EOSP-189��
 *
 */
public class EditorORPluginEntry {
	//����Ψһ��λ��ID
	private String id;

	private Collection<ElementEntry> elementEntries = new ArrayList<ElementEntry>();

	/**
	 * Ĭ�Ϲ�����
	 */
	public EditorORPluginEntry(String id, IConfigurationElement[] elements) {
		super();
		this.id = id;
		instertElementEntries(elements);
	}

	/**
	 * �������ӻ��ߺϲ���ͬһ���༭��������
	 * @param elements
	 */
	public void instertElementEntries(IConfigurationElement[] elements) {
		Assert.isNotNull(elements);
		fp:for (IConfigurationElement element : elements) {
			String elementClassPath = element.getAttribute(IConstant.NAME);
			for (ElementEntry elementEntry : elementEntries) {
				if(StringUtil.equal(elementClassPath, elementEntry.getElementClassPath())){
					IConfigurationElement[] children = element.getChildren(ElementEntry.ENABLEMENT);
					if(!ArrayUtils.isEmpty(children)){
						try {
							Expression expression = ElementHandler.getDefault().create(ExpressionConverter.getDefault(), children[0]);
							if(expression != null && expression.equals(elementEntry.getExpression())){
								elementEntry.addAllConfigurationElement(element);//�ϲ���ͬ�ڵ��factory
								continue fp;
							}
						} catch (CoreException e) {
							ExceptionUtil.getInstance().logException(e);
						}
					}
				}
			}
			elementEntries.add(new ElementEntry(element));
		}
	}

	/**
	 * ����Ĭ�ϵ�ElementEntry
	 * @param elementClassPath
	 * @return
	 */
	public ElementEntry getDefaultTesterElementEntry(String elementClassPath){
		for (ElementEntry entry : elementEntries) {
			if(StringUtil.equal(elementClassPath, entry.getElementClassPath())
					&& entry.getExpression() == null){
				return entry;
			}
		}
		return null;
	}

	/**
	 * ����ģ�ͷ���ElementEntryʵ��
	 * @param model
	 * @return
	 */
	public ElementEntry getElementEntry(Object model){
		for (ElementEntry entry : elementEntries) {
			if(entry.isEnable(model)){
				return entry;
			}
		}
		return getDefaultTesterElementEntry(model.getClass().getName());
	}

	/**
	 * Ϊָ��ģ�ͷ������е����Կؼ�������<BR>
	 * @param model
	 * @param pluginID
	 * @return
	 */
	public TabbedControlFactory getTabbedControlFactory(Object model, String pluginID) {
		ElementEntry entry = getElementEntry(model);
		if(null == entry)
			return null;
		return entry.getTabbedControlFactory(pluginID);
	}

	/**
	 * Ϊָ��ģ�ͷ������е����Կؼ�������<BR>
	 * ����ʹ��editorPart���Բ����Ƿ������Ҫ��t_Factories���ϣ����û����ʹ��pluginID
	 * Reutrn the control factory for properties editing.<BR>
	 * @param model
	 * @param editorPart
	 * @return
	 */
	public TabbedControlFactory getTabbedControlFactory(Object model, IWorkbenchPart editorPart) {
		String pluginID = CoreActivator.getDefault().getPackageAdmin().getBundle(editorPart.getClass()).getSymbolicName();
		return getTabbedControlFactory(model, pluginID);
	}

	/**
	 * Ϊָ��ģ�ͷ�����Ӧ�����Կؼ�������<BR>
	 * @param model
	 * @param r_Tab
	 * @param pluginID
	 * @return
	 */
	public IControlFactory getControlFactory(Object model, String r_Tab, String pluginID) {
		ElementEntry entry = getElementEntry(model);
		if(null == entry)
			return null;
		return entry.getControlFactory(r_Tab, pluginID);
	}

	/**
	 *
	 * @param model
	 * @param r_Tab
	 * @param editorPart
	 * @return
	 */
	public IControlFactory getControlFactory(Object model, String r_Tab, IWorkbenchPart editorPart) {
		String pluginID = CoreActivator.getDefault().getPackageAdmin().getBundle(editorPart.getClass()).getSymbolicName();
		return getControlFactory(model, r_Tab, pluginID);
	}

	/**
	 * @return the id
	 */
	public final String getId() {
		return id;
	}

}
