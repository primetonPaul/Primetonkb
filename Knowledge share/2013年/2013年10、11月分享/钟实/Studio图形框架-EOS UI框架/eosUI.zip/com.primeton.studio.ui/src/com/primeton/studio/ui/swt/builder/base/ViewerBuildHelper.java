/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/builder/base/ViewerBuildHelper.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2008-7-18
 *******************************************************************************/


package com.primeton.studio.ui.swt.builder.base;

import java.util.ArrayList;
import java.util.List;

import com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider;

/**
 * TODO �˴���д class ��Ϣ
 *
 * @author yangmd (mailto:������@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: ViewerBuildHelper.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/18 01:49:49  yangmd
 * Update:֧��ѡ����н������ơ����ơ�ɾ���������ö��������ö�������
 * 
 */
public class ViewerBuildHelper {
	/**
	 * ���캯��˽�С�
	 *
	 */
	private ViewerBuildHelper() {
		super();
	}
	
	/**
	 * 
	 * @param dataProvider
	 * @param children
	 * @param offset
	 */
	public static void moveUp(ITableDataProvider dataProvider,Object[] children, int offset){
		
		for (int i = 0; i < offset; i++) {
			moveUp(dataProvider, children);
		}
	}
	/**
	 * 
	 * @param dataProvider
	 * @param children
	 * @param offset
	 */
	public static void moveDown(ITableDataProvider dataProvider,Object[] children, int offset){
		for (int i = 0; i < offset; i++) {
			moveDown(dataProvider, children);
		}
	}
	/**
	 * 
	 * @param dataProvider
	 * @param children
	 */
	public static void moveUp(ITableDataProvider dataProvider,Object[] children){
		children = filter(dataProvider, children);
		sort(dataProvider, children);//�Ƚ�������
		for (int i = 0; i < children.length; i++) {
			Object object = children[i];
			
			int index = dataProvider.indexOf(object);
			if(index <= 0){
				break;
			}
			Object temp = dataProvider.get(index -1);
			dataProvider.set(index -1, object);
			dataProvider.set(index, temp);
		}
	}
	/**
	 * 
	 * @param dataProvider
	 * @param children
	 * @return
	 */
	public static void moveDown(ITableDataProvider dataProvider, Object[] children){
		children = filter(dataProvider, children);
		sort(dataProvider, children);//�Ƚ�������
		for (int i = children.length - 1; i >= 0; i--) {
			Object object = children[i];
			
			int index = dataProvider.indexOf(object);
			if(index >= dataProvider.size() - 1){
				break;
			}
			Object temp = dataProvider.get(index + 1);
			dataProvider.set(index + 1, object);
			dataProvider.set(index, temp);
		}
	}
	/**
	 * 
	 * @param dataProvider
	 * @param children
	 * @return
	 */
	private static Object[] filter(ITableDataProvider dataProvider, Object[] children) {
		List<Object> results = new ArrayList<Object>();
		for (int i = 0; i < children.length; i++) {
			Object object = children[i];
			if(dataProvider.indexOf(object) > -1){
				results.add(object);
			}
		}
		return results.toArray(new Object[results.size()]);
	}
	
	/**
	 * 
	 * @param dataProvider 
	 * @param children
	 */
	public static void sort(ITableDataProvider dataProvider, Object[] children){
		for (int i = 0; i < children.length; i++) {
			for (int j = i; j > 0 && dataProvider.indexOf(children[j]) < dataProvider.indexOf(children[j-1]) ; j--) {
				Object temp = children[j];
				children[i] = children[j-1];
				children[j-1] = temp;
			}
		}
	}
}
