/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/editor/swt/impl/JavaStyledTextPropertyEditor.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2007-3-9
 *******************************************************************************/


package com.primeton.studio.ui.editor.swt.impl;

import com.primeton.studio.swt.style.impl.DefaultStyle;
import com.primeton.studio.swt.style.impl.DefaultStyleProvider;
import com.primeton.studio.swt.style.impl.WordGroup;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;

/**
 * java����༭��ʽ
 *
 * @author yangjun (mailto:yangjun@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: JavaStyledTextPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.1  2007/03/09 10:18:29  yangjun
 * Add:����java����Ƭ�ϵ����Ա༭��
 * 
 */
public class JavaStyledTextPropertyEditor extends StyledTextPropertyEditor {
	
	public JavaStyledTextPropertyEditor(){
		this.defineJavaStypled();
	}

	private void defineJavaStypled(){
		DefaultStyle t_Style = new DefaultStyle();
		t_Style.setName("sql");

		WordGroup t_Group1 = new WordGroup();
		t_Group1.setColorName("red");

		String[] t_StringArray1 = new String[] { "new", "this", "import", "class", "for", "int", "return"
				,"abstract" ,"null" ,"boolean" ,"if" , "else", "break" ,"private" ,"public", "false" ,"void" 
				,"while" ,"String" ,"float"};
		for (int i = 0; i < t_StringArray1.length; i++)
		{
			String t_String = t_StringArray1[i];
			t_Group1.doAddWord(t_String);
		}

		WordGroup t_Group2 = new WordGroup();
		t_Group2.setColorName("green");

		String[] t_StringArray2 = new String[] { "table", "procedure", "index", "sequence", "cascade", "constraints", "not", "default", "null", "primary", "key" };
		for (int i = 0; i < t_StringArray2.length; i++)
		{
			String t_String = t_StringArray2[i];
			t_Group2.doAddWord(t_String);
		}

		WordGroup t_Group3 = new WordGroup();
		t_Group3.setColorName("blue");

		String[] t_StringArray3 = new String[] { "\"\"", "\'\'", "//"};
		for (int i = 0; i < t_StringArray3.length; i++)
		{
			String t_String = t_StringArray3[i];
			t_Group3.doAddWord(t_String);
		}

		t_Style.doAddWord(t_Group1);
		t_Style.doAddWord(t_Group2);
		t_Style.doAddWord(t_Group3);

		DefaultStyleProvider provider = new DefaultStyleProvider();
		provider.doAddStyle(t_Style);	

		this.setStyleProvider(provider);
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.swt.StyledTextPropertyEditor#cloneSelf()
	 */
	@Override
	public AbstractPropertyEditor cloneSelf() {
		
		return new JavaStyledTextPropertyEditor();
	}

}
