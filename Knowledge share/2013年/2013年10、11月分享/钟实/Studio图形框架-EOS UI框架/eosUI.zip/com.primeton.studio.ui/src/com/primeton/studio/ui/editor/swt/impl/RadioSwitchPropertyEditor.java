/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.editor.swt.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.ui.editor.ObjectEditor;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;

/**
 * ͨ��һ��Map��<Object,String[]>�ļ�ֵ�Է�ʽ�������Ƿ����ص�����<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: RadioSwitchPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.3  2007/03/28 08:45:54  lvyuan
 * UnitTest :�޸�һ�����ֵĴ���
 *
 * Revision 1.2  2007/03/26 05:44:15  wanglei
 * Rename:�������������ơ�
 *
 *
 *
 * Revision 1.1  2007/03/26 05:42:41  wanglei
 * UnitTest:�������ؿؼ�ʱBug��
 *
 */

public class RadioSwitchPropertyEditor extends RadioGroupPropertyEditor {

	private Map mapping = new HashMap();

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public RadioSwitchPropertyEditor() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf() {
		RadioSwitchPropertyEditor t_Editor = new RadioSwitchPropertyEditor();
		t_Editor.mapping = new HashMap(this.mapping);
		return t_Editor;
	}

	/**
	 * @return the mapping
	 */
	public Map getMapping() {
		return this.mapping;
	}

	/**
	 * Ӧ����<Object,String[]>�ļ�ֵ�ԡ�
	 *
	 * @param r_Mapping
	 *            the mapping to set
	 */
	public void setMapping(Map r_Mapping) {
		this.mapping = r_Mapping;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#afterBuild(org.eclipse.core.runtime.IAdaptable)
	 */
	public void afterBuild(IAdaptable r_Adaptable) {

		super.afterBuild(r_Adaptable);

		updateHiddenControls();

		this.doAddValueChangeListener(new IValueChangeListener() {

			public void valueChange(ValueChangeEvent r_Event) {
				updateHiddenControls();

			}
		});
	}

	/**
	 * ����Ҫ���صĿؼ���<BR>
	 *
	 */
	private void updateHiddenControls() {

		Object t_Value = this.doGetValue();
		ObjectEditor t_ObjectEditor = (ObjectEditor) this.getAdapter(ObjectEditor.class);

		if (null == t_ObjectEditor) {
			return;
		}

		for (Iterator t_Iterator = this.mapping.keySet().iterator(); t_Iterator.hasNext();) {
			Object t_Key = t_Iterator.next();

			boolean t_Exclude = true;

			if (ObjectUtils.equals(t_Value, t_Key)) {
				t_Exclude = false;
			}

			hideControls(t_ObjectEditor, t_Key, t_Exclude);
		}

		Composite t_Parent = (Composite) this.getAdapter(Composite.class);
        t_Parent.layout();
		t_Parent.getParent().layout(new Control[] {t_Parent});
	}

	/**
	 * @param r_ObjectEditor
	 * @param r_Key
	 * @param r_Exclude
	 */
	private void hideControls(ObjectEditor r_ObjectEditor, Object r_Key, boolean r_Exclude) {
		String[] t_Names = (String[]) this.mapping.get(r_Key);
		for (int i = 0; i < t_Names.length; i++) {
			String t_Name = t_Names[i];

			AbstractPropertyEditor t_PropertyEditor = (AbstractPropertyEditor) r_ObjectEditor.getPropertyEditor(t_Name);

			t_PropertyEditor.setVisible(!r_Exclude);

			Control t_LabelControl = t_PropertyEditor.getLabelControl();
			Control t_LayoutControl = t_PropertyEditor.getLayoutControl();

			if (t_LabelControl.getLayoutData() instanceof GridData) {
				GridData t_GridData = (GridData) t_LabelControl.getLayoutData();
				t_GridData.exclude = r_Exclude;
				t_LabelControl.setVisible(!r_Exclude);
			}

			if (t_LayoutControl.getLayoutData() instanceof GridData) {
				GridData t_GridData = (GridData) t_LayoutControl.getLayoutData();
				t_GridData.exclude = r_Exclude;
				t_LayoutControl.setVisible(!r_Exclude);
			}
		}
	}

}
