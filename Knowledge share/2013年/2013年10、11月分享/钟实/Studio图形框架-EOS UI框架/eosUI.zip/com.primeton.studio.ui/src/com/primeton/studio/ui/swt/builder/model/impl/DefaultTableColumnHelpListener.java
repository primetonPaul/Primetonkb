/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.ui.swt.builder.model.impl;

import org.eclipse.help.HelpSystem;
import org.eclipse.help.IContext;
import org.eclipse.swt.events.HelpEvent;
import org.eclipse.swt.events.HelpListener;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.help.IWorkbenchHelpSystem;

import com.primeton.studio.ui.swt.builder.model.base.ITableColumn;
import com.primeton.studio.ui.swt.helper.IHelpContext;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * Ϊ�����еĵ�Ԫ���ṩ�����İ���<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Provide help for table cell. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2007-3-3 ����05:12:35
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: DefaultTableColumnHelpListener.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */

public class DefaultTableColumnHelpListener implements HelpListener
{
	private ITableColumn tableColumn;

	private Control control;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 * 
	 * @param r_TableColumn
	 * @param r_Control
	 */
	public DefaultTableColumnHelpListener(ITableColumn r_TableColumn, Control r_Control)
	{
		super();
		this.tableColumn = r_TableColumn;
		this.control = r_Control;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.swt.events.HelpListener#helpRequested(org.eclipse.swt.events.HelpEvent)
	 */
	public void helpRequested(HelpEvent r_Event)
	{
		IWorkbenchHelpSystem t_HelpSystem = PlatformUI.getWorkbench().getHelpSystem();

		if (!t_HelpSystem.hasHelpUI())
		{
			return;
		}

		IHelpContext[] t_Contexts = this.tableColumn.getHelpContexts(this.control);
		if (null != t_Contexts)
		{
			for (int i = 0; i < t_Contexts.length; i++)
			{
				IHelpContext t_HelpContext = t_Contexts[i];

				IContext t_Context = HelpSystem.getContext(t_HelpContext.getContext());
				if (null != t_Context)
				{
					t_HelpSystem.displayHelp(t_Context);
				}
			}
		}
	}

}
