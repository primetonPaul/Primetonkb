/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.editor.swt.impl;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;

import com.primeton.studio.ui.editor.ILayoutDataBuilder;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.BooleanControlCreator;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �༭�������ı༭��<BR>
 * ʹ����CheckBox<BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The edtiro for editing boolean <BR>
 * Using CheckBox<BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: BooleanPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.7  2008/01/11 05:28:55  wanglei
 * Update:���������ؼ��������������⡣
 *
 * Revision 1.6  2007/04/24 15:34:15  caijing
 * UnitTest:fix nullpointer
 *
 * Revision 1.5  2007/04/12 05:35:45  wanglei
 * UnitTest:������ǩռλ�������²��ֲ����۵�Bug��
 *
 * Revision 1.4  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public final class BooleanPropertyEditor extends AbstractPropertyEditor
{
	private boolean usePostfix;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public BooleanPropertyEditor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator()
	{
		return new BooleanControlCreator(this);
	}

	/**
	 * ����������BooleanControlCreator��<BR>
	 *
	 * Return the real boolean control creator.<BR>
	 *
	 * @return
	 */
	public BooleanControlCreator getBooleanControlCreator()
	{
		return (BooleanControlCreator) this.getControlCreator();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		return Boolean.valueOf(this.getButton().getSelection());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value)
	{
		Button t_Button = this.getButton();

		if (r_Value instanceof Boolean)
		{
			t_Button.setSelection(((Boolean) r_Value).booleanValue());
		}
		else
		{
			t_Button.setSelection(false);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf()
	{
		BooleanPropertyEditor t_PropertyEditor = new BooleanPropertyEditor();
		t_PropertyEditor.usePostfix = this.usePostfix;
		return t_PropertyEditor;
	}

	/**
	 * ��������ѡ��İ�ť��<BR>
	 *
	 * Return the button for selection.<BR>
	 *
	 */
	public Button getButton()
	{
		return (Button) this.getEditorControl();
	}

	/**
	 * @return Returns the usePostfix.
	 */
	public boolean isUsePostfix()
	{
		return this.usePostfix;
	}

	/**
	 * @param r_usePostfix
	 *            The usePostfix to set.
	 */
	public void setUsePostfix(boolean r_UsePostfix)
	{
		this.usePostfix = r_UsePostfix;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#afterBuild(com.primeton.studio.core.IAdapter)
	 */
	public void afterBuild(IAdaptable r_Adaptable)
	{
		super.afterBuild(r_Adaptable);

		if (this.isUsePostfix())
		{
			Label t_Label=(Label)this.getLabelControl();
			/**
			 * fix nullpointer
			 * @author caijing
			 */
			if(t_Label != null)
			{
				t_Label.setText("");
				t_Label.setVisible(false);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	protected ILayoutDataBuilder createLayoutDataBuilder()
	{
		GridLayoutDataBuilder t_LayoutDataBuilder= new GridLayoutDataBuilder();
		t_LayoutDataBuilder.setHorizontalFill(false);
		return t_LayoutDataBuilder;
	}


}
