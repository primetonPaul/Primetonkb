package com.primeton.studio.ui.swt.properties.tabbed.entries;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.IConfigurationElement;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.core.impl.UIElementDescription;
import com.primeton.studio.ui.swt.factory.IControlFactory;

/**
 * 
 * ���ڶ�tab��չ��factory�ڵ�ļ򵥷�װ
 *
 * @author <a href="mailto:yujl@primeton.com">Yu J Lin</a>
 */
/*
 * �޸���ʷ
 * $Log: ControlFactoryEntry.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2010/04/27 10:53:08  wanglei
 * Jira:����EOSP-189��
 *
 */
public class ControlFactoryEntry {
	private static final String TAB = "tab";
	private static final Map<String,Integer> showStyles = new HashMap<String, Integer>();
	static{
		showStyles.put(null, IConstant.SHOW_IN_BOTH);
		showStyles.put("", IConstant.SHOW_IN_BOTH);
		showStyles.put(IConstant.INBOTH, IConstant.SHOW_IN_BOTH);
		showStyles.put(IConstant.PROPERTYDIALOG, IConstant.SHOW_IN_PROPERTYDIALOG);
		showStyles.put(IConstant.PROPERTYVIEW, IConstant.SHOW_IN_PROPERTYVIEW);
	}
	
	private String tab;
	private int priority;
	private int showStyle;
	private IConfigurationElement configurationElement;
	
	/**
	 * Ĭ�Ϲ��캯��
	 */
	public ControlFactoryEntry(IConfigurationElement configurationElement) {
		super();
		Assert.isNotNull(configurationElement);
		this.configurationElement = configurationElement;
		tab = configurationElement.getAttribute(TAB);
		showStyle = showStyles.get(configurationElement.getAttribute(IConstant.SHOWSTYLE));
		String attribute = configurationElement.getAttribute(IConstant.PRIORITY);
		priority = NumberUtils.toInt(attribute,0);
		
	}
	
	/**
	 * ����һ���µ�IControlFactory����
	 * @return
	 */
	public final IControlFactory newInstanceControlFactory(String pluginID){
		try {
			Object t_Object = configurationElement.createExecutableExtension(IConstant.CLASS_NAME);
			if (t_Object instanceof IControlFactory) {
				IControlFactory t_Factory = (IControlFactory) t_Object;
				UIElementDescription uiDescription = t_Factory.getUIDescription();
				if ((null != uiDescription) && (null == uiDescription.getBundleName())) {
					uiDescription.setBundleName(pluginID);
				}
				t_Factory.setShowStyle(showStyle);
				return t_Factory;
			}
		} catch (Exception ex) {
			ExceptionUtil.getInstance().logException(ex);
		}//����factory
		return null;
	}

	/**
	 * @return the priority
	 */
	public final int getPriority() {
		return priority;
	}

	/**
	 * @return the tab
	 */
	public final String getTab() {
		return tab;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((tab == null) ? 0 : tab.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final ControlFactoryEntry other = (ControlFactoryEntry) obj;
		if (tab == null) {
			if (other.tab != null)
				return false;
		} else if (!tab.equals(other.tab))
			return false;
		return true;
	}
	
	/**
	 * ��ȡ���Ҷ���
	 * @param tab
	 * @return
	 */
	public static Predicate getPredicate(String tab){
		return new ControlFactoryEntryPredicate(tab);
	}
	
	/**
	 * 
	 * ���ڲ���ControlFactoryEntry����Ķ���
	 * 
	 * @author <a href="mailto:yujl@primeton.com">Yu J Lin</a>
	 */
	private static class ControlFactoryEntryPredicate implements Predicate{

		private String tab;
		
		public ControlFactoryEntryPredicate(String tab){
			this.tab = tab;
		}
		/* (non-Javadoc)
		 * @see org.apache.commons.collections.Predicate#evaluate(java.lang.Object)
		 */
		public boolean evaluate(Object value) {
			if(value instanceof ControlFactoryEntry){
				ControlFactoryEntry entry = (ControlFactoryEntry) value;
				return StringUtils.equals(this.tab, entry.getTab());
			}
			return false;
		}
		
	}
}
