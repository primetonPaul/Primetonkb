/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.ui.swt.component.impl;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;

import com.primeton.studio.ui.editor.ObjectEditor;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����֧���Զ���������Ԫ�ر༭�ؼ���<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * This composite support scroll for a object editor. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-9-23 ����01:59:20
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: ScrolledPropertyComposite.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/03/20 08:55:28  lvyuan
 * Remove:�ָ�1.1�İ汾
 *
 * Revision 1.2  2007/03/20 06:31:26  lvyuan
 * Update:���ò���
 *
 * Revision 1.1  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public class ScrolledPropertyComposite extends ScrolledComposite
{
	private ObjectEditor objectEditor;

	/**
	 * �̳и���Ĺ��캯��<BR>
	 * 
	 * The default construtor from the parent class<BR>
	 * 
	 * @param r_Parent
	 *            the parent control
	 * @param r_Style
	 *            the style for the control
	 * 
	 * @param r_ObjectEditor
	 *            the object editor used to edit a object.
	 */
	public ScrolledPropertyComposite(Composite r_Parent, int r_Style, ObjectEditor r_ObjectEditor)
	{
		super(r_Parent, SWT.NONE | SWT.H_SCROLL | SWT.V_SCROLL);
		this.objectEditor = r_ObjectEditor;

		this.setExpandHorizontal(true);
		this.setExpandVertical(true);

		this.setBackground(r_Parent.getBackground());

		PropertyComposite t_PropertyComposite = new PropertyComposite(this, r_Style, r_ObjectEditor);
//        t_PropertyComposite.setLayout(new GridLayout(2,false));
//        t_PropertyComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
		this.setContent(t_PropertyComposite);
		this.setMinSize(this.computeSize(t_PropertyComposite));
	}

	/**
	 * ������͸ߡ�<BR>
	 * 
	 * Compute the size.<BR>
	 * 
	 * @param r_PropertyComposite
	 *            the control to be computed the size.
	 * 
	 */
	private Point computeSize(PropertyComposite r_PropertyComposite)
	{
		int t_Width = SWT.DEFAULT;
		if (this.objectEditor.getWidth() > 0)
		{
			t_Width = this.objectEditor.getWidth();
		}

		int t_Height = SWT.DEFAULT;
		if (this.objectEditor.getHeight() > 0)
		{
			t_Height = this.objectEditor.getHeight();
		}

		return r_PropertyComposite.computeSize(t_Width, t_Height);
	}

	/**
	 * ���ص�ǰ�Ķ���༭����<BR>
	 * 
	 * Return the object editor.
	 * 
	 * @return Returns the objectEditor.
	 */
	public final ObjectEditor getObjectEditor()
	{
		return this.objectEditor;
	}

}
