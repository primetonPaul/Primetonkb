/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.table.action.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.ui.swt.builder.base.AbstractControlAction;
import com.primeton.studio.ui.swt.builder.table.TableBuilder;
import com.primeton.studio.ui.swt.builder.table.action.ITableActionProvider;
import com.primeton.studio.ui.swt.builder.table.action.base.AbstractTableAction;
import com.primeton.studio.ui.swt.builder.table.action.base.AbstractTableComposite;

/**
 *
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * һ�����ؼ���������������һ������Ͷ��Action����ЩAction����ͨ��Button����ʾ��Ҳ����ͨ����������<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * A parent composite which contains a table and multi actions.<BR>
 * These actions can show in buttons ,it also support toolbar. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-10-29 ����10:39:40
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ButtonTableComposite.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2007/08/03 05:39:41  wanglei
 * Review:������Table,KTable,KTree�ȸ��ӿؼ�����������ʽ������Ӧ�����˶�Ӧ��Action��
 *
 * Revision 1.2  2007/04/16 02:26:17  wanglei
 * Add:��������ָ���������ʽ��
 *
 * Revision 1.1  2007/03/05 06:06:33  wanglei
 * �ύ��CVS
 *
 */
public class ButtonTableComposite extends AbstractTableComposite {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_Parent
	 * @param r_Style
	 * @param r_Title
	 * @param r_TableBuilder
	 * @param r_TableActionProvider
	 * @param r_TableStyle
	 * @param r_ActionStyle
	 */
	public ButtonTableComposite(Composite r_Parent, int r_Style, String r_Title, TableBuilder r_TableBuilder, ITableActionProvider r_TableActionProvider, int r_TableStyle, int r_ActionStyle) {
		super(r_Parent, r_Style, r_Title, r_TableBuilder, r_TableActionProvider, r_TableStyle, r_ActionStyle);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.component.base.AbstractTableComposite#createControl(org.eclipse.swt.widgets.Composite,
	 *      java.lang.String)
	 */
	protected Control createControl(Composite r_Parent, String r_Title, int r_ActionStyle) {
		this.buildTable(r_Parent);
		this.getTableBuilder().getViewer().getControl().setLayoutData(new GridData(GridData.FILL_BOTH));

		Composite t_ActionParent = new Composite(this, SWT.FLAT);
		t_ActionParent.setBackground(this.getBackground());

		GridData t_GridData = new GridData(GridData.VERTICAL_ALIGN_BEGINNING);
		t_ActionParent.setLayoutData(t_GridData);

		t_ActionParent.setLayout(new GridLayout(1, false));

		AbstractTableAction[] t_TableActions = this.getActions();
		if (!ArrayUtils.isEmpty(t_TableActions)) {
			buildActions(t_ActionParent, t_TableActions);

			this.updateActionStatus();
		}

		return t_ActionParent;
	}

	/**
	 * ����Action��<BR>
	 *
	 * Create actions.<BR>
	 *
	 * @param r_ActionParent
	 * @param r_TableActions
	 */
	private void buildActions(Composite r_ActionParent, AbstractTableAction[] r_TableActions) {

		Map t_ActionMap = AbstractControlAction.sort(r_TableActions);
		//Sort by group id

		for (Iterator t_Iterator = t_ActionMap.keySet().iterator(); t_Iterator.hasNext();) {
			Integer t_GroupID = (Integer) t_Iterator.next();
			List t_List = (List) t_ActionMap.get(t_GroupID);

			for (int i = 0; i < t_List.size(); i++) {
				AbstractTableAction t_TableAction = (AbstractTableAction) t_List.get(i);

				Button t_Button = t_TableAction.getButton(r_ActionParent, this);
				t_Button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.component.base.AbstractTableComposite#getColumnCount()
	 */
	protected int getColumnCount() {
		return 2;
	}

}
