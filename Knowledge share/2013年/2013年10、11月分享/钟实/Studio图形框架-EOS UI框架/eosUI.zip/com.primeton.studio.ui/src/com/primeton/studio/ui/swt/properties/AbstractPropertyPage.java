/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.properties;

import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.ui.IWorkbenchPropertyPage;
import org.eclipse.ui.dialogs.PropertyPage;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValidable;
import com.primeton.studio.core.IValidateListener;
import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.event.ValidateEvent;
import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.core.util.PropertiesUtil;
import com.primeton.studio.ui.swt.util.ValidateUtil;

/**
 * �ܹ��ṩ��Ϣ��ʾ������ҳ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractPropertyPage.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.3  2010/06/29 08:33:57  hongsq
 * Update:fix����ҳ����������ʾ������Ϣ������
 *
 * Revision 1.2  2008/12/18 09:05:57  lvyuan
 * BugFix:fix bug 14760
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2008/02/26 09:24:59  wanglei
 * Update:ʵ����IValueChangeListener��IValidateListener��
 *
 * Revision 1.4  2008/02/26 02:50:12  wanglei
 * Review:�������롣
 *
 * Revision 1.3  2007/12/11 05:58:08  tenghao
 * Update:  �޸�Bug
 *
 * Revision 1.2  2007/11/21 06:28:02  wanglei
 * Review:�ڴ����ؼ��ڼ䲻���ܴ�����Ϣ��
 *
 * Revision 1.1  2007/04/10 09:29:52  wanglei
 * Add:��ԭ��com.primeton.studio.core������Resources������ȫ���Ƶ���ǰ����С�
 *
 */
public abstract class AbstractPropertyPage extends PropertyPage implements IWorkbenchPropertyPage, IMessageCaller, IValueChangeListener, IValidateListener {
	private String message = null;
	private int type = -1;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractPropertyPage() {
		super();
	}

	/**
	 * ������Ϣ��<BR>
	 *
	 * Update message.<BR>
	 *
	 * @param r_Message
	 * @param r_Properties
	 * @param r_Type
	 */
	protected void updateMessage(String r_Message, Properties r_Properties, int r_Type) {
		String t_Message = r_Message + PropertiesUtil.toString(r_Properties);
		if (StringUtils.equals(this.message, t_Message) && r_Type == this.type) {
			return;
		}

		this.message = t_Message;
		this.type = r_Type;

	}

	/**
	 * {@inheritDoc}
	 */
	public final void clear() {
//		this.setErrorMessage(null);
		this.message = null;
		this.type = -1;
	}

	/**
	 * {@inheritDoc}
	 */
	public final void error(String r_Message, Properties r_Properties) {
//		this.setErrorMessage(r_Message + PropertiesUtil.toString(r_Properties));
		this.updateMessage(r_Message, r_Properties, IMessageProvider.ERROR);
	}

	/**
	 * {@inheritDoc}
	 */
	public final boolean hasError() {
		return this.isValid();
	}

	/**
	 * {@inheritDoc}
	 */
	public final void info(String r_Message, Properties r_Properties) {
//		this.setMessage(r_Message + PropertiesUtil.toString(r_Properties));
		String t_Message = r_Message + PropertiesUtil.toString(r_Properties);
		this.message = t_Message;
		this.type = IMessageProvider.INFORMATION;
	}

	/**
	 * {@inheritDoc}
	 */
	public final void warn(String r_Message, Properties r_Properties) {
//		this.setMessage(r_Message + PropertiesUtil.toString(r_Properties), IMessageProvider.WARNING);
		this.updateMessage(r_Message, r_Properties, IMessageProvider.WARNING);
	}

	/**
	 *
	 */
	protected void updateMessage() {
		if (!StringUtils.isEmpty(this.message)) {
			if (this.type == IMessageProvider.ERROR) {
				this.setErrorMessage(this.message);
			}
			else {
				this.setErrorMessage(null);
				this.setMessage(this.message, this.type);
			}
		}
		else {
			this.setErrorMessage(null);
			this.setMessage(null, IMessageProvider.WARNING);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void validateRequested(ValidateEvent r_Event) {
		this.clear();

		if (ValidateUtil.validate(getValidable(), this, r_Event)) {
			if (this.validate()) {
				this.setValid(true);
			}
			else {
				this.setValid(false);
			}
		}
		else {
			this.setValid(false);
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.PreferencePage#setValid(boolean)
	 */
	@Override
	public void setValid(boolean b) {
		super.setValid(b);
		updateMessage();
	}

	/**
	 * @return ��֤�Ľ��档<BR>
	 */
	protected IValidable getValidable(){
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public void valueChange(ValueChangeEvent r_Event) {
		this.validateRequested(r_Event);
	}

	/**
	 * ��֤
	 * @return
	 */
	public boolean validate() {
		return true;
	}
}
