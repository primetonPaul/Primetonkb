/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.swt.component.impl;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;

import com.primeton.studio.ui.editor.ObjectEditor;
import com.primeton.studio.ui.swt.component.base.AbstractPropertyComponent;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����༭������������<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The property editor for multi objects.<BR>
 * <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: MultiPropertyComposite.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.2  2008/02/25 09:20:23  wanglei
 * Review:ΪIValidable��validate��������IMessageCaller��Event����������
 *
 * Revision 1.1  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public final class MultiPropertyComposite extends AbstractPropertyComponent
{
	private ObjectEditor[] objectEditors;

	/**
	 * �̳и���Ĺ��캯��<BR>
	 *
	 * The default construtor from the parent class<BR>
	 *
	 *
	 * @param r_Parent
	 * @param r_Style
	 * @param r_ObjectEditors
	 *
	 */
	public MultiPropertyComposite(Composite r_Parent, int r_Style, ObjectEditor[] r_ObjectEditors)
	{
		super(r_Parent, r_Style);
		this.setLayout(new FillLayout(SWT.VERTICAL));
		// �������֡�<BR>
		// Prepare layout for multi objects.

		this.objectEditors = r_ObjectEditors;

		for (int i = 0; i < this.objectEditors.length; i++)
		{
			ObjectEditor t_Editor = this.objectEditors[i];
			new PropertyComposite(this, SWT.NONE, t_Editor);
		}

		this.load();
	}

	/**
	 * ���ص�ǰ�Ķ������༭����<BR>
	 *
	 * Return the object editors.<BR>
	 *
	 * @return Returns the objectEditors.
	 */
	public final ObjectEditor[] getObjectEditors()
	{
		return this.objectEditors;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	public void load()
	{
		for (int i = 0; i < this.objectEditors.length; i++)
		{
			ObjectEditor t_Editor = this.objectEditors[i];
			t_Editor.load();
		}

		for (int i = 0; i < this.objectEditors.length; i++)
		{
			ObjectEditor t_Editor = this.objectEditors[i];
			if (!t_Editor.validate(null, null))
				//FIXME_WangLei
			{
				return;
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#save()
	 */
	public void save()
	{
		for (int i = 0; i < this.objectEditors.length; i++)
		{
			ObjectEditor t_Editor = this.objectEditors[i];
			t_Editor.save();
		}
	}

	/**
	 * ����֧��ObjecEdior��Adapter��<BR>
	 *
	 * This method is overrided to suppor the adater of "ObjectEditor".<BR>
	 *
	 * @param r_Class
	 *            the target adapter class.
	 */
	protected Object getExtendAdapter(Class r_Class)
	{
		if (ObjectEditor[].class == r_Class)
		{
			return this.objectEditors;
		}
		return super.getExtendAdapter(r_Class);
	}
}
