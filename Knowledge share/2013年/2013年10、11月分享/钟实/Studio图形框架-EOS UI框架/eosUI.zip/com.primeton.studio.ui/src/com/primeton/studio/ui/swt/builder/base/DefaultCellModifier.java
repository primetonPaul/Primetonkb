/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.base;

import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.swt.widgets.Item;

import com.primeton.studio.ui.swt.builder.model.base.ITableColumnDescriptor;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��������Table����Tree�������޸�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * This class is used to control the modification for table and tree. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-26 ����06:04:40
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: DefaultCellModifier.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/02/21 09:20:11  wanglei
 * Review:�����¼�֪ͨ���ơ�
 *
 * Revision 1.2  2007/05/22 01:09:56  wanglei
 * Refactor:�ع���isEditable������
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public class DefaultCellModifier implements ICellModifier
{
	private ViewerBuilder viewerBuilder;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_ViewerBuilder
	 */
	public DefaultCellModifier(ViewerBuilder r_ViewerBuilder)
	{
		super();
		Assert.isNotNull(r_ViewerBuilder, "The builder shouldn't be null.");
		this.viewerBuilder = r_ViewerBuilder;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.ICellModifier#canModify(java.lang.Object, java.lang.String)
	 */
	public boolean canModify(Object r_Element, String r_Property)
	{
		if (this.viewerBuilder.isReadonly())
		{
			return false;
		}

		ITableColumnDescriptor t_Descriptor = getTableColumnDescriptor(r_Property);
		int t_ColumnIndex=this.viewerBuilder.indexOf(r_Property);
		int t_RowIndex=this.viewerBuilder.getDataProvider().indexOf(r_Element);

		if (null == t_Descriptor)
		{
			return false;
		}
		else
		{
			return t_Descriptor.isEditable(r_Element, t_ColumnIndex, t_RowIndex);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.ICellModifier#getValue(java.lang.Object, java.lang.String)
	 */
	public Object getValue(Object r_Element, String r_Property)
	{
		ITableColumnDescriptor t_Descriptor = getTableColumnDescriptor(r_Property);
		if (null == t_Descriptor)
		{
			return null;
		}
		else
		{
			return t_Descriptor.getValue(r_Element);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.ICellModifier#modify(java.lang.Object, java.lang.String, java.lang.Object)
	 */
	public void modify(Object r_Element, String r_Property, Object r_NewValue)
	{
		ITableColumnDescriptor t_Descriptor = getTableColumnDescriptor(r_Property);
		if (null != t_Descriptor)
		{
			Item t_Item = (Item) r_Element;
			t_Descriptor.setValue(t_Item.getData(), r_NewValue);
			Object t_OldValue=t_Descriptor.getValue(t_Item.getData());

			this.viewerBuilder.fireValueChanged(r_Element,r_Property,t_OldValue,r_NewValue);
			this.viewerBuilder.getViewer().refresh(t_Item.getData());
		}
	}

	/**
	 * @param r_Name
	 * @return
	 * @see com.primeton.studio.ui.swt.builder.base.ViewerBuilder#getTableColumnDescriptor(java.lang.String)
	 */
	public ITableColumnDescriptor getTableColumnDescriptor(String r_Name)
	{
		return this.viewerBuilder.getTableColumnDescriptor(r_Name);
	}

	/**
	 * @return Returns the viewerBuilder.
	 */
	public ViewerBuilder getViewerBuilder()
	{
		return this.viewerBuilder;
	}

}
