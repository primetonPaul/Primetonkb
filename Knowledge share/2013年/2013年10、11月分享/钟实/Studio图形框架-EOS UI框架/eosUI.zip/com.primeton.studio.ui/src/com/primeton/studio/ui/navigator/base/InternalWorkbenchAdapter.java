/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/navigator/base/InternalWorkbenchAdapter.java,v 1.2 2011/06/02 07:11:12 yujie Exp $
 * $Revision: 1.2 $
 * $Date: 2011/06/02 07:11:12 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2009-4-9
 *******************************************************************************/


package com.primeton.studio.ui.navigator.base;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.model.WorkbenchAdapter;

import com.primeton.studio.core.INamingElement;

/**
 * �ڲ�ʹ�õ�WorkbenchAdapter��<BR>
 *
 * @author wanglei (mailto:wanglei@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: InternalWorkbenchAdapter.java,v $
 * Revision 1.2  2011/06/02 07:11:12  yujie
 * Update:ui��ܲ���ύ
 *
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/04/14 08:04:02  wanglei
 * Add:������Navigator�Ļ��ࡣ
 *
 */
public class InternalWorkbenchAdapter extends WorkbenchAdapter {

	private static final InternalWorkbenchAdapter instance = new InternalWorkbenchAdapter();

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private InternalWorkbenchAdapter() {
		super();
	}

	/**
	 * @return the instance
	 */
	public static InternalWorkbenchAdapter getInstance() {
		return instance;
	}

	/**
	 * {@inheritDoc}
	 */
	public ImageDescriptor getImageDescriptor(Object object) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getLabel(Object object) {
		if (object instanceof INamingElement) {
			INamingElement namingElement = (INamingElement) object;
			return namingElement.getName();
		} else {
			return ObjectUtils.toString(object);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChildren(Object element) {
		return true;
	}
}
