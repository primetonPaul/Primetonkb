/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.factory.impl;

import org.eclipse.swt.SWT;

import com.primeton.studio.ui.swt.factory.UIDefinition;

/**
 * UIDefinition��Ĭ��ʵ��<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: DefaultUIDefinition.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.4  2008/02/18 06:15:41  wanglei
 * Update:��IControlFactory��createControl�����ع���ʹ��UIDefinition��Ϊ��������������
 *
 * Revision 1.3  2008/02/18 05:24:52  wanglei
 * Add:����getStyle�����͹��캯����
 *
 * Revision 1.2  2008/02/18 05:15:37  wanglei
 * Update:������һ��Ĭ��ʵ����
 *
 * Revision 1.1  2008/02/18 05:08:27  wanglei
 * Add:�ύ��CVS��
 *
 */
public class DefaultUIDefinition implements UIDefinition {

	private boolean eagerSave;

	private boolean view;

	private int style = SWT.NONE;

	public static final UIDefinition DEFAULT_INSTANCE = new UIDefinition() {

		public boolean isEagerSave() {
			return false;
		}

		public boolean isView() {
			return false;
		}

		/**
		 * {@inheritDoc}
		 */
		public int getStyle() {
			return SWT.NONE;
		}
	};

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public DefaultUIDefinition() {
		super();
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_EagerSave
	 * @param r_View
	 * @param r_Style
	 */
	public DefaultUIDefinition(boolean r_EagerSave, boolean r_View, int r_Style) {
		super();
		this.eagerSave = r_EagerSave;
		this.view = r_View;
		this.style = r_Style;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isEagerSave() {
		return this.eagerSave;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isView() {
		return this.view;
	}

	/**
	 * @param r_EagerSave The eagerSave to set.
	 */
	public void setEagerSave(boolean r_EagerSave) {
		this.eagerSave = r_EagerSave;
	}

	/**
	 * @param r_View The view to set.
	 */
	public void setView(boolean r_View) {
		this.view = r_View;
	}

	/**
	 * @param v The style to set.
	 */
	public void setStyle(int r_Style) {
		this.style = r_Style;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getStyle() {
		return this.style;
	}

}
