/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.model.base;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;

import com.eos.system.utility.CollectionUtil;
import com.primeton.studio.core.ICloneable;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.helper.IntrospectorHelper;
import com.primeton.studio.core.model.IDataProvider;
import com.primeton.studio.core.util.comparator.PropertyComparator;
import com.primeton.studio.ui.swt.builder.model.impl.DefaultTableColumnContextHelper;
import com.primeton.studio.ui.swt.helper.IAssitantHelper;
import com.primeton.studio.ui.swt.helper.IHelpContext;
import com.primeton.studio.ui.swt.helper.impl.DefaultHelpContext;
import com.primeton.studio.ui.swt.validator.ITableValidator;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * "ITableColumn"�Ļ���<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The base class for "ITableColumn". <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-10-4 ����09:33:37
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractTableColumn.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/11/20 02:23:40  chenxp
 * Bug: 13657 ��ʾ��һ�������ڴ��validator�õ���HashSet,���µõ�����֤�������ǲ����ġ�
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.11  2008/01/08 02:59:45  wanglei
 * UnitTest:���������Ӽ���Ԫ��ʱNPE��Bug��
 *
 * Revision 1.10  2007/07/26 03:23:01  wanglei
 * Update:������֤���ƣ�ʹ��ITableValidator������IValidator��
 *
 * Revision 1.9  2007/05/22 01:15:40  wanglei
 * Refactor:������isEditabl������
 *
 * Revision 1.8  2007/04/28 02:28:52  wanglei
 * UnitTest:������getIntrospector��������ϵͳע������ȡ������Ĭ��ʹ�õ�PropertyIntrospector��
 *
 * Revision 1.7  2007/04/24 07:52:49  wanglei
 * Add:Ϊ��������������ӳ�书�ܣ��������Ե�����ʾ�ı���
 *
 * Revision 1.6  2007/03/07 05:06:57  wanglei
 * ��Ĭ�Ͽ��ȸĳ�80��ͬʱĬ�ϲ�֧������
 *
 * Revision 1.5  2007/03/05 06:06:33  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractTableColumn implements ITableColumn
{
	private Introspector introspector = null;

	private boolean editable = true;

	private int width=80;

	private String propertyName;

	private String title;

	private ITableDataProvider dataProvider;

	private boolean resizable;

	private boolean useColor;

	private boolean movable;

	private boolean autoResizable;

	private boolean sortable = false;

	private int sortState;

	private Comparator comparator;

	private IAssitantHelper assitantHelper;

	private List validators = new ArrayList();

	// ��֤��

	private ITableColumnContextHelper contextHelper;

	private IHelpContext[] helpContexts;

	private IDataProvider provider;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public AbstractTableColumn()
	{
		super();
	}

	/**
	 * �������ݷ�������<BR>
	 *
	 * Return the introspector for this column.<BR>
	 *
	 * @return Returns the introspector.
	 */
	public Introspector getIntrospector(Object r_Object)
	{
		if (null == this.introspector)
		{
			if (null ==r_Object)
			{
				this.introspector = IntrospectorHelper.getInstance().getIntrospector(null);
			}
			else
			{
				this.introspector = IntrospectorHelper.getInstance().getIntrospector(r_Object.getClass());
			}
		}
		return this.introspector;
	}

	/**
	 * �������ݷ�������<BR>
	 *
	 * Set the introspector for this column.<BR>
	 *
	 * @param r_Introspector
	 *            The introspector to set.
	 */
	public void setIntrospector(Introspector r_Introspector)
	{
		this.introspector = r_Introspector;
	}

	/**
	 * ���õ�ǰ�������Ƿ������༭��<BR>
	 *
	 * Set this column is editable or not.<BR>
	 *
	 * @param r_Editable
	 *            The editable to set.
	 */
	public void setEditable(boolean r_Editable)
	{
		this.editable = r_Editable;
	}

	/**
	 * ���ص�ǰ�е���ʾ���⡣<BR>
	 *
	 * Return the title for the column header.<BR>
	 *
	 */
	public String getTitle()
	{
		return this.title;
	}

	/**
	 * ���õ�ǰ�е���ʾ���⡣<BR>
	 *
	 * Set the title for the column header.<BR>
	 *
	 * @param r_Title
	 *            The title to set.
	 */
	public void setTitle(String r_Title)
	{
		this.title = r_Title;
	}

	/**
	 * ���ص�ǰ�е�Ĭ�Ͽ��ȡ�<BR>
	 *
	 * Return the default width of the column.
	 *
	 */
	public int getWidth()
	{
		return this.width;
	}

	/**
	 * ���õ�ǰ�е�Ĭ�Ͽ��ȡ�<BR>
	 *
	 * Set the default width of the column.
	 *
	 * @param r_Width
	 *            The width to set.
	 */
	public void setWidth(int r_Width)
	{
		this.width = r_Width;
	}

	/**
	 * ���ص�ǰ������Ҫ��ʾ��������Ϣ��<BR>
	 *
	 * Return the property name to operate for this column.<BR>
	 *
	 */
	public String getPropertyName()
	{
		return this.propertyName;
	}

	/**
	 * ���õ�ǰ������Ҫ��ʾ��������Ϣ��<BR>
	 *
	 * Set the property name to operate for this column.<BR>
	 *
	 * @param r_PropertyName
	 *            The propertyName to set.
	 */
	public void setPropertyName(String r_PropertyName)
	{
		this.propertyName = r_PropertyName;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#getDataProvider()
	 */
	public ITableDataProvider getDataProvider()
	{
		return this.dataProvider;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#setDataProvider(com.primeton.ui.swt.builder.model.base.ITableDataProvider)
	 */
	public void setDataProvider(ITableDataProvider r_DataProvider)
	{
		this.dataProvider = r_DataProvider;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#isAutoResizable()
	 */
	public boolean isAutoResizable()
	{
		return this.autoResizable;
	}

	/**
	 * �����Ƿ������Զ������п����Է�����ʾ������<BR>
	 *
	 * Set whether to adjust the width of the column.<BR>
	 *
	 * @param r_AutoResizable
	 *            The autoResizable to set.
	 */
	public void setAutoResizable(boolean r_AutoResizable)
	{
		this.autoResizable = r_AutoResizable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#isResizable()
	 */
	public boolean isResizable()
	{
		return this.resizable;
	}

	/**
	 * �����Ƿ����������еĴ�С��<BR>
	 *
	 * Set whether to adjust the width of the column.<BR>
	 *
	 * @param r_Resizable
	 *            The resizable to set.
	 */
	public void setResizable(boolean r_Resizable)
	{
		this.resizable = r_Resizable;
	}

	/**
	 * ����ָ���ıȽ��������������û��ָ������ʹ��Property��������<BR>
	 *
	 * Return the specified comparator.If the user doesn't specify the comparator,the property comparator will be used.<BR>
	 *
	 */
	public Comparator getComparator()
	{
		if (null == this.comparator)
		{
			this.comparator = new PropertyComparator(this.getPropertyName());
		}

		return this.comparator;
	}

	/**
	 * ָ��һ���Ƚ�����������<BR>
	 *
	 * Set a specified comparator for sorting.<BR>
	 *
	 * @param r_Comparator
	 *            The comparator to set.
	 */
	public void setComparator(Comparator r_Comparator)
	{
		this.comparator = r_Comparator;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#getSortState()
	 */
	public int getSortState()
	{
		return this.sortState;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#setSortState(int)
	 */
	public void setSortState(int r_SortState)
	{
		this.sortState = r_SortState;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#isSortable()
	 */
	public boolean isSortable()
	{
		return this.sortable;
	}

	/**
	 * ���õ�ǰ���Ƿ���������<BR>
	 *
	 * Set this column is sortable or not.<BR>
	 *
	 * @param r_Sortable
	 *            The sortable to set.
	 */
	public void setSortable(boolean r_Sortable)
	{
		this.sortable = r_Sortable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#isMovable()
	 */
	public boolean isMovable()
	{
		return this.movable;
	}

	/**
	 * ���õ�ǰ�е���ͷ�Ƿ������û��ƶ���<BR>
	 *
	 * Set whether this column can be moved.<BR>
	 *
	 * @param r_Movable
	 *            The movable to set.
	 */
	public void setMovable(boolean r_Movable)
	{
		this.movable = r_Movable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#isEditable(java.lang.Object)
	 */
	public boolean isEditable(Object r_Element, int r_Column, int r_Row)
	{
		return this.editable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableColumnDescriptor#isEditable()
	 */
	public boolean isEditable()
	{
		return this.editable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#clone()
	 */
	public Object clone()
	{
		AbstractTableColumn t_TableColumn = this.doClone();

		t_TableColumn.editable = this.editable;
		t_TableColumn.introspector = (Introspector) this.introspector.clone();
		t_TableColumn.width = this.width;
		t_TableColumn.propertyName = this.propertyName;
		t_TableColumn.title = this.title;
		t_TableColumn.dataProvider = (ITableDataProvider) this.dataProvider.clone();
		t_TableColumn.resizable = this.resizable;
		t_TableColumn.movable = this.movable;
		t_TableColumn.autoResizable = this.autoResizable;
		t_TableColumn.sortable = this.sortable;
		t_TableColumn.sortState = this.sortState;

		if(null!=this.provider)
		{
			t_TableColumn.provider = (IDataProvider) this.provider.clone();
		}

		if (null != this.getAssitantHelper())
		{
			this.setAssitantHelper((IAssitantHelper) this.getAssitantHelper().clone());
		}

		if (this.comparator instanceof ICloneable)
		{
			t_TableColumn.comparator = (Comparator) ((ICloneable) this.comparator).clone();
		}
		else
		{
			t_TableColumn.comparator = this.comparator;
		}

		return t_TableColumn;
	}

	/**
	 * ����һ��Validator�������ڱ���ʱ�����Խ���������֤<BR>
	 *
	 * Add a validator,it will be called when the user input is stored.<BR>
	 *
	 * @param r_Validator
	 *            the validator to add
	 */
	public void doAddValidator(ITableValidator r_Validator)
	{
		if (null != r_Validator)
		{
			this.validators.add(r_Validator);
		}
	}

	/**
	 * ��ȥһ��Validator<BR>
	 *
	 * Remove a validator<BR>
	 *
	 * @param r_Validator
	 *            the validator to remove
	 */
	public void doRemoveValidator(ITableValidator r_Validator)
	{
		if (null != r_Validator)
		{
			this.validators.remove(r_Validator);
		}
	}

	/**
	 * ��ȥ����Validator<BR>
	 *
	 * Remove all the validator<BR>
	 *
	 */
	public void doClearValidators()
	{
		this.validators.clear();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableColumn#getValidators()
	 */
	public ITableValidator[] getValidators()
	{
		ITableValidator[] t_Validators = new ITableValidator[this.validators.size()];
		this.validators.toArray(t_Validators);
		return t_Validators;
	}

	/**
	 * ����������clone������Ȼ����clone�����и���AbstractTableColumnDescriptor��������ԡ�<BR>
	 *
	 * The derived class implements this method to clone a real object.The method of "clone" will clone the properties
	 * of "AbstractTableColumnDescriptor ".
	 *
	 */
	public abstract AbstractTableColumn doClone();

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableColumn#getAssitantHelper()
	 */
	public IAssitantHelper getAssitantHelper()
	{
		return this.assitantHelper;
	}

	/**
	 * @param r_AssitantHelper
	 *            the assitantHelper to set
	 */
	public void setAssitantHelper(IAssitantHelper r_AssitantHelper)
	{
		this.assitantHelper = r_AssitantHelper;
	}

	/**
	 * @param r_ContextHelper
	 *            the contextHelper to set
	 */
	public void setContextHelper(ITableColumnContextHelper r_ContextHelper)
	{
		this.contextHelper = r_ContextHelper;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableColumn#getContextHelper()
	 */
	public ITableColumnContextHelper getContextHelper()
	{
		if (null == this.contextHelper)
		{
			this.contextHelper = this.createContextHelper();
		}

		return this.contextHelper;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.ITableColumn#getHelpContexts()
	 */
	public IHelpContext[] getHelpContexts(Control r_Control)
	{
		IHelpContext[] t_HelpContexts = this.getExtraHelpContexts(r_Control);
		if (null == t_HelpContexts)
		{
			return this.helpContexts;
		}

		List t_List = new ArrayList();
		CollectionUtil.addAllQuietly(t_List, t_HelpContexts);
		CollectionUtil.addAllQuietly(t_List, this.helpContexts);

		IHelpContext[] t_Results = new IHelpContext[t_List.size()];
		t_List.toArray(t_Results);
		return t_Results;
	}

	/**
	 * �õ�����İ�����Ϣ��<BR>
	 *
	 * Return the extra help context.<BR>
	 *
	 * @param r_Control
	 */
	public IHelpContext[] getExtraHelpContexts(Control r_Control)
	{
		String t_Text = null;

		if (r_Control instanceof Combo)
		{
			t_Text = ((Combo) r_Control).getText();
		}

		if (r_Control instanceof CCombo)
		{
			t_Text = ((CCombo) r_Control).getText();
		}

		if (r_Control instanceof Text)
		{
			t_Text = ((Text) r_Control).getText();
		}

		if (StringUtils.isEmpty(t_Text))
		{
			return null;
		}
		else
		{
			return new IHelpContext[] { new DefaultHelpContext(t_Text, null) };
		}
	}

	/**
	 * @param r_HelpContexts
	 *            the helpContexts to set
	 */
	public void setHelpContexts(IHelpContext[] r_HelpContexts)
	{
		this.helpContexts = r_HelpContexts;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn#createContextHelper()
	 */
	protected ITableColumnContextHelper createContextHelper()
	{
		return new DefaultTableColumnContextHelper();
	}

	/**
	 * {@inheritDoc}
	 */
	public IDataProvider getProvider()
	{
		return this.provider;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setProvider(IDataProvider r_Provider)
	{
		this.provider=r_Provider;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isUseColor()
	{
		return this.useColor;
	}

	/**
	 * �����Ƿ�ʹ�ñ�����ǰ��ɫ��<BR>
	 *
	 * Set whether use background and foreground.<BR>
	 *
	 * @param r_UseColor
	 *            the useColor to set
	 */
	public void setUseColor(boolean r_UseColor)
	{
		this.useColor = r_UseColor;
	}


}
