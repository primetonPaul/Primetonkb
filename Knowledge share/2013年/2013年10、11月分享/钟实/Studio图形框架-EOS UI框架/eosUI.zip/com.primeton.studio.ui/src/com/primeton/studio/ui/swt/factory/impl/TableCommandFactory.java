/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.factory.impl;

import com.primeton.studio.core.IMemento;
import com.primeton.studio.core.impl.TableMemento;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.base.AbstractCommandFactory;
import com.primeton.studio.ui.swt.factory.base.AbstractKTableFactory;
import com.primeton.studio.ui.swt.factory.base.AbstractKTreeFactory;
import com.primeton.studio.ui.swt.factory.base.AbstractTableFactory;


/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ���ڱ����ICommandFactoryʵ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The implementation of IControlFactory for table, including table,ktable. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-2-19 ����05:04:09
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: TableCommandFactory.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/19 09:11:57  wanglei
 * Add:�ύ��CVS��
 *
 */

public class TableCommandFactory extends AbstractCommandFactory {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public TableCommandFactory() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public IMemento createMemento(IControlFactory r_ControlFactory) {

		if(r_ControlFactory instanceof AbstractTableFactory)
		{
			AbstractTableFactory t_TableFactory=(AbstractTableFactory)r_ControlFactory;
			return new TableMemento(t_TableFactory.getValue(), t_TableFactory.getType(), t_TableFactory.getTranslator());
		}

		if(r_ControlFactory instanceof AbstractKTableFactory)
		{
			AbstractKTableFactory t_TableFactory=(AbstractKTableFactory)r_ControlFactory;
			return new TableMemento(t_TableFactory.getValue(), t_TableFactory.getType(), t_TableFactory.getTranslator());
		}

		if(r_ControlFactory instanceof AbstractKTreeFactory)
		{
			AbstractKTreeFactory t_TreeFactory=(AbstractKTreeFactory)r_ControlFactory;
			return new TableMemento(t_TreeFactory.getValue(), t_TreeFactory.getType(), t_TreeFactory.getTranslator());
		}

		return null;
	}

}
