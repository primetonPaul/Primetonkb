/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.service;

import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;

import com.primeton.studio.core.service.base.AbstractXmlAliasNaming;
import com.primeton.studio.swt.style.impl.DefaultStyle;
import com.primeton.studio.swt.style.impl.DefaultStyleProvider;
import com.primeton.studio.swt.style.impl.WordGroup;
import com.primeton.studio.ui.editor.ObjectEditor;
import com.primeton.studio.ui.editor.swt.impl.BooleanPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.ClassPathPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.ComboPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.FileListPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.IntegerPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.LabelPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.RadioGroupPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.RadioSwitchPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.StringPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.StyledTextPropertyEditor;
import com.primeton.studio.ui.editor.swt.impl.TablePropertyEditor;
import com.primeton.studio.ui.editor.swt.layout.DelegateLayoutBuilder;
import com.primeton.studio.ui.editor.swt.layout.DelegateLayoutDataBuilder;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutBuilder;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;
import com.primeton.studio.ui.swt.builder.ktable.KTableBuilder;
import com.primeton.studio.ui.swt.builder.ktable.impl.KImagePropertyCellRenderer;
import com.primeton.studio.ui.swt.builder.ktable.impl.KMarkerImageCellRenderer;
import com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableColumn;
import com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel;
import com.primeton.studio.ui.swt.builder.ktable.impl.KTableCellEditorNumber;
import com.primeton.studio.ui.swt.builder.ktable.impl.KTableCellEditorSingleClickText;
import com.primeton.studio.ui.swt.builder.ktable.impl.factory.KPropertyEditorFactory;
import com.primeton.studio.ui.swt.builder.ktable.impl.factory.KPropertyRendererFactory;
import com.primeton.studio.ui.swt.builder.ktree.KTreeBuilder;
import com.primeton.studio.ui.swt.builder.ktree.KTreeModel;
import com.primeton.studio.ui.swt.builder.model.impl.BooleanTableColumnDescriptor;
import com.primeton.studio.ui.swt.builder.model.impl.ComboTableColumnDescriptor;
import com.primeton.studio.ui.swt.builder.model.impl.IntegerTableColumnDescriptor;
import com.primeton.studio.ui.swt.builder.model.impl.LineNumberTableColumnDescriptor;
import com.primeton.studio.ui.swt.builder.model.impl.ListTableDataProvider;
import com.primeton.studio.ui.swt.builder.model.impl.TextTableColumnDescriptor;
import com.primeton.studio.ui.swt.builder.table.TableBuilder;
import com.primeton.studio.ui.swt.builder.table.ViewerMessageCaller;
import com.primeton.studio.ui.swt.factory.impl.CompoundControlFactory;
import com.primeton.studio.ui.swt.helper.impl.DefaultHelpContext;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * Ϊ"aquarius ui"���е����ṩ������<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Provide alias for common classes of "aquarius ui". <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-9-16 ����10:54:08
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: UIXmlAliasNaming.java,v $
 * Revision 1.2  2011/06/02 07:11:12  yujie
 * Update:ui��ܲ���ύ
 *
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.18  2008/02/20 12:01:09  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.17  2008/02/20 09:18:13  wanglei
 * Remove:��ȥ���õ��ࡣ
 *
 * Revision 1.16  2008/02/20 08:37:19  wanglei
 * Remove:����֧��TreeBuilder��
 *
 * Revision 1.15  2008/02/15 09:25:28  wanglei
 * Remove:��ȥ���õ��ࡣ
 *
 * Revision 1.14  2008/02/15 09:18:07  wanglei
 * Remove:��ȥ���õ��ࡣ
 *
 * Revision 1.13  2008/02/15 07:15:27  wanglei
 * Remove:��ȥ�뵯�����йص����ݡ�
 *
 * Revision 1.12  2008/02/15 06:41:15  wanglei
 * Review:���UI��ܿ��ǵıȽ϶࣬��Щ����ʱû���ã�������ȥ��
 *
 * Revision 1.11  2008/02/15 05:52:56  wanglei
 * Review:�������ڿؼ���֧����ʱû�б�Ҫ��������ȥ��
 *
 * Revision 1.10  2007/11/28 09:23:30  wanglei
 * Review:��Դ��֤��ui������Ƶ�runtime����¡�
 *
 * Revision 1.9  2007/06/29 09:56:50  wanglei
 * Review:KTableCellEditorReadOnlyComboƴд�д���
 *
 * Revision 1.8  2007/04/16 06:03:01  wanglei
 * Add:�������µ��������ݡ�
 *
 * Revision 1.7  2007/04/13 03:08:44  wanglei
 * Add:������һЩ����ı�����
 *
 * Revision 1.6  2007/04/10 09:29:52  wanglei
 * Add:��ԭ��com.primeton.studio.core������Resources������ȫ���Ƶ���ǰ����С�
 *
 * Revision 1.5  2007/03/05 06:06:35  wanglei
 * �ύ��CVS
 *
 */
public class UIXmlAliasNaming extends AbstractXmlAliasNaming {

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public UIXmlAliasNaming() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.service.IXmlAliasNaming#doNaming()
	 */
	public void doNaming() {

		this.registerAlias(TableBuilder.class);
		this.registerAlias(ViewerMessageCaller.class);



		this.registerAlias(DefaultHelpContext.class);
		this.registerAlias(DefaultStyleProvider.class);
		this.registerAlias(DefaultStyle.class);
		this.registerAlias(WordGroup.class);

		this.registerAlias("lineNumberTableColumn", LineNumberTableColumnDescriptor.class);
		this.registerAlias("textTableColumn", TextTableColumnDescriptor.class);
		this.registerAlias("comboTableColumn", ComboTableColumnDescriptor.class);
		this.registerAlias("booleanTableColumn", BooleanTableColumnDescriptor.class);
		this.registerAlias("boolTableColumn", BooleanTableColumnDescriptor.class);
		this.registerAlias("integerTableColumn", IntegerTableColumnDescriptor.class);
		this.registerAlias("intTableColumn", IntegerTableColumnDescriptor.class);

		this.registerAlias(ListTableDataProvider.class);

		this.registerAlias(ObjectEditor.class);
		this.registerAlias(GridLayoutBuilder.class);
		this.registerAlias(GridLayoutDataBuilder.class);
		this.registerAlias(DelegateLayoutBuilder.class);
		this.registerAlias(DelegateLayoutDataBuilder.class);

		this.registerAlias("labelEditor", LabelPropertyEditor.class);
		this.registerAlias("stringEditor", StringPropertyEditor.class);
		this.registerAlias("booleanEditor", BooleanPropertyEditor.class);
		this.registerAlias("boolEditor", BooleanPropertyEditor.class);
		this.registerAlias("integerEditor", IntegerPropertyEditor.class);
		this.registerAlias("intEditor", IntegerPropertyEditor.class);
		this.registerAlias("comboEditor", ComboPropertyEditor.class);
		this.registerAlias("radioGroupEditor", RadioGroupPropertyEditor.class);
		this.registerAlias("radioSwitchEditor", RadioSwitchPropertyEditor.class);
		//this.registerAlias("directoryEditor", DirectoryPropertyEditor.class);

		//this.registerAlias("fileSelectionEditor", FileSelectionPropertyEditor.class);

		this.registerAlias("fileListEditor", FileListPropertyEditor.class);
		this.registerAlias("classPathEditor", ClassPathPropertyEditor.class);

		//this.registerAlias("javaClassEditor", JavaClassSelectionPropertyEditor.class);
		//this.registerAlias("javaClassComboEditor", JavaClassComboPropertyEditor.class);
		//this.registerAlias("javaInterfaceEditor", JavaInterfaceSelectionPropertyEditor.class);
		this.registerAlias("styleEditor", StyledTextPropertyEditor.class);

		this.registerAlias("tableEditor", TablePropertyEditor.class);

		this.registerAlias(KTableBuilder.class);
		this.registerAlias(KTreeBuilder.class);
		this.registerAlias(KPropertyTableSortedModel.class);
		this.registerAlias(KTreeModel.class);
		this.registerAlias(KPropertyTableColumn.class);
		this.registerAlias(KPropertyEditorFactory.class);
		this.registerAlias(KPropertyRendererFactory.class);
		this.registerAlias(KImagePropertyCellRenderer.class);
		this.registerAlias(KMarkerImageCellRenderer.class);

		this.registerAlias(KTableCellEditorNumber.class);
		this.registerAlias(KTableCellEditorSingleClickText.class);

		this.registerAlias(RowLayout.class);
		this.registerAlias(FillLayout.class);
		this.registerAlias(GridLayout.class);
		this.registerAlias(RowLayout.class);

		this.registerAlias(FormData.class);
		this.registerAlias(GridData.class);
		this.registerAlias(RowData.class);

		this.registerAlias(CompoundControlFactory.class);

//		this.registerAlias(EclipseFileExistValidator.class);
//		this.registerAlias(EclipseFileNotExistValidator.class);

//		this.registerAlias(EclipseDirectoryExistValidator.class);
//		this.registerAlias(EclipseDirectoryNotExistValidator.class);

//		this.registerAlias(EclipseProjectExistValidator.class);
//		this.registerAlias(EclipseProjectNotExistValidator.class);

	}
}
