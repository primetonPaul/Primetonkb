/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/dialog/DetailsMessageDialog.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on Jul 21, 2008
 *******************************************************************************/


package com.primeton.studio.ui.swt.dialog;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.IconAndMessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.primeton.studio.ui.ResourceMessages;

/**
 * ������ʾ��ϸ��Ϣ
 *
 * @author hongsq (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: DetailsMessageDialog.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.5  2009/04/22 09:38:12  lvyuan
 * Update:���ʻ�
 *
 * Revision 1.4  2008/09/10 08:23:45  yanfei
 * BUG 12847:CC��Ŀ�Ͽ�ʱ,ɾ������������ʾ̫����
 *
 * Revision 1.3  2008/07/23 09:52:17  hongsq
 * Update:�ع�������
 *
 * Revision 1.2  2008/07/23 09:41:04  hongsq
 * Update:����openStatusDialog����
 *
 * Revision 1.1  2008/07/23 07:49:32  hongsq
 * Update:��entity.ui�Ƶ�studio.ui�С�
 *
 * Revision 1.1  2008/07/22 01:36:11  hongsq
 * Update:����һ����ʾ��ϸ��Ϣ��ͨ�öԻ���
 *
 */
public class DetailsMessageDialog extends IconAndMessageDialog {
	public static final int ERROR = 0;

	public static final int WARN = 1;

	public static final int INFO = 2;

	private String title;

	private String details;

	private int type;

	private Text textBox;

	private static final String STANDARD_ERROR_MSG = ResourceMessages.ErrorMessage;

	private static final String STANDARD_WARNING_MSG = ResourceMessages.WarningMessage;

	private static final String STANDARD_ERROR_TITLE = ResourceMessages.Error;

	private static final String STANDARD_WARNING_TITLE = ResourceMessages.Warning;

	private static final String STANDARD_INFO_TITLE = ResourceMessages.Info;

	/**
	 * ������
	 * @param parentShell
	 * @param title
	 * @param message
	 * @param details
	 * @param type
	 */
	public DetailsMessageDialog(Shell parentShell, String title, String message, String details, int type) {
		super(parentShell);
		this.title = title;
		this.message = message;
		this.details = details;
		this.type = type;
		setShellStyle(0x10870);
	}

	/**
	 * ʹ��Ĭ�ϱ������ʾ��Ϣ
	 * @param parentShell
	 * @param details		��ϸ��Ϣ
	 */
	public static void openErrorDialog(Shell parentShell, String details) {
		openErrorDialog(parentShell, STANDARD_ERROR_TITLE, STANDARD_ERROR_MSG, details);
	}

	/**
	 * ʹ��Ĭ�ϱ������ʾ��Ϣ
	 * @param parentShell
	 * @param message		ֱ����ʾ����ʾ��Ϣ
	 * @param details		��ϸ��Ϣ
	 */
	public static void openErrorDialog(Shell parentShell, String message, String details) {
		openErrorDialog(parentShell, STANDARD_ERROR_TITLE, message, details);
	}

	/**
	 * ��һ��������ʾ��ϸ������Ϣ�ĶԻ���
	 * @param parentShell
	 * @param title
	 * @param message
	 * @param details
	 */
	public static void openErrorDialog(Shell parentShell, String title, String message, String details) {
		if (title == null)
			title = STANDARD_ERROR_TITLE;
		if (message == null)
			message = STANDARD_ERROR_MSG;
		DetailsMessageDialog dialog = new DetailsMessageDialog(parentShell, title, message, details, ERROR);
		dialog.open();
	}

	/**
	 * ����status����Ӧ�ĶԻ���
	 * @param parentShell
	 * @param title
	 * @param message
	 * @param status
	 */
	public static void openErrorDialog(Shell parentShell, String title, String message, IStatus status) {
		String details = getDetailsFromStatus(status);

		if (title == null)
			title = STANDARD_ERROR_TITLE;
		if (message == null)
			message = STANDARD_ERROR_MSG;
		DetailsMessageDialog dialog = new DetailsMessageDialog(parentShell, title, message, details, ERROR);
		dialog.open();
	}

	/**
	 * ��ȡstatus�еľ����쳣��Ϣ
	 * @param status
	 * @return
	 */
	private static String getDetailsFromStatus(IStatus status){

		if(status.isMultiStatus() == false){
			Throwable throwable = status.getException();
			if(null == throwable)
				return status.getMessage();

			if (throwable instanceof CoreException) {
				CoreException coreException = (CoreException) throwable;
				if(null == coreException.getStatus())
					return status.getMessage();

				return getDetailsFromStatus(coreException.getStatus());
			}

			return status.getMessage();
		}

		MultiStatus multiStatus = (MultiStatus) status;
		if(multiStatus.getChildren().length <= 0)
			return status.getMessage();

		StringBuffer details = new StringBuffer();

		for (int i = 0; i < multiStatus.getChildren().length; i++) {
			IStatus element = multiStatus.getChildren()[i];
			details.append(getDetailsFromStatus(element));

			if(i < multiStatus.getChildren().length - 1){
				details.append("\n"); //$NON-NLS-1$
			}
		}

		return details.toString();
	}

	/**
	 *
	 * @param parentShell
	 * @param details
	 */
	public static void openWarnDialog(Shell parentShell, String details) {
		openWarnDialog(parentShell, STANDARD_WARNING_TITLE, STANDARD_WARNING_MSG, details);
	}

	/**
	 * ����ϸ��Ϣ�ľ���Ի���
	 * @param parentShell
	 * @param title
	 * @param message
	 * @param details
	 */
	public static void openWarnDialog(Shell parentShell, String title,
			String message, String details) {
		if (title == null)
			title = STANDARD_WARNING_TITLE;
		if (message == null)
			message = STANDARD_WARNING_MSG;
		DetailsMessageDialog dialog = new DetailsMessageDialog(parentShell, title, message, details, WARN);
		dialog.open();
	}

	/**
	 *
	 * @param parentShell
	 * @param message
	 * @param details
	 */
	public static void openInfoDialog(Shell parentShell, String message, String details) {
		openInfoDialog(parentShell, STANDARD_INFO_TITLE, message, details);
	}

	/**
	 * ����ϸ��Ϣ����ʾ�Ի���
	 * @param parentShell
	 * @param title
	 * @param message
	 * @param details
	 */
	public static void openInfoDialog(Shell parentShell, String title,
			String message, String details) {
		if (title == null)
			title = STANDARD_INFO_TITLE;
		DetailsMessageDialog dialog = new DetailsMessageDialog(parentShell, title, message, details, INFO);
		dialog.open();
	}

	/**
	 * ֻ��һ��ok��ť
	 */
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
	}

	/**
	 * {@inheritDoc}
	 */
	protected void configureShell(Shell shell) {
		super.configureShell(shell);
		shell.setText(this.title);
	}

	/**
	 * {@inheritDoc}
	 */
	protected Control createDialogArea(Composite parent) {
		createMessageArea(parent);//��׼��messageDialog��

		Composite composite = new Composite(parent, 0);
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		composite.setLayout(layout);
		GridData data = new GridData(1808);
		data.horizontalSpan = 2;
		composite.setLayoutData(data);

		createTextBox(composite);
		return composite;
	}

	/**
	 * ������ʾ��ϸ��Ϣ���ı���
	 * @param parent
	 */
	private void createTextBox(Composite parent) {
		int style = 2634;
		this.textBox = new Text(parent, style);
		GridData gridData = new GridData(1808);
		gridData.heightHint = 140;
		gridData.widthHint = 100;
		gridData.horizontalSpan = 2;
		this.textBox.setLayoutData(gridData);
		this.textBox.addTraverseListener(new TraverseListener() {

			public void keyTraversed(TraverseEvent e) {
				if (e.detail == SWT.TRAVERSE_TAB_NEXT)
					e.doit = true;
			}

		});
		this.textBox.setText(this.details);
	}

	protected Image getImage() {
		if (this.type == INFO)
			return getInfoImage();
		if (this.type == WARN)
			return getWarningImage();
		else
			return getErrorImage();
	}
}
