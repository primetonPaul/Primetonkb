/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.context;

import java.util.HashMap;
import java.util.Map;

import com.primeton.studio.core.IValueRepository;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * IValueRepository��Ĭ��ʵ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The default implementaion for "IValueRepository".<BR>
 * <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-9-21 ����02:22:42
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: DefaultValueRepository.java,v $
 * Revision 1.2  2011/06/02 07:11:12  yujie
 * Update:ui��ܲ���ύ
 *
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/04/25 05:32:58  zhuxing
 * Update:�����ӿڷ���
 *
 * Revision 1.2  2008/03/03 01:56:43  zhuxing
 * Update:�������������ݽṹ(������������)
 *
 * Revision 1.1  2008/02/15 09:03:59  wanglei
 * Review:��DefaultValueRepository�Ƶ�com.primeton.studio.ui.context�����档
 *
 * Revision 1.6  2007/04/13 03:10:23  wanglei
 * Add:������Adapter�Ĺ��ܡ�
 *
 * Revision 1.5  2007/04/12 02:38:10  wanglei
 * Refactor:����IValueRepositor�������ع���
 *
 * Revision 1.4  2007/03/05 06:06:35  wanglei
 * �ύ��CVS
 *
 */
public class DefaultValueRepository extends HashMap implements IValueRepository
{
	/**
	 * parent value repository.
	 */
	private IValueRepository parent;

	/**
	 * sub value repositoty map.
	 */
	private Map<String, IValueRepository> subRepositories = new HashMap<String, IValueRepository>(); 
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public DefaultValueRepository()
	{
		super();
	}

	/**
	 * 
	 * @param parentRepository   parent value repository.
	 */
	public DefaultValueRepository(IValueRepository parentRepository) {
		this.parent = parentRepository;
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.core.IValueRepository#getParentRepository()
	 */
	public IValueRepository getParentRepository() {
		return this.parent;
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.core.IValueRepository#appendSubRepository(java.lang.String, com.primeton.studio.core.IValueRepository)
	 */
	public IValueRepository createSubRepository(String id) {
		IValueRepository repository = this.subRepositories.get(id);
		
		if (null == repository) {
			repository = new DefaultValueRepository();
			this.subRepositories.put(id, repository);
		}
		
		return repository;
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.core.IValueRepository#getSubRepository(java.lang.String)
	 */
	public IValueRepository getSubRepository(String id) {
		return this.subRepositories.get(id);
	}
	
	/* (non-Javadoc)
	 * @see com.primeton.studio.core.IValueRepository#getSubRepositories()
	 */
	public IValueRepository[] getSubRepositories() {
		IValueRepository[] subRepositories = new IValueRepository[this.subRepositories.values().size()];
		return this.subRepositories.values().toArray(subRepositories);
	}
	
	/**
	 *
	 * {@inheritDoc}
	 */
	public Object getAdapter(Class r_Class)
	{
		if (null == r_Class)
		{
			return null;
		}

		if (IValueRepository.class.isAssignableFrom(r_Class))
		{
			return this;
		}

//		if(IWorkspaceRoot.class==r_Class)
//		{
//			return ResourcesPlugin.getWorkspace().getRoot();
//		}

//		if(IWorkspace.class==r_Class)
//		{
//			return ResourcesPlugin.getWorkspace();
//		}

		return null;
	}

}
