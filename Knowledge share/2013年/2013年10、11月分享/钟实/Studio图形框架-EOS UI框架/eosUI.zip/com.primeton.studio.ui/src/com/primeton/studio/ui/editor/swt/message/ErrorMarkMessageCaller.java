/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.editor.swt.message;

import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jface.fieldassist.FieldDecoration;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.core.IBuildable;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.util.PropertiesUtil;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����ֱ���ڿؼ�����ʾ������Ϣ<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Show message on the control. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-12-20 ����02:07:00
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ErrorMarkMessageCaller.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/02/20 12:01:09  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.5  2007/04/09 01:18:23  wanglei
 * UnitTest:�����˿ؼ���ʾ�����־ʱ��λ���ƶ���һ��Bug��
 *
 * Revision 1.4  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */
public final class ErrorMarkMessageCaller implements IMessageCaller, IBuildable
{
	private AbstractPropertyEditor propertyEditor;

	private boolean hasError = false;

	/**
	 * @param r_PropertyEditor
	 */
	public ErrorMarkMessageCaller(AbstractPropertyEditor r_PropertyEditor)
	{
		super();
		this.propertyEditor = r_PropertyEditor;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#clear()
	 */
	public void clear()
	{
		this.hasError = false;

		this.propertyEditor.getDecoratedField().hideDecoration(this.propertyEditor.getWarnFieldDecoration());
		this.propertyEditor.getDecoratedField().hideDecoration(this.propertyEditor.getErrorFieldDecoration());
		// this.propertyEditor.getDecoratedField().hideDecoration(this.propertyEditor.getAssitantFieldDecoration());
		this.propertyEditor.getDecoratedField().hideHover();

		// if ((null != this.propertyEditor.getAssitantHelper()) && (this.propertyEditor.getEditorControl() ==
		// Display.getCurrent().getFocusControl()))
		// {
		// FieldDecoration t_FieldDecoration = this.propertyEditor.getAssitantFieldDecoration();
		// this.propertyEditor.getDecoratedField().addFieldDecoration(t_FieldDecoration, SWT.TOP | SWT.LEFT, false);
		// this.propertyEditor.getDecoratedField().showDecoration(t_FieldDecoration);
		// }
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#error(java.lang.String)
	 */
	public void error(String r_Message, Properties r_Properties)
	{
		FieldDecoration t_FieldDecoration = this.propertyEditor.getErrorFieldDecoration();
		t_FieldDecoration.setDescription(r_Message + PropertiesUtil.toString(r_Properties));
		this.propertyEditor.getDecoratedField().showDecoration(t_FieldDecoration);

		this.hasError = true;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#hasError()
	 */
	public boolean hasError()
	{
		return this.hasError;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#info(java.lang.String)
	 */
	public void info(String r_Message, Properties r_Properties)
	{
		if (null != r_Message)
		{
			Control t_EditorControl = this.propertyEditor.getEditorControl();
			if (null != t_EditorControl)
			{
				t_EditorControl.setToolTipText(r_Message + PropertiesUtil.toString(r_Properties));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#warn(java.lang.String)
	 */
	public void warn(String r_Message, Properties r_Properties)
	{
		FieldDecoration t_FieldDecoration = this.propertyEditor.getWarnFieldDecoration();
		t_FieldDecoration.setDescription(r_Message + PropertiesUtil.toString(r_Properties));
		this.propertyEditor.getDecoratedField().showDecoration(t_FieldDecoration);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IBuildable#build()
	 */
	public void build()
	{
		final FieldDecoration t_FieldDecoration = this.propertyEditor.getErrorFieldDecoration();
		this.propertyEditor.getDecoratedField().addFieldDecoration(t_FieldDecoration, SWT.TOP | SWT.LEFT, false);
		this.propertyEditor.getDecoratedField().hideDecoration(t_FieldDecoration);

		if (null != this.propertyEditor.getEditorControl())
		{
			this.propertyEditor.getEditorControl().addFocusListener(new FocusAdapter()
			{

				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.FocusAdapter#focusGained(org.eclipse.swt.events.FocusEvent)
				 */
				public void focusGained(FocusEvent r_Event)
				{
					AbstractPropertyEditor t_PropertyEditor = ErrorMarkMessageCaller.this.propertyEditor;

					if ((t_PropertyEditor.isAutoHover()) && (t_PropertyEditor.getEditorControl().isFocusControl()))
					{
						if (StringUtils.isNotEmpty(t_FieldDecoration.getDescription()))
						{
							t_PropertyEditor.getDecoratedField().showHoverText(t_FieldDecoration.getDescription());
						}
					}
				}

				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.FocusAdapter#focusLost(org.eclipse.swt.events.FocusEvent)
				 */
				public void focusLost(FocusEvent r_Event)
				{
					ErrorMarkMessageCaller.this.propertyEditor.getDecoratedField().hideHover();
				}

			});

			this.propertyEditor.getEditorControl().addMouseTrackListener(new MouseTrackAdapter()
			{

				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.MouseTrackAdapter#mouseExit(org.eclipse.swt.events.MouseEvent)
				 */
				public void mouseExit(MouseEvent r_Event)
				{
					ErrorMarkMessageCaller.this.propertyEditor.getDecoratedField().hideHover();
				}

			});
		}

	}

}
