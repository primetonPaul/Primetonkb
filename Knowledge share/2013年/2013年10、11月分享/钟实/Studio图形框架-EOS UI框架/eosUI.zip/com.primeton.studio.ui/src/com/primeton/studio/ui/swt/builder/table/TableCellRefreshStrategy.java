/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.table;


/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����ˢ�»�����֤�Ĳ���<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The strategy to refresh or validate table cell. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-2-21 ����10:15:13
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: TableCellRefreshStrategy.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/21 02:17:32  wanglei
 * Add:�ύ��CVS��
 *
 */

public class TableCellRefreshStrategy
{
	private boolean refreshRow = false;

	private boolean refreshColumn = false;

	private boolean refreshAll = false;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public TableCellRefreshStrategy()
	{
		super();
	}

	/**
	 *
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param r_Strategy
	 */
	public TableCellRefreshStrategy(TableCellRefreshStrategy r_Strategy)
	{
		this.refreshRow = r_Strategy.refreshRow;
		this.refreshColumn = r_Strategy.refreshColumn;
		this.refreshAll = r_Strategy.refreshAll;
	}

	/**
	 * @return the refreshAll
	 */
	public boolean isRefreshAll()
	{
		return this.refreshAll;
	}

	/**
	 * @param r_RefreshAll
	 *            the refreshAll to set
	 */
	public void setRefreshAll(boolean r_RefreshAll)
	{
		this.refreshAll = r_RefreshAll;
	}

	/**
	 * @return the refreshColumn
	 */
	public boolean isRefreshColumn()
	{
		return this.refreshColumn;
	}

	/**
	 * @param r_RefreshColumn
	 *            the refreshColumn to set
	 */
	public void setRefreshColumn(boolean r_RefreshColumn)
	{
		this.refreshColumn = r_RefreshColumn;
	}

	/**
	 * @return the refreshRow
	 */
	public boolean isRefreshRow()
	{
		return this.refreshRow;
	}

	/**
	 * @param r_RefreshRow
	 *            the refreshRow to set
	 */
	public void setRefreshRow(boolean r_RefreshRow)
	{
		this.refreshRow = r_RefreshRow;
	}

}
