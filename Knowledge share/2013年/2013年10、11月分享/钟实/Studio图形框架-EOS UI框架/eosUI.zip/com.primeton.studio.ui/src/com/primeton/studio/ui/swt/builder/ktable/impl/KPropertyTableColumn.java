/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.swt.builder.ktable.impl;

import org.apache.commons.lang.StringUtils;
import org.eclipse.swt.graphics.Color;

import com.primeton.studio.swt.ITextLengthProvider;
import com.primeton.studio.ui.activator.UIActivator;
import com.primeton.studio.ui.swt.builder.ktable.IKEditorFactory;
import com.primeton.studio.ui.swt.builder.ktable.IKRendererFactory;
import com.primeton.studio.ui.swt.builder.ktable.IKTableColumn;
import com.primeton.studio.ui.swt.builder.ktable.impl.factory.KPropertyEditorFactory;
import com.primeton.studio.ui.swt.builder.ktable.impl.factory.KPropertyRendererFactory;
import com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn;

import de.kupzog.ktable.KTableCellEditor;
import de.kupzog.ktable.KTableCellRenderer;
import de.kupzog.ktable.renderers.DefaultCellRenderer;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ������������ͨ��property�����ʶ���<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * This table column access the object by the property. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-7-15 ����12:31:55
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: KPropertyTableColumn.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.13  2008/04/17 09:53:23  wanglei
 * Update:֧�ֶԱ������ı���Ԫ��༭ʱ�ĳ������ơ�
 *
 * Revision 1.12  2008/04/17 08:44:46  wanglei
 * Update:֧�ֶԱ������ı���Ԫ��༭ʱ�ĳ������ơ�
 *
 * Revision 1.11  2008/02/20 09:08:52  wanglei
 * Update:��SignConstant�еĳ����Ƶ���ǰ���С�
 *
 * Revision 1.10  2007/09/12 02:50:39  wanglei
 * Review:֧�������С�п��Ķ��ƣ�������ֽ����϶�ʧ�������
 *
 * Revision 1.9  2007/07/26 06:14:05  wanglei
 * Review:������ͼ���ƣ�ʹ֮���Ի��档
 *
 * Revision 1.8  2007/05/30 02:09:48  wanglei
 * UnitTest:����KTextCellRenderer��tableColumn�ⲿ����ʱ����Ϊnull��Bug��
 *
 * Revision 1.7  2007/05/22 01:14:08  wanglei
 * Add:֧�ֱ��񱳾�ɫ��ǰ��ɫ��
 *
 * Revision 1.6  2007/04/28 02:26:47  wanglei
 * UnitTest:ȡֵʱ�����ٷ���""�ַ������Ƿ���null��
 *
 * Revision 1.5  2007/04/24 07:52:49  wanglei
 * Add:Ϊ��������������ӳ�书�ܣ��������Ե�����ʾ�ı���
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */
public class KPropertyTableColumn extends AbstractTableColumn implements IKTableColumn  , ITextLengthProvider
{
	private int maxLength=UIActivator.getDefaultMaxTableTextLength();

	public static final String DESC = "��";

	public static final String ASC = "��";

	public static final int SortNone = 1 << 1;

	public static final int SortAsc = 1 << 2;

	public static final int SortDesc = 1 << 3;

	private IKEditorFactory editFactory = new KPropertyEditorFactory();

	private IKRendererFactory rendererFactory = new KPropertyRendererFactory();

	private transient KTableCellEditor cellEditor;

	private boolean singleton = false;

	private boolean supportActive = true;

	private boolean warp = false;

	private Color background;

	private Color foreground;

	private int minWidth;

	private int maxWidth;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public KPropertyTableColumn()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.ktable.IKTableColumn#getCellEditor(java.lang.Object, int, int)
	 */
	public KTableCellEditor getCellEditor(Object r_Element, int r_Column, int r_Row)
	{
		if (!this.isEditable())
		{
			return null;
		}

		if (null != this.cellEditor && this.singleton)
		{
			return this.cellEditor;
		}

		if (null != this.editFactory)
		{
			this.cellEditor = this.editFactory.createEditor(this, r_Element, r_Column, r_Row);
			return this.cellEditor;
		}
		else
		{
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.ktable.IKTableColumn#getCellRenderer(java.lang.Object, int, int)
	 */
	public KTableCellRenderer getCellRenderer(Object r_Element, int r_Column, int r_Row)
	{
		if (null != this.rendererFactory)
		{
			return this.rendererFactory.createRenderer(this,r_Element, r_Column, r_Row);
		}
		else
		{
			return new KTextCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn#setPropertyName(java.lang.String)
	 */
	public void setPropertyName(String r_PropertyName)
	{
		if (this.editFactory instanceof KPropertyEditorFactory)
		{
			((KPropertyEditorFactory) this.editFactory).setPropertyName(r_PropertyName);
		}

		if (this.rendererFactory instanceof KPropertyRendererFactory)
		{
			((KPropertyRendererFactory) this.rendererFactory).setPropertyName(r_PropertyName);
		}

		super.setPropertyName(r_PropertyName);
	}

	/**
	 * ����Editor�Ĵ���������<BR>
	 *
	 * Return the factory for editor.<BR>
	 *
	 */
	public IKEditorFactory getEditFactory()
	{
		return this.editFactory;
	}

	/**
	 * ����Editor�Ĵ���������<BR>
	 *
	 * Set the factory for editor.<BR>
	 *
	 * @param r_EditFactory
	 *            Set editFactory��
	 */
	public void setEditFactory(IKEditorFactory r_EditFactory)
	{
		this.editFactory = r_EditFactory;
	}

	/**
	 * ����Renderer�Ĵ���������<BR>
	 *
	 * Return the factory for Renderer.<BR>
	 *
	 */
	public IKRendererFactory getRendererFactory()
	{
		return this.rendererFactory;
	}

	/**
	 * ����Renderer�Ĵ���������<BR>
	 *
	 * Set the factory for Renderer.<BR>
	 *
	 * @param r_RendererFactory
	 *            Set rendererFactory��
	 */
	public void setRendererFactory(IKRendererFactory r_RendererFactory)
	{
		this.rendererFactory = r_RendererFactory;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn#setSortState(int)
	 */
	public void setSortState(int r_SortState)
	{
		super.setSortState(r_SortState);

		if (super.getTitle().endsWith(ASC) || super.getTitle().endsWith(DESC))
		{
			super.setTitle(super.getTitle().substring(0, super.getTitle().length() - 1));
		}
		if (SortAsc == this.getSortState())
		{
			super.setTitle(super.getTitle() + ASC);
		}

		if (SortDesc == this.getSortState())
		{
			super.setTitle(super.getTitle() + DESC);
		}
	}

	/**
	 * �Ƿ�ʹ��Singleton��ʽ���������Դ�Ƿ�Ψһ�����̰߳�ȫ������£����Խ�ʡ��Դ�����Ч�ʡ�<BR>
	 *
	 * Return whether using singleton to keep the resource singleton.<BR>
	 * In the condition of thread-safe,it can improve the performance.<BR>
	 *
	 */
	public boolean isSingleton()
	{
		return this.singleton;
	}

	/**
	 * ����ʹ��Singleton��ʽ���������Դ�Ƿ�Ψһ�����̰߳�ȫ������£����Խ�ʡ��Դ�����Ч�ʡ�<BR>
	 *
	 * Set whether using singleton to keep the resource singleton.<BR>
	 * In the condition of thread-safe,it can improve the performance.<BR>
	 *
	 * @param r_Singleton
	 *            Set singleton��
	 */
	public void setSingleton(boolean r_Singleton)
	{
		this.singleton = r_Singleton;
	}

	/**
	 * �����Ƿ�֧���Զ�����ܡ�<BR>
	 * ���ֵ��Ϊ<code>true</code>�����Ҹ�Ԫ�������༭������굥���¼��Ϳ��Լ���༭�����б༭ָ������<BR>
	 *
	 * Set whether the editor support active-editing or not.<BR>
	 * If the parameter value is <code>true</code> and the element is editable,the mouse-click will activate the
	 * editor.<BR>
	 *
	 * @param r_SupportActive
	 *            Set supportActive��
	 */
	public void setSupportActive(boolean r_SupportActive)
	{
		this.supportActive = r_SupportActive;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.ktable.IKTableColumn#isSupportActive(java.lang.Object)
	 */
	public boolean isSupportActive(Object r_Value)
	{
		return this.supportActive && (!(r_Value instanceof Boolean));
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.model.base.AbstractTableColumn#doClone()
	 */
	public AbstractTableColumn doClone()
	{
		KPropertyTableColumn t_Column = new KPropertyTableColumn();

		t_Column.editFactory = (IKEditorFactory) this.editFactory.clone();
		t_Column.rendererFactory = (IKRendererFactory) this.rendererFactory.clone();
		t_Column.singleton = this.singleton;
		t_Column.supportActive = this.supportActive;
		t_Column.warp = this.warp;

		return t_Column;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.ktable.IKTableColumn#getContent(java.lang.Object, int, int)
	 */
	public Object getContent(Object r_Element, int r_Column, int r_Row)
	{
		if (StringUtils.isEmpty(this.getPropertyName()))
		{
			return null;
		}

		Object t_Object = this.getIntrospector(r_Element).getValue(r_Element, getPropertyName());

		if (null == t_Object)
		{
			return null;
		}

		if (t_Object instanceof String)
		{
			return this.doWrap((String) t_Object);
		}

		return t_Object;
	}

	/**
	 * ��һ���ַ����е�tab�ͻ��з��û��ɿա�<BR>
	 *
	 * Replace the tab and enter character by "".<BR>
	 *
	 * @param r_Text
	 *            the text to be wraped.
	 * @return the wraped text.
	 */
	protected String doWrap(String r_Text)
	{
		if (null == r_Text)
		{
			return " ";
		}

		if (this.isWarp())
		{
			String t_Text = StringUtils.replace(r_Text, "\r", "");
			t_Text = StringUtils.replace(t_Text, "\t", "");
			t_Text = StringUtils.replace(t_Text, "\n", "");

			return t_Text;
		}
		else
		{
			return r_Text;
		}
	}

	/**
	 * �����Ƿ��С�<BR>
	 *
	 * Return whether warp the string or not.<BR>
	 *
	 */
	public final boolean isWarp()
	{
		return this.warp;
	}

	/**
	 * �����Ƿ��С�<BR>
	 *
	 * Set whether warp the string or not.<BR>
	 *
	 * @param r_Warp
	 *            The warp to set.
	 */
	public final void setWarp(boolean r_Warp)
	{
		this.warp = r_Warp;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.ktable.IKTableColumn#setContent(java.lang.Object, int, int, java.lang.Object)
	 */
	public void setContent(Object r_Element, int r_Column, int r_Row, Object r_Value)
	{
		if (this.isEditable())
		{
			try
			{
				this.getIntrospector(r_Element).setValue(r_Element, getPropertyName(), r_Value);
			}
			catch (Exception e)
			{
				// Nothing to do
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Color getBackground(Object r_Element, int r_Column, int r_Row)
	{
		return this.background;
	}

	/**
	 * {@inheritDoc}
	 */
	public Color getForeground(Object r_Element, int r_Column, int r_Row)
	{
		return this.foreground;
	}

	/**
	 * @param r_Background the background to set
	 */
	public void setBackground(Color r_Background)
	{
		this.background = r_Background;
	}

	/**
	 * @param r_Foreground the foreground to set
	 */
	public void setForeground(Color r_Foreground)
	{
		this.foreground = r_Foreground;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getMinWidth() {
		return this.minWidth;
	}

	/**
	 * ������С���ȡ�<BR>
	 *
	 * Set the min width for the column.<BR>
	 *
	 * @param r_MinWidth
	 * @return
	 */
	public void setMinWidth(int r_MinWidth) {
		this.minWidth = r_MinWidth;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getMaxWidth() {
		return this.maxWidth;
	}

	/**
	 * ���������ȡ�<BR>
	 *
	 * Set the max width for the column.<BR>
	 *
	 * @param r_MaxWidth
	 * @return
	 */
	public void setMaxWidth(int r_MaxWidth) {
		this.maxWidth = r_MaxWidth;
	}

	/**
	 *
	 * {@inheritDoc}
	 */
	public int getMaxLength()
	{
		return this.maxLength;
	}

	/**
	 * @param maxLength The maxLength to set.
	 */
	public void setMaxLength(int maxLength)
	{
		this.maxLength = maxLength;
	}
}
