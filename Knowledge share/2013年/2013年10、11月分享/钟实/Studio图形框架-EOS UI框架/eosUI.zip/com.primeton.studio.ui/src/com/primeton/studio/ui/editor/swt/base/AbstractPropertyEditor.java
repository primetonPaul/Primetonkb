/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.editor.swt.base;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.set.ListOrderedSet;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.fieldassist.DecoratedField;
import org.eclipse.jface.fieldassist.FieldDecoration;
import org.eclipse.jface.fieldassist.FieldDecorationRegistry;
import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.primeton.studio.core.IMemento;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValidateListener;
import com.primeton.studio.core.IValidator;
import com.primeton.studio.core.IValueChangeListener;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.base.AbstractPropertyAccessor;
import com.primeton.studio.core.event.Event;
import com.primeton.studio.core.event.ValidateEvent;
import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.core.impl.DefaultValueChangeContainer;
import com.primeton.studio.core.impl.PropertyMemnto;
import com.primeton.studio.swt.util.LayoutUtil;
import com.primeton.studio.swt.util.SwtResourceUtil;
import com.primeton.studio.ui.ResourceMessages;
import com.primeton.studio.ui.editor.ILabelCustomized;
import com.primeton.studio.ui.editor.ILayoutDataBuilder;
import com.primeton.studio.ui.editor.IPropertyContextHelper;
import com.primeton.studio.ui.editor.IPropertyEditor;
import com.primeton.studio.ui.editor.ObjectEditor;
import com.primeton.studio.ui.editor.swt.impl.DefaultPropertyContextHelper;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;
import com.primeton.studio.ui.editor.swt.message.ErrorMarkMessageCaller;
import com.primeton.studio.ui.swt.helper.HelperRegistry;
import com.primeton.studio.ui.swt.helper.IAssitantHelper;
import com.primeton.studio.ui.swt.helper.IHelpContext;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �ṩ�����Ա༭����һ������ʵ��<BR>
 * ��Ҫ��һЩProperty��ʵ�� <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * A basic implemention for property editor.<BR>
 * It provide some property <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.6  2008/12/23 08:29:40  lvyuan
 * Update:�����ع�
 *
 * Revision 1.5  2008/10/20 08:32:18  liu-jun
 * JIRA:EOS-2674 ��5�汾һ������Alt+/��ʾ�ģ���Ԫ��ǰ��Ҫ��С���ݱ�ʾ commit by yangmd
 *
 * Revision 1.4  2008/07/31 09:53:20  yanfei
 * Update:10699 [�߼���][ҳ����]�߼���ҳ�����з�����õ�Ӧ�����ƴ��������ַ�ʱ���治��
 *
 * Revision 1.3  2008/07/25 09:17:24  wanglei
 * Update:����֧�ִ����ǡ�
 *
 * Revision 1.2  2008/07/15 08:02:59  yangmd
 * Update:�޸ļ���final���������������ء�
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.21  2008/06/04 08:36:02  wanglei
 * Update:֧�ֱ����������ݣ����������ݸı�ʱ������Ӧ�ļ�������
 *
 * Revision 1.19  2008/04/21 04:35:11  zhuxing
 * Update:refactoring, extract label customized interface
 *
 * Revision 1.18  2008/04/08 08:26:39  chenxp
 * Update:��updateViewMode������private��Ϊprotected,�Ա���������
 *
 * Revision 1.17  2008/04/08 04:28:31  yujl
 * update��ȷ��ÿ�ζ�����valueChange
 *
 * Revision 1.16  2008/04/07 13:18:35  yujl
 * CodeReview�����ӷ����������������ж��Ƿ�ʹ����֤���ͼ�����
 *
 * Revision 1.15  2008/03/13 07:23:04  wanglei
 * Update:֧���ڿؼ�ǰ�����Mark��
 *
 * Revision 1.14  2008/03/07 06:04:19  wanglei
 * Review:������������ʱ,��ͬ���ݲ�������Ϣ�Ĵ�����ʽ��
 *
 * Revision 1.13  2008/03/06 09:54:28  yangmd
 * Update:�޸����ڿؼ����ٵ��Ժ���ȥgetvalue���������bug
 *
 * Revision 1.12  2008/03/06 09:45:07  wanglei
 * Review:������KTableBuilderһЩ����ϵĲ��㡣
 *
 * Revision 1.11  2008/03/05 09:11:24  wanglei
 * UnitTest:��������ʱ����ȥ����ע�ʹ��롣
 *
 * Revision 1.10  2008/03/05 05:27:59  wanglei
 * Review:�������룬���⸴��ʱ�������⡣
 *
 * Revision 1.9  2008/03/05 02:27:49  wanglei
 * UnitTest:����setValueʱ������ѭ����Bug��
 *
 * Revision 1.8  2008/03/03 07:44:36  wanglei
 * Review:�ع�AbstractPropertyEditor����ȥ��doFullValidate����������֮�Է��¼��ķ�ʽ��
 *
 * Revision 1.7  2008/02/29 02:59:22  wanglei
 * Update:����isEnable������
 *
 * Revision 1.6  2008/02/28 09:13:16  yangmd
 * Update:ʹ��UI�߳̽�������ֵ����������̳߳�ͻ���´����bug
 *
 * Revision 1.5  2008/02/27 08:57:57  wanglei
 * Update:����UI��ܵ��ع����е�����
 *
 * Revision 1.4  2008/02/26 06:34:27  wanglei
 * Update:����UI��ܺ���ʱ����һЩ����������������⻹�ܶ࣬����������
 *
 * Revision 1.3  2008/02/25 09:20:23  wanglei
 * Review:ΪIValidable��validate��������IMessageCaller��Event����������
 *
 * Revision 1.2  2008/02/22 08:51:21  wanglei
 * Review:�����¼�֪ͨ���ơ�
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.25  2008/02/15 09:46:43  wanglei
 * Review:��Դ��messages�����Ƶ������棬���������һ�¡�
 *
 * Revision 1.24  2008/02/14 08:19:32  yangmd
 * Update:�޸�һ������
 *
 * Revision 1.23  2008/02/01 05:07:36  wanglei
 * Update:�������û�б��࣬�Ͳ��ᷢ�͸ı��¼���
 *
 * Revision 1.22  2008/01/16 08:20:00  wanglei
 * Update:֧��ֵ�ı�ʱҲ������֤��
 *
 * Revision 1.21  2008/01/14 01:22:35  wanglei
 * Add:��������֤��صķ�����
 *
 * Revision 1.20  2008/01/07 12:18:45  yangmd
 * Update:ȥ��checkDirty�����if�жϡ�
 *
 * Revision 1.19  2007/11/02 02:06:32  wanglei
 * Review:�����̳�checkDirty������
 *
 * Revision 1.18  2007/10/30 06:28:43  wanglei
 * Review:�ڱ���ǰ��Ӧ����֤�������֤��ͨ�����Ͳ����档
 *
 * Revision 1.17  2007/10/30 06:23:44  wanglei
 * Review:���¼��Ŀ����Ƶ������У��Ա��������ͨ�á�
 *
 * Revision 1.16  2007/09/29 08:55:05  yanfei
 * Review:�޸�����֤�����ϱ�������Set�ĳ�ListOrderedSet���Ա㰴���ӵ�˳���������
 *
 * Revision 1.15  2007/08/30 02:08:59  wanglei
 * UnitTest:�����޷���ȷ����enable��Bug��
 *
 * Revision 1.14  2007/06/19 01:50:18  wanglei
 * UnitTest:������setEnable��Bug��
 *
 * Revision 1.13  2007/05/22 01:08:50  wanglei
 * Update:��requiredĬ��ֵ�ĳ�false��
 *
 * Revision 1.12  2007/05/18 03:52:54  zhangzh
 * updata:�����˷���ﶨ��bug
 *
 * Revision 1.11  2007/05/17 06:44:47  wanglei
 * Refactor:��requiredĬ��ֵ��Ϊfalse
 *
 * Revision 1.10  2007/04/16 02:58:37  wanglei
 * UnitTest:�������ڲ����ʵ�ʱ�����ErrorEclipseMarkMessageCaller���ֵ��쳣��
 *
 * Revision 1.9  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */
public abstract class AbstractPropertyEditor extends AbstractPropertyAccessor implements IPropertyEditor, ILabelCustomized {
	/**
	 * Validation strategy constant (value <code>0</code>) indicating that the editor should perform validation after
	 * every key stroke.
	 *
	 * @see #setValidateStrategy
	 */
	public static final int VALIDATE_ON_FOCUS_GAIN = 1 << 1;

	/**
	 * Validation strategy constant (value <code>0</code>) indicating that the editor should perform validation after
	 * every key stroke.
	 *
	 * @see #setValidateStrategy
	 */
	public static final int VALIDATE_ON_FOCUS_LOST = 1 << 2;

	/**
	 * Validation strategy constant (value <code>1</code>) indicating that the editor should perform validation only
	 * when the text widget loses focus.
	 *
	 * @see #setValidateStrategy
	 */
	public static final int VALIDATE_ON_KEY_STROKE = 1 << 3;

	/**
	 * Validation strategy constant (value <code>1</code>) indicating that the editor should perform validation only
	 * when the text widget loses focus.
	 *
	 * @see #setValidateStrategy
	 */
	public static final int VALIDATE_ON_VALUE_CHANGE = 1 << 4;

	protected String label;

	// ��ǰ�ֶ���ʾ�ı�ǩ

	private int order;

	// ��ʾ��˳��

	private String toolTip;

	// ��ʾ����ʾ

	private boolean readonly = false;

	// ��ǰ�ؼ��Ƿ�ֻ��

	private boolean important = false;

	private boolean eagerSave = false;

	private boolean visible = true;

	// ��ǰ�ؼ��Ƿ�����

	private boolean enable = true;

	// ��ǰ�ؼ��Ƿ���������

	private boolean required = false;

	// ��ǰ�ؼ��Ƿ������д����

	private boolean markable = true;

	// �Ƿ�����ֱ���ڿؼ���ʹ�ô����־��

	private boolean autoHover = true;

	// �Ƿ�����ֱ���ڿؼ��ϸ���������ʾ��
	// ��Set�ĳ�ListOrderedSet���Ա㰴���ӵ�˳��������� modify by 20070929
	private ListOrderedSet validators = new ListOrderedSet();

	// ��֤��

	DefaultValueChangeContainer valueChangeContainer = new DefaultValueChangeContainer();

	private transient DecoratedField decoratedField;

	private transient IControlCreator controlCreator;

	private transient Control editorControl;

	private transient Control layoutControl;

	private transient Label labelControl;

	// ʵ�ʵĿؼ�

	private IAssitantHelper assitantHelper;

	private transient IAdaptable parentAdapter;

	// ��һ����Adapter

	private String bindingName;

	// ��ֵ
	private String reverseBindingName;

	// �����ֵ
	protected ILayoutDataBuilder layoutDataBuilder;

	private boolean viewMode;

	// ��ǰ�Ƿ�Ϊ�鿴ģʽ
	private ErrorMarkMessageCaller errorMarkMessageCaller;

	// �����ڿؼ�����ʾ������Ϣ��

	private FieldDecoration requiredFieldDecoration;

	// �����ڿؼ�����ʾ'*'����ʾ����

	private FieldDecoration warnFieldDecoration;

	// �����ڿؼ�����ʾ������Ϣ

	private FieldDecoration errorFieldDecoration;

	// �����ڿؼ�����ʾ������Ϣ

	private FieldDecoration assitantFieldDecoration;

	// �����ڿؼ�����ʾ������ʾ��Ϣ

	private boolean useLabel = true;

	private IHelpContext[] helpContexts;

	private IPropertyContextHelper contextHelper;

	private FocusListener listener = new FocusListener() {
		/*
		 * (non-Javadoc)
		 *
		 * @see org.eclipse.swt.events.FocusListener#focusGained(org.eclipse.swt.events.FocusEvent)
		 */
		public void focusGained(FocusEvent r_Event) {
			if (null != getAssitantHelper()) {
				getDecoratedField().addFieldDecoration(getAssitantFieldDecoration(), SWT.TOP | SWT.LEFT, false);
				getDecoratedField().showDecoration(getAssitantFieldDecoration());
			}
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see org.eclipse.swt.events.FocusListener#focusLost(org.eclipse.swt.events.FocusEvent)
		 */
		public void focusLost(FocusEvent r_Event) {
			if (null != getAssitantHelper()) {
				getDecoratedField().hideDecoration(getAssitantFieldDecoration());
			}
		}
	};
	
	private transient boolean dirty;

	private transient Object lastValue;
	//�ɱ༭�ؼ�����
	private static final List canAssisantHelpControls = new ArrayList();
	static{
		canAssisantHelpControls.clear();
		canAssisantHelpControls.add(Text.class);
		canAssisantHelpControls.add(StyledText.class);
		canAssisantHelpControls.add(Combo.class);
	}
	/**
	 * Ĭ������£���ʧȥ����ʱ����������֤<BR>
	 * The default vlidate strategy is focus_lost<BR>
	 */
	private int validateStrategy = VALIDATE_ON_FOCUS_LOST | VALIDATE_ON_KEY_STROKE | VALIDATE_ON_VALUE_CHANGE;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public AbstractPropertyEditor() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#doAddValidator(com.primeton.studio.ui.editor.IValidator)
	 */
	public void doAddValidator(IValidator r_Validator) {
		if (null != r_Validator) {
			this.validators.add(r_Validator);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#doRemoveValidator(com.primeton.studio.ui.editor.IValidator)
	 */
	public void doRemoveValidator(IValidator r_Validator) {
		if (null != r_Validator) {
			this.validators.remove(r_Validator);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#doClearValidators()
	 */
	public void doClearValidators() {
		this.validators.clear();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#getValidator()
	 */
	public IValidator[] getValidator() {
		IValidator[] t_Validators = new IValidator[this.validators.size()];
		this.validators.toArray(t_Validators);
		return t_Validators;
	}

	/**
	 * �����ڲ���̬���ɵ�Swt Control<BR>
	 *
	 * Return the editorControl for editing<BR>
	 *
	 */
	public final Control getEditorControl() {
		return this.editorControl;
	}

	/**
	 * ������Ҫ���в��ִ�����SWT Control<BR>
	 *
	 * Return the control for being layouted.<BR>
	 *
	 * @return
	 */
	public Control getLayoutControl() {
		return this.layoutControl;
	}

	/**
	 * ���ر�ǩ�ؼ���<BR>
	 *
	 * Return the label Control.
	 *
	 */
	public Control getLabelControl() {
		return this.labelControl;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#build(com.primeton.studio.core.IAdapter)
	 */
	public final void build(IAdaptable r_Adaptable, boolean r_Important) {
		this.parentAdapter = r_Adaptable;
		if (null != r_Adaptable) {
			Composite t_Composite = (Composite) r_Adaptable.getAdapter(Composite.class);
			this.buildEditorControl(t_Composite, r_Adaptable);
			this.getLayoutDataBuilder().doLayout(this);
		}

		if (this.isMarkable()) {
			this.errorMarkMessageCaller = new ErrorMarkMessageCaller(this);
		}

		if (this.isImportant() && r_Important) {
			this.editorControl.setEnabled(false);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#beforeBuild(com.primeton.studio.core.IAdapter)
	 */
	public void beforeBuild(IAdaptable r_Adaptable) {
		// Nothing to do
	}

	/**
	 * ������Ӧ�ı�ǩ��<BR>
	 *
	 * Create a label for the current property editor.<BR>
	 *
	 * @param r_Parent
	 * @param r_Adaptable
	 * @return
	 */
	protected Label buildLabelControl(Composite r_Parent, IAdaptable r_Adaptable) {
		if (!this.isUseLabel()) {
			return null;
		}

		Label t_LabelControl = new Label(r_Parent, SWT.FLAT);
		t_LabelControl.setBackground(r_Parent.getBackground());

		if (this.isRequired()) {
			t_LabelControl.setText(this.label + ResourceMessages.REQUIRED_MARK);
		} else {
			t_LabelControl.setText(this.label);
		}

		t_LabelControl.setAlignment(SWT.RIGHT);
		return t_LabelControl;
	}

	/**
	 * ���������༭��SWT�ؼ�<BR>
	 *
	 * Create the SWT editorControl to edit the value.<BR>
	 *
	 * @param r_Parent
	 *            the parent control
	 * @param r_Adaptable
	 *            the context
	 */
	protected void buildEditorControl(Composite r_Parent, IAdaptable r_Adaptable) {
		this.labelControl = this.buildLabelControl(r_Parent, r_Adaptable);
		// Create the label and place it on the left
		// The text is aligned right.
		IControlCreator t_ControlCreator = this.getControlCreator();

		Composite t_Parent = new Composite(r_Parent, SWT.NONE);
		t_Parent.setBackground(r_Parent.getBackground());
		t_Parent.setLayout(LayoutUtil.createCompactGridLayout(1));

		this.decoratedField = new DecoratedField(t_Parent, SWT.NONE, t_ControlCreator);
		this.decoratedField.getLayoutControl().setLayoutData(new GridData(GridData.FILL_BOTH));

		this.layoutControl = t_Parent;
		this.editorControl = this.decoratedField.getControl();
		// to build the editor editorControl for editing.

		this.decoratedField.getControl().getParent().setBackground(r_Parent.getBackground());

		FormData t_FormData = (FormData) this.editorControl.getLayoutData();
		t_FormData.bottom = new FormAttachment(100, 0);

		this.buildFieldDecoration();
		this.buildHelpContextListener();

		if (this.isMarkable() && (null == this.errorMarkMessageCaller)) {
			this.errorMarkMessageCaller = new ErrorMarkMessageCaller(this);
		}

		if (null != this.errorMarkMessageCaller) {
			this.errorMarkMessageCaller.build();
		}

		if (null == this.editorControl) {
			return;
		}
		// Place the editor editorControl on the right and fill it horizontally.
		// this.updateViewMode();
		if (null != this.toolTip) {
			this.editorControl.setToolTipText(this.toolTip);
		}
	}

	/**
	 * ���������İ�����<BR>
	 *
	 * Add help context.<BR>
	 *
	 */
	protected void buildHelpContextListener() {
		IPropertyContextHelper t_Helper = this.getContextHelper();

		if (null != t_Helper) {
			t_Helper.setHelp(this);
		}
	}

	/**
	 *
	 * �����ؼ���ʾ��Ϣ������"����","����","����"��"������ʾ"���֡�<BR>
	 *
	 * Create the field decoration for the control,including "required","wanr","error","assitant".<BR>
	 */
	protected void buildFieldDecoration() {
		FieldDecorationRegistry t_FieldDecorationRegistry = FieldDecorationRegistry.getDefault();

		// Image t_RequiredImage =
		// t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_REQUIRED).getImage();
		this.requiredFieldDecoration = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_REQUIRED);

		this.getDecoratedField().addFieldDecoration(this.requiredFieldDecoration, SWT.BOTTOM | SWT.LEFT, false);
		this.getDecoratedField().hideDecoration(this.requiredFieldDecoration);
		// �����������Ϊ��ռλ

		Image t_WarnImage = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_WARNING).getImage();
		this.warnFieldDecoration = new FieldDecoration(t_WarnImage, "");

		Image t_ErrorImage = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_ERROR).getImage();
		this.errorFieldDecoration = new FieldDecoration(t_ErrorImage, "");

		Image t_AssitantImage = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_CONTENT_PROPOSAL).getImage();
		
		String description = JFaceResources.getString("FieldDecorationRegistry.contentAssistMessage");
		description = description + "(Alt+/)";
		this.assitantFieldDecoration = new FieldDecoration(t_AssitantImage, description);
	}

	/**
	 * ���õ�ǰ�����༭���ݵ�SWT�ؼ�<BR>
	 *
	 * Set the SWT editor Control for editing data.<BR>
	 *
	 * @param r_EditorControl
	 *            set the editor control.
	 */
	protected void setEditorControl(Control r_EditorControl) {
		this.editorControl = r_EditorControl;
	}

	/**
	 * ��Ϊ�����ڽ���clone��ʱ��Ҫ���Ƹ����һЩ��������<BR>
	 * �����ṩ��һЩ�����Ĳ��������ٴ�����ظ�<BR>
	 *
	 * For the inheriented classes need some operations to clone the value of some properties.<BR>
	 * So a basic method to provide some clone function<BR>
	 *
	 * @param r_PropertyEditor
	 *            the property editor which's properties will be cloned.
	 */
	protected void cloneProperty(AbstractPropertyEditor r_PropertyEditor) {
		r_PropertyEditor.setPropertyName(this.getPropertyName());
		r_PropertyEditor.label = this.label;
		r_PropertyEditor.order = this.order;
		r_PropertyEditor.readonly = this.readonly;
		r_PropertyEditor.visible = this.visible;
		r_PropertyEditor.enable = this.enable;
		r_PropertyEditor.bindingName = this.bindingName;
		r_PropertyEditor.reverseBindingName = this.reverseBindingName;
		r_PropertyEditor.useLabel = this.useLabel;
		r_PropertyEditor.validateStrategy = this.validateStrategy;

		if (null != this.assitantHelper) {
			r_PropertyEditor.assitantHelper = (IAssitantHelper) this.assitantHelper.clone();
		}

		r_PropertyEditor.setIntrospector((Introspector) this.getIntrospector().clone());
		// clone the ui resource like font and color.

		if (null != this.validators) {
			for (Iterator t_Iterator = this.validators.iterator(); t_Iterator.hasNext();) {
				IValidator t_Validator = (IValidator) t_Iterator.next();
				r_PropertyEditor.validators.add(t_Validator.clone());
			}
		}

		this.layoutDataBuilder = this.getLayoutDataBuilder();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IValidable#validate()
	 */
	public boolean validate(IMessageCaller r_MessageCaller, Event r_Event) {
		if (null != this.errorMarkMessageCaller) {
			//this.errorMarkMessageCaller.clear();
		}

		return doValidate(r_MessageCaller);
	}

	/**
	 * @return
	 */
	private boolean doValidate(IMessageCaller r_MessageCaller) {
		for (Iterator t_Iterator = this.validators.iterator(); t_Iterator.hasNext();) {
			IValidator t_Validator = (IValidator) t_Iterator.next();

			if (!t_Validator.validate(this.getValue(), null, r_MessageCaller)) {
				return false;
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isEnable()
	 */
	public boolean isEnable() {

		if (SwtResourceUtil.isValid(this.getEditorControl())) {
			return this.enable && this.getEditorControl().isEnabled();
		}

		return this.enable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isVisible()
	 */
	public boolean isVisible() {
		return this.visible;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setEnable(boolean)
	 */
	public void setEnable(boolean r_Enable) {
		if (null != this.editorControl) {
			SwtResourceUtil.setEnable(this.editorControl, r_Enable);
		}

		if (null != this.getLayoutControl()) {
			SwtResourceUtil.setEnable(this.getLayoutControl(), r_Enable);
		}

		this.enable = r_Enable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setVisible(boolean)
	 */
	public void setVisible(boolean r_Visible) {
		if (this.visible != r_Visible) {
			this.visible = r_Visible;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isReadonly()
	 */
	public boolean isReadonly() {
		return this.readonly;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setReadonly(boolean)
	 */
	public void setReadonly(boolean r_Readonly) {
		if (this.readonly != r_Readonly) {
			this.readonly = r_Readonly;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IAdapter#getAdapter(java.lang.Class)
	 */
	public Object getAdapter(Class r_Class) {
		if (r_Class == IPropertyEditor.class) {
			return this;
		}
		if (r_Class == Control.class) {
			return this.editorControl;
		}
		if (null != this.parentAdapter) {
			return this.parentAdapter.getAdapter(r_Class);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isDirty()
	 */
	public boolean isDirty() {

		if (this.dirty) {
			return this.dirty;
		}

		return checkDirty();
	}

	/**
	 * @return
	 */
	protected boolean checkDirty() {
		//		if ((!this.isVisible()) || this.isReadonly() || (!this.isEnable())) {
		//			return false;
		//		}
		//ȥ��������жϣ���Ϊ�п����ڳ����иı�ֵ��������ͨ���û����ؼ�����ģ�ʵ���ϣ������ֵ�Ѿ������˸ı䣬
		//������Ӧ����Dirty��    modify by yangmd
		Object t_OldValue = this.getIntrospector().getValue(getElement(), getPropertyName());
		Object t_NewValue = this.getValue();
		return !ObjectUtils.equals(t_OldValue, t_NewValue);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#save()
	 */
	public void save() {
		if (this.checkDirty() && this.isControlValid() && this.validate(null, null)) {
			this.getIntrospector().setValue(getElement(), getPropertyName(), getValue());
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	public void load() {
		if (null == this.getEditorControl()) {
			return;
		}

		Object t_Value = this.getIntrospector().getValue(getElement(), getPropertyName());
		this.setValue(t_Value);
	}

	/**
	 * ����һ�������ĸ���<BR>
	 * ��Ϊ�༭���漰�������Beanֵ<BR>
	 * ��˿��Գ����̡߳���������<BR>
	 * ��˷����µĸ����߽����Щ����<BR>
	 * ��ȻReflection���Խ��������⣬�����ǵ���������<BR>
	 * ����ʹ��clone<BR>
	 *
	 * Because it uses the bean<BR>
	 * so thread, synchronisis will be put in think.<BR>
	 * For performance,we refuse Reflection.<BR>
	 *
	 * @return return the cloned property editor.
	 */
	@Override
	public final Object clone() {
		AbstractPropertyEditor t_Editor = this.cloneSelf();
		this.cloneProperty(t_Editor);
		return t_Editor;
	}

	/**
	 * �����෵�������ĸ��ơ�<BR>
	 *
	 * Return the clone object for this class.<BR>
	 *
	 */
	public abstract AbstractPropertyEditor cloneSelf();

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#getOrder()
	 */
	public int getOrder() {
		return this.order;
	}

	/**
	 * ���ذ���ص��������ƣ����Խ�����������<BR>
	 *
	 * Return the binding name.<BR>
	 *
	 * @return Returns the bindingName.
	 */
	public final String getBindingName() {
		return this.bindingName;
	}

	/**
	 * ���ð���ص��������ƣ����Խ�����������<BR>
	 *
	 * Set the binding name.<BR>
	 *
	 * @param r_BindingName
	 *            The bindingName to set.
	 */
	public final void setBindingName(String r_BindingName) {
		this.bindingName = r_BindingName;
	}

	/**
	 * ���ط������ص��������ƣ����Խ�����������<BR>
	 *
	 * Return the reverse binding name.<BR>
	 *
	 * @return Returns the reverseBindingName.
	 */
	public final String getReverseBindingName() {
		return this.reverseBindingName;
	}

	/**
	 * ���÷������ص��������ƣ����Խ�����������<BR>
	 *
	 * Set the reverse binding name.<BR>
	 *
	 * @param r_ReverseBindingName
	 *            The reverseBindingName to set.
	 */
	public final void setReverseBindingName(String r_ReverseBindingName) {
		this.reverseBindingName = r_ReverseBindingName;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#afterBuild(com.primeton.studio.core.IAdapter)
	 */
	public void afterBuild(IAdaptable r_Adaptable) {
		if (StringUtils.isNotEmpty(this.bindingName) || StringUtils.isNotEmpty(this.reverseBindingName)) {
			doBinding(r_Adaptable);
		}
		addListeners();
		this.setEnable(this.isEnable());
	}
	
	
	
	/**
	 * ����5�汾�����ṩ�����ĵ��ݡ�<BR>
	 */
	protected void addListeners(){
		//	JIRA 2674 6�汾��������5��ķ���������Alt+/�Ĵ�����ʾ�ڸõ�Ԫ���ǰ�����һ��С���ݡ�
		Control relEditorControl = this.getRelEditorControl(this.editorControl);
		relEditorControl.addFocusListener(listener);
	}
	
	/**
	 * ���������Ĺ��û��༭�Ŀ�
	 * @param control
	 * @return
	 */
	private Control getRelEditorControl(Control control){
		if(control == null)
			return null;
		if(!canAssisantHelpControls.contains(control.getClass())){
			if(!(control instanceof Composite))
				return control;
			Control[] childrens = ((Composite)control).getChildren();
			for (int i = 0; i < childrens.length; i++) {
				Control control2 = childrens[i];
				if(canAssisantHelpControls.contains(control2.getClass())){
					return control2;
				}
			}
		}
		return control;
	}
	/**
	 * @param r_Adaptable
	 */
	private void doBinding(IAdaptable r_Adaptable) {
		Object t_Object = r_Adaptable.getAdapter(ObjectEditor.class);
		if (t_Object instanceof ObjectEditor) {
			ObjectEditor t_ObjectEditor = (ObjectEditor) t_Object;
			final IPropertyEditor t_BindingEditor = t_ObjectEditor.getPropertyEditor(this.bindingName);

			if (null != t_BindingEditor) {
				Object t_Control = t_BindingEditor.getAdapter(Control.class);
				if (t_Control.getClass() == Button.class) {
					final Button t_Button = (Button) t_Control;
					this.initBinding(t_BindingEditor, t_Button);
					t_Button.addSelectionListener(new SelectionAdapter() {

						/*
						 * (non-Javadoc)
						 *
						 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
						 */
						@Override
						public void widgetSelected(SelectionEvent r_Event) {
							updateBinding(t_BindingEditor, t_Button);
						}
					});
				}
			}

			final IPropertyEditor t_ReverseBindingEditor = t_ObjectEditor.getPropertyEditor(this.reverseBindingName);
			if (null != t_ReverseBindingEditor) {
				Object t_Control = t_ReverseBindingEditor.getAdapter(Control.class);
				if (t_Control.getClass() == Button.class) {
					final Button t_Button = (Button) t_Control;
					this.initReverseBinding(t_ReverseBindingEditor, t_Button);
					t_Button.addSelectionListener(new SelectionAdapter() {

						/*
						 * (non-Javadoc)
						 *
						 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
						 */
						@Override
						public void widgetSelected(SelectionEvent r_Event) {
							updateBinding(t_ReverseBindingEditor, t_Button);
							updateReverseBinding(t_ReverseBindingEditor, t_Button);
						}
					});
				}
			}
		}
	}

	/**
	 * ���ݰ󶨵�ֵ���õ�ǰ�༭���Ƿ���Ա༭<BR>
	 *
	 * Update whether the editor can edit data or not by the binding name.<BR>
	 *
	 * @param r_PropertyEditor
	 *            the context property editor
	 * @param r_Button
	 *            the selection button.
	 */
	protected void updateBinding(IPropertyEditor r_PropertyEditor, Button r_Button) {
		this.editorControl.setEnabled(r_Button.getSelection());
	}

	/**
	 * ���ݷ���󶨵�ֵ���õ�ǰ�༭���Ƿ���Ա༭<BR>
	 *
	 * Set whether the editor can edit data or not by the reverse binding name.<BR>
	 *
	 * @param r_PropertyEditor
	 *            the context property editor
	 * @param r_Button
	 *            the selection button.
	 */
	protected void updateReverseBinding(IPropertyEditor r_PropertyEditor, Button r_Button) {
		this.editorControl.setEnabled(!r_Button.getSelection());
	}

	/**
	 * ���ݰ󶨵�ֵ��ʼ����ǰ�༭���Ƿ���Ա༭<BR>
	 *
	 * Init whether the editor can edit data or not by the binding name.<BR>
	 *
	 * @param r_PropertyEditor
	 *            the context property editor
	 * @param r_Button
	 *            the selection button.
	 */
	protected void initBinding(IPropertyEditor r_PropertyEditor, Button r_Button) {
		this.editorControl.setEnabled(r_Button.getSelection());
	}

	/**
	 * ���ݷ���󶨵�ֵ��ʼ����ǰ�༭���Ƿ���Ա༭<BR>
	 *
	 * Init whether the editor can edit data or not by the reverse binding name.<BR>
	 *
	 * @param r_PropertyEditor
	 *            the context property editor
	 * @param r_Button
	 *            the selection button.
	 */
	protected void initReverseBinding(IPropertyEditor r_PropertyEditor, Button r_Button) {
		this.editorControl.setEnabled(!r_Button.getSelection());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#getValue()
	 */
	public final Object getValue() {
		if (null == this.getEditorControl()) {
			return null;
		} else {
			final List<Object> list = new ArrayList<Object>(1);
			if (this.isControlValid()) {
				Display display = this.getEditorControl().getDisplay();
				if (display != null) {
					if (display.getThread() == Thread.currentThread()) {
						list.add(doGetValue());
					} else {
						display.syncExec(new Runnable() {
							public void run() {
								list.add(doGetValue());
							}
						});
					}
				}
			}
			if (list.size() > 0) {
				return list.get(0);
			}
			return null;
		}
	}

	/**
	 * �õ�����ֵ<BR>
	 *
	 * Return the value.<BR>
	 *
	 */
	protected abstract Object doGetValue();

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setValue(java.lang.Object)
	 */
	public final void setValue(final Object r_Value) {

		final Object t_Value = this.getValue();

		boolean flag = isValueChangeContainerEnable(r_Value);
		this.valueChangeContainer.setEnableValueEvent(flag);
		this.valueChangeContainer.setEnableValidateEvent(flag);

		if (this.isControlValid()) {
			Display display = this.getEditorControl().getDisplay();
			if (display != null) {
				if (display.getThread() == Thread.currentThread()) {
					doSetValue(r_Value);

					this.fireValueChanged(new ValueChangeEvent(this, t_Value, r_Value));
					this.valueChangeContainer.setEnableValueEvent(true);
					this.valueChangeContainer.setEnableValidateEvent(true);
				} else {
					display.syncExec(new Runnable() {
						public void run() {
							doSetValue(r_Value);

							fireValueChanged(new ValueChangeEvent(this, t_Value, r_Value));
							AbstractPropertyEditor.this.valueChangeContainer.setEnableValueEvent(true);
							AbstractPropertyEditor.this.valueChangeContainer.setEnableValidateEvent(true);
						}
					});
				}
			}
		}
	}

	/**
	 * �ж�changeEnableContainer�Ƿ����
	 * @param r_Value
	 */
	protected boolean isValueChangeContainerEnable(final Object r_Value) {
		Object t_Value = this.getValue();
		if (ObjectUtils.equals(r_Value, t_Value)) {
			return false;
		}
		return true;
	}

	/**
	 * ����ֵ<BR>
	 *
	 * Set the value.<BR>
	 *
	 * @param r_Value
	 *            the value to set for the editor control.
	 */
	protected abstract void doSetValue(Object r_Value);

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isSupportValidate()
	 */
	public boolean isSupportValidate() {
		return (this.isVisible()) && (!this.validators.isEmpty()) && (this.isEnable());
		// while the editorControl is not hide and contains over 1 validators.
	}

	/**
	 * ���ؿؼ��Ƿ���Ч��<BR>
	 *
	 * Return whether this editorControl is valid or not.<BR>
	 *
	 */
	public boolean isControlValid() {
		return SwtResourceUtil.isValid(this.getEditorControl());
	}

	/**
	 * ����������ʾ�ı�ǩ���֡�<BR>
	 *
	 * Return the label for the current property.<BR>
	 *
	 */
	public String getLabel() {
		return this.label;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.editor.ILabelCustomized#setLabel(java.lang.String)
	 */
	public void setLabel(String r_Label) {
		this.label = r_Label;
	}

	/**
	 * ������ʾ��Ϣ��<BR>
	 *
	 * Return the tooltip.<BR>
	 *
	 */
	public String getToolTip() {
		return this.toolTip;
	}

	/**
	 * ������ʾ��Ϣ��<BR>
	 *
	 * Set the tooltip.<BR>
	 *
	 * @param r_ToolTip
	 *            the toolTip to set
	 */
	public void setToolTip(String r_ToolTip) {
		this.toolTip = r_ToolTip;
	}

	/**
	 * ���ص�ǰ���Ե�˳��<BR>
	 *
	 * Return the order by the current property editor.<BR>
	 *
	 * @param r_Order
	 *            the order to set
	 */
	public void setOrder(int r_Order) {
		this.order = r_Order;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isViewMode()
	 */
	public final boolean isViewMode() {
		return this.viewMode;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setViewMode(boolean)
	 */
	public final void setViewMode(boolean r_ViewMode) {
		if (this.viewMode != r_ViewMode) {
			this.viewMode = r_ViewMode;
			this.updateViewMode();
		}
	}

	/**
	 * ���ݲ鿴ģʽ�����¿ؼ���<BR>
	 *
	 * Update the editorControl by "viewMode".<BR>
	 *
	 */
	protected void updateViewMode() {
		if (null != this.editorControl) {
			this.editorControl.setEnabled(this.isEnable() && (!this.isViewMode()));
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#getLayoutDataBuilder()
	 */
	public final ILayoutDataBuilder getLayoutDataBuilder() {
		if (null == this.layoutDataBuilder) {
			this.layoutDataBuilder = this.createLayoutDataBuilder();
		}
		return this.layoutDataBuilder;
	}

	/**
	 * ����������ظ÷������ṩ�Լ��Ĳ��ִ�����<BR>
	 *
	 * The derived classes can override this method to provide new layout-data builder.<BR>
	 *
	 * @return
	 */
	protected ILayoutDataBuilder createLayoutDataBuilder() {
		return new GridLayoutDataBuilder();
	}

	/**
	 * ���ò��ִ�������<BR>
	 *
	 * Set the layout-data builder.<BR>
	 *
	 * @param r_LayoutDataBuilder
	 *            the layoutBuilder to set
	 */
	public void setLayoutDataBuilder(ILayoutDataBuilder r_LayoutDataBuilder) {
		this.layoutDataBuilder = r_LayoutDataBuilder;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isRequired()
	 */
	public boolean isRequired() {
		return this.required;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setRequired(boolean)
	 */
	public void setRequired(boolean r_Required) {
		if (this.required == r_Required) {
			return;
		}

		this.required = r_Required;

		if (null != this.getLabelControl()) {
			// this.decoratedField.addFieldDecoration(getRequiredFieldDecoration(), SWT.LEFT | SWT.BOTTOM, false);

			if (this.isRequired()) {
				((Label)this.getLabelControl()).setText(this.label + ResourceMessages.REQUIRED_MARK);
			} else {
				((Label)this.getLabelControl()).setText(this.label);
			}
		}
	}

	/**
	 * @return the controlCreator
	 */
	protected abstract IControlCreator createControlCreator();

	/**
	 * @return the controlCreator
	 */
	public final IControlCreator getControlCreator() {

		if (null == this.controlCreator) {
			this.controlCreator = this.createControlCreator();
		}

		return this.controlCreator;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isMarkable()
	 */
	public final boolean isMarkable() {
		return this.markable;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setMarkable(boolean)
	 */
	public final void setMarkable(boolean r_Markable) {
		if (this.markable != r_Markable) {
			this.markable = r_Markable;
		}
	}

	/**
	 * ����������ʾ��־���ֶοؼ���<BR>
	 *
	 * @return the decoratedField
	 */
	public DecoratedField getDecoratedField() {
		return this.decoratedField;
	}

	/**
	 * @return the errorFieldDecoration
	 */
	public FieldDecoration getErrorFieldDecoration() {
		return this.errorFieldDecoration;
	}

	/**
	 * @return the requiredFieldDecoration
	 */
	public FieldDecoration getRequiredFieldDecoration() {
		return this.requiredFieldDecoration;
	}

	/**
	 * @return the warnFieldDecoration
	 */
	public FieldDecoration getWarnFieldDecoration() {
		return this.warnFieldDecoration;
	}

	/**
	 * @return the assitantFieldDecoration
	 */
	public FieldDecoration getAssitantFieldDecoration() {
		return this.assitantFieldDecoration;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isAutoHover()
	 */
	public boolean isAutoHover() {
		return this.autoHover;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setAutoHover(boolean)
	 */
	public void setAutoHover(boolean r_AutoHover) {
		this.autoHover = r_AutoHover;
	}

	/**
	 * @return Returns the useLabel.
	 */
	public boolean isUseLabel() {
		return this.useLabel;
	}

	/**
	 * @param r_UseLabel
	 *            The useLabel to set.
	 */
	public void setUseLabel(boolean r_UseLabel) {
		if (this.useLabel != r_UseLabel) {
			this.useLabel = r_UseLabel;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#getMemento()
	 */
	public IMemento getMemento() {
		return new PropertyMemnto(this.getIntrospector(), this.getElement(), this.getPropertyName());
	}

	/**
	 * ���ش�����ʾ���֡�<BR>
	 *
	 * Return the assitant helper.<BR>
	 *
	 */
	public IAssitantHelper getAssitantHelper() {
		if (null == this.assitantHelper) {
			if (null == this.getElement()) {
				return null;
			}

			String t_ID = this.getElement().getClass().getName() + "." + this.getPropertyName();
			this.assitantHelper = HelperRegistry.getHelper(t_ID);
		}

		return this.assitantHelper;
	}

	/**
	 * @param r_AssitantHelper
	 *            The assitantHelper to set.
	 */
	public void setAssitantHelper(IAssitantHelper r_AssitantHelper) {
		this.assitantHelper = r_AssitantHelper;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isImportant()
	 */
	public boolean isImportant() {
		return this.important;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setImportant(boolean)
	 */
	public void setImportant(boolean r_Important) {
		if (this.important != r_Important) {
			this.important = r_Important;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#isEagerSave()
	 */
	public boolean isEagerSave() {
		return this.eagerSave;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#setEagerSave(boolean)
	 */
	public void setEagerSave(boolean r_EagerSave) {
		if (this.eagerSave != r_EagerSave) {
			this.eagerSave = r_EagerSave;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#getHelpContexts()
	 */
	public IHelpContext[] getHelpContexts() {
		return this.helpContexts;
	}

	/**
	 * @param r_HelpContexts
	 *            the helpContexts to set
	 */
	public void setHelpContexts(IHelpContext[] r_HelpContexts) {
		this.helpContexts = r_HelpContexts;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.IPropertyEditor#getContextHelper()
	 */
	public IPropertyContextHelper getContextHelper() {
		if (null == this.contextHelper) {
			this.contextHelper = new DefaultPropertyContextHelper();
		}

		return this.contextHelper;
	}

	/**
	 * ���������ĵ����֡�<BR>
	 *
	 * Set the assitantHelper for context.<BR>
	 *
	 * @param r_ContextHelper
	 */
	public void setContextHelper(IPropertyContextHelper r_ContextHelper) {
		this.contextHelper = r_ContextHelper;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setFocus() {
		if (null != this.editorControl) {
			this.editorControl.setFocus();
		}
	}

	/**
	 * ������֤����<BR>
	 * ֻ֧�ֵ��������������ʧȥ����ʱ������֤<BR>
	 * ������ͬʱ���<BR>
	 *
	 * Return the strategy for validation.<BR>
	 * Just support keyType event or focus lost event.<BR>
	 * You can't uses them together.<BR>
	 *
	 */
	public int getValidateStrategy() {
		return this.validateStrategy;
	}

	/**
	 * ������֤����<BR>
	 * ������������ʧȥ����ʱ������֤<BR>
	 * ����ͬʱ���,ʹ��"|"<BR>
	 *
	 * Return the strategy for validation.<BR>
	 * Just support keyType event or focus lost event.<BR>
	 * You can't uses them together.<BR>
	 *
	 * @param r_ValidateStrategy
	 *            The validateStrategy to set.
	 */
	public void setValidateStrategy(int r_ValidateStrategy) {
		this.validateStrategy = r_ValidateStrategy;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.events.KeyListener#keyPressed(org.eclipse.swt.events.KeyEvent)
	 */
	public void keyPressed(KeyEvent r_Event) {
		// Nothing to do
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.events.KeyListener#keyReleased(org.eclipse.swt.events.KeyEvent)
	 */
	public void keyReleased(KeyEvent r_Event) {
		fireValueChanged(new ValueChangeEvent(this, this.getLastValue(), getValue()));
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.events.FocusListener#focusGained(org.eclipse.swt.events.FocusEvent)
	 */
	public void focusGained(FocusEvent r_Event) {
		if ((this.getValidateStrategy() & VALIDATE_ON_FOCUS_GAIN) != 0) {
			fireValidateEvent(new ValidateEvent(this));
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.events.FocusListener#focusLost(org.eclipse.swt.events.FocusEvent)
	 */
	public void focusLost(FocusEvent r_Event) {

		if ((this.getValidateStrategy() & VALIDATE_ON_FOCUS_LOST) != 0) {
			fireValidateEvent(new ValidateEvent(this));
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.events.SelectionListener#widgetDefaultSelected(org.eclipse.swt.events.SelectionEvent)
	 */
	public void widgetDefaultSelected(SelectionEvent r_Event) {
		// Nothing to do

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.events.SelectionListener#widgetSelected(org.eclipse.swt.events.SelectionEvent)
	 */
	public void widgetSelected(SelectionEvent r_Event) {
		fireValueChanged(new ValueChangeEvent(this, this.getLastValue(), getValue()));
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.swt.events.ModifyListener#modifyText(org.eclipse.swt.events.ModifyEvent)
	 */
	public void modifyText(ModifyEvent r_Event) {
		fireValueChanged(new ValueChangeEvent(this, this.getLastValue(), getValue()));
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doAddValidateListener(com.primeton.studio.core.IValidateListener)
	 */
	public void doAddValidateListener(IValidateListener r_Listener) {
		this.valueChangeContainer.doAddValidateListener(r_Listener);
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doAddValueChangeListener(com.primeton.studio.core.IValueChangeListener)
	 */
	public void doAddValueChangeListener(IValueChangeListener r_Listener) {
		this.valueChangeContainer.doAddValueChangeListener(r_Listener);
	}

	/**
	 *
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doClearValidateListeners()
	 */
	public void doClearValidateListeners() {
		this.valueChangeContainer.doClearValidateListeners();
	}

	/**
	 *
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doClearValueChangeListeners()
	 */
	public void doClearValueChangeListeners() {
		this.valueChangeContainer.doClearValueChangeListeners();
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doRemoveValidateListener(com.primeton.studio.core.IValidateListener)
	 */
	public void doRemoveValidateListener(IValidateListener r_Listener) {
		this.valueChangeContainer.doRemoveValidateListener(r_Listener);
	}

	/**
	 * @param r_Listener
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#doRemoveValueChangeListener(com.primeton.studio.core.IValueChangeListener)
	 */
	public void doRemoveValueChangeListener(IValueChangeListener r_Listener) {
		this.valueChangeContainer.doRemoveValueChangeListener(r_Listener);
	}

	/**
	 * @param r_Event
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#fireValidateEvent(com.primeton.studio.core.event.ValidateEvent)
	 */
	public void fireValidateEvent(ValidateEvent r_Event) {
		this.valueChangeContainer.fireValidateEvent(r_Event);
	}

	/**
	 * @param r_Event
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#fireValueChanged(com.primeton.studio.core.event.ValueChangeEvent)
	 */
	public void fireValueChanged(ValueChangeEvent r_Event) {
		this.valueChangeContainer.fireValueChanged(r_Event);
	}

	/**
	 * @return
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#getValidateListener()
	 */
	public IValidateListener[] getValidateListener() {
		return this.valueChangeContainer.getValidateListener();
	}

	/**
	 * @return
	 * @see com.primeton.studio.core.base.AbstractValueChangeContainer#getValueChangeListeners()
	 */
	public IValueChangeListener[] getValueChangeListeners() {
		return this.valueChangeContainer.getValueChangeListeners();
	}

	/**
	 * @return the lastValue
	 */
	public Object getLastValue() {
		if (null == this.lastValue) {
			this.lastValue = this.getElementValue();
		}

		return this.lastValue;
	}

	/**
	 * @param r_LastValue
	 *            the lastValue to set
	 */
	public void setLastValue(Object r_LastValue) {
		this.lastValue = r_LastValue;
	}

	/**
	 * @param errorMarkMessageCaller The errorMarkMessageCaller to set.
	 */
	protected void setErrorMarkMessageCaller(
			ErrorMarkMessageCaller errorMarkMessageCaller) {
		this.errorMarkMessageCaller = errorMarkMessageCaller;
	}

	public FocusListener getFocusListener() {
		return listener;
	}
}
