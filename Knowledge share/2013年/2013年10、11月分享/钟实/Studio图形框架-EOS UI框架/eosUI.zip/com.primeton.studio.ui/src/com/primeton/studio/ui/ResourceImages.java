/***********************************************************************************************************************
 * $Header:
 * /cvsroot/EOS6/develop/src/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/messages/ResourceImages.java,v
 * 1.1 2007/03/05 06:06:33 wanglei Exp $ $Revision: 1.1 $ $Date: 2011/06/01 01:25:08 $
 *
 * ====================================================================
 *
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 1999-2003 The Apache Software Foundation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
 * following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
 * following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any, must include the following acknowlegement:
 * "This product includes software developed by the Apache Software Foundation (http://www.apache.org/)." Alternately,
 * this acknowlegement may appear in the software itself, if and wherever such third-party acknowlegements normally
 * appear.
 *
 * 4. The names "The Jakarta Project", "Commons", and "Apache Software Foundation" must not be used to endorse or
 * promote products derived from this software without prior written permission. For written permission, please contact
 * apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache" nor may "Apache" appear in their names without
 * prior written permission of the Apache Group.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * APACHE SOFTWARE FOUNDATION OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. ====================================================================
 *
 * This software consists of voluntary contributions made by many individuals on behalf of the Apache Software
 * Foundation. For more information on the Apache Software Foundation, please see <http://www.apache.org/>.
 *
 */

package com.primeton.studio.ui;

import org.eclipse.jface.resource.ImageDescriptor;

import com.primeton.studio.swt.util.SwtResourceUtil;
import com.primeton.studio.ui.activator.UIActivator;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ���ͼƬ<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * For images <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-3-5 ����01:28:15
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ResourceImages.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.2  2009/04/23 08:02:13  lvyuan
 * BugFix:fix bug 16858 by chenxp
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/02/20 12:01:10  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.2  2008/02/20 09:21:58  wanglei
 * Update:��ResourceUtil�еķ����Ƶ�SwtResourceUtil�С�
 *
 * Revision 1.1  2008/02/15 09:46:42  wanglei
 * Review:��Դ��messages�����Ƶ������棬���������һ�¡�
 *
 * Revision 1.5  2008/02/15 08:42:38  wanglei
 * Review:��ResourceUtil��constant���Ƶ�util���С�
 *
 * Revision 1.4  2008/01/16 07:01:29  lvyuan
 * Update:����ͼƬ
 *
 * Revision 1.3  2007/04/02 10:54:42  lvyuan
 * Add:�������뼰���������Action����
 *
 * Revision 1.2  2007/03/07 05:07:24  wanglei
 * ������ͼƬ�����ı�
 * Revision 1.1 2007/03/05 06:06:33 wanglei �ύ��CVS
 *
 */
public class ResourceImages {

	public static ImageDescriptor PROBLEM_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/problem.gif");

	public static ImageDescriptor BASIC_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/basic.gif");

	public static ImageDescriptor ADVANCED_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/advanced.gif");

	public static ImageDescriptor DOCUMENT_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/document.gif");

	public static ImageDescriptor ERROR_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/error.gif");

	public static ImageDescriptor WARN_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/warn.gif");

	public static ImageDescriptor UP_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/up.gif");

	public static ImageDescriptor DOWN_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/down.gif");

	public static ImageDescriptor TOP_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/top.gif");

	public static ImageDescriptor ADD_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/add.gif");

	public static ImageDescriptor INSERT_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/insert.gif");

	public static ImageDescriptor COLLAPSE_ALL_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/collapseAll.gif");

	public static ImageDescriptor REMOVE_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/remove.gif");

	public static ImageDescriptor EXPAND_ALL_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/expand.gif");

	public static ImageDescriptor EXPAND_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/expand.gif");

	public static ImageDescriptor BOTTOM_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/bottom.gif");

	public static ImageDescriptor COLLAPSE_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/collapse.gif");

    public static ImageDescriptor PARAMETER_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/parameter.gif");

    public static ImageDescriptor RETURNS_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/returns.gif");

    public static ImageDescriptor ADDPARAMETER_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/addparameter.gif");

    public static ImageDescriptor ADDRETURNS_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/addreturns.gif");

    public static ImageDescriptor REFRASH_ICON = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/refresh.gif");
    
    public static ImageDescriptor READONLY_CHECKED = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/readonlyChecked.gif");
    
    public static ImageDescriptor READONLY_UNCHECKED = SwtResourceUtil.loadIcon(UIActivator.PLUGIN_ID, "/icons/eview16/readonlyUnchecked.gif");

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 */
	private ResourceImages() {
		super();
	}

}
