/**
 * ***************************************************************************** Copyright (c) 2001-2007 Primeton
 * Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.table.action.impl;

import com.primeton.studio.core.IObjectTranslator;
import com.primeton.studio.ui.ResourceImages;
import com.primeton.studio.ui.ResourceMessages;
import com.primeton.studio.ui.swt.builder.table.TableBuilder;
import com.primeton.studio.ui.swt.builder.table.action.base.AbstractTableAction;

/**
 * �ڱ�����ѡ�е�������ǰ����һ�С�<BR>
 *
 * @author <a href="mailto:wanglei@primeton.com">Wang Lei</a>
 */
/*
 * �޸���ʷ
 *
 * $Log: InsertTableAction.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/02/15 09:46:43  wanglei
 * Review:��Դ��messages�����Ƶ������棬���������һ�¡�
 *
 * Revision 1.2  2007/09/04 08:23:47  wanglei
 * Review:�����������¶����,ͨ��getActiveObject�Զ�ѡ�в���ʼ�༭��Ӧ����
 *
 * Revision 1.1  2007/03/07 05:06:01  wanglei
 * ͨ��IObjectTranslator֧�ֱ����е����ӺͲ��롣
 *
 */

public class InsertTableAction extends AbstractTableAction {

	private IObjectTranslator translator;

	private Object model;

	private String type;

	private Object activeObject;

	/**
	 * ���캯����<BR>
	 *
	 * The constructor.<BR>
	 *
	 * @param r_Translator
	 * @param r_Model
	 * @param r_Type
	 */
	public InsertTableAction(IObjectTranslator r_Translator, Object r_Model, String r_Type) {
		super();
		this.translator = r_Translator;
		this.model = r_Model;
		this.type = r_Type;

		this.setImageDescriptor(ResourceImages.INSERT_ICON);
		this.setText(ResourceMessages.INSERT);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.table.action.base.AbstractTableAction#doRun(com.primeton.studio.ui.swt.builder.table.TableBuilder)
	 */
	public void doRun(TableBuilder r_TableBuilder) {
		Object t_Object = this.translator.newObject(this.model, this.type);
		if (null != t_Object) {
			int t_Index = r_TableBuilder.getTable().getSelectionIndex();

			if (-1 == t_Index) {
				r_TableBuilder.getDataProvider().add(t_Object);
			}
			else {
				r_TableBuilder.getDataProvider().insert(t_Index, t_Object);
			}

			this.activeObject = t_Object;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	protected Object getActiveObject() {
		return this.activeObject;
	}

}
