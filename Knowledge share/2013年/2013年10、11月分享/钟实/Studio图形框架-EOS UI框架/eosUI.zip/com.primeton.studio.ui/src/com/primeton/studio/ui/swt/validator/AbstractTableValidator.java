/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/validator/AbstractTableValidator.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 * 
 * Created on 2009-3-2
 *******************************************************************************/


package com.primeton.studio.ui.swt.validator;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.IMessageCaller;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * һ��ITableValidator�Ļ���ʵ�֣� ��Ҫ���ṩ������Ϣ�ı���<BR>
 *
 * @author ��ˮ�� (mailto:hongsq@xmkfzx.com)
 */
/*
 * �޸���ʷ
 * $Log: AbstractTableValidator.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/07/21 05:55:40  chenxp
 * Add:�ύ���뵽CVS
 *
 * Revision 1.1  2009/01/09 09:15:12  hongsq
 * Update:ITableValidator�ĳ���ʵ��
 *
 */
public abstract class AbstractTableValidator implements ITableValidator {

	private String message;

	// The error message

	private int level = IConstant.ERROR;

	// the message level

	/**
	 * Ĭ�Ϲ��캯��<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public AbstractTableValidator() {
		super();
	}

	/**
	 * �Թ��캯���ķ�ʽ�ṩ��ʾ��Ϣ��<BR>
	 *
	 * Pass the message by the parameters.<BR>
	 *
	 * @param message
	 *            the message to be shown.
	 */
	public AbstractTableValidator(String message) {
		super();
		this.message = message;
	}

	/**
	 * ������ʾ��Ϣ<BR>
	 *
	 * Return the message for prompt.<BR>
	 *
	 * @return return the message to be shown.
	 */
	public String getMessage() {
		return this.message;
	}

	/**
	 * ������ʾ��Ϣ<BR>
	 *
	 * Set the message for prompt.<BR>
	 *
	 * @param message
	 *            The message to set.
	 */
	public final void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * ������Ϣ��ʾ����<BR>
	 *
	 * Return the message level.<BR>
	 *
	 * @see com.primeton.studio.core.IConstant#ERROR
	 * @see com.primeton.studio.core.IConstant#INFO
	 * @see com.primeton.studio.core.IConstant#WARN
	 *
	 * @return the level
	 */
	public int getLevel() {
		return this.level;
	}

	/**
	 * ������Ϣ��ʾ����<BR>
	 *
	 * Set the message level.<BR>
	 *
	 * @param level
	 *            the level to set
	 *
	 * @see com.primeton.studio.core.IConstant#ERROR
	 * @see com.primeton.studio.core.IConstant#INFO
	 * @see com.primeton.studio.core.IConstant#WARN
	 */
	public void setLevel(int level) {
		if ((IConstant.WARN == level) || (IConstant.INFO == level)) {
			this.level = level;
		} else {
			this.level = IConstant.ERROR;
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.ICloneable#clone()
	 */
	public Object clone() {
		// Most of these objects are safe for thread.
		// Just return itself.
		return this;
	}

	/**
	 * ��ʾ������Ϣ��<BR>
	 *
	 * @param messageCaller
	 */
	private void updateMessage(final IMessageCaller messageCaller) {
		if (null == messageCaller) {
			return;
		}

		if (IConstant.ERROR == this.getLevel()) {
			messageCaller.error(this.getMessage(), null);
			return;
		}

		if (IConstant.WARN == this.getLevel()) {
			messageCaller.warn(this.getMessage(), null);
			return;
		}

		if (IConstant.INFO == this.getLevel()) {
			messageCaller.info(this.getMessage(), null);
			return;
		}
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.swt.validator.ITableValidator#validate(java.lang.Object, java.lang.Object, int, int, com.primeton.studio.core.IMessageCaller)
	 */
	public boolean validate(Object value, Object builder, int column, int row, IMessageCaller messageCaller) {
		if (this.doValidate(value, builder, column, row, messageCaller)) {
			return true;
		} else {
			this.updateMessage(messageCaller);
			return IConstant.ERROR != this.getLevel();
		}
	}

	/**
	 * ��֤
	 * @param value
	 * @param builder
	 * @param column
	 * @param row
	 * @param messageCaller
	 * @return
	 */
	protected abstract boolean doValidate(Object value, Object builder, int column, int row, IMessageCaller messageCaller);
}
