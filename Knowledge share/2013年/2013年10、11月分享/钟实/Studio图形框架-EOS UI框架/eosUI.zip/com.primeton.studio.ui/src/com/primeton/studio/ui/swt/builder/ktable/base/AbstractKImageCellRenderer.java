/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.ktable.base;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.draw2d.ColorConstants;
import org.eclipse.jface.fieldassist.FieldDecoration;
import org.eclipse.jface.fieldassist.FieldDecorationRegistry;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.ui.internal.OverlayIcon;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.swt.resource.PooledImageDescriptor;
import com.primeton.studio.swt.tooltip.Tooltip;
import com.primeton.studio.swt.util.SwtResourceUtil;
import com.primeton.studio.ui.swt.builder.ktable.IKTableColumn;
import com.primeton.studio.ui.swt.builder.ktable.impl.KPropertyTableSortedModel;

import de.kupzog.ktable.KTableModel;
import de.kupzog.ktable.renderers.DefaultCellRenderer;
import de.kupzog.ktable.renderers.FixedCellRenderer;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ΪKTable�ṩͼ������Ļ���<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * The base class to renderer image for ktable. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-27 ����10:27:55
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractKImageCellRenderer.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.3  2009/10/21 07:32:21  chenxp
 * BUG: 22323 ��web����ͼԪ�У�ѡ�񸽼��е�wsdl��˫�����������У�ʹ������Ӧ��С������˫���󣬺��������û���� (hongsq)
 *
 * Revision 1.2  2008/12/03 01:09:32  lvyuan
 * BugFix:fix bug 11775
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.10  2008/02/20 12:01:09  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.9  2008/01/02 06:11:08  wanglei
 * Update:����ѡ��״̬��Ĭ�ϵı���ɫ��
 *
 * Revision 1.8  2007/10/12 09:55:14  chenxp
 * UnitTest:fix a bug.
 *
 * Revision 1.7  2007/08/30 01:11:46  wanglei
 * UnitTest:�����п��ܳ���NPE��Bug��
 *
 * Revision 1.6  2007/07/27 03:45:09  wanglei
 * UnitTest:������Ϊû����ȷ�ָ�����ɫ��Bug��
 *
 * Revision 1.5  2007/07/27 02:43:09  wanglei
 * Review:ʹ��getText���ṩ�ı����и��õ���չ�ԡ�
 *
 * Revision 1.4  2007/07/26 06:14:05  wanglei
 * Review:������ͼ���ƣ�ʹ֮���Ի��档
 *
 * Revision 1.3  2007/07/26 03:23:02  wanglei
 * Update:������֤���ƣ�ʹ��ITableValidator������IValidator��
 *
 * Revision 1.2  2007/05/22 01:12:07  wanglei
 * UnitTest:�������������Ϊnullʱ��NPE�쳣��
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public abstract class AbstractKImageCellRenderer extends DefaultCellRenderer
{

	/**
	 * �̳��Գ���Ĺ��캯����<BR>
	 *
	 * The inheried constructor.<BR>
	 *
	 * @param r_Style
	 */
	public AbstractKImageCellRenderer(int r_Style)
	{
		super(r_Style);
	}

	/**
	 * ����̳и÷����Է�����Ӧ���ı�������ʾ��<BR>
	 *
	 * The derived classes should override this method to return text.<BR>
	 *
	 * @param r_TableColumn
	 * @param r_Content
	 * @return
	 */
	protected String getText(IKTableColumn r_TableColumn,Object r_Content)
	{
		if(null!=r_TableColumn.getProvider())
		{
			Object t_Value=r_TableColumn.getProvider().getKey(r_Content);
			return ObjectUtils.toString(t_Value);
		}
		else
		{
			return ObjectUtils.toString(r_Content);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.renderers.DefaultCellRenderer#drawCell(org.eclipse.swt.graphics.GC,
	 *      org.eclipse.swt.graphics.Rectangle, int, int, java.lang.Object, boolean, boolean, boolean,
	 *      de.kupzog.ktable.KTableModel)
	 */
	public void drawCell(GC r_GC, Rectangle r_Rect, int r_Column, int r_Row, Object r_Content, boolean r_Focus, boolean r_Fixed, boolean r_Clicked, KTableModel r_TableModel)
	{
		super.drawCell(r_GC, r_Rect, r_Column, r_Row,ObjectUtils.toString(r_Content) , r_Focus, r_Fixed, r_Clicked, r_TableModel);

		if (!(r_TableModel instanceof KPropertyTableSortedModel))
		{
			r_Rect = drawDefaultSolidCellLine(r_GC, r_Rect, COLOR_LINE_LIGHTGRAY, COLOR_LINE_LIGHTGRAY);
			return;
		}

		ImageDescriptor t_ImageDescriptor = getImageDescriptor(r_TableModel, r_Content, r_Column, r_Row);
		t_ImageDescriptor = this.getDecorated(t_ImageDescriptor, r_TableModel, r_Content, r_Column, r_Row);
		Image t_Image = null;

		if(t_ImageDescriptor instanceof PooledImageDescriptor){
			t_ImageDescriptor = ((PooledImageDescriptor)t_ImageDescriptor).getImageDescriptor();
		}
		
		if (null != t_ImageDescriptor)
		{
			t_Image = t_ImageDescriptor.createImage();
		}

		try
		{
			this.drawCell(r_GC, r_Rect, r_Focus, r_Fixed, r_Clicked, r_Column, r_Row, r_Content, t_Image, r_TableModel);
		}
		finally
		{
			SwtResourceUtil.dispose(t_Image);
		}
	}

	/**
	 * @param r_GC
	 * @param r_Rect
	 * @param r_Focus
	 * @param t_Image
	 */
	protected void drawCell(GC r_GC, Rectangle r_Rect, boolean r_Focus, boolean r_Fixed, boolean r_Clicked, int r_Column, int r_Row, Object r_Content, Image t_Image, KTableModel r_TableModel)
	{
		this.applyFont(r_GC);

		Color t_OldBackGround=this.getBackground();

		boolean t_Editable=true;

		if(r_TableModel instanceof KPropertyTableSortedModel)
		{
			IKTableColumn t_Column=((KPropertyTableSortedModel)r_TableModel).getColumn(r_Column);
			Object t_Element= ((KPropertyTableSortedModel)r_TableModel).getRowObject(r_Row);

			t_Editable=t_Column.isEditable(t_Element, r_Column, r_Row);
			if(!t_Editable)
			{
				this.setBackground(FixedCellRenderer.COLOR_FIXEDBACKGROUND);
			}
		}

		if (r_Focus && (super.m_Style & INDICATION_FOCUS) != 0)
		{
			drawImage(r_GC, r_Rect, r_Column, r_Row, r_Content, t_Image, r_Focus, r_Fixed, r_Clicked,  COLOR_BGFOCUS, this.getForeground(),r_TableModel);
			r_GC.drawFocus(r_Rect.x, r_Rect.y, r_Rect.width, r_Rect.height);
		}
		else if (r_Focus && (super.m_Style & INDICATION_FOCUS_ROW) != 0)
		{
			drawImage(r_GC, r_Rect, r_Column, r_Row, r_Content, t_Image, r_Focus, r_Fixed, r_Clicked, COLOR_BGFOCUS, ColorConstants.white, r_TableModel);
		}
		else
		{
			drawImage(r_GC, r_Rect, r_Column, r_Row, r_Content, t_Image, r_Focus, r_Fixed, r_Clicked, this.getBackground(), this.getForeground(), r_TableModel);
		}

		r_Rect = drawDefaultSolidCellLine(r_GC, r_Rect, ColorConstants.gray, ColorConstants.gray);

		if ((super.m_Style & INDICATION_COMMENT) != 0)
		{
			drawCommentSign(r_GC, r_Rect);
		}

		this.resetFont(r_GC);
		this.setBackground(t_OldBackGround);
	}

	/**
	 * ��ָ��λ�ã�Ȼ��ָ���ı���ɫ�����ͼ��<BR>
	 *
	 * Draw a image in the specified position with the specified back ground color.<BR>
	 *
	 * @param r_GC
	 *            the graph
	 * @param r_Rect
	 *            the bounds for the draw
	 * @param r_Text
	 * @param r_Image
	 *            the image for the draw
	 * @param r_BackgroundColor
	 *            the background color for the draw bounds.
	 * @param r_ForegroundColor
	 *            the foreground color for the draw text.
	 */

	protected void drawImage(GC r_GC, Rectangle r_Rect, int r_Column, int r_Row, Object r_Content, Image r_Image, boolean r_Focus, boolean r_Fixed, boolean r_Clicked, Color r_BackgroundColor, Color r_ForegroundColor, KTableModel r_TableModel)
	{
		String t_Text=null;

		if(r_TableModel instanceof KPropertyTableSortedModel)
		{
			KPropertyTableSortedModel t_TableModel = (KPropertyTableSortedModel) r_TableModel;
			IKTableColumn t_Column=t_TableModel.getColumn(r_Column);
			Object t_Object=t_TableModel.getRowObject(r_Row);

			Color t_Foreground=t_Column.getForeground(t_Object, r_Column, r_Row);
			Color t_Background=t_Column.getBackground(t_Object, r_Column, r_Row);

			if(null!=t_Background &&(!r_Focus))
			{
				r_BackgroundColor=t_Background;
			}

			if(null!=t_Foreground)
			{
				r_ForegroundColor=t_Foreground;
			}

			t_Text=this.getText(t_Column, r_Content);
			if(t_Text==null)
			{
				t_Text="";
			}
		}
		else
		{
			t_Text=ObjectUtils.toString(r_Content);
		}

		if(r_Focus)
		{
			r_ForegroundColor=this.COLOR_TEXT;
		}

		super.drawCellContent(r_GC, r_Rect, t_Text, r_Image, r_ForegroundColor, r_BackgroundColor);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.kupzog.ktable.KTableCellRenderer#getOptimalWidth(org.eclipse.swt.graphics.GC, int, int, java.lang.Object,
	 *      boolean)
	 */
	public int getOptimalWidth(GC r_GC, int r_Column, int r_Row, Object r_Content, boolean r_Fixed, KTableModel r_TableModel)
	{
		ImageDescriptor t_ImageDescriptor = getImageDescriptor(r_TableModel, r_Content, r_Column, r_Row);
		t_ImageDescriptor = this.getDecorated(t_ImageDescriptor, r_TableModel, r_Content, r_Column, r_Row);
		int t_X;

		if (null == t_ImageDescriptor)
		{
			t_X = 2;
		}
		else
		{
			t_X = t_ImageDescriptor.getImageData().width + 2;
		}

		if(r_TableModel instanceof KPropertyTableSortedModel)
		{
			KPropertyTableSortedModel t_TableModel = (KPropertyTableSortedModel) r_TableModel;
			IKTableColumn t_Column=t_TableModel.getColumn(r_Column);

			String t_Text=this.getText(t_Column, r_Content);
			if(null==t_Text)
			{
				t_Text="";
			}
			return t_X = t_X + super.getOptimalWidth(r_GC, r_Column, r_Row, t_Text, r_Fixed, r_TableModel);
		}
		else
		{
			return super.getOptimalWidth(r_GC, r_Row, t_X, ObjectUtils.toString(r_Content), r_Fixed, r_TableModel);
		}
	}


	/**
	 * ������̳и÷����Է��غ��ʵ�ͼƬ��Ϣ��<BR>
	 *
	 * The derived class can override this method to return image info.<BR>
	 *
	 * @param r_Content
	 */
	protected ImageDescriptor getImageDescriptor(KTableModel r_TableModel, Object r_Content, int r_Column, int r_Row)
	{
		return null;
	}

	/**
	 * �õ�װ�κ��ImageDescriptor��<BR>
	 *
	 * Return the ImageDescriptor which is to be decorated.<BR>
	 *
	 * @param r_ImageDescriptor
	 * @param r_TableModel
	 * @param r_Content
	 * @param r_Column
	 * @param r_Row
	 * @return
	 */
	protected ImageDescriptor getDecorated(ImageDescriptor r_ImageDescriptor, KTableModel r_TableModel, Object r_Content, int r_Column, int r_Row)
	{
		Tooltip t_Tooltip = ((KPropertyTableSortedModel) r_TableModel).getTooltip(r_Column, r_Row);

		if (null == t_Tooltip)
		{
			return r_ImageDescriptor;
		}

		ImageDescriptor t_ImageDescriptor = this.doGetDecoratedImageDescriptor(t_Tooltip);
		if (null == t_ImageDescriptor)
		{
			return r_ImageDescriptor;
		}

		if (null == r_ImageDescriptor)
		{
			return t_ImageDescriptor;
		}

		ImageData t_ImageData = t_ImageDescriptor.getImageData();

		Point t_Point = new Point(t_ImageData.width, t_ImageData.height);
		ImageDescriptor t_Icon = new OverlayIcon(r_ImageDescriptor, t_ImageDescriptor, t_Point);

		return t_Icon;
	}

	/**
	 * ���ݴ�����Ϣ�õ�װ�ε�ͼƬ��<BR>
	 *
	 * Get the decorated image by the error message.<BR>
	 *
	 * @param r_Tooltip
	 * @return
	 */
	private ImageDescriptor doGetDecoratedImageDescriptor(Tooltip r_Tooltip)
	{
		ImageDescriptor t_ImageDescriptor = null;

		if (r_Tooltip.getLevel() == IConstant.WARN)
		{
			FieldDecorationRegistry t_FieldDecorationRegistry = FieldDecorationRegistry.getDefault();
			FieldDecoration t_FieldDecoration = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_WARNING);

			t_ImageDescriptor = ImageDescriptor.createFromImage(t_FieldDecoration.getImage());
		}

		if (r_Tooltip.getLevel() == IConstant.ERROR)
		{
			FieldDecorationRegistry t_FieldDecorationRegistry = FieldDecorationRegistry.getDefault();
			FieldDecoration t_FieldDecoration = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_ERROR);
			t_ImageDescriptor = ImageDescriptor.createFromImage(t_FieldDecoration.getImage());
		}

		return t_ImageDescriptor;
	}

}
