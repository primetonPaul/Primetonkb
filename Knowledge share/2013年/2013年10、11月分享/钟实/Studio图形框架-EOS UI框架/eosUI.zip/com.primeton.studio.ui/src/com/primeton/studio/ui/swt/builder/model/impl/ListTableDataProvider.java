/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.model.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections.comparators.ReverseComparator;

import com.primeton.studio.swt.adapter.StructuredContentProviderAdapter;
import com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ͨ��һ��java.util.List�����ṩ���ݡ�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Provide model by a java.util.List. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-5-1 14:07:43
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ListTableDataProvider.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.6  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.5  2007/05/22 08:37:22  wanglei
 * Add:������clear������
 *
 * Revision 1.4  2007/03/05 06:06:31  wanglei
 * �ύ��CVS
 *
 */
public class ListTableDataProvider extends StructuredContentProviderAdapter implements ITableDataProvider {
	private List values = new ArrayList();

	/**
	 * ������XML�������л�ʹ��<BR>
	 *
	 * This method is used for the xml Serialization.<BR>
	 *
	 */
	protected ListTableDataProvider() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#clone()
	 */
	public Object clone() {
		ListTableDataProvider t_Provider = new ListTableDataProvider(new ArrayList(this.values));
		return t_Provider;
	}

	/**
	 * ͨ�����캯������Ҫʹ�õ�List.
	 *
	 * Using the parameter to set the "List" data.<BR>
	 *
	 * @param r_Values
	 */
	public ListTableDataProvider(List r_Values) {
		super();
		this.values = r_Values;

		if (null == this.values) {
			this.values = new ArrayList();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#getIndex(java.lang.Object)
	 */
	public int indexOf(Object r_Object) {
		return this.values.indexOf(r_Object);
	}

	/**
	 * ����ֵ���ϡ�<BR>
	 *
	 * Return the values collection.<BR>
	 *
	 * @return Returns the values.
	 */
	public List getValues() {
		return this.values;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#sort(java.util.Comparator, boolean)
	 */
	public void sort(Comparator r_Comparator, boolean r_ASC) {
		if (r_ASC) {
			Collections.sort(getValues(), r_Comparator);
		}
		else {
			Collections.sort(getValues(), new ReverseComparator(r_Comparator));
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.IStructuredContentProvider#getElements(java.lang.Object)
	 */
	public Object[] getElements(Object r_inputElement) {
		Object[] t_Values = new Object[this.values.size()];
		this.values.toArray(t_Values);

		return t_Values;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#add(java.lang.Object)
	 */
	public void add(Object r_Object) {
		this.values.add(r_Object);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#remove(int)
	 */
	public void remove(int r_Index) {
		this.values.remove(r_Index);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#remove(java.lang.Object)
	 */
	public void remove(Object r_Object) {
		this.values.remove(r_Object);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#setObject(int, java.lang.Object)
	 */
	public Object set(int r_Index, Object r_Object) {
		Object t_Old = this.values.get(r_Index);
		this.values.set(r_Index, r_Object);

		return t_Old;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#get(int)
	 */
	public Object get(int r_Index) {
		return this.values.get(r_Index);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#insert(int, java.lang.Object)
	 */
	public void insert(int r_Index, Object r_Object) {
		this.values.add(r_Index, r_Object);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.ui.swt.builder.model.base.ITableDataProvider#size()
	 */
	public int size() {
		return this.values.size();
	}

	/**
	 * {@inheritDoc}
	 */
	public void clear() {
		this.values.clear();
	}
}
