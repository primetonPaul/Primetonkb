/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */

package com.primeton.studio.ui.editor.swt.impl;

import org.eclipse.jface.fieldassist.IControlCreator;

import com.primeton.studio.core.exception.ExceptionUtil;
import com.primeton.studio.core.util.CovertorUtil;
import com.primeton.studio.ui.editor.ILayoutDataBuilder;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.TableControlCreator;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;
import com.primeton.studio.ui.swt.builder.table.TableBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ֧����һ������������һ������ֵ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * Use a table to edit the value of a property . <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-9-23 ����04:41:53
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: TablePropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.4  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */
public class TablePropertyEditor extends AbstractPropertyEditor
{
	private TableBuilder tableBuilder;

	private boolean useCheck;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public TablePropertyEditor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator()
	{
		return new TableControlCreator(this.getTableBuilder(), this.isUseCheck());
	}

	/**
	 * ����������TableCreator��<BR>
	 * 
	 * Return the real table control creator.<BR>
	 * 
	 * @return
	 */
	public TableControlCreator getTableControlCreator()
	{
		return (TableControlCreator) this.getControlCreator();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf()
	{
		TablePropertyEditor t_PropertyEditor = new TablePropertyEditor();
		t_PropertyEditor.tableBuilder = (TableBuilder) this.tableBuilder.clone();
		return t_PropertyEditor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		if (null != this.tableBuilder)
		{
			Object[] t_Objects = this.tableBuilder.getCheckedItems();
			Class t_Type = this.getIntrospector().getType(this.getElement(), getPropertyName());
			try
			{
				Object t_Object = CovertorUtil.convert(t_Objects, t_Type);
				return t_Object;
			}
			catch (Exception e)
			{
				ExceptionUtil.getInstance().handleException(e);
			}
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value)
	{
		Object[] t_Values;
		try
		{
			t_Values = (Object[]) CovertorUtil.convert(r_Value, Object[].class);
			this.tableBuilder.setItemState(t_Values, true);
		}
		catch (Exception e)
		{
			ExceptionUtil.getInstance().handleException(e);
		}
	}

	/**
	 * ���ر��񹹽�����<BR>
	 * 
	 * Return the table builder.<BR>
	 * 
	 */
	public TableBuilder getTableBuilder()
	{
		return this.tableBuilder;
	}

	/**
	 * ���ñ��񹹽�����<BR>
	 * 
	 * Set the table builder.<BR>
	 * 
	 * @param r_TableBuilder
	 *            the tableBuilder to set
	 */
	public void setTableBuilder(TableBuilder r_TableBuilder)
	{
		this.tableBuilder = r_TableBuilder;
	}

	/**
	 * �����Ƿ�Ϊ�����Check���ܡ�<BR>
	 * 
	 * Return whether open the check function.<BR>
	 * 
	 */
	public boolean isUseCheck()
	{
		return this.useCheck;
	}

	/**
	 * �����Ƿ�Ϊ�����Check���ܡ�<BR>
	 * 
	 * Set whether open the check function.<BR>
	 * 
	 * @param r_UseCheck
	 *            the useCheck to set
	 */
	public void setUseCheck(boolean r_UseCheck)
	{
		this.useCheck = r_UseCheck;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createLayoutDataBuilder()
	 */
	protected ILayoutDataBuilder createLayoutDataBuilder()
	{
		return GridLayoutDataBuilder.newFullBothLayout();
	}
}
