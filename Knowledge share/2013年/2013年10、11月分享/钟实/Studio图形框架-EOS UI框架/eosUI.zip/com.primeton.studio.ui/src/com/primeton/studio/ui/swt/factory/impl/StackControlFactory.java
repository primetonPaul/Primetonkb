/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/factory/impl/StackControlFactory.java,v 1.1 2011/06/01 01:25:07 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:07 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2007-8-23
 *******************************************************************************/

package com.primeton.studio.ui.swt.factory.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.core.ICommand;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.IValueRepository;
import com.primeton.studio.core.command.CompoundCommand;
import com.primeton.studio.core.event.Event;
import com.primeton.studio.core.impl.UIElementDescription;
import com.primeton.studio.swt.util.LayoutUtil;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.UIDefinition;
import com.primeton.studio.ui.swt.factory.base.AbstractControlFactory;

/**
 *
 * ��StackLayout���ֵ�ControlFactory
 *
 * @author yujl (mailto:yujl@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: StackControlFactory.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:33  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.5  2008/02/27 06:11:01  wanglei
 * Review:��ȥMap��get/set������
 *
 * Revision 1.4  2008/02/26 06:34:27  wanglei
 * Update:����UI��ܺ���ʱ����һЩ����������������⻹�ܶ࣬����������
 *
 * Revision 1.3  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.2  2008/02/18 06:15:41  wanglei
 * Update:��IControlFactory��createControl�����ع���ʹ��UIDefinition��Ϊ��������������
 *
 * Revision 1.1  2007/10/25 06:52:51  zhangzh
 * add:��flow������ƶ����������
 *
 * Revision 1.5  2007/10/15 03:27:27  yujl
 * update:����ע��
 *
 * Revision 1.4  2007/10/10 03:12:54  wangdz
 * Update:�޸ı�����
 *
 * Revision 1.3  2007/10/08 09:39:23  wangdz
 * Update:�ع�(clear up)
 *
 * Revision 1.2  2007/08/24 00:34:08  yujl
 * ADD:��ȡ������AbstractConfigurationFactory()
 *
 */
public class StackControlFactory extends AbstractControlFactory {

	private Map<String, IControlFactory> factoriesMap = new HashMap<String, IControlFactory>();

	private Map<IControlFactory, Composite> compositeMap = new HashMap<IControlFactory, Composite>();

	private StackLayout stackLayout = new StackLayout();

	private Composite parent;

	private boolean srolled = true;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 */
	public StackControlFactory() {
		super();
	}

	/**
	 * ����һ���ؼ����������������ؼ���<BR>
	 * �Կؼ�������Ϊkey<BR>
	 *
	 * Add a control factory to create control.<BR>
	 *
	 * @param factory
	 */
	public void doAddFactory(IControlFactory factory) {
		if (null != factory) {
			this.doAddFactory(factory.getClass().getName(), factory);
		}
	}

	public void doSetTopControl(IControlFactory factory) {
		if ((null != factory) && !this.compositeMap.isEmpty() && (null != (this.stackLayout.topControl = this.compositeMap.get(factory)))) {
			this.parent.layout();
		}
	}

	public void doSetTopControl(String key) {
		if ((null != key) && !key.equals("") && !this.compositeMap.isEmpty() && (null != (this.stackLayout.topControl = this.compositeMap.get(this.factoriesMap.get(key))))) {
			this.parent.layout();
		}
	}

	/**
	 * ����һ���ؼ����������������ؼ���<BR>
	 * �Կؼ�������Ϊkey<BR>
	 *
	 * Add a control factory to create control.<BR>
	 *
	 * @param factory
	 */
	public void doAddFactory(String key, IControlFactory factory) {
		if (null != factory) {
			this.factoriesMap.put(key, factory);
			factory.doAddValidateListener(this);
			factory.doAddValueChangeListener(this);
		}
	}

	/**
	 * ɾ��һ���ؼ�������<BR>
	 *
	 * Remove a control factory.<BR>
	 *
	 * @param factory
	 */
	public void doRemoveFactory(IControlFactory factory) {
		if (null != factory) {
			this.factoriesMap.remove(factory.getClass().getName());
			factory.doRemoveValidateListener(this);
			factory.doRemoveValueChangeListener(this);
		}
	}

	/**
	 * ����ؼ�������<BR>
	 *
	 * Clear all control factories.<BR>
	 *
	 * @param r_Factory
	 */
	public void doClearFactory() {

		for (Iterator iterator = this.factoriesMap.values().iterator(); iterator.hasNext();) {
			IControlFactory controlFactory = (IControlFactory) iterator.next();

			controlFactory.doRemoveValidateListener(this);
			controlFactory.doRemoveValueChangeListener(this);
		}

		this.factoriesMap.clear();
	}

	/**
	 * �������пؼ�������<BR>
	 *
	 * Return all the control factories.<BR>
	 *
	 * @param r_Factory
	 */
	public IControlFactory[] getFactories() {
		IControlFactory[] factories = new IControlFactory[this.factoriesMap.size()];
		this.factoriesMap.values().toArray(factories);
		return factories;
	}

	/**
	 * ���ؿؼ�������������<BR>
	 *
	 * return the size of control factories.<BR>
	 */
	public int size() {
		return this.factoriesMap.size();
	}

	/**
	 * ����ָ�������Ŀؼ�������<BR>
	 *
	 * Return the factory on the specified index.<BR>
	 *
	 * @param r_Index
	 */
	public IControlFactory getFactory(String key) {
		return this.factoriesMap.get(key);
	}

	/**
	 * ����StackLayout
	 * @return
	 */
	public StackLayout getStackLayout() {
		return this.stackLayout;
	}

	/**
	 * ����StackLayout
	 * @param stackLayout
	 */
	public void setStackLayout(StackLayout stackLayout) {
		this.stackLayout = stackLayout;
	}

	/**
	 * ����UI��Ϣ��<BR>
	 *
	 * Update the ui desciption.<BR>
	 *
	 */
	protected void updateUIDescription() {
		UIElementDescription description = this.getUIDescription();
		if (null == description) {
			return;
		}

		if ((description.getWidth() > 0) || (description.getHeight() > 0)) {
			return;
		}

		int width = 0;
		int height = 0;

		for (IControlFactory factory : this.factoriesMap.values()) {
			if (factory.isVisible()) {
				UIElementDescription newDescription = factory.getUIDescription();
				if (null != newDescription) {
					width = Math.max(width, newDescription.getWidth());
					height = Math.max(height, newDescription.getHeight());

					if (StringUtils.isBlank(description.getWindowTitle()) && (StringUtils.isNotBlank(newDescription.getWindowTitle()))) {
						description.setWindowTitle(newDescription.getWindowTitle());
					}

					if (StringUtils.isBlank(description.getTitle()) && (StringUtils.isNotBlank(newDescription.getTitle()))) {
						description.setTitle(newDescription.getTitle());
					}
				}
			}
		}
		description.setWidth(width);
		description.setHeight(height);
	}

	@Override
	protected Control doCreateControl(Composite parent, UIDefinition r_UIDefinition) {

		this.updateUIDescription();

		ScrolledComposite rootParent = new ScrolledComposite(parent, this.getDefaultScrollStyle());
		rootParent.setBackground(parent.getBackground());
		rootParent.setExpandHorizontal(true);
		rootParent.setExpandVertical(true);
		rootParent.setLayoutData(new GridData(GridData.FILL_BOTH));

		this.parent = new Composite(rootParent, SWT.NONE);
		this.parent.setBackground(rootParent.getBackground());
		this.parent.setLayout(this.stackLayout);
		this.parent.setLayoutData(new GridData(GridData.FILL_BOTH));

		for (IControlFactory factory : this.factoriesMap.values()) {
			if (factory.isVisible()) {
				Composite childComposite = new Composite(this.parent, SWT.NONE);
				childComposite.setLayout(LayoutUtil.createCompactGridLayout(1));
				childComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
				factory.createControl(childComposite, r_UIDefinition);
				this.compositeMap.put(factory, childComposite);
			}
		}
		rootParent.setContent(this.parent);
		if (!this.isSrolled()) {
			rootParent.setMinSize(0, 0);
		}
		else {
			rootParent.setMinSize(200, 200);
		}
		return rootParent;
	}

	/**
	 * �������֡�<BR>
	 *
	 * Create Grid Layout��<BR>
	 *
	 */
	protected int getDefaultScrollStyle() {
		return SWT.NONE | SWT.V_SCROLL | SWT.H_SCROLL;
	}

	/**
	 * �������֡�<BR>
	 *
	 * Create Grid Layout��<BR>
	 *
	 */
	public GridLayout createGridLayout() {
		return new GridLayout(1, false);
	}

	/**
	 * ����һ���¹�����<BR>
	 *
	 * Create a new factory.<BR>
	 */
	public final StackControlFactory createFactory() {
		return new StackControlFactory();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.IControlFactory#getCommand()
	 */
	public ICommand getCommand() {
		CompoundCommand compoundCommand = new CompoundCommand();
		for (IControlFactory factory : this.factoriesMap.values()) {
			ICommand command = factory.getCommand();
			if (null != command) {
				compoundCommand.doAddCommand(command);
			}
		}
		return compoundCommand;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	public void load() {
		for (IControlFactory factory : this.factoriesMap.values()) {
			factory.load();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#save()
	 */
	public void save() {
		for (IControlFactory factory : this.factoriesMap.values()) {
			factory.save();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.base.AbstractControlFactory#doSetValue(java.lang.Object)
	 */
	@Override
	protected void doSetValue(Object value) {
		super.doSetValue(value);
		for (IControlFactory factory : this.factoriesMap.values()) {
			factory.setValue(value);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.IControlFactory#isDirty()
	 */
	public boolean isDirty() {
		for (IControlFactory factory : this.factoriesMap.values()) {
			if (factory.isDirty()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doInitContext(IValueRepository r_Context) {
		for (IControlFactory factory : this.factoriesMap.values()) {
			factory.initContext(r_Context);
		}
	}

	public boolean isSrolled() {
		return this.srolled;
	}

	public void setSrolled(boolean srolled) {
		this.srolled = srolled;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean validate(IMessageCaller r_MessageCaller, Event r_Event) {
		for (IControlFactory factory : this.factoriesMap.values()) {
			if (!factory.validate(r_MessageCaller, r_Event)) {
				return false;
			}
		}
		return true;
	}

}
