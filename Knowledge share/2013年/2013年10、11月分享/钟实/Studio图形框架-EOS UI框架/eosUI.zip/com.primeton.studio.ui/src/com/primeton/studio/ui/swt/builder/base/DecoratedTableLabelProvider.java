/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.base;

import org.eclipse.core.runtime.Assert;
import org.eclipse.draw2d.ColorConstants;
import org.eclipse.jface.fieldassist.FieldDecoration;
import org.eclipse.jface.fieldassist.FieldDecorationRegistry;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ITableColorProvider;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.ui.internal.OverlayIcon;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.swt.adapter.TableLabelProviderAdapter;
import com.primeton.studio.swt.resource.PooledImageDescriptor;
import com.primeton.studio.swt.tooltip.Tooltip;
import com.primeton.studio.ui.swt.builder.model.base.ITableColumnDescriptor;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����֧��Table��Tree����֤�������д�������ݣ������ṩһ����Ӧ��ͼ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * It's used to support the validation for table and tree.<BR>
 * It can show a icon for error or warning. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-26 ����05:36:50
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: DecoratedTableLabelProvider.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/04/12 05:52:11  wanglei
 * Review:����getImage�����Ĳ�����
 *
 * Revision 1.6  2008/02/20 12:01:08  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.5  2007/06/04 11:57:42  wanglei
 * UnitTest:����Ĭ������²�ʹ�ñ���ɫ��
 *
 * Revision 1.4  2007/05/22 01:09:32  wanglei
 * Add:֧�ֱ��񱳾�ɫ��ǰ��ɫ��
 *
 * Revision 1.3  2007/05/11 07:24:22  wanglei
 * UnitTest:����PooledImageDescriptor��ͼƬû�л����Bug��
 *
 * Revision 1.2  2007/05/11 06:12:42  wanglei
 * UnitTest:������loadIcon������Դй©��Bug��
 *
 * Revision 1.1  2007/03/05 06:06:34  wanglei
 * �ύ��CVS
 *
 */

public class DecoratedTableLabelProvider extends TableLabelProviderAdapter implements ITableColorProvider {
	private ViewerBuilder viewerBuilder;

	private static final ImageData DefaultImageData = new ImageData(16, 16, 1, new PaletteData(new RGB[] { new RGB(255, 255, 255) }));

	private static final ImageDescriptor DefaultImage = PooledImageDescriptor.getImageDescriptor(ImageDescriptor.createFromImageData(DefaultImageData));

	private static final ImageDescriptor ErrorImage;

	private static final ImageDescriptor WarnImage;

	static {
		FieldDecorationRegistry t_FieldDecorationRegistry = FieldDecorationRegistry.getDefault();
		FieldDecoration t_FieldDecoration = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_WARNING);

		WarnImage = PooledImageDescriptor.getImageDescriptor(t_FieldDecoration.getImage());

		t_FieldDecoration = t_FieldDecorationRegistry.getFieldDecoration(FieldDecorationRegistry.DEC_ERROR);
		ErrorImage = PooledImageDescriptor.getImageDescriptor(t_FieldDecoration.getImage());
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_ViewerBuilder
	 */
	public DecoratedTableLabelProvider(ViewerBuilder r_ViewerBuilder) {
		super();
		Assert.isNotNull(r_ViewerBuilder, "The builder shouldn't be null.");
		this.viewerBuilder = r_ViewerBuilder;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnText(java.lang.Object, int)
	 */
	public String getColumnText(Object r_Element, int r_ColumnIndex) {
		ITableColumnDescriptor t_Column = this.viewerBuilder.getTableColumnDescriptor(r_ColumnIndex);
		return t_Column.getText(r_Element, this.viewerBuilder.getViewer());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.adapter.TableLabelProviderAdapter#getColumnImage(java.lang.Object, int)
	 */
	public Image getColumnImage(Object r_Element, int r_Column) {
		ITableColumnDescriptor t_Column = this.viewerBuilder.getTableColumnDescriptor(r_Column);
		Tooltip t_Tooltip = this.viewerBuilder.getViewerMessageCaller().getTooltip(r_Element, r_Column);
		int t_Row=this.viewerBuilder.getDataProvider().indexOf(r_Element);

		if (null == t_Tooltip) {
			return t_Column.getImage(r_Element, r_Column, t_Row, this.viewerBuilder.getViewer());
		}

		ImageDescriptor t_ImageDescriptor = null;

		if (t_Tooltip.getLevel() == IConstant.WARN) {
			t_ImageDescriptor = WarnImage;
		}

		if (t_Tooltip.getLevel() == IConstant.ERROR) {
			t_ImageDescriptor = ErrorImage;
		}

		if (null == t_ImageDescriptor) {
			return t_Column.getImage(r_Element, r_Column, t_Row, this.viewerBuilder.getViewer());
		}

		Image t_Image = t_Column.getImage(r_Element, r_Column, t_Row, this.viewerBuilder.getViewer());
		ImageDescriptor t_BaseImageDescriptor = null;
		if (null == t_Image) {
			t_BaseImageDescriptor = DefaultImage;
		}
		else {
			t_BaseImageDescriptor = PooledImageDescriptor.getImageDescriptor(t_Image);

			while (t_BaseImageDescriptor instanceof PooledImageDescriptor) {
				t_BaseImageDescriptor = ((PooledImageDescriptor) t_BaseImageDescriptor).getImageDescriptor();
			}
		}

		ImageData t_ImageData = t_BaseImageDescriptor.getImageData();
		Point t_Point = new Point(t_ImageData.width, t_ImageData.height);

		ImageDescriptor t_Icon = new OverlayIcon(t_BaseImageDescriptor, t_ImageDescriptor, t_Point);

		t_Icon = PooledImageDescriptor.getImageDescriptor(t_Icon);
		return t_Icon.createImage();
	}

	/**
	 * @param r_Index
	 * @see com.primeton.studio.ui.swt.builder.base.ViewerBuilder#getTableColumnDescriptor(int)
	 */
	public ITableColumnDescriptor getTableColumnDescriptor(int r_Index) {
		return this.viewerBuilder.getTableColumnDescriptor(r_Index);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.ITableColorProvider#getBackground(java.lang.Object, int)
	 */
	public Color getBackground(Object r_Element, int r_ColumnIndex)
	{
		ITableColumnDescriptor t_Column = this.viewerBuilder.getTableColumnDescriptor(r_ColumnIndex);

		if(t_Column.isUseColor())
		{
			int t_RowIndex=this.viewerBuilder.getDataProvider().indexOf(r_Element);
			if(t_Column.isEditable(r_Element, r_ColumnIndex, t_RowIndex)&&t_Column.isUseColor())
			{
				return ColorConstants.white;
			}
			else
			{
				return ColorConstants.button;
			}
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.ITableColorProvider#getForeground(java.lang.Object, int)
	 */
	public Color getForeground(Object r_Element, int r_ColumnIndex)
	{
		return null;
	}

}
