/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.editor;

import java.util.Hashtable;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.exception.ExceptionUtil;


/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����ͨ����չ����ߴ���ķ�ʽ��ע��һЩIPropertyEditor���Ӷ��ṩ�����Ĳ�����ơ�<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Register some IPropertyEditor by extension-point or code.<BR>
 * These class can be used by many plugins. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-3-14 ����11:19:16
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: PropertyEditorFactoryRepository.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/03/19 09:51:58  wanglei
 * Update:��UIActivator�е������ƹ�����֧�������ء�
 *
 * Revision 1.2  2007/04/05 01:12:31  wanglei
 * Refactor:������ʵ�֣�����ObjectEditor��Ϊ������
 *
 * Revision 1.1  2007/03/30 01:23:27  wanglei
 * Add:����IPropertyEditor��ע��⡣
 *
 */

public class PropertyEditorFactoryRepository
{
	private static final PropertyEditorFactoryRepository instance = new PropertyEditorFactoryRepository();

	private final Hashtable editorFactories = new Hashtable();

	/**
	 * ��Ϊ����Ҫʵ�������Թ��캯��Ϊ˽��<BR>
	 * �μ�Singletonģʽ<BR>
	 *
	 * Only one instance is needed,so the default constructor is private<BR>
	 * Please refer to singleton design pattern.
	 */
	private PropertyEditorFactoryRepository()
	{
		super();

		try {
			this.loadPropertyEditorFactories();
		} catch (Exception e) {
			ExceptionUtil.getInstance().logException(e);
		}

	}

	/**
	 * ����չ��"org.aquarius.ui.propertyEditorFactory"��ȡ����Ӧ�����Կؼ���Ϣ��<BR>
	 *
	 * Load property editor factory from the extension "org.aquarius.ui.propertyEditorFactory".<BR>
	 *
	 */
	private void loadPropertyEditorFactories() {
		IExtensionRegistry t_ExtensionRegistry = Platform.getExtensionRegistry();
		IExtensionPoint t_ExtensionPoint = t_ExtensionRegistry.getExtensionPoint(IPropertyEditorFactory.ExtensionID);

		if (null != t_ExtensionPoint) {
			IExtension[] t_Extensions = t_ExtensionPoint.getExtensions();

			for (int i = 0; i < t_Extensions.length; i++) {
				IExtension t_Extension = t_Extensions[i];
				IConfigurationElement[] t_ConfigurationElements = t_Extension.getConfigurationElements();

				for (int j = 0; j < t_ConfigurationElements.length; j++) {
					IConfigurationElement t_ConfigurationElement = t_ConfigurationElements[j];
					doLoadPropertyEditorFactory(t_ConfigurationElement);
				}
			}
		}

	}

	/**
	 * ����չ��������һ��IPropertyEditorFactory��<BR>
	 *
	 * Load a IPropertyEditorFactory from the extension point.<BR>
	 *
	 * @param r_ConfigurationElement
	 */
	private void doLoadPropertyEditorFactory(IConfigurationElement r_ConfigurationElement) {
		try {
			Object t_Object = r_ConfigurationElement.createExecutableExtension(IConstant.CLASS_NAME);
			String t_Name = r_ConfigurationElement.getAttribute(IConstant.NAME);

			if (t_Object instanceof IPropertyEditorFactory) {
				this.registerEditorFactory(t_Name, (IPropertyEditorFactory) t_Object);
			}
		} catch (CoreException e) {
			ExceptionUtil.getInstance().logException(e);
		}

	}

	/**
	 * @return the instance
	 */
	public static PropertyEditorFactoryRepository getInstance()
	{
		return instance;
	}

	/**
	 * Ϊָ��������ע��һ��EditorFactory��<BR>
	 *
	 * Register a property editor factory for the specified type.<BR>
	 *
	 * @param r_Type
	 * @param r_PropertyEditorFactory
	 */
	public synchronized void registerEditorFactory(String r_Type, IPropertyEditorFactory r_PropertyEditorFactory)
	{
		if (null != r_PropertyEditorFactory && null != r_Type)
		{
			this.editorFactories.put(r_Type, r_PropertyEditorFactory);
		}
	}

	/**
	 *
	 * ע��ָ�����ͼ���Ӧ��EditorFactory��<BR>
	 *
	 * Unregister a property editor factory for the specified type.<BR>
	 *
	 * @param r_Name
	 */
	public synchronized IPropertyEditorFactory unregisterEditorFactory(String r_Name)
	{
		if (null != r_Name)
		{
			return (IPropertyEditorFactory) this.editorFactories.remove(r_Name);
		}
		else
		{
			return null;
		}
	}

	/**
	 * ����ָ�����Ͷ�Ӧ��IPropertyEditorFactory��<BR>
	 *
	 * Find a property editor factory for the specified type.<BR>
	 * @param r_ObjectEditor TODO
	 * @param r_Name
	 *
	 * @see #registerEditorFactory(String, IPropertyEditorFactory)
	 *
	 */
	public synchronized IPropertyEditorFactory getPropertyEditorFactory(ObjectEditor r_ObjectEditor, String r_Name)
	{
		if (null != r_Name)
		{
			IPropertyEditorFactory t_PropertyEditorFactory = (IPropertyEditorFactory) this.editorFactories.get(r_Name);
			return t_PropertyEditorFactory;
		}
		else
		{
			return null;
		}
	}

	/**
	 * ����ָ�����Ͷ�Ӧ��IPropertyEditor��<BR>
	 *
	 * Find a property editor for the specified type.<BR>
	 * @param r_ObjectEditor 	 * @param r_Name
	 *
	 * @see #registerEditorFactory(String, IPropertyEditorFactory)
	 *
	 */
	public synchronized IPropertyEditor getPropertyEditor(ObjectEditor r_ObjectEditor, String r_Name)
	{
		if (null != r_Name)
		{
			IPropertyEditorFactory t_PropertyEditorFactory = (IPropertyEditorFactory) this.editorFactories.get(r_Name);
			if (null != t_PropertyEditorFactory)
			{
				return t_PropertyEditorFactory.createPropertyEditor(r_ObjectEditor);
			}
		}
		return null;
	}

}
