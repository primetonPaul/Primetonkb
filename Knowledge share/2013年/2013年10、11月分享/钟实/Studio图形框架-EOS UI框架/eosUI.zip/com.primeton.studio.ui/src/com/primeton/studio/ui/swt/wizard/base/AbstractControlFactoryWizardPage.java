/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.wizard.base;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.PlatformUI;

import com.primeton.studio.core.event.ValidateEvent;
import com.primeton.studio.core.impl.UIElementDescription;
import com.primeton.studio.ui.swt.factory.IControlFactory;
import com.primeton.studio.ui.swt.factory.impl.DefaultUIDefinition;
import com.primeton.studio.ui.swt.util.ValidateUtil;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ����IControlFactory��WizardPage<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Based on AbstractControlFactoryWizardPage. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-2-26 ����11:28:51
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: AbstractControlFactoryWizardPage.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.3  2008/08/19 02:39:55  yanfei
 * Update:���Ӱ������֧�֡�
 *
 * Revision 1.2  2008/08/15 03:44:06  yanfei
 * Update:����UIElementDescription����windowTitle
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.10  2008/03/18 05:19:14  wanglei
 * Review:������ʾ������Ϣʱ�����ܡ�
 *
 * Revision 1.9  2008/03/11 07:15:00  tenghao
 * Update: �޸�Bug
 *
 * Revision 1.8  2008/03/10 09:14:31  wanglei
 * Update:֧���û������Ƿ�һ��ʼ����ʾ��֤��ͨ���Ĵ�����Ϣ��
 *
 * Revision 1.7  2008/03/04 06:01:55  wanglei
 * UnitTest:����û�����������Ϣ��Bug��
 *
 * Revision 1.6  2008/02/28 06:25:39  wanglei
 * Review:����validate������
 *
 * Revision 1.5  2008/02/28 06:07:02  wanglei
 * UnitTest:������ΪUI����ع������Bug��
 *
 * Revision 1.4  2008/02/26 09:13:46  wanglei
 * Update:������֤˳��
 *
 * Revision 1.3  2008/02/26 08:42:18  wanglei
 * Update:ʹ��UIElementDescription��Ϣ�����ҳ�档
 *
 * Revision 1.2  2008/02/26 08:24:30  wanglei
 * Review:����ʵ����IValueChangeListener��IValidateListener��
 *
 * Revision 1.1  2008/02/26 05:27:52  wanglei
 * Add:�ύ��CVS��
 *
 */

public abstract class AbstractControlFactoryWizardPage extends AbstractWizardPage {

	private IControlFactory controlFactory;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_PageName
	 * @param r_Title
	 * @param r_TitleImage
	 */
	public AbstractControlFactoryWizardPage(String r_PageName, String r_Title, ImageDescriptor r_TitleImage) {
		super(r_PageName, r_Title, r_TitleImage);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_PageName
	 */
	public AbstractControlFactoryWizardPage(String r_PageName) {
		super(r_PageName);
	}

	/**
	 * {@inheritDoc}
	 */
	protected final Control doCreateControl(Composite r_Parent) {
		PlatformUI.getWorkbench().getHelpSystem().setHelp(r_Parent, getHelpContextId());
		this.controlFactory = this.getControlFactory();

		if (null != this.controlFactory) {

			UIElementDescription elementDescription = this.controlFactory.getUIDescription();
			if (null != elementDescription) {

				if(StringUtils.isNotEmpty(elementDescription.getTitle()))
				{
					this.setTitle(elementDescription.getTitle());
				}

				if(StringUtils.isNotEmpty(elementDescription.getDescription()))
				{
					this.setDescription(elementDescription.getDescription());
				}

				if(StringUtils.isNotEmpty(elementDescription.getWindowTitle()))
				{
					if (this.getWizard() instanceof Wizard) {
						Wizard wizard = (Wizard) this.getWizard();

						wizard.setWindowTitle(elementDescription.getWindowTitle());
					}
				}
			}

			Control t_Control = this.controlFactory.createControl(r_Parent, DefaultUIDefinition.DEFAULT_INSTANCE);
			this.controlFactory.doAddValueChangeListener(this);
			this.controlFactory.doAddValidateListener(this);

			if (this.isShowInitialErrorMessage()) {
				this.setPageComplete(this.controlFactory.validate(this, null));
			}
			else {
				this.setPageComplete(this.controlFactory.validate(null, null));
			}

			return t_Control;
		}
		else {
			return new Composite(r_Parent, SWT.NONE);
		}
	}

	protected abstract String getHelpContextId();
	/**
	 * @return
	 */
	protected abstract IControlFactory createControlFactory();

	/**
	 * @return Returns the controlFactory.
	 */
	public IControlFactory getControlFactory() {

		if (null == this.controlFactory) {
			this.controlFactory = this.createControlFactory();
		}

		return this.controlFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public void validateRequested(ValidateEvent r_Event) {
		this.clear();

		if (ValidateUtil.validate(this.controlFactory, this, r_Event)) {
			this.setPageComplete(true);
		}
		else {
			this.setPageComplete(false);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean validate() {
		return ValidateUtil.validate(this.controlFactory, this, null);
	}

}
