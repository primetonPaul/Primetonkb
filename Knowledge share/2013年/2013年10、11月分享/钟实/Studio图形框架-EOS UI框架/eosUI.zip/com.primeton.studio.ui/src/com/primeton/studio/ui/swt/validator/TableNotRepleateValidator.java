/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/validator/TableNotRepleateValidator.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Id: TableNotRepleateValidator.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Name:  $
 * $Date: 2011/06/01 01:25:08 $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * �й��������а�Ȩ����.
 *
 *******************************************************************************/


package com.primeton.studio.ui.swt.validator;

import org.apache.commons.lang.StringUtils;

import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.Introspector;
import com.primeton.studio.core.helper.IntrospectorHelper;
import com.primeton.studio.ui.swt.builder.model.base.ITableDataProvider;
import com.primeton.studio.ui.swt.builder.table.TableBuilder;

/**
 * 
 * Table������ֵ�����ظ�(��Columnʹ��)
 *
 * @author ��ˮ�� (mailto:hongsq@primeton.com)
 */
/*
 * �޸���ʷ
 * $Log: TableNotRepleateValidator.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2009/09/01 07:27:56  hongsq
 * Update:�ṩKTable,KTree,Table���е�������֤����������ģ��ʹ��
 *
 */
public class TableNotRepleateValidator extends AbstractTableValidator {

	private TableBuilder tableBuilder;

	private String propertyName;

	private int column;

	/**
	 * @param tableBuilder
	 * @param message
	 */
	public TableNotRepleateValidator(TableBuilder tableBuilder, String propertyName, int column, String message) {
		super(message);
		this.column = column;
		this.propertyName = propertyName;
		this.tableBuilder = tableBuilder;
	}

	/* (non-Javadoc)
	 * @see com.primeton.studio.ui.swt.validator.AbstractTableValidator#doValidate(java.lang.Object, java.lang.Object, int, int, com.primeton.studio.core.IMessageCaller)
	 */
	@Override
	protected boolean doValidate(Object value, Object builder, int column, int row, IMessageCaller messageCaller) {
		if(null == value)
			return true;//������У���е����Ĺ�����

		if ((value instanceof String) && StringUtils.isEmpty((String) value)) {
			return true;
		}

		if(column != this.column)
			return true;

		ITableDataProvider provider = tableBuilder.getDataProvider();
		int count = provider.size();
		for (int i = 0; i < count; i++) {
			if(i == row)
				continue;//���ж��Լ�

			Object element = provider.get(i);
			if(null == element)
				return true;

			Introspector introspector = IntrospectorHelper.getInstance().getIntrospector(element.getClass());

			if((value instanceof String) && StringUtils.equalsIgnoreCase((String) value, (String) introspector.getValue(element, this.propertyName))){
				return false;
			}else if(value.equals(introspector.getValue(element, this.propertyName)))
				return false;
		}

		return true;
	}

}
