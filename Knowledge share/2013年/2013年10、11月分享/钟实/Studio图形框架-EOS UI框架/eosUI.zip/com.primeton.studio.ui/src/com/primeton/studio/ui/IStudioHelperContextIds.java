/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/IStudioHelperContextIds.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-8-18
 *******************************************************************************/


package com.primeton.studio.ui;


public interface IStudioHelperContextIds {
	public static final String PREFIX = "com.primeton.studio.workbench.help."; //$NON-NLS-1$



	// Actions
	public static final String MISSING = PREFIX + "missing"; //$NON-NLS-1$

	// ��ͼ
	public static final String EOS_RESOURCE_VIEW = PREFIX + "eos_resource_view"; //$NON-NLS-1$
	public static final String EOS_DATABASE_VIEW = PREFIX + "eos_database_view"; //$NON-NLS-1$
	public static final String EOS_SERVER_VIEW = PREFIX + "eos_server_view"; //$NON-NLS-1$
	public static final String EOS_ORGANIZATION_VIEW = PREFIX + "eos_organization_view"; //$NON-NLS-1$
	public static final String EOS_OUTLINE_VIEW = PREFIX + "eos_outline_view"; //$NON-NLS-1$
	public static final String EOS_COMPONENT_VIEW = PREFIX + "eos_component_view"; //$NON-NLS-1$
	public static final String EOS_DEBUG_VIEW = PREFIX + "eos_debug_view"; //$NON-NLS-1$
	public static final String EOS_BREAKPOINT_VIEW = PREFIX + "eos_breakpoint_view"; //$NON-NLS-1$
	public static final String EOS_VARIABLES_VIEW = PREFIX + "eos_variables_view"; //$NON-NLS-1$
	public static final String EOS_TEMPLATE_VIEW = PREFIX + "eos_template_view"; //$NON-NLS-1$

	// ��
	public static final String NEW_EOS_PROJECT_WIZARD = PREFIX + "new_eos_project_wizard"; //$NON-NLS-1$
	public static final String NEW_CONTRIBUTION_WIZARD = PREFIX + "new_contribution_wizard"; //$NON-NLS-1$
	public static final String NEW_BIZLET_WIZARD = PREFIX + "new_bizlet_wizard"; //$NON-NLS-1$
	public static final String NEW_IMPORT_BIZLET_WIZARD = PREFIX + "new_import_bizlet_wizard"; //$NON-NLS-1$
	public static final String NEW_COMPOSITE_WIZARD = PREFIX + "new_composite_wizard"; //$NON-NLS-1$
	public static final String NEW_JAVA_COMPONENT_WIZARD = PREFIX + "new_java_component_wizard"; //$NON-NLS-1$
	public static final String NEW_EOS_COMPONENT_WIZARD = PREFIX + "new_eos_component_wizard"; //$NON-NLS-1$
	public static final String NEW_WORKFLOW_WIZARD = PREFIX + "new_workflow_wizard"; //$NON-NLS-1$
	public static final String NEW_PAGEFLOW_WIZARD = PREFIX + "new_pageflow_wizard"; //$NON-NLS-1$
	public static final String NEW_DATASET_WIZARD = PREFIX + "new_dataset_wizard"; //$NON-NLS-1$
	public static final String NEW_NAMINGSQL_WIZARD = PREFIX + "new_namingsql_wizard"; //$NON-NLS-1$
	public static final String NEW_INTERFACE_WIZARD = PREFIX + "new_interface_wizard"; //$NON-NLS-1$
	public static final String NEW_XSD_WIZARD = PREFIX + "new_xsd_wizard"; //$NON-NLS-1$
	public static final String NEW_SERVICE_AEGIS_WIZARD = PREFIX + "new_service_aegis_wizard";
	public static final String NEW_BEAN_SERVICE_AEGIS_WIZARD = PREFIX + "new_bean_aegis_wizard";

	// �༭��
	public static final String COMMON_EDITOR_INTRODUCE = PREFIX + "common_editor_introduce"; //$NON-NLS-1$
	public static final String BIZ_EDITOR = PREFIX + "biz_editor"; //$NON-NLS-1$
	public static final String PAGEFLOW_EDITOR = PREFIX + "pageflow_editor"; //$NON-NLS-1$
	public static final String DATASET_EDITOR = PREFIX + "dataset_editor"; //$NON-NLS-1$
	public static final String NAMINGSQL_EDITOR = PREFIX + "namingsql_editor"; //$NON-NLS-1$
	public static final String WORKFLOW_EDITOR = PREFIX + "workflow_editor"; //$NON-NLS-1$
	public static final String COMPOSITE_EDITOR = PREFIX + "composite_editor"; //$NON-NLS-1$
	public static final String WSDL_EDITOR = PREFIX + "wsdl_editor"; //$NON-NLS-1$

	// �ĵ�����
	public static final String DOC_EXPORT_WIZARD = PREFIX + "doc_export_wizard"; //$NON-NLS-1$

	// ����
	public static final String EOS_DEBUG = PREFIX + "eos_debug"; //$NON-NLS-1$

	// �߼������ԶԻ��� 
	public static final String BIZ_START_NODE = PREFIX + "biz_start_node"; //$NON-NLS-1$
	public static final String BIZ_END_NODE = PREFIX + "biz_end_node"; //$NON-NLS-1$
	public static final String BIZ_SETVALUE_NODE = PREFIX + "biz_setvalue_node"; //$NON-NLS-1$
	public static final String BIZ_LOOP_NODE = PREFIX + "biz_loop_node"; //$NON-NLS-1$
	public static final String BIZ_SUBPROCESS_NODE = PREFIX + "biz_subprocess_node"; //$NON-NLS-1$
	public static final String BIZ_INVOKE_SERVICE_NODE = PREFIX + "biz_invoke_service_node"; //$NON-NLS-1$
	public static final String BIZ_BIZLET_NODE = PREFIX + "biz_bizlet_node"; //$NON-NLS-1$
	public static final String BIZ_EXCEPTION_NODE = PREFIX + "biz_exception_node"; //$NON-NLS-1$
	public static final String BIZ_CONNECTION_NODE = PREFIX + "biz_connection_node"; //$NON-NLS-1$
	public static final String BIZ_EXIT_CONNECTION_NODE = PREFIX + "biz_exit_connection_node"; //$NON-NLS-1$
	public static final String BIZ_EXCEPTION_CONNECTION_NODE = PREFIX + "biz_exception_connection_node"; //$NON-NLS-1$

	// ҳ�������ԶԻ��� 
	public static final String PAGEFLOW_PAGEFOW = PREFIX + "pageflow_pagefow"; //$NON-NLS-1$
	public static final String PAGEFLOW_START_NODE = PREFIX + "pageflow_start_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_END_NODE = PREFIX + "pageflow_end_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_ASSIGN_NODE = PREFIX + "pageflow_assign_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_SUBPROCESS_NODE = PREFIX + "pageflow_subprocess_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_INVOKE_SERVICE_NODE = PREFIX + "pageflow_invoke_service_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_INVOKE_POJO_NODE = PREFIX + "pageflow_invoke_pojo_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_VIEW_NODE = PREFIX + "pageflow_view_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_SUBPAGEFOW_NODE = PREFIX + "pageflow_subpagefow_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_SWITCH_NODE = PREFIX + "pageflow_switch_node"; //$NON-NLS-1$
	public static final String PAGEFLOW_ACTION_CONNECTION = PREFIX + "pageflow_action_connection"; //$NON-NLS-1$
	public static final String PAGEFLOW_COMMON_CONNECTION = PREFIX + "pageflow_common_connection"; //$NON-NLS-1$
	public static final String PAGEFLOW_EXCEPTION_CONNECTION = PREFIX + "pageflow_exception_connection"; //$NON-NLS-1$

	// ���������ԶԻ��� 
	public static final String WORKFLOW_WORKFLOW = PREFIX + "workflow_workflow"; //$NON-NLS-1$
	public static final String WORKFLOW_START_NODE = PREFIX + "workflow_start_node"; //$NON-NLS-1$
	public static final String WORKFLOW_MAN_ACTIVITY_NODE = PREFIX + "workflow_man_activity_node"; //$NON-NLS-1$
	public static final String WORKFLOW_AUTO_ACTIVITY_NODE = PREFIX + "workflow_auto_activity_node"; //$NON-NLS-1$
	public static final String WORKFLOW_SUBFLOW_ACTIVITY_NODE = PREFIX + "workflow_subflow_activity_node"; //$NON-NLS-1$
	public static final String WORKFLOW_SWITCH_ACTIVITY_NODE = PREFIX + "workflow_switch_activity_node"; //$NON-NLS-1$
	public static final String WORKFLOW_END_NODE = PREFIX + "workflow_end_node"; //$NON-NLS-1$
	public static final String WORKFLOW_CONNECTION = PREFIX + "workflow_connection"; //$NON-NLS-1$

	// ���ݼ����ԶԻ��� 
	public static final String DATASET_NPENTITY_NODE = PREFIX + "dataset_npentity_node"; //$NON-NLS-1$
	public static final String DATASET_PEENTITY_NODE = PREFIX + "dataset_peentity_node"; //$NON-NLS-1$
	public static final String DATASET_SPENTITY_NODE = PREFIX + "dataset_spentity_node"; //$NON-NLS-1$
	public static final String DATASET_ASSOCIATION_UN_1TO1_CONNECTION = PREFIX + "dataset_association_un_1to1_connection"; //$NON-NLS-1$
	public static final String DATASET_ASSOCIATION_UN_NTO1_CONNECTION = PREFIX + "dataset_association_un_nto1_connection"; //$NON-NLS-1$
	public static final String DATASET_ASSOCIATION_UN_1TON_CONNECTION = PREFIX + "dataset_association_un_1ton_connection"; //$NON-NLS-1$

	// ����װ�� 
	public static final String COMPOSITE_EOSCOMPONENT_NODE = PREFIX + "composite_eoscomponent_node"; //$NON-NLS-1$
	public static final String COMPOSITE_JAVACOMPONENT_NODE = PREFIX + "composite_javacomponent_node"; //$NON-NLS-1$
	public static final String COMPOSITE_COPOSITECOMPONENT_NODE = PREFIX + "composite_copositecomponent_node"; //$NON-NLS-1$
	public static final String COMPOSITE_SERVICE_NODE = PREFIX + "composite_service_node"; //$NON-NLS-1$
	public static final String COMPOSITE_REFERENCE_NODE = PREFIX + "composite_reference_node"; //$NON-NLS-1$
	public static final String COMPOSITE_PROMOTE_CONNECTION = PREFIX + "composite_promote_connection"; //$NON-NLS-1$
	public static final String COMPOSITE_PROPERTY_CONNECTION = PREFIX + "composite_property_connection"; //$NON-NLS-1$

}
