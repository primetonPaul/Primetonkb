/*******************************************************************************
 * $Header: /cvsroot/PTP25/develop/components/ide-ui/develop/core/studio/com.primeton.studio.ui/src/com/primeton/studio/ui/swt/editor/ComboBoxCellEditor.java,v 1.1 2011/06/01 01:25:08 wang-mh Exp $
 * $Revision: 1.1 $
 * $Date: 2011/06/01 01:25:08 $
 *
 *==============================================================================
 *
 * Copyright (c) 2001-2006 Primeton Technologies, Ltd.
 * All rights reserved.
 *
 * Created on 2008-7-14
 *******************************************************************************/


package com.primeton.studio.ui.swt.editor;

import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.primeton.studio.core.model.IDataProvider;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * SWT�ṩ��ComboCellEditor����ʱʹ��������Ϊ����������ֵ����UI�����ʹ�õ���IDataProvider������<BR>
 * ���������ṩһ��ComboCellEditor��������
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Because the ComboCellEditor in swt use integer as input and output.<BR>
 * But in UI framework ,it use IDataProvider go handle the selection.<BR>
 * A additional ComboCellEditor is needed. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2008-7-14 ����11:26:31
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * Update History
 *
 * $Log: ComboBoxCellEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/08/20 07:09:56  yanfei
 * Update:��IListProvider��ΪIDataProvider�ӿ�
 *
 * Revision 1.1  2008/07/14 03:43:27  wanglei
 * Add:�ύ��CVS��
 *
 */

public class ComboBoxCellEditor extends CellEditor
{

	private IDataProvider listProvider;

	CCombo comboBox;

	String key;

	/**
	 * Default ComboBoxCellEditor style
	 */
	private static final int defaultStyle = SWT.NONE;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_Parent
	 * @param r_DataProvider
	 */
	public ComboBoxCellEditor(Composite r_Parent, IDataProvider r_DataProvider)
	{
		this(r_Parent, r_DataProvider, defaultStyle);
	}

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 *
	 * @param r_Parent
	 * @param r_Style
	 * @param r_DataProvider
	 */
	public ComboBoxCellEditor(Composite r_Parent, IDataProvider r_DataProvider, int r_Style)
	{
		super(r_Parent, r_Style);
		this.listProvider = r_DataProvider;

		String[] t_Items = this.listProvider.getKeys();
		if (t_Items != null)
		{
			this.comboBox.removeAll();
			this.comboBox.setItems(t_Items);

			setValueValid(true);
		}

		this.comboBox.addKeyListener(new KeyAdapter()
		{
			// hook key pressed - see PR 14201

			/**
			 *
			 * {@inheritDoc}
			 */
			public void keyPressed(KeyEvent r_Event)
			{
				keyReleaseOccured(r_Event);
			}
		});

		this.comboBox.addSelectionListener(new SelectionAdapter()
		{

			/**
			 *
			 * {@inheritDoc}
			 */
			public void widgetDefaultSelected(SelectionEvent r_Event)
			{
				applyEditorValueAndDeactivate();
			}

			/**
			 *
			 * {@inheritDoc}
			 */
			public void widgetSelected(SelectionEvent r_Event)
			{
				ComboBoxCellEditor.this.key = ComboBoxCellEditor.this.comboBox.getText();
			}
		});

		this.comboBox.addTraverseListener(new TraverseListener()
		{
			/**
			 *
			 * {@inheritDoc}
			 */
			public void keyTraversed(TraverseEvent r_Event)
			{
				if (r_Event.detail == SWT.TRAVERSE_ESCAPE || r_Event.detail == SWT.TRAVERSE_RETURN)
				{
					r_Event.doit = false;
				}
			}
		});

		this.comboBox.addFocusListener(new FocusAdapter()
		{

			/**
			 *
			 * {@inheritDoc}
			 */
			public void focusLost(FocusEvent r_Event)
			{
				ComboBoxCellEditor.this.focusLost();
			}
		});
	}

	/**
	 * {@inheritDoc}
	 */

	protected Control createControl(Composite r_Parent)
	{
		this.comboBox = new CCombo(r_Parent, getStyle());
		this.comboBox.setFont(r_Parent.getFont());

		return this.comboBox;
	}

	/**
	 * Applies the currently selected value and deactiavates the cell editor
	 */
	void applyEditorValueAndDeactivate()
	{
		// must set the selection before getting value
		Object newValue = doGetValue();
		markDirty();
		boolean isValid = isCorrect(newValue);
		setValueValid(isValid);

		if (!isValid)
		{
			// Nothing to to
		}

		fireApplyEditorValue();
		deactivate();
	}

	/**
	 * {@inheritDoc}
	 */

	protected Object doGetValue()
	{

		return this.key;

	}

	/**
	 * {@inheritDoc}
	 */

	protected void doSetFocus()
	{
		this.comboBox.setFocus();
	}

	/**
	 * {@inheritDoc}
	 */

	protected void doSetValue(Object r_Value)
	{
		Assert.isTrue(this.comboBox != null);

		this.key = this.listProvider.getKey(r_Value);

		if (null != this.key)
		{
			this.comboBox.setText(this.key);
		}
	}

	/**
	 * {@inheritDoc}
	 */

	protected void focusLost()
	{
		if (isActivated())
		{
			applyEditorValueAndDeactivate();
		}
	}

	/**
	 * {@inheritDoc}
	 */

	protected void keyReleaseOccured(KeyEvent r_Event)
	{
		if (r_Event.character == '\u001b')
		{ // Escape character
			fireCancelEditor();
		}
		else if (r_Event.character == '\t')
		{ // tab key
			applyEditorValueAndDeactivate();
		}
	}
}
