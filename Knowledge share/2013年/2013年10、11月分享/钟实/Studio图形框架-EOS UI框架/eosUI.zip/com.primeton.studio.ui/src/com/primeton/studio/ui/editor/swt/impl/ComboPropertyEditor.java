/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.editor.swt.impl;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.widgets.Combo;

import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.ui.editor.swt.base.AbstractListPropertyEditor;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.ComboControlCreator;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ʹ�����������ѡ��<BR>
 * Ҳ�����û��ֹ�����<BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Using combobox to choose data.<BR>
 * It also allow to input data<BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ComboPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.2  2008/10/06 06:53:31  yanfei
 * BUG 7606 EOS��Ŀ����,ѡ��Web Server,�� BackSpace��,Ӧ��ȥ��,������ComboPropertyEditor��keyReleased������
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.8  2007/11/02 02:06:46  wanglei
 * UnitTest:�̳�checkDirty������
 *
 * Revision 1.7  2007/09/21 09:43:17  wanglei
 * UnitTest:��refresh��������null���жϡ�
 *
 * Revision 1.6  2007/07/30 02:38:49  wanglei
 * Review:�����û����Զ�ѡ��͹ر��Զ�ѡ��Ĺ��ܡ�
 *
 * Revision 1.5  2007/04/18 02:38:42  caijing
 * Update:ȡ��final
 *
 * Revision 1.4  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public class ComboPropertyEditor extends AbstractListPropertyEditor {
	private boolean autoSelected = false;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public ComboPropertyEditor() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf() {
		ComboPropertyEditor t_PropertyEditor = new ComboPropertyEditor();
		t_PropertyEditor.autoSelected = this.autoSelected;
		return t_PropertyEditor;
	}

	/**
	 * ����������ComboControlCreator��<BR>
	 *
	 * Return the real combo control creator.<BR>
	 *
	 * @return
	 */
	public ComboControlCreator getComboControlCreator() {
		return (ComboControlCreator) this.getControlCreator();
	}

	public void keyReleased(KeyEvent r_Event) {
		Combo combo = this.getCombo();
		if ((combo.getStyle() & SWT.READ_ONLY) != SWT.READ_ONLY )
			fireValueChanged(new ValueChangeEvent(this, this.getLastValue(), getValue()));
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	public void load() {
		if (null == this.getEditorControl()) {
			return;
		}

		this.getDataProvider().build(this);

		this.refresh();

		Object t_Value = this.getIntrospector().getValue(getElement(), getPropertyName());
		this.setValue(t_Value);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractListPropertyEditor#refresh()
	 */
	public void refresh() {
		Combo t_Combo = this.getCombo();
		if (null != t_Combo) {
			String t_Text = t_Combo.getText();

			t_Combo.removeAll();
			t_Combo.setItems(this.getDataProvider().getKeys());

			if (!this.isReadonly()) {
				t_Combo.setText(t_Text);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#afterBuild(com.primeton.studio.core.IAdapter)
	 */
	public void afterBuild(IAdaptable r_Adaptable) {
		super.afterBuild(r_Adaptable);

		if (this.isControlValid()) {
			Combo t_Combo = this.getCombo();

			t_Combo.addFocusListener(this);
			t_Combo.addKeyListener(this);
			t_Combo.addSelectionListener(this);
			t_Combo.addModifyListener(this);

			if (null != this.getAssitantHelper()) {
				this.getAssitantHelper().addContentProposal(t_Combo);
			}
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue() {
		Combo t_Combo = this.getCombo();
		return this.getDataProvider().getValue(t_Combo.getText());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value) {
		Combo t_Combo = this.getCombo();

		if (null == r_Value) {
			if (t_Combo.getItemCount() > 0 && this.isAutoSelected()) {
				t_Combo.select(0);
			}

			return;
		}

		String t_Key = this.getDataProvider().getKey(r_Value);

		if (null != t_Key) {
			t_Combo.setText(t_Key);
		}
		else {
			if (t_Combo.getItemCount() > 0 && this.isAutoSelected()) {
				t_Combo.select(0);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#isDirty()
	 */
	public boolean isDirty() {
		if ((!this.isVisible()) || (!this.isEnable())) {
			return false;
		}

		Object t_OldValue = this.getIntrospector().getValue(getElement(), getPropertyName());
		Object t_NewValue = this.getValue();

		return !ObjectUtils.equals(t_OldValue, t_NewValue);
	}

	/**
	 * ����ѡ���õ�������<BR>
	 *
	 * Return the combo for the selection.<BR>
	 *
	 */
	public Combo getCombo() {
		return (Combo) this.getEditorControl();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator() {
		return new ComboControlCreator(this);
	}

	/**
	 * ������û�к������ݵ�ʱ���Ƿ��Զ�ѡ���1�<BR>
	 *
	 * Return whether select the first item as the default item while there is no data available.<BR>
	 *
	 * @return the autoSelected
	 */
	public final boolean isAutoSelected() {
		return this.autoSelected;
	}

	/**
	 * ������û�к������ݵ�ʱ���Ƿ��Զ�ѡ���1�<BR>
	 *
	 * Set whether select the first item as the default item while there is no data available.<BR>
	 *
	 * @param r_AutoSelected the autoSelected to set
	 */
	public final void setAutoSelected(boolean r_AutoSelected) {
		this.autoSelected = r_AutoSelected;
	}

	/**
	 * {@inheritDoc}
	 */

	protected boolean checkDirty() {
		if ((!this.isVisible()) || (!this.isEnable())) {
			return false;
		}

		Object t_OldValue = this.getIntrospector().getValue(getElement(), getPropertyName());
		Object t_NewValue = this.getValue();
		return !ObjectUtils.equals(t_OldValue, t_NewValue);
	}

}
