/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */

package com.primeton.studio.ui.swt.builder.table;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import com.primeton.studio.core.IConstant;
import com.primeton.studio.core.IMessageCaller;
import com.primeton.studio.core.util.PropertiesUtil;
import com.primeton.studio.swt.tooltip.ITooltipProvider;
import com.primeton.studio.swt.tooltip.Tooltip;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * ��ΪSwt��Table�ǲ�֧�ֵ�����Ԫ��Ĵ�����ʾ��Ϊ�˷��㽫������֤�ʹ�����ʾ��ϣ��ṩ�������<BR>
 * �����Լ�¼ÿ����Ԫ��Ĵ�����Ϣ��������ʾ��<BR>
 * <P>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Because the swt table doesn't support cell tooltip.<BR>
 * This class integerate the tooltip and validation. <BR>
 * <P>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2007-2-21 ����01:31:25
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: ViewerMessageCaller.java,v $
 * Revision 1.1  2011/06/01 01:25:08  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:35  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.7  2008/03/13 08:57:03  chenxp
 * Update:����getClonedErrors����
 *
 * Revision 1.6  2008/03/11 01:20:57  wanglei
 * UnitTest:����ClassCastException��
 *
 * Revision 1.5  2008/03/10 06:50:34  wanglei
 * Review:������hasError�Ĵ���
 *
 * Revision 1.4  2008/02/20 12:01:08  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.3  2007/12/12 05:15:50  wanglei
 * Update:ITooltipProvider�ƶ���λ�á�
 *
 * Revision 1.2  2007/07/26 03:23:01  wanglei
 * Update:������֤���ƣ�ʹ��ITableValidator������IValidator��
 *
 * Revision 1.1  2007/03/05 06:06:33  wanglei
 * �ύ��CVS
 *
 */

public final class ViewerMessageCaller implements IMessageCaller, ITooltipProvider
{
	private int currentCololumn;

	private Object currentObject;

	private Map errors = new HashMap();

	private ITooltipProvider tooltipProvider;

	/**
	 * ������ʾ��Ϣ�Ĵ洢�������ݲ��������������<BR>
	 *
	 * Pass a tooltip provider to construct a object.<BR>
	 *
	 * @param r_TooltipProvider
	 */
	public ViewerMessageCaller(ITooltipProvider r_TooltipProvider)
	{
		super();
		this.tooltipProvider = r_TooltipProvider;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#clear()
	 */
	public synchronized void clear()
	{
		Map t_Map = (Map) this.errors.get(new Integer(this.currentCololumn));
		if (null == t_Map)
		{
			return;
		}
		else
		{
			t_Map.remove(this.currentObject);
		}
	}

	/**
	 * ������еĴ�����Ϣ��<BR>
	 *
	 * Clear all the errors.<BR>
	 *
	 */
	public void clearAll()
	{
		this.errors.clear();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#error(java.lang.String, java.util.Properties)
	 */
	public void error(String r_Message, Properties r_Properties)
	{
		this.setMessage(r_Message, r_Properties, IConstant.ERROR);
	}

	/**
	 * ������ʾ��Ϣ��<BR>
	 *
	 * Set the message and extension properties.<BR>
	 *
	 * @param r_Message
	 * @param r_Properties
	 * @param r_Level
	 */
	private synchronized void setMessage(String r_Message, Properties r_Properties, int r_Level)
	{
		Map t_Map = (Map) this.errors.get(new Integer(this.currentCololumn));
		if (null == t_Map)
		{
			t_Map = new HashMap();
			this.errors.put(new Integer(this.currentCololumn), t_Map);
		}

		String t_Value = r_Message + PropertiesUtil.toString(r_Properties);
		t_Map.put(this.currentObject, new Tooltip(t_Value, r_Level));
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#hasError()
	 */
	public boolean hasError()
	{
		for (Iterator t_Iterator = this.errors.values().iterator(); t_Iterator.hasNext();)
		{
			Map t_Map = (Map)t_Iterator.next();

			for (Iterator t_MapIterator = t_Map.values().iterator(); t_MapIterator.hasNext();)
			{
				Tooltip t_Tooltip=(Tooltip)t_MapIterator.next();
				if(t_Tooltip.getLevel()==IConstant.ERROR)
				{
					return true;
				}
			}
		}

		return false;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#info(java.lang.String, java.util.Properties)
	 */
	public void info(String r_Message, Properties r_Properties)
	{
		this.setMessage(r_Message, r_Properties, IConstant.INFO);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IMessageCaller#warn(java.lang.String, java.util.Properties)
	 */
	public void warn(String r_Message, Properties r_Properties)
	{
		this.setMessage(r_Message, r_Properties, IConstant.WARN);
	}

	/**
	 * @return Returns the currentCololumn.
	 */
	public int getCurrentCololumn()
	{
		return this.currentCololumn;
	}

	/**
	 * @param r_CurrentColumn
	 *            The currentCololumn to set.
	 */
	public void setCurrentCololumn(int r_CurrentColumn)
	{
		this.currentCololumn = r_CurrentColumn;
	}

	/**
	 * @return Returns the currentObject.
	 */
	public Object getCurrentObject()
	{
		return this.currentObject;
	}

	/**
	 * @param r_CurrentObject
	 *            The currentObject to set.
	 */
	public void setCurrentObject(Object r_CurrentObject)
	{
		this.currentObject = r_CurrentObject;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.swt.builder.table.tooltip.ITooltipProvider#getTooltip(java.lang.Object, int)
	 */
	public Tooltip getTooltip(Object r_Element, int r_ColumnIndex)
	{
		Map t_Map = (Map) this.errors.get(new Integer(r_ColumnIndex));
		if (null == t_Map)
		{
			return null;
		}

		Tooltip t_Tooltip = (Tooltip) t_Map.get(r_Element);

		if (null != t_Tooltip)
		{
			return t_Tooltip;
		}
		else
		{
			if (null == this.tooltipProvider)
			{
				return null;
			}
			else
			{
				return this.tooltipProvider.getTooltip(r_Element, r_ColumnIndex);
			}
		}
	}

	/**
	 * @return Returns the tooltipProvider.
	 */
	public ITooltipProvider getTooltipProvider()
	{
		return this.tooltipProvider;
	}

	/**
	 * @param r_TooltipProvider
	 *            The tooltipProvider to set.
	 */
	public void setTooltipProvider(ITooltipProvider r_TooltipProvider)
	{
		this.tooltipProvider = r_TooltipProvider;
	}

	/**
	 * �õ�Clone�汾�Ĵ�����Ϣ��<BR>
	 *
	 *
	 *
	 * @return
	 */
	public Map getClonedErrors()
	{
		return new HashMap(this.errors);
	}
}
