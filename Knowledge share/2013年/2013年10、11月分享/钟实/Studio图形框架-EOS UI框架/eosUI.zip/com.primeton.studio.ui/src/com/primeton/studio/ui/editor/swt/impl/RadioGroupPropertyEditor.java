/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 *
 */
package com.primeton.studio.ui.editor.swt.impl;

import org.apache.commons.lang.ObjectUtils;
import org.eclipse.jface.fieldassist.IControlCreator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Layout;

import com.primeton.studio.core.event.ValueChangeEvent;
import com.primeton.studio.swt.util.SwtResourceUtil;
import com.primeton.studio.ui.editor.ILayoutDataBuilder;
import com.primeton.studio.ui.editor.swt.base.AbstractListPropertyEditor;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.RadioGroupControlCreator;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * �����û�ѡ��<BR>
 * <BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 *
 * <strong>English Doc��</strong><BR>
 * Provide the values for choosing. <BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 *
 * Created Time: 2006-4-23 13:12:53
 *
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 *
 * $Log: RadioGroupPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.3  2008/06/04 08:36:01  wanglei
 * Update:֧�ֱ����������ݣ����������ݸı�ʱ������Ӧ�ļ�������
 *
 * Revision 1.2  2008/03/03 07:44:36  wanglei
 * Review:�ع�AbstractPropertyEditor����ȥ��doFullValidate����������֮�Է��¼��ķ�ʽ��
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.12  2007/11/02 07:02:59  wanglei
 * Review:��Button�ı�ʱҲӦ�ý�����֤��
 *
 * Revision 1.11  2007/10/25 07:46:45  zhangzh
 * UnitTest:fix �����༭����bug
 *
 * Revision 1.10  2007/09/20 12:33:36  hongsq
 * Update:����һ���Զ���Ĳ��֣�����ʹ�����Լ�����Button
 *
 * Revision 1.9  2007/07/24 02:41:19  wanglei
 * Remove:����ʹ��Group������ʹ����ͨ��Composite��
 *
 * Revision 1.8  2007/03/26 05:45:29  wanglei
 * Refactor:ȥ��final�������̳С�
 *
 *
 *
 * Revision 1.7  2007/03/20 11:27:23  wanglei
 * UnitTest:�����Ƚ϶���ʱNullPointerException���쳣��
 *
 * Revision 1.6  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */
public class RadioGroupPropertyEditor extends AbstractListPropertyEditor {
	private boolean horizontalAlign = false;

	private Layout buttonLayout = null;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 *
	 * The default constructor.<BR>
	 */
	public RadioGroupPropertyEditor() {
		super();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	@Override
	protected IControlCreator createControlCreator() {
		return new RadioGroupControlCreator(this);
	}

	/**
	 * ����������ControlCreator��<BR>
	 *
	 * Return the real radio group control creator.<BR>
	 *
	 * @return
	 */
	public RadioGroupControlCreator getRadioGroupControlCreator() {
		return (RadioGroupControlCreator) this.getControlCreator();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	@Override
	public AbstractPropertyEditor cloneSelf() {
		return new RadioGroupPropertyEditor();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	@Override
	protected Object doGetValue() {
		Composite t_Parent = (Composite) this.getEditorControl();
		Control[] t_Children = t_Parent.getChildren();

		for (int i = 0; i < t_Children.length; i++) {
			Button t_Button = (Button) t_Children[i];

			if (t_Button.getSelection()) {
				return t_Button.getData();
			}
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	@Override
	protected void doSetValue(Object r_Value) {
		Composite t_Parent = (Composite) this.getEditorControl();
		Control[] t_Children = t_Parent.getChildren();

		for (int i = 0; i < t_Children.length; i++) {
			Button t_Button = (Button) t_Children[i];
			t_Button.setSelection(false);
		}

		for (int i = 0; i < t_Children.length; i++) {
			Button t_Button = (Button) t_Children[i];

			if (t_Button.getData().equals(r_Value)) {
				t_Button.setSelection(true);
				break;
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.core.IStore#load()
	 */
	@Override
	public void load() {
		if (null == this.getEditorControl()) {
			return;
		}

		this.dispose();
		this.refresh();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractListPropertyEditor#refresh()
	 */
	@Override
	public void refresh() {
		Object t_Value = this.getIntrospector().getValue(getElement(), getPropertyName());

		Composite t_Parent = (Composite) this.getEditorControl();
		boolean t_Processed = false;

		String[] t_Keys = this.getDataProvider().getKeys();
		for (int i = 0; i < t_Keys.length; i++) {
			Button t_Button = new Button(t_Parent, SWT.FLAT | SWT.RADIO);
			Object t_DataValue = this.getDataProvider().getValue(t_Keys[i]);

			t_Button.setText(t_Keys[i]);
			t_Button.setData(t_DataValue);

			if (ObjectUtils.equals(t_Value, t_DataValue)) {
				t_Button.setSelection(true);
				fireValueChanged(new ValueChangeEvent(RadioGroupPropertyEditor.this, getValue()));
				t_Processed = true;
			}

			t_Button.addSelectionListener(new SelectionAdapter() {

				/*
				 * (non-Javadoc)
				 *
				 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
				 */
				@Override
				public void widgetSelected(SelectionEvent r_Event) {
					Object t_NewValue=getValue();
					fireValueChanged(new ValueChangeEvent(RadioGroupPropertyEditor.this,getLastValue(),t_NewValue));
					setLastValue(t_NewValue);
				}

			});
		}

		if ((!t_Processed) && (t_Keys.length > 0)) {
			Button t_Button = (Button) t_Parent.getChildren()[0];
			t_Button.setSelection(true);
		}

		t_Parent.layout();
	}

	/**
	 * �ͷ�ԭ�е�swt��Դ<BR>
	 *
	 * Dispose the swt resource<BR>
	 *
	 */
	protected void dispose() {
		Composite t_Parent = (Composite) this.getEditorControl();
		SwtResourceUtil.dispose(t_Parent.getChildren());
	}

	/**
	 * ���ع�ѡ���Button��<BR>
	 *
	 * Return the buttons for selection.<BR>
	 *
	 */
	public Button[] getButtons() {
		Composite t_Parent = (Composite) this.getEditorControl();
		Control[] t_Children = t_Parent.getChildren();
		Button[] t_Buttons = new Button[t_Children.length];

		for (int i = 0; i < t_Children.length; i++) {
			t_Buttons[i] = (Button) t_Children[i];
		}

		return t_Buttons;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createLayoutDataBuilder()
	 */
	@Override
	protected ILayoutDataBuilder createLayoutDataBuilder() {
		GridLayoutDataBuilder t_LayoutBuilder = new GridLayoutDataBuilder();

		if (this.isHorizontalAlign()) {
			t_LayoutBuilder.setLabelVerticalIndent(6);
		}

		return t_LayoutBuilder;
	}

	/**
	 * @return the horizontalAlign
	 */
	public boolean isHorizontalAlign() {
		return this.horizontalAlign;
	}

	/**
	 * @param r_horizontalAlign
	 *            the horizontalAlign to set
	 */
	public void setHorizontalAlign(boolean r_horizontalAlign) {
		this.horizontalAlign = r_horizontalAlign;
	}

	/**
	 *
	 * @return the buttonLayout
	 */
	public Layout getButtonLayout() {
		return this.buttonLayout;
	}

	/**
	 *
	 * @param buttonLayout
	 * 			the buttonLayout to set
	 */
	public void setButtonLayout(Layout buttonLayout) {
		this.buttonLayout = buttonLayout;
	}

}
