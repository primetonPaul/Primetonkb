/**
 * *****************************************************************************
 * Copyright (c) 2001-2007 Primeton Technologies, Ltd. <BR>
 * All rights reserved. <BR>
 * Created on 2006-12-22 <BR>
 * *****************************************************************************
 * 
 */
package com.primeton.studio.ui.editor.swt.impl;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.jface.fieldassist.IControlCreator;

import com.eos.system.utility.ArrayUtil;
import com.primeton.studio.ui.editor.ILayoutDataBuilder;
import com.primeton.studio.ui.editor.swt.base.AbstractPropertyEditor;
import com.primeton.studio.ui.editor.swt.creator.impl.FileListControlCreator;
import com.primeton.studio.ui.editor.swt.layout.GridLayoutDataBuilder;
import com.primeton.studio.ui.swt.component.impl.FileListComponent;

/**
 * <strong>����˵��(Chinese Doc)��</strong><BR>
 * <BR>
 * һ������������·���ı༭��<BR>
 * ֧������ͼ���<BR>
 * <strong>��������: </strong><BR>
 * ��ǰ׺"t_"��ͷ�ı�����ͨ����ʾ����һ���ֲ�����������Ч����һ���������ڲ�<BR>
 * ��ǰ׺"r_"��ͷ�ı�����ͨ����ʾ����һ�������������ʾӢ�� reference
 * <P>
 * 
 * <strong>English Doc��</strong><BR>
 * A editor for setting the class path<BR>
 * It support String[] or collection of string<BR>
 * <BR>
 * <strong>Rule for naming: </strong><BR>
 * prefix of "t_" means the variable inside the body of a method <BR>
 * prefix of "r_" means the parameter,i like to call it reference
 * <P>
 * 
 * Created Time: 2006-4-23 13:12:53
 * 
 * @author <a href="mailto:wl_95421@hotmail.com">Lei.Wang</a>
 * @version $Revision: 1.1
 */
/*
 * �޸���ʷ
 * 
 * $Log: FileListPropertyEditor.java,v $
 * Revision 1.1  2011/06/01 01:25:07  wang-mh
 * Add:����ƽ̨Ǩ��
 *
 * Revision 1.1  2011/04/26 03:17:34  guwei
 * Add: PTP
 *
 * Revision 1.1  2008/07/04 11:54:38  build
 * Added by Needle,Sxn,Sccot
 *
 * Revision 1.1  2008/02/20 12:01:07  wanglei
 * Review:����com.primeton.studio.swt��������Լ���չ��SWT�����Ƶ��ò����
 *
 * Revision 1.5  2007/12/19 01:14:40  wanglei
 * Review:ͳһʹ��EOC�ṩ��Util�࣬����ʹ��Studio�е�Util�ࡣ
 *
 * Revision 1.4  2007/03/05 06:06:32  wanglei
 * �ύ��CVS
 *
 */

public class FileListPropertyEditor extends AbstractPropertyEditor
{
	private String fileName;

	private String fileExtension;

	/**
	 * Ĭ�Ϲ��캯����<BR>
	 * 
	 * The default constructor.<BR>
	 */
	public FileListPropertyEditor()
	{
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createControlCreator()
	 */
	protected IControlCreator createControlCreator()
	{
		return new FileListControlCreator(this);
	}

	/**
	 * ����������FileListControlCreator��<BR>
	 * 
	 * Return the real file list control creator.<BR>
	 * 
	 * @return
	 */
	public FileListControlCreator getFileListControlCreator()
	{
		return (FileListControlCreator) this.getControlCreator();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneProperty(com.primeton.studio.ui.editor.swt.AbstractPropertyEditor)
	 */
	public void cloneProperty(AbstractPropertyEditor r_PropertyEditor)
	{
		super.cloneProperty(r_PropertyEditor);

		((FileListPropertyEditor) r_PropertyEditor).fileExtension = this.fileExtension;
		((FileListPropertyEditor) r_PropertyEditor).fileName = this.fileName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#cloneSelf()
	 */
	public AbstractPropertyEditor cloneSelf()
	{
		return new FileListPropertyEditor();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#isDirty()
	 */
	public boolean isDirty()
	{
		if ((!this.isVisible()) || (!this.isEnable()))
		{
			return false;
		}

		Object t_Value = this.getIntrospector().getValue(this.getElement(), this.getPropertyName());
		FileListComponent t_ClassPathComposite = this.getComponent();
		String[] t_OldValue = ArrayUtil.getStringArrayValues(t_Value);
		String[] t_NewValue = t_ClassPathComposite.getItems();

		return !ArrayUtils.isEquals(t_OldValue, t_NewValue);
	}

	/**
	 * ����ѡ���ļ�ʱ�޶�����չ����<BR>
	 * 
	 * Return the file extension name for selecting the file.<BR>
	 * 
	 * @return Returns the fileExtension.
	 */
	public String getFileExtension()
	{
		return this.fileExtension;
	}

	/**
	 * ����ѡ���ļ�ʱ�޶�����չ����<BR>
	 * 
	 * Set the file extension name for selecting the file.<BR>
	 * 
	 * @param r_FileExtension
	 *            The fileExtension to set.
	 */
	public void setFileExtension(String r_FileExtension)
	{
		this.fileExtension = r_FileExtension;
	}

	/**
	 * ���ط��ص��ļ�����<BR>
	 * 
	 * Return the selected file name.<BR>
	 * 
	 * @return Returns the fileName.
	 */
	public String getFileName()
	{
		return this.fileName;
	}

	/**
	 * ���÷��ص��ļ�����<BR>
	 * 
	 * Set the selected file name.<BR>
	 * 
	 * @param r_FileName
	 *            The fileName to set.
	 */
	public void setFileName(String r_FileName)
	{
		this.fileName = r_FileName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doGetValue()
	 */
	protected Object doGetValue()
	{
		return this.getComponent().getItems();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#doSetValue(java.lang.Object)
	 */
	protected void doSetValue(Object r_Value)
	{
		FileListComponent t_ClassPathComposite = this.getComponent();
		t_ClassPathComposite.setItems(ArrayUtil.getStringArrayValues(r_Value));
	}

	/**
	 * �����ļ��б���<BR>
	 * 
	 * Return the file list component.<BR>
	 * 
	 * @return
	 */
	public FileListComponent getComponent()
	{
		return ((FileListComponent) this.getEditorControl());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.primeton.studio.ui.editor.swt.AbstractPropertyEditor#createLayoutDataBuilder()
	 */
	protected ILayoutDataBuilder createLayoutDataBuilder()
	{
		return GridLayoutDataBuilder.newFullBothLayout();
	}

}
