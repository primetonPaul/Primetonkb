/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-17 ����09:09:12

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.util;

import java.io.Serializable;
import java.util.List;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-17
 *    fix->1.
 *         2.
 * </pre> 
 */
public class RefreshResult implements Serializable {
	
	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = -5241170240950023519L;

	/**
	 * �Ƿ����쳣
	 */
	private boolean hasError = false;
	
	/**
	 * ��һ��ˢ��ʧ�ܵ���
	 */
	private String firstErrorClass;
	
	/**
	 * ˢ��ʧ�ܵ��༯��
	 */
	private List<String> refreshedErrorClasses;
	
	/**
	 * ���ӵ���ȫ·��
	 */
	private List<String> addedClasses;
	
	/**
	 * ���µ���ȫ·��
	 */
	private List<String> updatedClasses;
	
	/**
	 * ɾ������ȫ·��
	 */
	private List<String> removedClasses;

	public boolean isHasError() {
		return hasError;
	}

	public void setHasError(boolean hasError) {
		this.hasError = hasError;
	}

	public String getFirstErrorClass() {
		return firstErrorClass;
	}

	public void setFirstErrorClass(String firstErrorClass) {
		this.firstErrorClass = firstErrorClass;
	}

	public List<String> getRefreshedErrorClasses() {
		return refreshedErrorClasses;
	}

	public void setRefreshedErrorClasses(List<String> refreshedErrorClasses) {
		this.refreshedErrorClasses = refreshedErrorClasses;
	}

	public List<String> getAddedClasses() {
		return addedClasses;
	}

	public void setAddedClasses(List<String> addedClasses) {
		this.addedClasses = addedClasses;
	}

	public List<String> getUpdatedClasses() {
		return updatedClasses;
	}

	public void setUpdatedClasses(List<String> updatedClasses) {
		this.updatedClasses = updatedClasses;
	}

	public List<String> getRemovedClasses() {
		return removedClasses;
	}

	public void setRemovedClasses(List<String> removedClasses) {
		this.removedClasses = removedClasses;
	}
	
}

/*
 * �޸���ʷ
 * $Log: RefreshResult.java,v $
 * Revision 1.2  2013/04/17 08:10:59  chenwq
 * update:ʵ�����л��ӿ�
 *
 * Revision 1.1  2013/04/17 02:29:41  zhaopp
 * Update
 * 
 */