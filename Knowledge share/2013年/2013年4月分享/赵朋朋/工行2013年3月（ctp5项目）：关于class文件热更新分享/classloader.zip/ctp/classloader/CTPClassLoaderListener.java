/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-2 ����02:02:20

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader;

import java.io.File;

import com.icbc.ctp.classloader.resource.DynClassDirScanImpl;
import com.icbc.ctp.classloader.resource.IDynClassDirScan;
import com.icbc.ctp.classloader.service.ICTPClassLoaderService;
import com.icbc.ctp.classloader.util.LoadedOrdinaryClass;
import com.icbc.ctp.framework.runtime.ApplicationContext;
import com.icbc.ctp.framework.runtime.IRuntimeListener;
import com.icbc.ctp.framework.runtime.RuntimeEvent;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-2
 *    fix->1.
 *         2.
 * </pre> 
 */
public class CTPClassLoaderListener implements IRuntimeListener {

	/* (non-Javadoc)
	 * @see com.icbc.ctp.framework.runtime.IRuntimeListener#start(com.icbc.ctp.framework.runtime.RuntimeEvent)
	 */
	@Override
	public void start(RuntimeEvent event) {
		ApplicationContext context = event.getApplicationContext();
		String dir = context.getWarRealPath()+"WEB-INF/dynclasses/";
		File classDir = new File(dir);
		IDynClassDirScan scan = new DynClassDirScanImpl(classDir);
		scan.scan();
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.framework.runtime.IRuntimeListener#stop(com.icbc.ctp.framework.runtime.RuntimeEvent)
	 */
	@Override
	public void stop(RuntimeEvent event) {
		ICTPClassLoaderService.INSTANCE.clear();
		LoadedOrdinaryClass.clear();
		OpIdAndOpStepIdReferenceRelation.getInstance().clear();
	}

}

/*
 * �޸���ʷ
 * $Log: CTPClassLoaderListener.java,v $
 * Revision 1.2  2013/04/27 08:38:41  zhaopp
 * Update:
 *
 * Revision 1.1  2013/04/09 02:53:49  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */