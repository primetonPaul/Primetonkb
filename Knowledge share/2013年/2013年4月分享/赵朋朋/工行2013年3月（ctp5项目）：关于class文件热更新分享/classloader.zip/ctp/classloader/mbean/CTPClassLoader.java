/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����12:02:01

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.mbean;

import com.icbc.ctp.classloader.service.ICTPClassLoaderService;
import com.icbc.ctp.classloader.util.RefreshResult;
import com.icbc.ctp.core.IContext;
import com.icbc.ctp.core.factory.OpAssemblyFactory;
import com.icbc.ctp.core.impl.Context;
import com.icbc.ctp.core.impl.Operation;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-2
 *    fix->1.
 *         2.
 * </pre> 
 */
public class CTPClassLoader implements CTPClassLoaderMBean{

	public void executeOp() {
		Operation op = null;
		try {
			for(int i=0;i<10000;i++){
				op = OpAssemblyFactory.getInstance().createOperation("com.icbc.project.app.helloworld.helloworld"+i);
				IContext context=new Context();
				op.doExecute(context);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.mbean.CTPClassLoaderMBean#refreshDynClassDir(java.net.URL)
	 */
	@Override
	public RefreshResult refreshDynClassDir(boolean ignoreException) {
		return ICTPClassLoaderService.INSTANCE.refreshDynClassDir(ignoreException);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.mbean.CTPClassLoaderMBean#getClassInstancesNum(java.lang.String)
	 */
	@Override
	public int getClassInstancesNum(String classname) {
		return ICTPClassLoaderService.INSTANCE.getClassInstancesNum(classname);
	}
}

/*
 * �޸���ʷ
 * $Log: CTPClassLoader.java,v $
 * Revision 1.6  2013/04/17 02:29:41  zhaopp
 * Update
 *
 * Revision 1.5  2013/04/15 02:21:31  zhaopp
 * Update
 *
 * Revision 1.4  2013/04/09 12:23:53  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */
