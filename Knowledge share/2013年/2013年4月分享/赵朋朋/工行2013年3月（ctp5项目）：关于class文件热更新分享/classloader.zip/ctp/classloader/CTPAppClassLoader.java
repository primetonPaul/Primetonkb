/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����12:02:01

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;

import com.icbc.cte.logging.Log;
import com.icbc.cte.logging.LogFactory;
import com.icbc.ctp.classloader.util.CTPClassLoaderUtil;
import com.icbc.ctp.classloader.util.LoadedOrdinaryClass;
import com.icbc.ctp.utility.StringUtil;


/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-2
 *    fix->1.
 *         2.
 * </pre> 
 */
public class CTPAppClassLoader extends URLClassLoader {
	protected ClassLoader parent = null;
	
    Log log = LogFactory.getLog(CTPAppClassLoader.class);
	
	public CTPAppClassLoader(URL[] classpath, ClassLoader parent){
		super(classpath,parent);
		if(null != parent)
			this.parent = parent;
		else
			this.parent = getParent();
	}
	
	/**
	 * ���¸���findClass����
	 */
	protected Class<?> findClass(String className) throws ClassNotFoundException{
		Class<?> clazz = null;
		if(CTPClassLoaderUtil.isTest()){
			try {
				clazz = findCtpClassPath(className);
			} catch (Exception e) {
				if(null != this.parent && null == clazz){
					try {
						clazz = this.parent.loadClass(className);
					} catch (ClassNotFoundException e1) {
						// ignore
					} 
				}
			}
			return clazz;
		}else{
			// ���ø�����������أ�����ȥclassesĿ¼�¼��أ���ͨjava�ࣩ������еĻ��ͼ��غ󷵻ء�
			// ���û����ȥdynclassesĿ¼�¼���
			try {
				if(null != this.parent){
					String classname = CTPClassLoaderUtil.getClassName(className);
					clazz = this.parent.loadClass(classname);
					if(null != clazz)
						return clazz;
				}
			} catch (Throwable e) {
				// ignore
			}
		}
		return findCtpClassPath(className);
	}

	
	
	private Class<?> findCtpClassPath(String className) throws ClassNotFoundException{
		if(!StringUtil.isNotNullAndBlank(className))
			throw new RuntimeException("class name is null!");
		Class<?> clazz = null;
		try {
			byte[] classData = CTPClassLoaderUtil.loadClassData(className);
			String name = CTPClassLoaderUtil.generateStandardClassName(className);
			clazz = defineClass(name,classData, 0,classData.length);
			// ������CTPAppClassLoader���ص�dynclassesĿ¼�µ���ͨjava��
			LoadedOrdinaryClass.addLoadedClass(name, clazz);
		} catch (IOException e) {
			log.info("CTPAppClassLoader can not find {0}!",new Object[]{className},e);
			throw new ClassNotFoundException(className);
		}
		return clazz;
	}
	
	/**
	 * ��д����loadClass����
	 */
	public Class<?> loadClass(String className) throws ClassNotFoundException {
		return loadClass(className,false);
	}
	
	@Override
	protected Class<?> loadClass(String className,
			boolean resolveClass) throws ClassNotFoundException {
		// dynclassesĿ¼�µ���ͨjava��ͳһ�ɴ�����������أ�����Ѿ�������ֱ�ӷ���
		Class<?> temp = LoadedOrdinaryClass.getLoadedClass(className);
		
		if(null != temp){
			return temp;
		}
		
		if (className.startsWith("java.")){//����ϵͳ��ֱ��װ�ز���¼�󷵻�
			temp = findSystemClass(className);//���ø��෽��
			return temp;
		}
		
		temp = findClass(className);
		
		if(null == temp){
			throw new ClassNotFoundException(className);
		}
		
		if(resolveClass){
			resolveClass(temp);//���ø��෽��
		}
		return temp;
	}
}

/*
 * �޸���ʷ
 * $Log: CTPAppClassLoader.java,v $
 * Revision 1.12  2013/04/28 06:56:17  zhaopp
 * Update���ع�
 *
 * Revision 1.11  2013/04/27 08:38:41  zhaopp
 * Update:
 *
 * Revision 1.10  2013/04/17 02:29:41  zhaopp
 * Update
 *
 * Revision 1.9  2013/04/16 10:57:51  zhaopp
 * Update���׳�ClassNotFoundException
 *
 * Revision 1.8  2013/04/16 10:14:14  zhaopp
 * Update
 *
 * Revision 1.7  2013/04/11 08:50:33  zhaopp
 * Update����ͬOP��Ӧ��ͬOpstep�Ĳ�ͬʵ��
 *
 * Revision 1.6  2013/04/11 03:12:05  zhaopp
 * Update
 *
 * Revision 1.5  2013/04/09 12:23:53  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */