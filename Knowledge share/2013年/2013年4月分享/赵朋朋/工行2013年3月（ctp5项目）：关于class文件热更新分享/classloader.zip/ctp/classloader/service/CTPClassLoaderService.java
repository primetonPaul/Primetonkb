/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����04:57:45

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.icbc.cte.logging.Log;
import com.icbc.cte.logging.LogFactory;
import com.icbc.ctp.classloader.OpIdAndOpStepIdReferenceRelation;
import com.icbc.ctp.classloader.resource.DynClassDirScanImpl;
import com.icbc.ctp.classloader.resource.IClassesCache;
import com.icbc.ctp.classloader.resource.IDynClassDirScan;
import com.icbc.ctp.classloader.util.CTPClassLoaderUtil;
import com.icbc.ctp.classloader.util.RefreshResult;
import com.icbc.ctp.core.IComposite;
import com.icbc.ctp.core.IExecutable;
import com.icbc.ctp.core.factory.AComponentFactory;
import com.icbc.ctp.core.factory.JavaStepFactory;
import com.icbc.ctp.core.factory.OpStepFactory;
import com.icbc.ctp.core.impl.Operation;
import com.icbc.ctp.core.impl.OperationStep;
import com.icbc.ctp.core.model.IDefinition;
import com.icbc.ctp.core.model.JavaStepDefinition;
import com.icbc.ctp.core.model.OpStepDefinition;
import com.icbc.ctp.framework.resource.ext.pool.IModelPool;
import com.icbc.ctp.ioc.xmlconfig.FileSystemXmlApplicationContext;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-1
 *    fix->1.
 *         2.
 * </pre> 
 */
public class CTPClassLoaderService implements ICTPClassLoaderService {
	private static Log log = LogFactory.getLog(CTPClassLoaderService.class);
	private IDynClassDirScan scaner =null;
	
	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.service.ICTPClassLoaderService#getSingleInstance(java.lang.String)
	 */
	@Override
	public Object getSingleInstance(String classname) throws Exception {
		return IClassesCache.INSTANCE.getClassSingleInstance(classname);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.service.ICTPClassLoaderService#getNewInstance(java.lang.String)
	 */
	@Override
	public Object getNewInstance(String classname) throws Exception {
		return IClassesCache.INSTANCE.getClassNewInstance(classname);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.service.ICTPClassLoaderService#getClass(java.lang.String)
	 */
	@Override
	public Class<?> getClass(String classname) throws Exception {
		return IClassesCache.INSTANCE.getClass(classname);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.service.ICTPClassLoaderService#refreshDynClassDir()
	 */
	@Override
	public RefreshResult refreshDynClassDir(boolean ignoreException) {
		File classDir = null;
		// unit test
		boolean isTest = Boolean.valueOf(System.getProperty("CTP_TEST"));
		if(isTest){
			classDir = new File(System.getProperty("CTP_DynClasses"));
		}else{
			classDir = new File(CTPClassLoaderUtil.ctpClassPath);
		}
		
		// scan 
		scaner = new DynClassDirScanImpl(classDir);
		scaner.scan();
		
		List<String> updatedClasses = scaner.getUpdatedClasses();
		List<String> removedClasses = scaner.getRemovedClasses();
		List<String> addedClasses = scaner.getAddedClasses();
		// remove classes
		for (String classURL : removedClasses) {
			IClassesCache.INSTANCE.removeAllInstances(classURL);
			IClassesCache.INSTANCE.removeClassEntryByClassURL(classURL);
		}
		
		RefreshResult result = new RefreshResult();
		List<String> updatedSuccessClasses = new ArrayList<String>();
		List<String> refreshedErrorClasses = new ArrayList<String>();
		// update classes
		for (String classURL : updatedClasses) {
			String classname = null;
			try {
				IClassesCache.INSTANCE.removeAllInstances(classURL);
				IClassesCache.INSTANCE.removeClassEntryByClassURL(classURL);
				classname = CTPClassLoaderUtil.getStandardClassName(classURL);
				unloadReferenceOpStep(classname);
				updatedSuccessClasses.add(classURL);
			} catch (Exception e) {
				log.error("refresh dynamic class error!",e);
				result.setHasError(true);
				if(!ignoreException){
					result.setFirstErrorClass(classURL);
					result.setUpdatedClasses(updatedSuccessClasses);
					result.setAddedClasses(addedClasses);
					refreshedErrorClasses.add(classURL);
					result.setRefreshedErrorClasses(refreshedErrorClasses);
					result.setRemovedClasses(removedClasses);
					return result;
				}else{
					refreshedErrorClasses.add(classURL);
				}
			}
		}
		if(result.isHasError()){
			result.setFirstErrorClass(refreshedErrorClasses.get(0));
		}
		result.setAddedClasses(addedClasses);
		result.setRefreshedErrorClasses(refreshedErrorClasses);
		result.setRemovedClasses(removedClasses);
		result.setUpdatedClasses(updatedSuccessClasses);
		
		return result;
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.service.ICTPClassLoaderService#clear()
	 */
	@Override
	public void clear() {
		IClassesCache.INSTANCE.clear();
	}
	
	/**
	 * ж�ظ������Ӧ��OpStep
	 * @param classname
	 * @throws Exception
	 */
	private static void unloadReferenceOpStep(String classname)	throws Exception {
		List<String> list = OpIdAndOpStepIdReferenceRelation.getInstance().getClassAndOpRelation().get(classname);
		if(null != list){
			for (String str : list) {
				String opId = null;
				String opStepId = null;
				if(str.contains("$")){
					String[] string = str.split("\\$");
					if(string.length == 2){
						opId = string[0];
						opStepId = string[1];
						// ��ȡModelPool�ж�Ӧ��OP
						IComposite operation = IModelPool.INSTANCE.get(IComposite.class, opId);
						if(null != operation){
							Operation op = (Operation)operation;
							// ��OP��ȡ��opStep����
							Map<String, IExecutable> opstepMap = op.getOpstepMap();
							// ж�ص��������Ӧ��opStep
							opstepMap.remove(opStepId);
							
							OperationStep opStep = null;//FlowAssemblyFactory
							AComponentFactory opAssemblyFactory = (AComponentFactory) FileSystemXmlApplicationContext.get("operationFactory");
							Map<String, IDefinition> opStepDefinition = OpIdAndOpStepIdReferenceRelation.getInstance().getOpAndJavaStepDefinition();
//							String key = opId+"$"+opStepId;
							IDefinition def = opStepDefinition.get(str);
							
							if(def instanceof JavaStepDefinition){
								JavaStepFactory javaStepFactory = new JavaStepFactory();
								javaStepFactory.setFacadeFactory(opAssemblyFactory);
								// ���ظ����࣬����javaStep
								opStep = javaStepFactory.createComponent(def);
							}else if(def instanceof OpStepDefinition){
								OpStepFactory opStepFactory = new OpStepFactory();
								opStepFactory.setFacadeFactory(opAssemblyFactory);
								// ���ظ����࣬����opStep
								opStep = opStepFactory.createComponent(def);
							}
							// �滻���µ�OpStep
							opstepMap.put(opStepId, opStep);
						}
					
					}
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.service.ICTPClassLoaderService#removeAllInstances(java.lang.String)
	 */
	@Override
	public void removeAllInstances(String classname) {
		IClassesCache.INSTANCE.removeAllInstances(classname);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.service.ICTPClassLoaderService#getClassInstancesNum(java.lang.String)
	 */
	@Override
	public int getClassInstancesNum(String classname) {
		return IClassesCache.INSTANCE.getClassEntry(classname).instance.size();
	}

}

/*
 * �޸���ʷ
 * $Log: CTPClassLoaderService.java,v $
 * Revision 1.8  2013/04/27 08:38:41  zhaopp
 * Update:
 *
 * Revision 1.7  2013/04/20 03:26:48  zhaopp
 * *** empty log message ***
 *
 * Revision 1.6  2013/04/17 02:29:41  zhaopp
 * Update
 *
 * Revision 1.5  2013/04/15 02:21:31  zhaopp
 * Update
 *
 * Revision 1.4  2013/04/13 06:28:59  zhaopp
 * Update���������ģ��
 *
 * Revision 1.3  2013/04/12 06:25:36  zhaopp
 * Add����ϵ�Ԫ���԰���
 *
 * Revision 1.2  2013/04/11 08:50:33  zhaopp
 * Update����ͬOP��Ӧ��ͬOpstep�Ĳ�ͬʵ��
 *
 * Revision 1.1  2013/04/09 02:53:49  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */