/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����11:26:17

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.resource;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.icbc.ctp.classloader.util.CTPClassLoaderUtil;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-1
 *    fix->1.
 *         2.
 * </pre> 
 */
public class DynClassDirScanImpl implements IDynClassDirScan {
	protected List<String> addedClasses = new ArrayList<String>();
	protected List<String> updatedClasses = new ArrayList<String>();
	protected List<String> removedClasses = new ArrayList<String>();
	protected String classDirName = null;
	protected Map<String,Long> existingClasses;
	private File classDir = null;
	
	public DynClassDirScanImpl(File classDir) {
		this.classDir = classDir;
		this.classDirName = classDir.getPath();
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IDynClassDirScan#scan()
	 */
	@Override
	public void scan() {
		
		existingClasses = IClassesCache.INSTANCE.getAllClassFileLastModified();
		if (classDir.isDirectory() && classDir.exists()) {
			processDir(classDir);
		}else{
			File defaultDynClassDir=new File(CTPClassLoaderUtil.ctpClassPath);
			if (defaultDynClassDir.isDirectory() && defaultDynClassDir.exists()) {
				processDir(defaultDynClassDir);
			}
		}	
		removeResource();
		
	}
	
	/**
	 * ����ɾ������Դ�ļ�
	 */
	private void removeResource(){
		for(String exitingPath:existingClasses.keySet()){
			if (!new File(exitingPath).exists()){
				IClassesCache.INSTANCE.removeClassUpdateTime(exitingPath);
				removedClasses.add(exitingPath);
			}
		}
	}

	private void processDir(File dir) {
		File[] subFiles = dir.listFiles();
		if(subFiles != null){
			for(File subFile:subFiles){
				if (subFile.isDirectory()){
					processDir(subFile);
				}else{
					processResource(subFile);
				}
			}
		}
	}
	
	/**
	 * ��������������������class�ļ��� 
	 * <pre>
	 *
	 * </pre>
	 * @param resource
	 */
	protected void processResource(File clazz){
		addResource(clazz);
		updateResource(clazz);
	}
	
	/**
	 * �������������������ӵ�class�ļ��� 
	 * <pre>
	 *
	 * </pre>
	 * @param clazz
	 */
	private void addResource(File clazz){

		String classURL = clazz.getPath();
		if (existingClasses.get(classURL) == null){
			//����
			IClassesCache.INSTANCE.registerClassUpdateTime(classURL, clazz.lastModified());
			addedClasses.add(classURL);
		}

	}

	/**
	 * �������������������µ�class�ļ��� 
	 * <pre>
	 *
	 * </pre>
	 * @param clazz
	 */
	protected void updateResource(File clazz){

		String classURL = clazz.getPath();
		long modifyTime = clazz.lastModified();
		if (existingClasses.get(classURL) != null && existingClasses.get(classURL).longValue() < modifyTime){
			//�޸�
			IClassesCache.INSTANCE.removeClassUpdateTime(classURL);
			IClassesCache.INSTANCE.registerClassUpdateTime(classURL, modifyTime);
			updatedClasses.add(classURL);
		}

	}
	
	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IDynClassDirScan#getAddedResource()
	 */
	@Override
	public List<String> getAddedClasses() {
		return this.addedClasses;
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IDynClassDirScan#getUpdatedResource()
	 */
	@Override
	public List<String> getUpdatedClasses() {
		return this.updatedClasses;
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IDynClassDirScan#getRemovedResource()
	 */
	@Override
	public List<String> getRemovedClasses() {
		return this.removedClasses;
	}

}

/*
 * �޸���ʷ
 * $Log: DynClassDirScanImpl.java,v $
 * Revision 1.1  2013/04/09 02:53:49  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */