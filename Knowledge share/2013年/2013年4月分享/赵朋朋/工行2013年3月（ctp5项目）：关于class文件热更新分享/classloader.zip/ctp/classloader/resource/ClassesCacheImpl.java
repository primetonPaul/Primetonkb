/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����12:02:01

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.resource;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.icbc.ctp.classloader.OpStepClassLoader;
import com.icbc.ctp.classloader.util.CTPClassLoaderUtil;
import com.icbc.ctp.classloader.util.ClassEntry;
import com.icbc.ctp.utility.StringUtil;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-1
 *    fix->1.
 *         2.
 * </pre> 
 */
public class ClassesCacheImpl implements IClassesCache {
	private Map<String, ClassEntry> classInfoes = new ConcurrentHashMap<String, ClassEntry>();
	private Map<String,Long> existingClasses = new ConcurrentHashMap<String,Long>();
	
	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#getClassEntries()
	 */
	@Override
	public Map<String, ClassEntry> getClassEntries() {
		return classInfoes;
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#addClassEntry(java.lang.String)
	 */
	@Override
	public Object getClassSingleInstance(String classname) throws Exception{
		try {
			isUnitTest();
			String className = CTPClassLoaderUtil.getClassName(classname);
			Class<?> clazz = ClassesCacheImpl.class.getClassLoader().loadClass(className);
			if(null != clazz)
				return clazz.newInstance();
		} catch (Throwable e) {
			String classURL = CTPClassLoaderUtil.getStandardClassPath(classname);
			Class<?> clazz = getClassByCtpClassLoader(classname,classURL);
			Object obj = clazz.newInstance();
			List<Object> instances = classInfoes.get(classURL).instance;
			if(null != instances && instances.size() > 0)
				return instances.get(0);
			else
				cacheInstance(classURL, obj);
			return obj;
		}
		return null;
	}

	private void cacheInstance(String classURL, Object obj) {
		ClassEntry entry = classInfoes.get(classURL);
		if(null == entry.instance){
			entry.instance = new ArrayList<Object>();
		}
		entry.instance.add(obj);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#getClassNewInstance(java.lang.String)
	 */
	@Override
	public Object getClassNewInstance(String classname) throws Exception {
		try {
			isUnitTest();
			String className = CTPClassLoaderUtil.getClassName(classname);
			Class<?> clazz = ClassesCacheImpl.class.getClassLoader().loadClass(className);
			if(null != clazz)
				return clazz.newInstance();
		} catch (Throwable e) {
			String classURL = CTPClassLoaderUtil.getStandardClassPath(classname);
			Class<?> clazz = getClassByCtpClassLoader(classname,classURL);
			Object obj = clazz.newInstance();
			cacheInstance(classURL,obj);
			return obj;
		}
		return null;
	}

	private void isUnitTest() throws Exception {
		boolean isTest = Boolean.valueOf(System.getProperty("CTP_TEST"));
		if(isTest){
			throw new Exception();
		}
	}
	
	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#removeClassEntry(java.lang.String)
	 */
	@Override
	public void removeClassEntryByClassName(String classname) {
		String classURL = CTPClassLoaderUtil.getStandardClassPath(classname);
		removeClassEntryByClassURL(classURL);
	}
	
	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#removeClassEntryByClassURL(java.lang.String)
	 */
	@Override
	public void removeClassEntryByClassURL(String classURL) {
		String standardClassPathByClassURL = CTPClassLoaderUtil.getStandardClassPathByClassURL(classURL);
		if(StringUtil.isNotNullAndBlank(standardClassPathByClassURL))
			classInfoes.remove(standardClassPathByClassURL);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#addClassEntry(java.lang.String)
	 */
	@Override
	public Class<?> getClass(String classname) throws Exception {
		try {
			isUnitTest();
			String className = CTPClassLoaderUtil.getClassName(classname);
			Class<?> clazz = ClassesCacheImpl.class.getClassLoader().loadClass(className);
			return clazz;
		} catch (Throwable e) {
			String classURL = CTPClassLoaderUtil.getStandardClassPath(classname);
			return getClassByCtpClassLoader(classname, classURL);
		}
	}

	private Class<?> getClassByCtpClassLoader(String classname, String classURL)
			throws ClassNotFoundException, MalformedURLException {
		if(StringUtil.isNull(classURL) || StringUtil.isNull(classname))
			return null;
		ClassEntry entry = classInfoes.get(classURL);
		if(null != entry){
			if( null != entry.loadedClass)
				return entry.loadedClass;
			else if(null != entry.classLoader){
				return entry.classLoader.loadClass(classname);
			}
				
		}else{
			OpStepClassLoader ctpClassLoader = new OpStepClassLoader(new URL[]{new File(CTPClassLoaderUtil.ctpClassPath).toURI().toURL()}, ClassesCacheImpl.class.getClassLoader());
			entry = new ClassEntry();
			Class<?> clazz = ctpClassLoader.loadClass(classname);
			entry.classLoader = ctpClassLoader;
			entry.loadedClass = clazz;
			classInfoes.put(classURL, entry);
			return clazz;
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#addClassEntry(java.lang.String, com.icbc.ctp.classloader.util.ClassEntry)
	 */
	@Override
	public void addClassEntry(String classname, ClassEntry entry) {
		String classURL = CTPClassLoaderUtil.getStandardClassPath(classname);
		if(StringUtil.isNull(classURL))
			return;
		if(classInfoes.containsKey(classURL)){
			return;
		}else{
			classInfoes.put(classURL, entry);
		}
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#updateClassEntry(java.lang.String, com.icbc.ctp.classloader.util.ClassEntry)
	 */
	@Override
	public void updateSingleClassEntry(String classname, ClassEntry entry) {
		String classURL = CTPClassLoaderUtil.getStandardClassPath(classname);
		if(StringUtil.isNull(classURL))
			return;
		if(classInfoes.containsKey(classURL)){
			classInfoes.remove(classname);
			classInfoes.put(classname, entry);
		}
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#clearEntries()
	 */
	@Override
	public void clear() {
		classInfoes.clear();
		existingClasses.clear();
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#registerClassUpdateTime(java.lang.String, java.lang.Long)
	 */
	@Override
	public void registerClassUpdateTime(String classURL, Long classUpdateTime) {
		existingClasses.put(classURL, classUpdateTime);
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#getClassUpdateTime(java.lang.String)
	 */
	@Override
	public long getClassUpdateTime(String classURL) {
		if(StringUtil.isNullOrBlank(classURL)){
			return existingClasses.get(classURL);
		}
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#getAllClassFileLastModified()
	 */
	@Override
	public Map<String, Long> getAllClassFileLastModified() {
		return existingClasses;
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#removeClassUpdateTime(java.lang.String)
	 */
	@Override
	public void removeClassUpdateTime(String classURL) {
		String standardClassPathByClassURL = CTPClassLoaderUtil.getStandardClassPathByClassURL(classURL);
		if(StringUtil.isNotNullAndBlank(standardClassPathByClassURL)){
			existingClasses.remove(standardClassPathByClassURL);
		}
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#removeAllInstances(java.lang.String)
	 */
	@Override
	public void removeAllInstances(String classURL) {
		if(classInfoes.containsKey(CTPClassLoaderUtil.getStandardClassPathByClassURL(classURL))){
			List<Object> objects = classInfoes.get(classURL).instance;
			for (Object obj : objects) {
				obj = null;
			}
			classInfoes.get(classURL).instance = null;
		}
	}

	/* (non-Javadoc)
	 * @see com.icbc.ctp.classloader.resource.IClassesCache#getClassEntry(java.lang.String)
	 */
	@Override
	public ClassEntry getClassEntry(String classname) {
		return classInfoes.get(CTPClassLoaderUtil.getStandardClassPath(classname));
	}

}

/*
 * �޸���ʷ
 * $Log: ClassesCacheImpl.java,v $
 * Revision 1.6  2013/04/27 08:38:41  zhaopp
 * Update:
 *
 * Revision 1.5  2013/04/12 06:25:36  zhaopp
 * Add����ϵ�Ԫ���԰���
 *
 * Revision 1.4  2013/04/11 08:50:33  zhaopp
 * Update����ͬOP��Ӧ��ͬOpstep�Ĳ�ͬʵ��
 *
 * Revision 1.3  2013/04/09 12:56:58  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */