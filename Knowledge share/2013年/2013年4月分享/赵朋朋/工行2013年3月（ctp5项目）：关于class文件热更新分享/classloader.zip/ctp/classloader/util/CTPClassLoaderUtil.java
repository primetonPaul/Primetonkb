/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����12:02:01

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;

import com.icbc.cte.logging.Log;
import com.icbc.cte.logging.LogFactory;
import com.icbc.ctp.framework.runtime.ApplicationContext;
import com.icbc.ctp.utility.StringUtil;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-2
 *    fix->1.
 *         2.
 * </pre> 
 */
public class CTPClassLoaderUtil {
	public static String ctpClassPath = ApplicationContext.getInstance().getWarRealPath()+"WEB-INF/dynclasses/";
	private static Log log = LogFactory.getLog(CTPClassLoaderUtil.class);
	
	/**
	 * ����class�ļ�
	 * @param className
	 * @return
	 * @throws IOException
	 */
	public static byte[] loadClassData(String classname) throws IOException{
		InputStream binaryStream = null;
		try {
			File classFile = verifyClassFile(classname);
			if(null != classFile){
				binaryStream = new FileInputStream(classFile);
			}
			return IOUtils.toByteArray(binaryStream);
		} finally {
			binaryStream.close();
		}
	}
	
	public static String getClassName(String classname) {
		if(classname.contains("#")){
			classname = classname.substring(1);
		}
		return classname;
	}
	
	public static File verifyClassFile(String classname) {
		String tempPath = generateStandardClassPath(classname);
		File file = searchFile(ctpClassPath+tempPath);
		return file;
	}
	
	/**
	 * ��������������ȡ��׼���ļ�·����ͳһ��file.getPath()�� 
	 * <pre>
	 *
	 * </pre>
	 * @param classname
	 * @return
	 */
	public static String getStandardClassPath(String classname) {
		isUnitTest();
		classname = getClassName(classname);
		String tempPath = generateStandardClassPath(classname);
		File file = searchFile(ctpClassPath + tempPath);
		if(null != file)
			return file.getPath();
		return null;
	}
	
	/**
	 * ������������ͨ��classURL��ȡ��׼���ļ�·���� 
	 * <pre>
	 *
	 * </pre>
	 * @param classURL
	 * @return
	 */
	public static String getStandardClassPathByClassURL(String classURL) {
		if(StringUtil.isNullOrBlank(classURL))
			return null;
		File file = searchFile(classURL);
		if(null != file)
			return file.getPath();
		else{
			return classURL.replace("/", "\\");
		}
	}
	
	private static void isUnitTest() {
		if(isTest()){
			ctpClassPath = ApplicationContext.getInstance().getWarRealPath();
		}
	}

	public static boolean isTest() {
		boolean isTest = Boolean.valueOf(System.getProperty("CTP_TEST"));
		return isTest;
	}

	/**
	 * ��������������ȡ��׼�������� 
	 * <pre>
	 *
	 * </pre>
	 * @param classURL
	 * @return
	 */
	public static String getStandardClassName(String classURL) {
		String temp = classURL;
		if(isTest()){
			if(temp.contains("bin")){
				temp = temp.substring(temp.indexOf("bin")+4);
			}
			return generateStandardClassName(temp);
		}
		if(temp.contains("dynclasses")){
			int index = temp.indexOf("dynclasses");
			temp = temp.substring(index+11);
		}
		return generateStandardClassName(temp);
	}
	
	private static String generateStandardClassPath(String classname) {
		String tempPath = classname;
		
		if(tempPath.endsWith(".class")){
			tempPath = tempPath.substring(0, tempPath.indexOf(".class"));
		}
		if(tempPath.contains("."))
			tempPath = tempPath.replace('.', '/');
		
		tempPath = tempPath.concat(".class");
		return tempPath;
	}
	
	public static String generateStandardClassName(String classname) {
		String tempPath = classname;
		
		if(tempPath.endsWith(".class")){
			tempPath = tempPath.substring(0, tempPath.indexOf(".class"));
		}
		if(tempPath.contains("/"))
			tempPath = tempPath.replace('/', '.');
		
		if(tempPath.contains("\\"))
			tempPath = tempPath.replace('\\', '.');
		
		if(tempPath.contains(File.separator)){
			String separator = File.separator;
			tempPath = tempPath.replace(separator, ".");
		}
		return tempPath;
	}
	
	/**
	 * �����ļ�
	 * @param ctpClassPath
	 * @return
	 */
	public static File searchFile(String classPath) {
		File file = new File(classPath);
		if(!file.exists())
			return null;
		else
			return file;
//		else{
//			String[] files = new File(classPath).list();
//			if(null != files){
//				for (String filename : files) {
//					String classpath = classPath + File.separator + filename;
//					if(new File(classpath).isDirectory()){
//						return searchFile(classpath);
//					}
//				}
//			}
//		}
	}
	
	/**
	 * ���ز���ѹ�ļ�
	 * @param fileURL
	 */
	public static List<String> downloadAndUncompressFile(URL fileURL) {
		// ���Թ���
		String fileFullName = downloadFile(fileURL, ctpClassPath);
		try {
			return uncompress(fileFullName,ctpClassPath);
		} catch (IOException e) {
			log.error("uncompress jar file error: {0}",new Object[]{fileFullName},e);
		} finally{
			forceDelete(fileFullName);
		}
		return null;
	}

	/**
	 * ȥ����̨�������ȸ��µĹ�����
	 * 
	 * @param theURL
	 * @param filePath
	 * @return
	 * @throws IOException
	 */
	private static String downloadFile(URL theURL, String filePath) {
		URLConnection con = null;
		String fileFullPath = null;
		String fileFullName = null;
		try {
			con = theURL.openConnection();
			String urlPath = con.getURL().getFile();
			fileFullName = urlPath.substring(urlPath.lastIndexOf("/") + 1);
		} catch (IOException e) {
			log.error("The URL can not connect: {0} ", new Object[] { theURL },
					e);
		}
		if (fileFullName != null) {
			byte[] buffer = new byte[4 * 1024];
			int read;
			if(!(filePath.endsWith("/") || !filePath.endsWith(File.separator)))
				fileFullPath = filePath + "/" + fileFullName;
			else
				fileFullPath = filePath + fileFullName;
			File fileFolder = new File(filePath);
			if (!fileFolder.exists()) {
				fileFolder.mkdir();
			}
			InputStream in = null;
			FileOutputStream os = null;
			try {
				in = con.getInputStream();
				os = new FileOutputStream(fileFullPath);
				while ((read = in.read(buffer)) > 0) {
					os.write(buffer, 0, read);
				}
			} catch (IOException e) {
				log.error("Save component package error!", e);
			} finally {
				try {
					os.close();
					in.close();
				} catch (IOException e) {
				}
			}
			return fileFullPath;
		}
		return null;
	}
	
	/**
	 * ��ѹ��jar��
	 * @param fileName
	 * @param outputPath
	 * @throws IOException
	 */
	private static List<String> uncompress(String fileName, String outputPath)
			throws IOException {
		if (!(outputPath.endsWith("/") || outputPath.endsWith(File.separator))) {
			outputPath += File.separator;
		}
		
		List<String> classnames = new ArrayList<String>();
		JarFile jarFile = new JarFile(fileName);

		for (Enumeration e = jarFile.entries(); e.hasMoreElements();) {
			JarEntry jarEntry = (JarEntry) e.nextElement();
			String classname = jarEntry.getName();
			if(!classname.endsWith(".class")){
				continue;
			}
			classnames.add(generateStandardClassName(classname));
			
			String outFileName = outputPath + classname;
			File file = new File(outFileName);
//			System.out.println(f.getAbsolutePath());

			// ������·����Ŀ¼�����и�Ŀ¼
			makeParentDir(outFileName);

			// �����Ŀ¼����ֱ�ӽ�����һ��ѭ��
			if (file.isDirectory()) {
				continue;
			}

			InputStream in = null;
			OutputStream out = null;

			try {
				in = jarFile.getInputStream(jarEntry);
				out = new BufferedOutputStream(new FileOutputStream(file));
				byte[] buffer = new byte[2048];
				int nBytes = 0;
				while ((nBytes = in.read(buffer)) > 0) {
					out.write(buffer, 0, nBytes);
				}
			} finally {
				if(null != out){
					out.flush();
					out.close();
				}
				if(null != in)
					in.close();
			}
		}
		return classnames;
	}
	
	/**
	 * �����ļ�·�������и�Ŀ¼
	 * @param outFileName
	 */
	private static void makeParentDir(String outFileName) {
		// ƥ��ָ���
		Pattern p = Pattern.compile("[/\\" + File.separator + "]");
		Matcher m = p.matcher(outFileName);
		// ÿ�ҵ�һ��ƥ��ķָ������򴴽�һ���÷ָ�����ǰ��Ŀ¼
		while (m.find()) {
			int index = m.start();
			String subDir = outFileName.substring(0, index);
			File subDirFile = new File(subDir);
			if (!subDirFile.exists())
				subDirFile.mkdir();
		}
	}
	
	/**
	 * ǿ��ɾ��ĳ���ļ�
	 * @param fileFullName
	 * @return
	 */
	private static boolean forceDelete(String fileFullName){   
		if(!StringUtil.isNotNullAndBlank(fileFullName))
			return false;
		File file = new File(fileFullName);
	    boolean result = false;   
	    int tryCount = 0;   
	    while(!result && tryCount++ < 5){   
		    System.gc();   
		    result = file.delete();   
	    }   
	    return result;   
	}  
	
}

/*
 * �޸���ʷ
 * $Log: CTPClassLoaderUtil.java,v $
 * Revision 1.10  2013/04/28 06:56:17  zhaopp
 * Update���ع�
 *
 * Revision 1.9  2013/04/27 08:38:41  zhaopp
 * Update:
 *
 * Revision 1.8  2013/04/12 06:25:36  zhaopp
 * Add����ϵ�Ԫ���԰���
 *
 * Revision 1.7  2013/04/11 08:50:33  zhaopp
 * Update����ͬOP��Ӧ��ͬOpstep�Ĳ�ͬʵ��
 *
 * Revision 1.6  2013/04/11 03:13:08  zhaopp
 * Add����Ԫ���Բ���
 *
 * Revision 1.5  2013/04/09 12:23:53  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */
