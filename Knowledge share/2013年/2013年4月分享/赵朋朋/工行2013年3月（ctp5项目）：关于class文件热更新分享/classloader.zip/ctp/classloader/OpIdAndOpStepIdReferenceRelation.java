/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����12:02:01

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.icbc.ctp.core.model.IDefinition;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-2
 *    fix->1.
 *         2.
 * </pre> 
 */
public class OpIdAndOpStepIdReferenceRelation {
	private Map<String/*class name*/,List<String/*OpId$opStepId*/>> classAndOpRelation = new ConcurrentHashMap<String,List<String/*OpId$opStepId*/>>();
	private Map<String/*opId$opStepId*/,IDefinition> opStepDefinition = new ConcurrentHashMap<String, IDefinition>();
	
	private static OpIdAndOpStepIdReferenceRelation reference = null;
	
	private OpIdAndOpStepIdReferenceRelation(){}
	
	public static OpIdAndOpStepIdReferenceRelation getInstance(){
		if(null != reference){
			return reference;
		}
		reference = new OpIdAndOpStepIdReferenceRelation();
		return reference;
	}

	public Map<String/*class name*/,List<String/*OpId$opStepId*/>> getClassAndOpRelation() {
		return classAndOpRelation;
	}
	
	public Map<String/*opId$opStepId*/,IDefinition> getOpAndJavaStepDefinition(){
		return opStepDefinition;
	}
	
	public void clear(){
		classAndOpRelation.clear();
		opStepDefinition.clear();
	}
}

/*
 * �޸���ʷ
 * $Log: OpIdAndOpStepIdReferenceRelation.java,v $
 * Revision 1.7  2013/04/27 08:38:41  zhaopp
 * Update:
 *
 * Revision 1.6  2013/04/13 06:28:59  zhaopp
 * Update���������ģ��
 *
 * Revision 1.5  2013/04/11 08:50:33  zhaopp
 * Update����ͬOP��Ӧ��ͬOpstep�Ĳ�ͬʵ��
 *
 * Revision 1.4  2013/04/09 12:23:53  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */