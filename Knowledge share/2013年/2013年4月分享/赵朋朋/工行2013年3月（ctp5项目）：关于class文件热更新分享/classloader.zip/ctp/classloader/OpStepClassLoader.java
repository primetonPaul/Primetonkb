/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-25 ����10:21:06

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader;

import java.io.IOException;
import java.net.URL;

import com.icbc.ctp.classloader.util.CTPClassLoaderUtil;
import com.icbc.ctp.utility.StringUtil;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-25
 *    fix->1.
 *         2.
 * </pre> 
 */
public class OpStepClassLoader extends CTPAppClassLoader {

	/**
	 * @param classpath
	 * @param parent
	 */
	public OpStepClassLoader(URL[] classpath, ClassLoader parent) {
		super(classpath, parent);
	}
	
	@Override
	public Class<?> loadClass(String className) throws ClassNotFoundException {
		try {
			// �ȵ��ø���CTPAppClassLoader����
			return super.loadClass(className,false);
		} catch (Throwable e) {
			// ignore
		}
		return loadClass(className,false);
	}
	
	@Override
	protected Class<?> loadClass(String className, boolean resolveClass)
			throws ClassNotFoundException {
		// ȥ��Opstep�ı�ʶ
		String classname = CTPClassLoaderUtil.getClassName(className);
		
		Class<?> temp = findOpStepClass(classname);
		
		if(null == temp){
			throw new ClassNotFoundException(className);
		}
		
		if(resolveClass && null != temp){
			resolveClass(temp);//���ø��෽��
		}
		return temp;
	}
	
	protected Class<?> findOpStepClass(String className) throws ClassNotFoundException{
		Class<?> clazz = null;
		
		if(CTPClassLoaderUtil.isTest()){
			try {
				clazz = findOpStepClassPath(className);
			} catch (Exception e) {
				if(null != parent && null == clazz){
					try {
						clazz = parent.loadClass(className);
					} catch (Exception e1) {
						// ignore
					}
				}
			}
			return clazz;
		}else{
			try {
				// ���ø�����������أ�����ȥclassesĿ¼�¼��أ�OpStep��������еĻ��ͼ��غ󷵻ء�
				// ���û����ȥdynclassesĿ¼�¼���
				if(null != this.parent){
					clazz = this.parent.loadClass(className);
					if(null != clazz)
						return clazz;
				}
			} catch (ClassNotFoundException e1) {
				// ignore
			} 
		}
	
		return findOpStepClassPath(className);
	}
	
	private Class<?> findOpStepClassPath(String className) throws ClassNotFoundException{
		if(!StringUtil.isNotNullAndBlank(className))
			throw new RuntimeException("class name is null!");
		Class<?> clazz = null;
		try {
			byte[] classData = CTPClassLoaderUtil.loadClassData(className);
			String name = CTPClassLoaderUtil.generateStandardClassName(className);
			clazz = defineClass(name,classData, 0,classData.length);
		} catch (IOException e) {
			log.info("CTPAppClassLoader can not find {0}!",new Object[]{className},e);
			throw new ClassNotFoundException(className);
		}
		return clazz;
	}
	
	
}

/*
 * �޸���ʷ
 * $Log: OpStepClassLoader.java,v $
 * Revision 1.2  2013/04/28 06:56:17  zhaopp
 * Update���ع�
 *
 * Revision 1.1  2013/04/27 08:38:41  zhaopp
 * Update:
 * 
 */