/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-25 ����04:06:40

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-25
 *    fix->1.
 *         2.
 * </pre> 
 */
public class LoadedOrdinaryClass {
	// ������CTPAppClassLoader���ص���ͨjava��
    private static Map<String, Class<?>> classes = new ConcurrentHashMap<String, Class<?>>();
    
    private LoadedOrdinaryClass(){}
    
    public static void addLoadedClass(String classname, Class<?> clazz){
    	if(!classes.containsKey(classname))
    		classes.put(classname, clazz);
    }
    
    public static Class<?> getLoadedClass(String classname){
    	return classes.get(classname);
    }
    
    public static void clear(){
    	classes.clear();
    }
}

/*
 * �޸���ʷ
 * $Log: LoadedOrdinaryClass.java,v $
 * Revision 1.2  2013/04/28 06:56:17  zhaopp
 * Update���ع�
 *
 * Revision 1.1  2013/04/27 08:38:41  zhaopp
 * Update:
 * 
 */