/*********************************************
 * Copyright (c) 2010 ICBC.
 * All rights reserved.
 * Created on 2013-4-1 ����12:02:01

 * Contributors:
 *     zhaopp - initial implementation
 *********************************************/

package com.icbc.ctp.classloader.util;

import java.util.List;

/**
 * ����������� 
 * <pre>
 *
 * </pre>
 *
 * @since 
 *
 * <pre>
 *	  modify by zhaopp on 2013-4-2
 *    fix->1.
 *         2.
 * </pre> 
 */
public class ClassEntry {
    /**
     * Loaded class.
     */
    public Class<?> loadedClass = null;


    /**
     * class path from where the object was loaded.
     */
    public String path = null;
    
    public ClassLoader classLoader = null;
    
    public List<Object> instance = null;
    
}

/*
 * �޸���ʷ
 * $Log: ClassEntry.java,v $
 * Revision 1.4  2013/04/09 12:23:53  zhaopp
 * Add:CTPӦ��class�ȸ���
 * 
 */
